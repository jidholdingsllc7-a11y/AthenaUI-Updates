# AthenaUI — Athena Link: passphrase-derived identity crypto
# File: backend/athena_link/crypto.py
# Created: 2026-11-02 11:18 CST
# Updated: 2026-11-02 11:18 CST
#
# Implements the "Revised auth model" from
# _dev_notes/athenaui-directory-worker.md: a user's Athena Link identity
# (Ed25519 signing keypair + AES-256-GCM payload key) is deterministically
# re-derived from (passphrase, public salt) via Argon2id on every install
# that knows the passphrase -- the passphrase and derived keys NEVER touch
# the network, only the resulting Ed25519 public key is ever sent to the
# athena-directory Worker.

from __future__ import annotations

import base64
import os
from typing import Tuple

from argon2.low_level import Type, hash_secret_raw
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

# Argon2id parameters -- deliberately expensive (OWASP recommends Argon2id
# as the preferred password-hashing algorithm; these exceed its baseline
# minimum of time_cost=2/memory_cost=19456) since this is the ONLY
# authentication factor protecting a user's Athena Link identity, and the
# public salt means an attacker never needs to contact the Worker at all to
# try candidate passphrases completely offline.
_ARGON2_TIME_COST = 3
_ARGON2_MEMORY_COST_KIB = 65536  # 64 MiB
_ARGON2_PARALLELISM = 4
_DERIVED_KEY_LEN = 64  # 32 bytes Ed25519 seed + 32 bytes AES-256 key


def derive_identity(passphrase: str, salt_b64: str) -> Tuple[bytes, bytes]:
    """
    Deterministically derives (ed25519_seed, aes_key) from (passphrase, salt).
    `salt_b64` is the PUBLIC per-username salt returned by the directory
    Worker's GET /salt/{username} -- safe to be public, it only adds
    uniqueness/defeats rainbow tables; the passphrase itself is the secret.
    Any install that knows the same (username, passphrase) re-derives the
    IDENTICAL keys independently, with zero data exchanged between installs.
    """
    salt = base64.b64decode(salt_b64)
    raw = hash_secret_raw(
        secret=passphrase.encode("utf-8"),
        salt=salt,
        time_cost=_ARGON2_TIME_COST,
        memory_cost=_ARGON2_MEMORY_COST_KIB,
        parallelism=_ARGON2_PARALLELISM,
        hash_len=_DERIVED_KEY_LEN,
        type=Type.ID,
    )
    return raw[:32], raw[32:]


def public_key_b64_from_seed(seed: bytes) -> str:
    private_key = Ed25519PrivateKey.from_private_bytes(seed)
    public_bytes = private_key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)
    return base64.b64encode(public_bytes).decode("ascii")


def sign_message(seed: bytes, message: str) -> str:
    private_key = Ed25519PrivateKey.from_private_bytes(seed)
    signature = private_key.sign(message.encode("utf-8"))
    return base64.b64encode(signature).decode("ascii")


def verify_signature(public_key_b64: str, message: str, signature_b64: str) -> bool:
    """Verifies a signature from another install sharing this same Athena
    Link identity (same public key, derived from the same passphrase) --
    used by the peer-to-peer agent discovery/import routes, which a remote
    install calls directly (not through the directory Worker), so
    verification has to happen locally here instead."""
    try:
        public_key = Ed25519PublicKey.from_public_bytes(base64.b64decode(public_key_b64))
        public_key.verify(base64.b64decode(signature_b64), message.encode("utf-8"))
        return True
    except (InvalidSignature, ValueError):
        return False


def canonical_message(parts) -> str:
    """Must exactly match athena-directory-worker's src/crypto.ts
    `canonicalMessage()` (colon-joined parts) -- any mismatch here makes
    every signed request fail Worker-side signature verification."""
    return ":".join(str(p) for p in parts)


def new_aes_key() -> bytes:
    return os.urandom(32)


def aes_encrypt(aes_key: bytes, plaintext: bytes) -> str:
    """AES-256-GCM encrypt. Returns base64(12-byte nonce || ciphertext+tag)."""
    nonce = os.urandom(12)
    ciphertext = AESGCM(aes_key).encrypt(nonce, plaintext, None)
    return base64.b64encode(nonce + ciphertext).decode("ascii")


def aes_decrypt(aes_key: bytes, blob_b64: str) -> bytes:
    blob = base64.b64decode(blob_b64)
    nonce, ciphertext = blob[:12], blob[12:]
    return AESGCM(aes_key).decrypt(nonce, ciphertext, None)
