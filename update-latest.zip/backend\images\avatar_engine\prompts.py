﻿# AthenaUI v3.5 — Image Generator Prompts
# File: backend/images/avatar_engine/prompts.py
# Created: 2026-04-11 10:07 CDT
# Updated: 2026-08-31

import random

def normalize_age_description(description: str) -> str:
    """
    If the user describes a clearly underage avatar, rewrite to 'young adult (18+)'.
    """
    lowered = description.lower()
    underage_markers = [
        "child", "kid", "teen", "13", "14", "15", "16", "17",
        "middle school", "high school", "minor"
    ]
    if any(m in lowered for m in underage_markers):
        return description + " (as a young adult, clearly 18+)"
    return description

def build_avatar_prompt(character: dict, user_description: str | None = None) -> str:
    base = f"Portrait of {character['profile'].get('full_name') or character['name']}."
    if user_description:
        safe_desc = normalize_age_description(user_description)
        base += " " + safe_desc
    else:
        base += " A modern, realistic portrait, age clearly 18+."
    return base


def build_selfie_prompt(
    character: dict,
    user_description: str | None = None,
    emotion: str | None = None,
    location: str | None = None,
) -> str:
    """
    Builds a prompt for an image-edit call that uses the character's
    existing avatar/gallery photo as the reference image, asking the model
    for a NEW candid selfie of the same person/identity -- optionally
    steered by an emotional cue (from chat), an explicit user request,
    and/or the current scene's location (e.g. a group chat's scene
    description), so the background and clothing can naturally shift to
    fit the moment instead of always reusing the reference photo's setting.

    A pose/angle/setting/lighting combination is randomly picked on EVERY
    call (independent of user_description/emotion/location) so repeated
    selfies of the same character -- e.g. the periodic auto-selfie trigger,
    which often calls this with no emotion/description at all -- never
    reuse the exact same prompt text twice in a row and end up looking
    like near-duplicate photos.
    """
    profile = character.get("profile") if isinstance(character, dict) else None
    name = (profile or {}).get("full_name") or character.get("name", "this person")

    _POSES = [
        "smiling directly at the camera",
        "glancing slightly off to the side with a relaxed smile",
        "mid-laugh, caught off guard",
        "giving a playful peace sign",
        "leaning in close with a warm, casual expression",
        "looking over their shoulder back at the camera",
        "resting their chin on one hand, looking thoughtful",
    ]
    _ANGLES = [
        "shot from slightly above",
        "shot at eye level",
        "shot from slightly below, looking up",
        "close-up framing, just head and shoulders",
        "a bit further back, showing the upper body",
    ]
    _LIGHTING = [
        "soft natural daylight",
        "warm golden-hour light",
        "bright indoor lighting",
        "soft evening lamp light",
        "overcast, even outdoor light",
    ]
    _SETTINGS = [
        "at home",
        "out on a walk",
        "sitting at a coffee shop",
        "in their car",
        "on a balcony or patio",
        "in front of a plain neutral background",
        "out running errands",
    ]

    base = (
        f"A new candid selfie-style photo of {name}, the exact same person shown in the "
        "reference photo -- same face, same identity, same general appearance. Natural "
        "phone-selfie framing, taken from arm's length, "
        f"{random.choice(_POSES)}, {random.choice(_ANGLES)}, with {random.choice(_LIGHTING)}."
    )
    if not location:
        base += f" They're {random.choice(_SETTINGS)}."

    _EMOTION_MOODS = {
        "very_happy": "overjoyed, beaming with happiness",
        "happy": "happy, smiling warmly",
        "excited": "excited, energetic, eyes bright",
        "mellow": "mellow, relaxed, at ease",
        "very_sad": "visibly sad, subdued",
        "sad": "a little down, subdued",
        "startled": "startled, caught off guard, wide-eyed",
        "amused": "laughing, caught mid-laugh",
        "embarrassed": "flustered and embarrassed",
        "angry": "visibly annoyed or upset",
        "scared": "nervous or alarmed",
    }

    if user_description:
        base += " " + normalize_age_description(user_description)
    if emotion:
        mood = _EMOTION_MOODS.get(emotion, emotion.replace("very_", "").replace("_", " "))
        base += (
            f" Their expression and body language clearly show they are feeling {mood} "
            "right now. Feel free to naturally adjust their background/setting (e.g. "
            "living room, restaurant, outdoors) and clothing/outfit to fit this mood and "
            "moment, rather than reusing the exact same background as the reference photo."
        )

    if location:
        base += f" The current scene/setting is: {location}."

    base += " Vary the pose, outfit, and background from any previous selfie -- don't repeat the same shot."
    base += " Photorealistic, age clearly 18+."
    return base


def build_pair_prompt(character_a: dict, character_b: dict, user_description: str) -> str:
    """
    Builds a prompt for an image-edit call that combines two characters'
    reference photos (their own avatar/gallery photo each) into a single
    new image, per the user's requested scene description.
    """
    profile_a = character_a.get("profile") if isinstance(character_a, dict) else None
    profile_b = character_b.get("profile") if isinstance(character_b, dict) else None
    name_a = (profile_a or {}).get("full_name") or character_a.get("name", "the first person")
    name_b = (profile_b or {}).get("full_name") or character_b.get("name", "the second person")

    safe_desc = normalize_age_description(user_description)
    return (
        f"A single combined photo featuring {name_a} (the exact same person as in the first "
        f"reference photo) and {name_b} (the exact same person as in the second reference "
        f"photo) together in one scene, keeping each person's face and identity unchanged "
        f"from their reference photo. {safe_desc} Photorealistic, age clearly 18+."
    )


_ORDINALS = ["first", "second", "third"]


def build_group_prompt(characters: list[dict], user_description: str) -> str:
    """
    Builds a prompt for an image-edit call that combines 2-3 characters'
    reference photos into a single new image, per the user's requested
    scene description. Generalizes build_pair_prompt to a variable-length
    group (e.g. multiple agents in the same group chat).
    """
    names = []
    for character in characters:
        profile = character.get("profile") if isinstance(character, dict) else None
        names.append((profile or {}).get("full_name") or character.get("name", "a person"))

    mentions = ", ".join(
        f"{name} (the exact same person as in the {_ORDINALS[i]} reference photo)"
        for i, name in enumerate(names)
    )

    safe_desc = normalize_age_description(user_description)
    return (
        f"A single combined photo featuring {mentions}, all together in one scene, keeping "
        f"each person's face and identity unchanged from their own reference photo. "
        f"{safe_desc} Photorealistic, age clearly 18+."
    )


def build_family_resemblance_prompt(
    source_character: dict,
    new_name: str,
    relation: str,
    user_description: str | None = None,
) -> str:
    """
    Builds a prompt for an image-edit call that uses an EXISTING character's
    reference photo to generate a portrait of a DIFFERENT, new character who
    is a close blood relative of theirs (sibling/parent/child) -- a distinct
    person who shares a visible family resemblance, not the same identity.
    """
    profile = source_character.get("profile") if isinstance(source_character, dict) else None
    source_name = (profile or {}).get("full_name") or source_character.get("name", "the reference person")

    base = (
        f"A portrait of {new_name}, the {relation} of {source_name} (the person shown in the "
        "reference photo). This is a DIFFERENT person, not the same one from the reference photo "
        "-- but with a clear, believable family resemblance: similar bone structure, similar "
        "coloring, and a family likeness in the face, while still having their own distinct "
        "features and identity."
    )

    if user_description:
        base += " " + normalize_age_description(user_description)

    base += " Photorealistic, age clearly 18+."
    return base
