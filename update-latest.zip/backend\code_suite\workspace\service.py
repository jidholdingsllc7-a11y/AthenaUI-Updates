﻿# AthenaUI v3.5 — Code Suite Workspace Service
# File: backend/code_suite/workspace/service.py
# Created: 2026-04-07 13:22 CDT
# Updated: 2026-07-27 19:49 CDT

import os
from pathlib import Path
from typing import List, Dict, Optional

from workspace.service import WorkspaceService as _CanonicalWorkspaceService


class WorkspaceError(Exception):
    pass


class WorkspaceService:
    """
    Manages per-user workspaces: root path, file IO, archive dir.

    Root resolution is delegated to the single canonical
    `workspace.service.WorkspaceService` (same module used by onboarding to
    create the workspace and by every other tool/route that touches it) so
    there is exactly one place that reads `workspace_path` from the vault
    and exactly one fallback/auto-create path -- previously this class
    re-implemented that lookup independently and raised `WorkspaceError`
    instead of falling back to a default, which let callers (e.g. build_map)
    silently drift onto a different, ad hoc directory.
    """

    def __init__(self, username: str):
        self.username = username
        self.root = _CanonicalWorkspaceService(username).root
        self.archive_dir = self.root / "archive"
        self.archive_dir.mkdir(parents=True, exist_ok=True)

    # ---------------- File helpers ----------------

    def _resolve(self, rel_path: str) -> Path:
        p = (self.root / rel_path).resolve()
        # NOTE: a plain string startswith() check here is a path-traversal
        # bypass -- e.g. root "C:\Foo" would incorrectly accept a sibling
        # directory like "C:\Foo-evil\secret.txt" since it string-prefix-
        # matches without being a real subpath. is_relative_to() (or the
        # parents-based fallback below) does a real path-segment check.
        try:
            is_inside = p == self.root or p.is_relative_to(self.root)
        except AttributeError:
            # Python < 3.9 fallback
            is_inside = p == self.root or self.root in p.parents
        if not is_inside:
            raise WorkspaceError("Path escapes workspace root.")
        return p

    def read_file(self, rel_path: str) -> str:
        p = self._resolve(rel_path)
        if not p.is_file():
            raise WorkspaceError(f"File not found: {rel_path}")
        return p.read_text(encoding="utf-8")

    def write_file(self, rel_path: str, content: str):
        p = self._resolve(rel_path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")

    def create_file(self, rel_path: str, content: str = ""):
        self.write_file(rel_path, content)

    def list_dir(self, rel_path: str = ".") -> List[Dict]:
        p = self._resolve(rel_path)
        if not p.is_dir():
            raise WorkspaceError(f"Not a directory: {rel_path}")
        entries = []
        for name in os.listdir(p):
            full = p / name
            entries.append({
                "name": name,
                "rel_path": str(full.relative_to(self.root)),
                "is_dir": full.is_dir(),
                "size": full.stat().st_size if full.is_file() else None,
            })
        return entries

    # ---------------- Archive helpers ----------------

    def archive_file(self, rel_path: str) -> Optional[Path]:
        src = self._resolve(rel_path)
        if not src.is_file():
            return None
        rel = src.relative_to(self.root)
        archive_target = self.archive_dir / rel
        archive_target.parent.mkdir(parents=True, exist_ok=True)
        # simple versioning: append timestamp
        from time import strftime, localtime
        ts = strftime("%Y%m%d_%H%M%S", localtime())
        versioned = archive_target.with_suffix(archive_target.suffix + f".{ts}.bak")
        versioned.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
        return versioned

    def archive_content(self, rel_path: str, content: str, tag: str = "") -> Path:
        """Archives the given content under a dated filename -- for cases
        where the snapshot to preserve isn't simply "whatever is on disk
        right now" (e.g. a pre-edit original after the live file has
        already been overwritten by write_file_tracked, or a rejected edit
        attempt moments before it's reverted). `archive_file()` above
        covers the simpler case of archiving the file's current content."""
        archive_target = self.archive_dir / rel_path
        archive_target.parent.mkdir(parents=True, exist_ok=True)
        from time import strftime, localtime
        ts = strftime("%Y%m%d_%H%M%S", localtime())
        suffix = f".{ts}.{tag}.bak" if tag else f".{ts}.bak"
        versioned = archive_target.with_suffix(archive_target.suffix + suffix)
        versioned.write_text(content, encoding="utf-8")
        return versioned

    def delete_file(self, rel_path: str):
        p = self._resolve(rel_path)
        if p.is_file():
            p.unlink()
        elif p.is_dir():
            # optional: restrict recursive delete
            raise WorkspaceError("Directory deletion not allowed via this endpoint.")
