# AthenaUI v3.5 — Full System Backup / Restore Service
# File: backend/backup/service.py
#
# Builds and restores a single portable, ENCRYPTED ".athenabak" archive
# (see backup/crypto.py for the passphrase-based AES-256-GCM envelope,
# mirroring the Maximos Memory Server's own ".mxbak" scheme) containing
# whatever the user checked off in a granular selection: settings, personal
# data, the workspace directory, individual user-created characters (full
# profile + gallery + chat history), and/or specific system agents' CHAT
# HISTORY ONLY (their profile is never included -- it's reseeded fresh from
# characters/system/system_agents/*.base.json on restore).
#
# Inner archive layout (before the whole thing gets passphrase-encrypted):
#   - manifest.json      -- format marker, username, login credential hash
#                            (so a restored account can log back in),
#                            the selection that was actually backed up,
#                            timestamps, and a dummy placeholder subscription
#                            block (no real billing/subscription model
#                            exists yet).
#   - vault_export.json  -- a PLAINTEXT export of the DPAPI-encrypted vault
#                            (preferences, secrets/api keys, activity stats,
#                            parental controls, hardware state, the "user"
#                            profile dict which also holds calendar events,
#                            competitor snapshots, UI theme, etc, and every
#                            SELECTED non-system character's profile/
#                            gallery-paths/pets). Plaintext is safe here
#                            because the archive as a whole is encrypted at
#                            rest (see backup/crypto.py) -- produced/
#                            consumed via VaultController, never by copying
#                            the raw vault.db file, because its master key
#                            is Windows-DPAPI-protected and is NOT portable
#                            across machines/profiles.
#   - data/...            -- a raw copy of the SELECTED per-user files under
#                            data/users/{username}/ (spreadsheets sqlite,
#                            personal contacts sqlite, CRM sqlite, profile
#                            avatar/gallery, chat backgrounds, generated
#                            videos, job templates, themes, etc under
#                            "settings"/"personal_data"; individual
#                            characters' galleries under their own
#                            selection), EXCLUDING the vault/ folder
#                            (handled above) and EXCLUDING any system
#                            character's folder under characters/ (system
#                            characters are reseeded fresh on restore, not
#                            backed up).
#   - workspace/...       -- a raw copy of the user's Code Suite workspace
#                            directory (WorkspaceService), only when
#                            "workspace" is selected.
#   - mms/{name}.mxbak    -- one already-encrypted Maximos Memory Server
#                            backup blob per selected character (user OR
#                            system), fetched live from the Maximos Memory
#                            Server's own HTTP API
#                            (chat/memory/maximos_client.py's
#                            backup_agent/restore_agent, calling its
#                            /backup and /restore routes) using the SAME
#                            passphrase as the outer AthenaUI envelope --
#                            this is what lets a full system backup/restore
#                            be initiated entirely from within AthenaUI
#                            without ever needing to open the separate
#                            Maximos Memory Server app.

from __future__ import annotations

import json
import logging
import re
import zipfile
from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path
from typing import Any, Dict, List, Optional

from core.runtime.runtime import get_runtime
from vault.controller import VaultController, SYSTEM_CHARACTERS
from vault.models import VaultData, VaultCharacter
from vault.service import VaultService
from workspace.service import WorkspaceService
from chat.memory.maximos_client import get_client as get_maximos_client
from backup.crypto import BackupCryptoError, encrypt_blob, decrypt_blob

logger = logging.getLogger(__name__)

BACKUP_FORMAT = "athenaui_full_backup_v2"
APP_VERSION = "3.5"

MANIFEST_NAME = "manifest.json"
VAULT_EXPORT_NAME = "vault_export.json"
DATA_PREFIX = "data/"
WORKSPACE_PREFIX = "workspace/"
MMS_PREFIX = "mms/"

# Top-level data/users/{u}/ dirs that belong to "personal_data" rather than
# the general "settings" catch-all.
PERSONAL_DATA_DIRS = {"personal", "crm", "spreadsheets"}

# Defensive caps against zip-bomb style abuse on restore.
MAX_TOTAL_UNCOMPRESSED_BYTES = 500 * 1024 * 1024  # 500 MB
MAX_ENTRY_COUNT = 20000

_USERNAME_RE = re.compile(r"^[A-Za-z0-9_\-]{1,64}$")


class BackupError(Exception):
    pass


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _user_root(username: str) -> Path:
    runtime = get_runtime()
    return runtime.env.DATA_DIR / "users" / username


def _users_json_path() -> Path:
    runtime = get_runtime()
    return runtime.env.DATA_DIR / "users" / "users.json"


def _load_users_json() -> Dict[str, Any]:
    path = _users_json_path()
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def _save_users_json(data: Dict[str, Any]) -> None:
    path = _users_json_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


# ---------------------------------------------------------
# Selection
# ---------------------------------------------------------

def _normalize_selection(username: str, selection: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Fills in a full/complete selection when the caller didn't specify one
    (legacy callers / scheduled backups default to a full system backup),
    and expands `full_system: true` into every category + every character
    the account actually has."""
    vault = VaultController.get_vault(username)
    all_user_characters = [name for name in vault.characters.keys() if name not in SYSTEM_CHARACTERS]

    sel = dict(selection or {})
    full_system = bool(sel.get("full_system", not selection))

    if full_system:
        return {
            "full_system": True,
            "settings": True,
            "personal_data": True,
            "workspace": True,
            "characters": all_user_characters,
            "system_chat": sorted(SYSTEM_CHARACTERS),
        }

    return {
        "full_system": False,
        "settings": bool(sel.get("settings")),
        "personal_data": bool(sel.get("personal_data")),
        "workspace": bool(sel.get("workspace")),
        "characters": [c for c in (sel.get("characters") or []) if c in vault.characters and c not in SYSTEM_CHARACTERS],
        "system_chat": [c for c in (sel.get("system_chat") or []) if c in SYSTEM_CHARACTERS],
    }


def list_backup_items(username: str) -> Dict[str, Any]:
    """Returns everything the frontend needs to render the backup checklist:
    the fixed categories, every user-created character, and every system
    agent (chat-history-only)."""
    vault = VaultController.get_vault(username)
    user_characters = sorted(
        [name for name in vault.characters.keys() if name not in SYSTEM_CHARACTERS]
    )
    return {
        "categories": [
            {"id": "settings", "label": "Settings & Preferences (API keys, theme, activity stats, parental controls, profile)"},
            {"id": "personal_data", "label": "Personal Data (Contacts, CRM, Spreadsheets, Calendar)"},
            {"id": "workspace", "label": "Workspace Directory (Code Suite files)"},
        ],
        "user_characters": [{"name": name, "system": False} for name in user_characters],
        "system_characters": [{"name": name, "system": True} for name in sorted(SYSTEM_CHARACTERS)],
    }


# ---------------------------------------------------------
# Export
# ---------------------------------------------------------

def _filtered_vault_export(username: str, selection: Dict[str, Any]) -> Dict[str, Any]:
    vault: VaultData = VaultController.get_vault(username)
    data = vault.dict()

    if not selection.get("settings"):
        for field in ("secrets", "preferences", "activity_stats", "parental_controls", "hardware", "user"):
            data.pop(field, None)

    selected_characters = set(selection.get("characters") or [])
    data["characters"] = {
        name: char for name, char in data["characters"].items()
        if name not in SYSTEM_CHARACTERS and name in selected_characters
    }
    return data


def _write_data_files(zf: zipfile.ZipFile, username: str, selection: Dict[str, Any]) -> None:
    root = _user_root(username)
    if not root.exists():
        return
    selected_characters = set(selection.get("characters") or [])
    for file in root.rglob("*"):
        if not file.is_file():
            continue
        rel = file.relative_to(root)
        parts = rel.parts
        if not parts:
            continue
        # Skip the raw (DPAPI-encrypted, non-portable) vault DB -- its
        # contents are already covered by vault_export.json.
        if parts[0] == "vault":
            continue
        if parts[0] == "characters" and len(parts) > 1:
            char_name = parts[1]
            if char_name in SYSTEM_CHARACTERS or char_name not in selected_characters:
                continue
        elif parts[0] in PERSONAL_DATA_DIRS:
            if not selection.get("personal_data"):
                continue
        elif parts[0] != "characters":
            if not selection.get("settings"):
                continue
        zf.write(file, DATA_PREFIX + "/".join(parts))


def _write_workspace_files(zf: zipfile.ZipFile, username: str) -> None:
    try:
        ws_root = WorkspaceService(username).root
    except Exception:
        logger.warning("Backup: could not resolve workspace root for %s", username, exc_info=True)
        return
    if not ws_root.exists():
        return
    for file in ws_root.rglob("*"):
        if not file.is_file():
            continue
        rel = file.relative_to(ws_root)
        zf.write(file, WORKSPACE_PREFIX + "/".join(rel.parts))


def _write_mms_chat_history(
    zf: zipfile.ZipFile, username: str, character_names: List[str], passphrase: str
) -> Dict[str, List[str]]:
    """Fetches an encrypted Maximos Memory Server backup blob for each
    listed character and stores it in the archive. Never hard-fails the
    whole backup if the Maximos Memory Server is unreachable for one
    character -- just reports it so the user can see what was skipped."""
    client = get_maximos_client()
    included: List[str] = []
    skipped: List[str] = []
    for name in character_names:
        blob = client.backup_agent(username, name, passphrase)
        if blob is None:
            skipped.append(name)
            continue
        zf.writestr(f"{MMS_PREFIX}{name}.mxbak", blob)
        included.append(name)
    return {"included": included, "skipped": skipped}


def create_full_backup(
    username: str, *, passphrase: str, selection: Optional[Dict[str, Any]] = None
) -> bytes:
    """
    Builds the encrypted full backup archive for `username` per `selection`
    (see `_normalize_selection`) and returns its raw encrypted bytes. Raises
    BackupError if the account doesn't exist or the passphrase is empty.
    """
    if not passphrase:
        raise BackupError("A passphrase is required to encrypt the backup.")

    users = _load_users_json()
    user_entry = users.get(username)
    if not isinstance(user_entry, dict):
        raise BackupError(f"No such user: {username}")

    sel = _normalize_selection(username, selection)

    manifest = {
        "format": BACKUP_FORMAT,
        "app_version": APP_VERSION,
        "username": username,
        "created_at": _now_iso(),
        "password_salt": user_entry.get("password_salt"),
        "password_hash": user_entry.get("password_hash"),
        "onboarding_complete": bool(user_entry.get("onboarding_complete")),
        "selection": sel,
        # No real billing/subscription system exists yet -- this is a
        # placeholder so the backup format doesn't need to change shape
        # once one is built.
        "subscription": {
            "plan": "free",
            "key": None,
            "status": "not_implemented",
        },
    }

    vault_export = _filtered_vault_export(username, sel)

    mms_report = {"included": [], "skipped": []}
    chat_history_targets = list(sel.get("characters") or []) + list(sel.get("system_chat") or [])

    buffer = BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(VAULT_EXPORT_NAME, json.dumps(vault_export, indent=2, default=str))
        _write_data_files(z, username, sel)
        if sel.get("workspace"):
            _write_workspace_files(z, username)
        if chat_history_targets:
            mms_report = _write_mms_chat_history(z, username, chat_history_targets, passphrase)
        manifest["mms_chat_history"] = mms_report
        z.writestr(MANIFEST_NAME, json.dumps(manifest, indent=2))

    return encrypt_blob(passphrase, buffer.getvalue())



# ---------------------------------------------------------
# Restore
# ---------------------------------------------------------

def _validate_zip_members(zf: zipfile.ZipFile) -> None:
    if len(zf.infolist()) > MAX_ENTRY_COUNT:
        raise BackupError("Backup file has too many entries.")

    total = 0
    for info in zf.infolist():
        total += info.file_size
        if total > MAX_TOTAL_UNCOMPRESSED_BYTES:
            raise BackupError("Backup file is too large.")

        name = info.filename
        if name.startswith("/") or name.startswith("\\"):
            raise BackupError("Backup file contains an unsafe path.")
        if ":" in name:  # e.g. "C:\\..." drive letters
            raise BackupError("Backup file contains an unsafe path.")
        # Normalize and check for parent-directory traversal.
        norm = Path(name)
        if ".." in norm.parts:
            raise BackupError("Backup file contains an unsafe path.")


def _read_manifest(zf: zipfile.ZipFile) -> Dict[str, Any]:
    try:
        raw = zf.read(MANIFEST_NAME)
    except KeyError:
        raise BackupError("This does not look like an AthenaUI backup file (missing manifest).")
    try:
        manifest = json.loads(raw)
    except Exception:
        raise BackupError("This backup file's manifest is corrupted.")
    if manifest.get("format") != BACKUP_FORMAT:
        raise BackupError("This file is not a recognized AthenaUI backup.")
    return manifest


def _read_vault_export(zf: zipfile.ZipFile) -> Dict[str, Any]:
    try:
        raw = zf.read(VAULT_EXPORT_NAME)
    except KeyError:
        return {}
    try:
        return json.loads(raw)
    except Exception:
        raise BackupError("This backup file's vault data is corrupted.")


def _extract_data_files(zf: zipfile.ZipFile, username: str) -> int:
    root = _user_root(username)
    root.mkdir(parents=True, exist_ok=True)
    count = 0
    for info in zf.infolist():
        if info.is_dir():
            continue
        if not info.filename.startswith(DATA_PREFIX):
            continue
        rel = info.filename[len(DATA_PREFIX):]
        if not rel:
            continue
        # Defensive: never let a restored file land inside the vault/ dir --
        # backups never contain one, but don't trust the archive blindly.
        if rel.split("/", 1)[0] == "vault":
            continue
        dest = (root / rel).resolve()
        if root.resolve() not in dest.parents and dest != root.resolve():
            raise BackupError("Backup file contains an unsafe path.")
        dest.parent.mkdir(parents=True, exist_ok=True)
        with zf.open(info) as src, open(dest, "wb") as out:
            out.write(src.read())
        count += 1
    return count


def _extract_workspace_files(zf: zipfile.ZipFile, username: str) -> int:
    try:
        ws_root = WorkspaceService(username).root
    except Exception:
        logger.warning("Restore: could not resolve workspace root for %s", username, exc_info=True)
        return 0
    ws_root.mkdir(parents=True, exist_ok=True)
    count = 0
    for info in zf.infolist():
        if info.is_dir():
            continue
        if not info.filename.startswith(WORKSPACE_PREFIX):
            continue
        rel = info.filename[len(WORKSPACE_PREFIX):]
        if not rel:
            continue
        dest = (ws_root / rel).resolve()
        if ws_root.resolve() not in dest.parents and dest != ws_root.resolve():
            raise BackupError("Backup file contains an unsafe path.")
        dest.parent.mkdir(parents=True, exist_ok=True)
        with zf.open(info) as src, open(dest, "wb") as out:
            out.write(src.read())
        count += 1
    return count


def _restore_mms_chat_history(zf: zipfile.ZipFile, username: str, passphrase: str) -> Dict[str, List[str]]:
    """Restores every embedded `mms/{name}.mxbak` blob back into the
    Maximos Memory Server for this user, via its own /restore HTTP route
    (chat/memory/maximos_client.py's restore_agent) -- never hard-fails the
    whole restore if one character's memory can't be restored (wrong-era
    passphrase mismatch, server unreachable, privacy mode, etc.)."""
    client = get_maximos_client()
    restored: List[str] = []
    failed: List[str] = []
    for info in zf.infolist():
        if info.is_dir() or not info.filename.startswith(MMS_PREFIX) or not info.filename.endswith(".mxbak"):
            continue
        name = info.filename[len(MMS_PREFIX):-len(".mxbak")]
        if not name:
            continue
        blob = zf.read(info)
        result = client.restore_agent(username, name, blob, passphrase)
        if result is None:
            failed.append(name)
        else:
            restored.append(name)
    return {"restored": restored, "failed": failed}


def _apply_vault_export(username: str, vault_export: Dict[str, Any], *, seed_system_first: bool) -> int:
    if seed_system_first:
        VaultService.seed_system_agents(username)

    vault: VaultData = VaultController.get_vault(username)

    if vault_export:
        prefs = vault_export.get("preferences") or {}
        for field in ("chat_provider", "chat_model", "image_provider", "image_model", "code_provider", "code_model"):
            if field in prefs:
                setattr(vault.preferences, field, prefs[field])

        secrets = vault_export.get("secrets") or {}
        if "api_keys" in secrets:
            vault.secrets.api_keys = secrets["api_keys"] or {}
        if "system_keys" in secrets:
            vault.secrets.system_keys = secrets["system_keys"] or {}

        api_keys = vault_export.get("api_keys") or {}
        for field in ("chat", "image", "code", "apps"):
            if field in api_keys:
                setattr(vault.api_keys, field, api_keys[field] or {})
        for field in ("chat_default_provider", "image_default_provider", "code_default_provider"):
            if field in api_keys:
                setattr(vault.api_keys, field, api_keys[field])

        if "activity_stats" in vault_export:
            stats = vault_export["activity_stats"] or {}
            for period in ("daily", "weekly", "monthly", "quarterly", "yearly"):
                if period in stats:
                    setattr(vault.activity_stats, period, stats[period] or {})

        if "parental_controls" in vault_export:
            pc = vault_export["parental_controls"] or {}
            vault.parental_controls.enabled = bool(pc.get("enabled", vault.parental_controls.enabled))
            vault.parental_controls.rules = pc.get("rules", vault.parental_controls.rules) or {}

        if "hardware" in vault_export:
            hw = vault_export["hardware"] or {}
            vault.hardware.camera_device_id = hw.get("camera_device_id")
            vault.hardware.camera_enabled = bool(hw.get("camera_enabled", False))

        if "user" in vault_export and isinstance(vault_export["user"], dict):
            vault.user = vault_export["user"]

    restored_characters = 0
    for name, char_data in (vault_export.get("characters") or {}).items():
        if name in SYSTEM_CHARACTERS:
            continue  # defensive -- exports never include these, but don't trust blindly
        try:
            vault.characters[name] = VaultCharacter(**char_data)
            restored_characters += 1
        except Exception:
            continue

    VaultController.save_vault(username, vault)
    return restored_characters


def restore_full_backup(
    file_bytes: bytes,
    *,
    passphrase: str,
    expected_username: Optional[str] = None,
    allow_create: bool = False,
) -> Dict[str, Any]:
    """
    Restores an encrypted AthenaUI backup archive.

    - expected_username=None, allow_create=True: the public, pre-login
      "reinstalled on a new PC" flow. A brand-new local account is created
      from the manifest's own embedded credential hash. Refuses if an
      account with that username already exists locally.
    - expected_username=<current user>, allow_create=False: the
      authenticated "restore into my own account" flow from Settings.
      Refuses if the archive's username doesn't match the caller's.
    """
    if not passphrase:
        raise BackupError("A passphrase is required to decrypt this backup.")

    try:
        zip_bytes = decrypt_blob(passphrase, file_bytes)
    except BackupCryptoError as e:
        raise BackupError(str(e))

    try:
        zf = zipfile.ZipFile(BytesIO(zip_bytes))
    except zipfile.BadZipFile:
        raise BackupError("This is not a valid backup file.")

    with zf:
        _validate_zip_members(zf)
        manifest = _read_manifest(zf)

        username = str(manifest.get("username") or "")
        if not _USERNAME_RE.match(username):
            raise BackupError("Backup file has an invalid username.")

        if expected_username is not None:
            if username != expected_username:
                raise BackupError(
                    "This backup belongs to a different account. Log in as that "
                    "account to restore it, or use the login-page restore for a new account."
                )
            seed_system_first = False
        else:
            if not allow_create:
                raise BackupError("Account creation from backup is not permitted here.")
            users = _load_users_json()
            if username in users:
                raise BackupError(
                    f"An account named '{username}' already exists on this machine. "
                    "Log in and restore from Settings instead."
                )
            users[username] = {
                "password_salt": manifest.get("password_salt"),
                "password_hash": manifest.get("password_hash"),
                "onboarding_complete": bool(manifest.get("onboarding_complete", True)),
            }
            _save_users_json(users)
            seed_system_first = True

        vault_export = _read_vault_export(zf)

        try:
            files_restored = _extract_data_files(zf, username)
            workspace_files_restored = _extract_workspace_files(zf, username)
            characters_restored = _apply_vault_export(username, vault_export, seed_system_first=seed_system_first)
            mms_report = _restore_mms_chat_history(zf, username, passphrase)
        except BackupError:
            raise
        except Exception as e:
            raise BackupError(f"Restore failed: {e}")

    return {
        "username": username,
        "files_restored": files_restored,
        "workspace_files_restored": workspace_files_restored,
        "characters_restored": characters_restored,
        "mms_chat_history_restored": mms_report["restored"],
        "mms_chat_history_failed": mms_report["failed"],
    }

