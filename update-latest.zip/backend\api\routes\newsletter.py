# AthenaUI v3.5 — Public Newsletter Opt-in/Opt-out Routes
# File: backend/api/routes/newsletter.py
#
# Unlike every other route in this file's neighborhood, these two endpoints
# are DELIBERATELY public/unauthenticated -- a customer visiting the opt-in
# webpage has no AthenaUI account and never will, so they can't carry a
# session/auth token. `username` in the URL identifies whose newsletter list
# to join/leave (the business owner running this AthenaUI instance), NOT the
# customer. This mirrors how a real-world "Subscribe"/"Unsubscribe" link
# works: no login required, just an email address.
#
# Security notes:
#   - No secrets or private data are exposed here -- subscribe/unsubscribe
#     only ever accept an email (and optional name), and only ever return a
#     status, never the subscriber list itself (that's authenticated, see
#     the newsletter_list_subscribers tool instead).
#   - `username` is validated by simply attempting the operation -- an
#     unknown username just creates/uses that user's own isolated
#     subscribers.sqlite (harmless; there is nothing else at that path).

from __future__ import annotations

from typing import Any, Dict

from fastapi import APIRouter, Body, HTTPException

from newsletter.service import NewsletterError, subscribe, unsubscribe

router = APIRouter(prefix="/newsletter", tags=["newsletter"])


@router.post("/{username}/subscribe")
async def public_subscribe(username: str, payload: Dict[str, Any] = Body(...)):
    email = str(payload.get("email", "")).strip()
    if not email:
        raise HTTPException(status_code=400, detail="email is required")
    try:
        subscribe(username, email=email, name=payload.get("name"), source="public_page")
    except NewsletterError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"ok": True, "message": "You're subscribed. Thanks for signing up!"}


@router.post("/{username}/unsubscribe")
async def public_unsubscribe(username: str, payload: Dict[str, Any] = Body(...)):
    email = str(payload.get("email", "")).strip()
    if not email:
        raise HTTPException(status_code=400, detail="email is required")
    try:
        unsubscribe(username, email=email)
    except NewsletterError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"ok": True, "message": "You've been unsubscribed."}
