# AthenaUI v3.5 — Admin API ("Manage Users")
# File: backend/api/routes/admin.py
# Purpose: System-wide admin-password-gated user management, reachable
#          from the login/splash screen WITHOUT logging into any user
#          account. Lets a developer/operator view all registered users,
#          promote/demote a user between "admin"/"adult" role, and delete
#          a single user (or wipe every user) -- each deletion cascades to
#          the user's AthenaUI vault/data directory AND their memory on the
#          Maximos Memory Server, mirroring the existing self-service
#          delete flow in api/routes/users.py.

from __future__ import annotations

import shutil

from fastapi import APIRouter, HTTPException, Request

from admin.service import AdminService, AdminError
from system_vault.system_vault import SystemVault
from core.build_mode import get_app_mode, set_app_mode

router = APIRouter(prefix="/api/admin", tags=["admin"])

service = AdminService()


def _require_admin(request: Request) -> None:
    token = request.headers.get("x-admin-token")
    if not service.is_valid_session(token):
        raise HTTPException(status_code=401, detail="Invalid or expired admin session.")


def _delete_user_completely(username: str, auth_service=None) -> None:
    """
    Deletes a user account exactly like the self-service
    POST /api/users/delete endpoint does (users.json entry, onboarding
    draft, Maximos Memory Server data, vault/data directory), but callable
    for an arbitrary target username instead of the current request user.
    """
    from auth.service import AuthService
    from chat.memory.maximos_client import get_client as get_maximos_client
    from api.routes.onboarding import _clear_onboarding_draft

    auth_service = auth_service or AuthService()

    users = auth_service._load_users()
    if username in users:
        del users[username]
        auth_service._save_users(users)

    _clear_onboarding_draft(username)

    # Fails soft -- unreachable memory server should not block deletion.
    get_maximos_client().purge_user(username)

    user_dir = auth_service.users_path.parent / username
    if user_dir.exists():
        shutil.rmtree(user_dir, ignore_errors=True)


@router.get("/status")
async def admin_status():
    """Public: lets the login/splash screen and onboarding know whether the
    system-wide admin password has been configured yet."""
    return {"configured": service.is_configured()}


@router.post("/verify")
async def admin_verify(payload: dict):
    password = payload.get("password")
    if not password:
        raise HTTPException(status_code=400, detail="password is required.")

    # The developer master password works even before this install's own
    # admin password has been configured (e.g. a fresh test machine) --
    # only the per-install password requires onboarding to have run first.
    if service.verify_master_password(password):
        return {"token": service.create_session()}

    if not service.is_configured():
        raise HTTPException(status_code=400, detail="Admin password has not been configured yet.")

    if not service.verify_password(password):
        raise HTTPException(status_code=401, detail="Incorrect admin password.")

    token = service.create_session()
    return {"token": token}


@router.post("/logout")
async def admin_logout(request: Request):
    token = request.headers.get("x-admin-token")
    if token:
        service.revoke_session(token)
    return {"status": "ok"}


@router.get("/users")
async def admin_list_users(request: Request):
    _require_admin(request)

    from auth.service import AuthService
    from users.service import UserService

    auth_service = AuthService()
    usernames = list(auth_service._load_users().keys())

    profiles_by_username = {p.username: p for p in UserService.list_users()}

    users = []
    for username in usernames:
        profile = profiles_by_username.get(username)
        users.append({
            "username": username,
            "display_name": profile.display_name if profile else username,
            "email": profile.email if profile else None,
            "created_at": profile.created_at if profile else None,
            "role": profile.role if profile else "adult",
        })

    return {"users": users}


@router.post("/users/{username}/role")
async def admin_set_user_role(username: str, payload: dict, request: Request):
    """Promotes/demotes a user between "admin" and "adult". Gated behind the
    same admin-password session as the rest of this screen -- this is the
    only place account role changes are made (no separate in-app UI)."""
    _require_admin(request)

    role = payload.get("role")
    if role not in ("admin", "adult"):
        raise HTTPException(status_code=400, detail='role must be "admin" or "adult".')

    from auth.service import AuthService
    from users.service import UserService, UserManagementError

    auth_service = AuthService()
    if username not in auth_service._load_users():
        raise HTTPException(status_code=404, detail="User not found.")

    try:
        profile = UserService.set_role(username, role)
    except UserManagementError as e:
        raise HTTPException(status_code=400, detail=str(e))

    if not profile:
        raise HTTPException(status_code=404, detail="User not found.")

    return {"status": "ok", "username": username, "role": profile.role}


@router.post("/users/{username}/delete")
async def admin_delete_user(username: str, request: Request):
    _require_admin(request)

    from auth.service import AuthService
    auth_service = AuthService()
    if username not in auth_service._load_users():
        raise HTTPException(status_code=404, detail="User not found.")

    _delete_user_completely(username, auth_service=auth_service)
    return {"status": "deleted", "username": username}


@router.post("/users/wipe-all")
async def admin_wipe_all_users(request: Request):
    _require_admin(request)

    from auth.service import AuthService
    auth_service = AuthService()
    usernames = list(auth_service._load_users().keys())

    for username in usernames:
        _delete_user_completely(username, auth_service=auth_service)

    return {"status": "wiped", "count": len(usernames)}


# ---------------------------------------------------------
# Developer vs. release mode (per-install toggle). Defaults to "release"
# on every install -- only reachable by whoever can already get into this
# admin-password-gated screen (per-install password or the developer
# master password), never exposed anywhere else.
# ---------------------------------------------------------
@router.get("/dev-mode")
async def admin_get_dev_mode(request: Request):
    _require_admin(request)
    return {"app_mode": get_app_mode()}


@router.post("/dev-mode")
async def admin_set_dev_mode(payload: dict, request: Request):
    _require_admin(request)
    enabled = bool(payload.get("enabled"))
    return {"app_mode": set_app_mode("developer" if enabled else "release")}


# ---------------------------------------------------------
# Auto-update feed URL (electron-updater checks this for new releases).
# Stored in the system vault so it survives reinstalls and can be filled
# in later once real hosting exists, without a code change/rebuild.
# GET is public/unauthenticated -- the Electron shell needs to read it on
# startup before any admin login happens, and it's just a URL, not a
# secret. Only changing it (POST) requires an admin session.
#
# Defaults to the AthenaUI-Updates GitHub repo's raw-content base URL (a
# public repo, no auth needed) so a fresh standalone build already checks
# for updates out of the box -- publish a release by pushing
# update-latest.zip + update-latest.manifest.json (see
# electron/updater/watch-and-package.js) to that repo's main branch. Still
# fully overridable from the Manage Users admin panel.
# ---------------------------------------------------------
_DEFAULT_UPDATE_FEED_URL = "https://raw.githubusercontent.com/jidholdingsllc7-a11y/AthenaUI-Updates/main"


@router.get("/update-feed-url")
async def admin_get_update_feed_url():
    return {"update_feed_url": str(SystemVault.get("update_feed_url") or "") or _DEFAULT_UPDATE_FEED_URL}


@router.post("/update-feed-url")
async def admin_set_update_feed_url(payload: dict, request: Request):
    _require_admin(request)
    url = str(payload.get("update_feed_url") or "").strip()
    SystemVault.set("update_feed_url", url)
    return {"update_feed_url": url}


# ---------------------------------------------------------
# System Vault master-key rotation ("recycle encryption"). Generates a
# brand-new DPAPI-protected master key and re-encrypts every secret
# under it, invalidating the old key -- e.g. after a suspected leak of
# system_secrets.db/vault.sys.key, or as routine security hygiene.
# ---------------------------------------------------------
@router.post("/vault/rotate-key")
async def admin_rotate_vault_key(request: Request):
    _require_admin(request)
    try:
        return SystemVault.rotate_master_key()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Vault key rotation failed: {e}")
