﻿# AthenaUI v3.5 — Provider-specific router for Text Generation Inference (TGI)
# File: backend/llm/routers/huggingface_tgi_router.py
# Created: 2026-03-28 21:46 CDT
# Updated: 2026-07-27 19:49 CDT

import json
import requests
from typing import Any, Dict, List, Optional

from llm.routers.base import BaseLLMRouter
from llm.router_selector.router_selector import RouterSelector
from llm.routers.providers import PROVIDER_HF_TGI
from core.runtime.runtime import get_runtime

from tools.registry.tool_examples import TOOL_EXAMPLES



class HuggingFaceTGIRouter(BaseLLMRouter):
    """
    Provider-specific router for HuggingFace Text Generation Inference (TGI).
    Supports:
    - chat (OpenAI-style)
    - tool calling (emulated)
    - streaming (stub)
    """

    API_URL_TEMPLATE = "{base_url}/v1/chat/completions"

    # ---------------------------------------------------------
    # Build system prompt with tool examples
    # ---------------------------------------------------------

    def _build_system_prompt(self, base_prompt: Optional[str], *, include_tool_examples: bool = True) -> str:
        if not include_tool_examples:
            return base_prompt if base_prompt else "You are AthenaUI v3.1."

        examples_json = json.dumps(TOOL_EXAMPLES, indent=2)

        tool_usage_block = f"""
TGI does NOT support native tool calling.
If you need to call a tool, output ONLY a JSON object describing the tool call.

Here are examples of correct tool usage:
{examples_json}
"""

        if base_prompt:
            return base_prompt + "\n\n" + tool_usage_block

        return "You are AthenaUI v3.1.\n\n" + tool_usage_block

    # ---------------------------------------------------------
    # Chat Completion
    # ---------------------------------------------------------

    def chat(
        self,
        messages: List[Dict[str, Any]],
        *,
        tools: Optional[List[Dict[str, Any]]] = None,
        tool_choice: Optional[str] = None,  # ignored (TGI cannot force tools)
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> Dict[str, Any]:

        runtime = get_runtime()

        base_url = runtime.env.HF_TGI_BASE_URL
        if not base_url:
            raise RuntimeError("HF_TGI_BASE_URL not set in environment.")

        url = self.API_URL_TEMPLATE.format(base_url=base_url)

        headers = {
            "Content-Type": "application/json",
        }

        # Extract any upstream persona/memory system prompt already present
        extracted_prompt, remaining_messages = self._extract_system_prompt(messages)
        final_system_prompt = self._build_system_prompt(system_prompt or extracted_prompt, include_tool_examples=bool(tools))

        # Inject system message
        full_messages = [{"role": "system", "content": final_system_prompt}] + remaining_messages

        # Tool emulation
        if tools:
            tool_desc = json.dumps(tools, indent=2)
            full_messages.append({
                "role": "system",
                "content": (
                    "Available tools:\n"
                    f"{tool_desc}\n"
                    "If you need to call a tool, respond ONLY with a JSON object describing the tool call."
                ),
            })

        payload: Dict[str, Any] = {
            "model": self.model_id,
            "messages": full_messages,
            "temperature": temperature,
        }

        if max_tokens is not None:
            payload["max_tokens"] = max_tokens

        # Send request
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        data = response.json()

        # Normalize TGI response (OpenAI-style)
        choice = data["choices"][0]
        message = choice.get("message", {})

        return {
            "id": data.get("id"),
            "model": data.get("model"),
            "content": message.get("content"),
            "tool_calls": None,  # TGI cannot return structured tool calls
            "finish_reason": choice.get("finish_reason"),
            "raw": data,
        }

    # ---------------------------------------------------------
    # Streaming (stub)
    # ---------------------------------------------------------

    def stream_chat(self, *args, **kwargs):
        raise NotImplementedError("TGI streaming not implemented yet.")


# ---------------------------------------------------------
# Register Router
# ---------------------------------------------------------

RouterSelector.register_router(PROVIDER_HF_TGI, HuggingFaceTGIRouter)

