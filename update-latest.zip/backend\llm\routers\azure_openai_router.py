﻿# AthenaUI v3.5 — Provider-specific router for Azure-hosted OpenAI models
# File: backend/llm/routers/azure_openai_router.py
# Created: 2026-03-28 21:31 CDT
# Updated: 2026-07-27 19:49 CDT

import json
import requests
from typing import Any, Dict, List, Optional

from llm.routers.base import BaseLLMRouter, model_rejects_custom_temperature
from llm.router_selector.router_selector import RouterSelector
from llm.routers.providers import PROVIDER_AZURE_OPENAI
from core.runtime.runtime import get_runtime

from tools.registry.tool_examples import TOOL_EXAMPLES



class AzureOpenAIRouter(BaseLLMRouter):
    """
    Provider-specific router for Azure OpenAI deployments.
    Supports:
    - chat
    - tool calling (OpenAI v2)
    - images
    - streaming (stub)
    """

    API_URL_TEMPLATE = (
        "https://{resource}.openai.azure.com/openai/deployments/"
        "{deployment}/chat/completions?api-version={api_version}"
    )

    IMAGE_URL_TEMPLATE = (
        "https://{resource}.openai.azure.com/openai/deployments/"
        "{deployment}/images/generations?api-version={api_version}"
    )

    # ---------------------------------------------------------
    # Build system prompt with tool examples
    # ---------------------------------------------------------

    def _build_system_prompt(self, base_prompt: Optional[str], *, include_tool_examples: bool = True) -> str:
        if not include_tool_examples:
            return base_prompt if base_prompt else "You are AthenaUI v3.1."

        examples_json = json.dumps(TOOL_EXAMPLES, indent=2)

        tool_usage_block = f"""
You have access to a set of tools. Use them whenever needed.

Here are examples of correct tool usage:
{examples_json}

Azure OpenAI uses the same tool-calling format as OpenAI v2:
- "tools": [...]
- "tool_choice": ...
- "message.tool_calls": [...]

If you need to call a tool, do NOT explain â€” just call it.
"""

        if base_prompt:
            return base_prompt + "\n\n" + tool_usage_block

        return "You are AthenaUI v3.1.\n\n" + tool_usage_block

    # ---------------------------------------------------------
    # Chat Completion
    # ---------------------------------------------------------

    def chat(
        self,
        messages: List[Dict[str, Any]],
        *,
        tools: Optional[List[Dict[str, Any]]] = None,
        tool_choice: Optional[str] = None,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> Dict[str, Any]:

        runtime = get_runtime()

        api_key = runtime.env.AZURE_OPENAI_API_KEY
        resource = runtime.env.AZURE_OPENAI_RESOURCE
        deployment = self.model_id  # deployment name
        api_version = runtime.env.AZURE_OPENAI_API_VERSION or "2024-02-01"

        if not api_key:
            raise RuntimeError("Azure OpenAI API key not set.")
        if not resource:
            raise RuntimeError("Azure OpenAI resource name not set.")

        url = self.API_URL_TEMPLATE.format(
            resource=resource,
            deployment=deployment,
            api_version=api_version,
        )

        headers = {
            "api-key": api_key,
            "Content-Type": "application/json",
        }

        # Extract any upstream persona/memory system prompt already present
        extracted_prompt, remaining_messages = self._extract_system_prompt(messages)
        final_system_prompt = self._build_system_prompt(system_prompt or extracted_prompt, include_tool_examples=bool(tools))

        # Inject system message
        full_messages = [{"role": "system", "content": final_system_prompt}] + remaining_messages

        payload: Dict[str, Any] = {
            "messages": full_messages,
        }
        if not model_rejects_custom_temperature(deployment):
            payload["temperature"] = temperature

        if max_tokens is not None:
            # Same max_tokens -> max_completion_tokens rename as OpenAI's own
            # API (Azure OpenAI mirrors it) -- see openai_router.py.
            payload["max_completion_tokens"] = max_tokens

        # Tool calling (OpenAI v2)
        if tools:
            payload["tools"] = tools
            if tool_choice:
                payload["tool_choice"] = tool_choice

        # Send request
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        data = response.json()

        # Normalize Azure OpenAI response
        choice = data["choices"][0]
        message = choice.get("message", {})

        result = {
            "id": data.get("id"),
            "model": deployment,
            "content": message.get("content"),
            "tool_calls": message.get("tool_calls"),
            "finish_reason": choice.get("finish_reason"),
            "raw": data,
        }

        return result

    # ---------------------------------------------------------
    # Image Generation
    # ---------------------------------------------------------

    def generate_image(
        self,
        prompt: str,
        *,
        size: str = "1024x1024",
        n: int = 1,
    ) -> Dict[str, Any]:

        runtime = get_runtime()

        api_key = runtime.env.AZURE_OPENAI_API_KEY
        resource = runtime.env.AZURE_OPENAI_RESOURCE
        deployment = self.model_id
        api_version = runtime.env.AZURE_OPENAI_API_VERSION or "2024-02-01"

        if not api_key:
            raise RuntimeError("Azure OpenAI API key not set.")
        if not resource:
            raise RuntimeError("Azure OpenAI resource name not set.")

        url = self.IMAGE_URL_TEMPLATE.format(
            resource=resource,
            deployment=deployment,
            api_version=api_version,
        )

        headers = {
            "api-key": api_key,
            "Content-Type": "application/json",
        }

        payload = {
            "prompt": prompt,
            "size": size,
            "n": n,
        }

        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        data = response.json()

        return {
            "images": data.get("data", []),
            "raw": data,
        }

    # ---------------------------------------------------------
    # Streaming (stub)
    # ---------------------------------------------------------

    def stream_chat(
        self,
        messages: List[Dict[str, Any]],
        *,
        tools: Optional[List[Dict[str, Any]]] = None,
        tool_choice: Optional[str] = None,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ):
        raise NotImplementedError("Azure OpenAI streaming not implemented yet.")


# ---------------------------------------------------------
# Register Router
# ---------------------------------------------------------

RouterSelector.register_router(PROVIDER_AZURE_OPENAI, AzureOpenAIRouter)

