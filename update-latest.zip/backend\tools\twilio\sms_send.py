# AthenaUI -- Twilio SMS Send Tool
# File: backend/tools/twilio/sms_send.py
#
# Sends a real text message to a real phone number via the user's
# configured Twilio account. Publicly-facing and irreversible once sent, so
# this is flagged dangerous/requires_approval, same as
# social_media_post_x.py -- the executor's approval gate will surface an
# Allow/Deny prompt before this ever actually runs.

from typing import Any, Dict

from twilio_integration.service import TwilioServiceError, send_sms

capabilities = {
    "needs_bridge": False,
    "needs_filesystem": False,
    "needs_network": True,
    "needs_user": True,
    "is_dangerous": True,
    "requires_approval": True,
}


async def run(args: Dict[str, Any]):
    import asyncio

    username = args.get("username")
    to = (args.get("to") or "").strip()
    body = (args.get("body") or "").strip()
    if not username:
        return {"error": "Missing 'username' argument."}
    if not to:
        return {"error": "Missing 'to' argument."}
    if not body:
        return {"error": "Missing 'body' argument."}

    try:
        result = await asyncio.to_thread(
            send_sms, username, to, body, args.get("include_stop_notice", True)
        )
    except TwilioServiceError as e:
        return {"error": str(e)}

    return {"ok": True, "result": result}
