# AthenaUI -- Ledger SQLite store
# File: backend/ledger/db.py
#
# Local persistence for marketing-activity ledger records (every published
# post, plus manual-paste posts awaiting proof). Mirrors the existing
# logs_system/db/service.py (TailLogDb) pattern: plain SQLite, WAL mode, a
# threading.Lock around writes so insert order is always reliable.

from __future__ import annotations

import json
import sqlite3
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional

DB_DIR = Path(__file__).resolve().parent / "db"
DB_PATH = DB_DIR / "ledger_records.db"


class LedgerDb:
    def __init__(self, path: Path = DB_PATH) -> None:
        self._path = path
        self._lock = threading.Lock()
        DB_DIR.mkdir(parents=True, exist_ok=True)
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS ledger_records (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    record_id TEXT UNIQUE NOT NULL,
                    username TEXT NOT NULL,
                    character TEXT,
                    tool_name TEXT,
                    platform TEXT,
                    record_type TEXT NOT NULL,
                    status TEXT NOT NULL,
                    content TEXT,
                    external_ref TEXT,
                    proof_url TEXT,
                    proof_screenshot_path TEXT,
                    signature_json TEXT,
                    scdo_push_status TEXT,
                    scdo_response_json TEXT,
                    created_at TEXT NOT NULL,
                    published_at TEXT
                )
                """
            )
            conn.execute("PRAGMA journal_mode=WAL")
            conn.commit()

    def _connect(self) -> sqlite3.Connection:
        return sqlite3.connect(self._path)

    def insert(self, record: Dict[str, Any]) -> None:
        with self._lock, self._connect() as conn:
            conn.execute(
                """
                INSERT INTO ledger_records (
                    record_id, username, character, tool_name, platform, record_type,
                    status, content, external_ref, proof_url, proof_screenshot_path,
                    signature_json, scdo_push_status, scdo_response_json, created_at, published_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    record["record_id"], record["username"], record.get("character"),
                    record.get("tool_name"), record.get("platform"), record["record_type"],
                    record["status"], record.get("content"), record.get("external_ref"),
                    record.get("proof_url"), record.get("proof_screenshot_path"),
                    json.dumps(record.get("signature") or {}),
                    record.get("scdo_push_status"), json.dumps(record.get("scdo_response") or {}),
                    record["created_at"], record.get("published_at"),
                ),
            )
            conn.commit()

    def update(self, record_id: str, **fields: Any) -> None:
        if not fields:
            return
        columns = []
        values: List[Any] = []
        for key, value in fields.items():
            if key in ("signature", "scdo_response"):
                columns.append(f"{'signature_json' if key == 'signature' else 'scdo_response_json'} = ?")
                values.append(json.dumps(value or {}))
            else:
                columns.append(f"{key} = ?")
                values.append(value)
        values.append(record_id)
        with self._lock, self._connect() as conn:
            conn.execute(f"UPDATE ledger_records SET {', '.join(columns)} WHERE record_id = ?", values)
            conn.commit()

    def _row_to_dict(self, row: sqlite3.Row) -> Dict[str, Any]:
        d = dict(row)
        d["signature"] = json.loads(d.pop("signature_json") or "{}")
        d["scdo_response"] = json.loads(d.pop("scdo_response_json") or "{}")
        return d

    def get(self, record_id: str) -> Optional[Dict[str, Any]]:
        with self._connect() as conn:
            conn.row_factory = sqlite3.Row
            row = conn.execute("SELECT * FROM ledger_records WHERE record_id = ?", (record_id,)).fetchone()
            return self._row_to_dict(row) if row else None

    def list_for_user(self, username: str, *, status: Optional[str] = None, limit: int = 200) -> List[Dict[str, Any]]:
        query = "SELECT * FROM ledger_records WHERE username = ?"
        params: List[Any] = [username]
        if status:
            query += " AND status = ?"
            params.append(status)
        query += " ORDER BY id DESC LIMIT ?"
        params.append(limit)
        with self._connect() as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(query, params).fetchall()
            return [self._row_to_dict(r) for r in rows]


ledger_db = LedgerDb()
