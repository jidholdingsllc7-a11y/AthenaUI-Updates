# AthenaUI -- Scheduler Set Recurring Pace Tool
# File: backend/tools/system/scheduler/set_recurring_pace.py
#
# Lets a character, WHILE a recurring scheduled job (see schedule_job's
# repeat_every_minutes) is executing, control how soon its next occurrence
# runs -- 'active' for a short/fast re-check (e.g. mid-conversation on X,
# expecting a reply soon), 'idle' to return to the job's normal interval.
# Only meaningful during a recurring job's own execution -- the current
# job_id is resolved automatically from context, never passed as an
# argument (the model has no reliable way to know it).

from typing import Any, Dict

from scheduler import service as scheduler_service
from scheduler.job_context import get_current_job_id

capabilities = {
    "needs_bridge": False,
    "needs_filesystem": False,
    "needs_network": False,
    "needs_user": True,
}


async def run(args: Dict[str, Any]):
    username = args.get("username")
    pace = (args.get("pace") or "").strip().lower()
    reason = (args.get("reason") or "").strip() or None

    if pace not in ("active", "idle"):
        return {"error": "pace must be 'active' or 'idle'."}

    job_id = get_current_job_id()
    if not job_id:
        return {"error": "Not currently running inside a scheduled job -- there is no recurring check to adjust."}

    try:
        job = scheduler_service.set_next_pace(username, job_id, pace, reason=reason)
    except ValueError as e:
        return {"error": str(e)}

    interval = job.get("active_repeat_every_minutes") if pace == "active" else job.get("repeat_every_minutes")
    return {
        "ok": True,
        "pace": pace,
        "next_check_in_minutes": interval,
    }
