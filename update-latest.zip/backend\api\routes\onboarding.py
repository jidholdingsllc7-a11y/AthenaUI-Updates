﻿# AthenaUI v3.5 — Onboarding API Routes
# File: backend/api/routes/onboarding.py
# Created: 2026-04-14 22:31 CDT
# Updated: 2026-07-27 19:49 CDT

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Depends, Form, File, UploadFile
from pydantic import BaseModel
from typing import Optional, Literal
import json
from pathlib import Path
import os

from auth.service import AuthService, get_current_user, get_current_user_optional
from google.service import GoogleService
from llm.routers.providers import ALL_PROVIDERS
from workspace.service import WorkspaceService
from vault.service import VaultService
from users.service import UserService  # NEW: for username/email validation
from users.service import UserManagementError
from config.loader import ConfigLoader
from llm.provider_detection.provider_auto_detector import detect_provider
from vault.controller import VaultController

router = APIRouter(prefix="/onboarding", tags=["onboarding"])


def _provider_label(provider_id: str) -> str:
    return provider_id.replace("_", " ").title()




def _onboarding_drafts_path() -> Path:
    backend_root = Path(__file__).resolve().parents[2]
    users_dir = backend_root / "data" / "users"
    users_dir.mkdir(parents=True, exist_ok=True)
    path = users_dir / "onboarding_drafts.json"
    if not path.exists():
        path.write_text("{}", encoding="utf-8")
    return path


def _load_onboarding_drafts() -> dict:
    path = _onboarding_drafts_path()
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(payload, dict):
            return payload
    except Exception:
        pass
    return {}


def _save_onboarding_drafts(drafts: dict) -> None:
    path = _onboarding_drafts_path()
    path.write_text(json.dumps(drafts, indent=2), encoding="utf-8")


def _get_onboarding_draft(username: str) -> dict:
    drafts = _load_onboarding_drafts()
    data = drafts.get(username, {})
    return data if isinstance(data, dict) else {}


def _update_onboarding_draft(username: str, updates: dict) -> dict:
    drafts = _load_onboarding_drafts()
    current = drafts.get(username, {})
    if not isinstance(current, dict):
        current = {}
    current.update(updates)
    drafts[username] = current
    _save_onboarding_drafts(drafts)
    return current


def _clear_onboarding_draft(username: str) -> None:
    drafts = _load_onboarding_drafts()
    if username in drafts:
        del drafts[username]
        _save_onboarding_drafts(drafts)


# ---------------------------------------------------------
# Request Models
# ---------------------------------------------------------

class UsernameRequest(BaseModel):
    username: str

class ProviderRequest(UsernameRequest):
    provider_id: str
    api_key: str

class ModelSelectionRequest(UsernameRequest):
    model_id: str

class WorkspacePathRequest(UsernameRequest):
    base_path: str

class FinalizeRequest(BaseModel):
    username: str
    password: str
    email: str
    first_name: str
    last_name: Optional[str] = None
    system_email: Optional[str] = None
    system_email_app_password: Optional[str] = None
    admin_password: Optional[str] = None


class ImageProviderRequest(UsernameRequest):
    mode: Literal["chat_provider", "custom"]
    provider_id: Optional[str] = None
    api_key: Optional[str] = None


def _resolve_username(payload: dict, user):
    if user:
        return user["username"]
    username = payload.get("username")
    if not username:
        raise HTTPException(400, "username is required for onboarding.")
    return username


# ---------------------------------------------------------
# Helper: Minimum onboarding requirements
# ---------------------------------------------------------
@router.get("/minimum")
async def onboarding_minimum():
    return {
        "requires_provider": True,
        "requires_chat_model": True,
        "requires_workspace": True,
        "requires_username": True,
        "requires_email": True,
    }


@router.get("/providers")
async def onboarding_list_providers():
    """
    Public provider list for onboarding/settings provider dropdowns.
    """
    return {
        "providers": [
            {
                "id": provider_id,
                "label": _provider_label(provider_id),
            }
            for provider_id in ALL_PROVIDERS
        ]
    }


# ---------------------------------------------------------
# Step 1: Provider + API key
# ---------------------------------------------------------
@router.post("/provider")
async def onboarding_set_provider(
    payload: ProviderRequest,
    user=Depends(get_current_user_optional),
):
    provider_id = payload.provider_id
    api_key = payload.api_key
    username = _resolve_username(payload.dict(), user)

    if not provider_id or not api_key:
        raise HTTPException(400, "provider_id and api_key are required.")

    _update_onboarding_draft(username, {
        "provider_id": provider_id,
        "provider_api_key": api_key,
        "provider_source": "custom",
    })

    return {"status": "ok"}


# ---------------------------------------------------------
# Step 2: Detect models
# ---------------------------------------------------------
@router.post("/detect")
async def onboarding_detect_models(
    payload: Optional[UsernameRequest] = None,
    user=Depends(get_current_user_optional),
):
    username = _resolve_username(payload.dict() if payload else {}, user)
    draft = _get_onboarding_draft(username)

    provider_id = str(draft.get("provider_id") or "").strip()
    api_key = str(draft.get("provider_api_key") or "").strip()

    if not provider_id or not api_key:
        return {
            "available": False,
            "models": [],
            "warnings": ["Provider/API key not configured for onboarding draft."],
            "error": "Provider and API key are required before model detection.",
        }

    result = detect_provider(provider_id, {"api_key": api_key})

    _update_onboarding_draft(username, {
        "provider_id": provider_id,
        "detected_chat_models": result.models or [],
    })

    return {
        "available": result.available,
        "models": result.models,
        "warnings": result.warnings,
        "error": result.error,
    }


# ---------------------------------------------------------
# Step 2b: Detect image models
# ---------------------------------------------------------
@router.post("/detect-image-models")
async def onboarding_detect_image_models(
    payload: Optional[UsernameRequest] = None,
    user=Depends(get_current_user_optional),
):
    """
    Returns available image models from the detected provider.
    Falls back to common OpenAI image models.
    """
    username = _resolve_username(payload.dict() if payload else {}, user)
    try:
        draft = _get_onboarding_draft(username)
        provider_id = str(draft.get("image_provider_id") or "").strip()
        source = str(draft.get("image_provider_source") or "").strip() or "chat_provider"

        if not provider_id:
            provider_id = str(draft.get("provider_id") or "").strip()

        detected_models = []
        warnings = []
        api_key = ""

        if source == "custom":
            api_key = str(draft.get("image_provider_api_key") or "").strip()
        elif source == "chat_provider":
            api_key = str(draft.get("provider_api_key") or "").strip()

        if provider_id and api_key:
            detection = detect_provider(provider_id, {"api_key": api_key})
            detected_models = detection.models or []
            warnings = detection.warnings or []

        if not detected_models:
            detected_models = ["gpt-image-1"]

        image_model_ids = [
            model_id for model_id in detected_models
            if any(token in model_id.lower() for token in ["image", "dall-e", "vision"])
        ]

        # Preserve order while removing duplicates.
        seen = set()
        unique_image_model_ids = []
        for model_id in image_model_ids:
            if model_id in seen:
                continue
            seen.add(model_id)
            unique_image_model_ids.append(model_id)

        models = [
            {
                "id": model_id,
                "name": model_id,
                "description": f"Detected {provider_id} image-capable model",
            }
            for model_id in unique_image_model_ids
        ]

        return {
            "available": len(models) > 0,
            "models": models,
            "provider_id": provider_id,
            "provider_source": source,
            "warnings": warnings,
        }
    except Exception as e:
        return {
            "available": False,
            "models": [],
            "error": str(e),
        }


# ---------------------------------------------------------
# Step 4a: Configure image provider source
# ---------------------------------------------------------
@router.post("/image-provider")
async def onboarding_set_image_provider(
    payload: ImageProviderRequest,
    user=Depends(get_current_user_optional),
):
    username = _resolve_username(payload.dict(), user)
    mode = payload.mode

    draft = _get_onboarding_draft(username)
    provider_id = ""
    api_key = ""

    if mode == "chat_provider":
        provider_id = str(draft.get("provider_id") or "").strip()
        if not provider_id:
            raise HTTPException(400, "Chat provider is not configured yet.")
        api_key = str(draft.get("provider_api_key") or "").strip()
        if not api_key:
            raise HTTPException(400, "Chat provider API key is not configured for this user.")

    elif mode == "custom":
        provider_id = str(payload.provider_id or "").strip()
        api_key = str(payload.api_key or "").strip()
        if not provider_id:
            raise HTTPException(400, "provider_id is required for custom image provider.")
        if not api_key:
            raise HTTPException(400, "api_key is required for custom image provider.")
    else:
        raise HTTPException(400, "Unsupported image provider mode.")

    _update_onboarding_draft(username, {
        "image_provider_source": mode,
        "image_provider_id": provider_id,
        "image_provider_api_key": api_key,
    })

    return {
        "status": "ok",
        "mode": mode,
        "provider_id": provider_id,
        "has_api_key": bool(api_key),
    }


# ---------------------------------------------------------
# Step 3: Select chat model
# ---------------------------------------------------------
@router.post("/select-chat-model")
async def onboarding_select_chat_model(
    payload: ModelSelectionRequest,
    user=Depends(get_current_user_optional),
):
    model_id = payload.model_id
    username = _resolve_username(payload.dict(), user)
    if not model_id:
        raise HTTPException(400, "model_id is required.")

    _update_onboarding_draft(username, {"selected_chat_model": model_id})
    return {"status": "ok"}


# ---------------------------------------------------------
# Step 4: Select image model
# ---------------------------------------------------------
@router.post("/select-image-model")
async def onboarding_select_image_model(
    payload: ModelSelectionRequest,
    user=Depends(get_current_user_optional),
):
    model_id = payload.model_id
    username = _resolve_username(payload.dict(), user)
    if not model_id:
        raise HTTPException(400, "model_id is required.")

    _update_onboarding_draft(username, {"selected_image_model": model_id})
    return {"status": "ok"}


# ---------------------------------------------------------
# Step 5: Workspace selection
# ---------------------------------------------------------
@router.post("/workspace")
async def onboarding_set_workspace(
    payload: WorkspacePathRequest,
    user=Depends(get_current_user_optional),
):
    username = _resolve_username(payload.dict(), user)

    if not payload.base_path:
        raise HTTPException(400, "base_path is required.")

    preview_workspace = str((Path(payload.base_path).expanduser().resolve() / WorkspaceService.WORKSPACE_NAME))
    _update_onboarding_draft(username, {
        "workspace_base_path": payload.base_path,
        "workspace_path": preview_workspace,
    })

    return {"status": "ok", "workspace": preview_workspace}


# ---------------------------------------------------------
# Step 6: Finalize onboarding (NEW)
# ---------------------------------------------------------
@router.post("/finalize-full")
async def onboarding_finalize_full(
    payload: FinalizeRequest,
    user=Depends(get_current_user_optional),
):
    username = payload.username.strip()
    email = payload.email.strip().lower()

    if not username:
        raise HTTPException(400, "username is required.")
    if not email:
        raise HTTPException(400, "email is required.")

    # Validate email subscription limit
    if UserService.count_accounts_for_email(email) >= 5:
        raise HTTPException(400, "Email already has 5 accounts.")

    auth_service = AuthService()
    auth_users = auth_service._load_users()
    existing_auth_user = auth_users.get(username)

    # Ensure auth users.json has this onboarding user and password.
    if not existing_auth_user:
        auth_service.register(username, payload.password)
    else:
        # If user already fully onboarded, do not allow re-register.
        if existing_auth_user.get("onboarding_complete"):
            raise HTTPException(400, "Username already exists.")

        # Recover from partial onboarding: set/refresh password hash and continue.
        from utils.crypto.passwords import hash_password
        salt_hex, hash_hex = hash_password(payload.password)
        existing_auth_user["password_salt"] = salt_hex
        existing_auth_user["password_hash"] = hash_hex
        existing_auth_user["onboarding_complete"] = False
        auth_users[username] = existing_auth_user
        auth_service._save_users(auth_users)

    draft = _get_onboarding_draft(username)

    provider_id = str(draft.get("provider_id") or "").strip()
    provider_api_key = str(draft.get("provider_api_key") or "").strip()
    if not provider_id or not provider_api_key:
        raise HTTPException(400, "Provider must be configured before finalizing onboarding.")

    if bool(payload.system_email) ^ bool(payload.system_email_app_password):
        raise HTTPException(400, "Both system_email and system_email_app_password are required together.")

    workspace_base_path = str(draft.get("workspace_base_path") or "").strip()
    if not workspace_base_path:
        raise HTTPException(400, "Workspace not set.")

    # Create vault only now (strict no-scaffolding-before-finalize rule).
    VaultController.get_or_create_vault_for_onboarding_finalize(username)

    workspace = WorkspaceService.create_workspace(
        base_path=workspace_base_path,
        username=username,
    )

    VaultService.set_secret(username, "llm.provider_id", provider_id)
    VaultService.set_secret(username, f"llm.{provider_id}.api_key", provider_api_key)
    VaultService.set_provider_key(username, "chat", provider_id, {"api_key": provider_api_key})
    VaultService.set_preference(username, "llm.provider_id", provider_id)
    VaultService.set_preference(username, "llm.provider_source", "custom")

    selected_chat_model = str(draft.get("selected_chat_model") or "").strip() or "gpt-4o-mini"
    VaultService.set_preference(username, "llm.chat_model", selected_chat_model)

    selected_image_model = str(draft.get("selected_image_model") or "").strip() or "gpt-image-1"
    VaultService.set_preference(username, "llm.image_model", selected_image_model)

    image_provider_source = str(draft.get("image_provider_source") or "").strip() or "chat_provider"
    image_provider_id = str(draft.get("image_provider_id") or "").strip() or provider_id
    image_provider_api_key = str(draft.get("image_provider_api_key") or "").strip()
    if image_provider_source == "chat_provider" and not image_provider_api_key:
        image_provider_api_key = provider_api_key

    VaultService.set_preference(username, "llm.image_provider_source", image_provider_source)
    VaultService.set_preference(username, "llm.image_provider_id", image_provider_id)
    if image_provider_api_key:
        VaultService.set_provider_key(username, "image", image_provider_id, {"api_key": image_provider_api_key})

    VaultService.set_preference(username, "onboarding.completed", True)

    # Save user metadata
    try:
        UserService.register_onboarding_user(
            username=username,
            email=email,
            first_name=payload.first_name,
            last_name=payload.last_name,
        )
    except UserManagementError as e:
        raise HTTPException(400, str(e))

    if payload.system_email and payload.system_email_app_password:
        GoogleService.set_system_email_credentials(
            username=username,
            email=payload.system_email,
            app_password=payload.system_email_app_password,
        )

    # Persist onboarding selections and key metadata into the user vault/profile for post-login use.
    vault = VaultService.get_vault(username)
    user_data = dict(vault.user or {})

    chat_key_data = VaultService.get_provider_key(username, "chat", provider_id) if provider_id else None
    image_key_data = VaultService.get_provider_key(username, "image", image_provider_id) if image_provider_id else None
    has_chat_api_key = bool((chat_key_data or {}).get("api_key") or VaultService.get_secret(username, f"llm.{provider_id}.api_key")) if provider_id else False
    has_image_api_key = bool((image_key_data or {}).get("api_key")) if image_provider_id else False

    if workspace and not user_data.get("workspace_path"):
        user_data["workspace_path"] = workspace
    if workspace and not user_data.get("workspace_directory"):
        user_data["workspace_directory"] = workspace
    user_data["provider_id"] = provider_id
    user_data["selected_chat_model"] = selected_chat_model
    user_data["selected_image_model"] = selected_image_model
    user_data["image_provider_source"] = image_provider_source
    user_data["image_provider_id"] = image_provider_id
    user_data["has_chat_api_key"] = has_chat_api_key
    user_data["has_image_api_key"] = has_image_api_key
    vault.user = user_data

    if hasattr(VaultService, "save_vault"):
        VaultService.save_vault(username, vault)

    _clear_onboarding_draft(username)

    # Ensure all bundled system agents are seeded into this new user account.
    try:
        VaultService.seed_system_agents(username)
    except Exception as e:
        raise HTTPException(500, f"Failed to seed system agents: {e}")

    # One-time, system-wide setup of the "Manage Users" admin password
    # (stored in the SystemVault, not this user's vault). No-op if it was
    # already configured by an earlier onboarding.
    if payload.admin_password:
        from admin.service import AdminService, AdminError
        try:
            AdminService().set_password(payload.admin_password)
        except AdminError as e:
            raise HTTPException(400, str(e))

    return {
        "status": "ok",
        "username": username,
        "email": email,
        "provider": provider_id,
        "chat_model": selected_chat_model,
        "image_model": selected_image_model,
        "image_provider_source": image_provider_source,
        "image_provider_id": image_provider_id,
        "workspace": vault.user.get("workspace_path"),
    }


# ---------------------------------------------------------
# Optional selfie upload (called right after finalize-full succeeds, since
# the new account has no auth token yet at that point in the flow)
# ---------------------------------------------------------
@router.post("/avatar")
async def onboarding_upload_avatar(
    username: str = Form(...),
    file: UploadFile = File(...),
):
    profile = UserService.get_user(username)
    if not profile:
        raise HTTPException(status_code=404, detail="User not found.")

    UserService.save_avatar(username, file.filename or "avatar.jpg", file.file)
    return {"status": "ok"}


# ---------------------------------------------------------
# Helper: Check onboarding status
# ---------------------------------------------------------
@router.get("/status")
async def onboarding_status(
    user=Depends(get_current_user_optional),
):
    # NOTE: completion is tracked per-user in data/users/users.json
    # (`onboarding_complete`), set by /onboarding/finalize-full via
    # UserService.register_onboarding_user(). This must NOT use
    # OnboardingService.is_complete(), which reads a single legacy global
    # flag from config/state.json shared by every user/session -- that flag
    # is unrelated to per-user onboarding and caused already-onboarded users
    # to be bounced back to the onboarding flow after login.
    auth = AuthService()

    # If unauthenticated and no users exist, onboarding is not complete
    if not user:
        # If users already exist, first-run onboarding should be considered complete
        # for unauthenticated callers so UI can route to login.
        users = auth._load_users()
        return {"completed": len(users) > 0}

    auth_user = auth.get_user(user["username"])
    return {"completed": bool(auth_user and auth_user.get("onboarding_complete"))}

