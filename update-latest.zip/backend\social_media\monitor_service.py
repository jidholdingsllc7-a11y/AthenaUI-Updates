# AthenaUI v3.5 — X (Twitter) Mentions/DMs Monitoring Config Service
# File: backend/social_media/monitor_service.py
#
# Per-user "assign an agent to monitor X mentions/DMs" configuration for the
# Social Media dashboard -- mirrors auto_reply/service.py's email-inbox
# pattern (single assigned character + user-authored instructions + an
# always-on notification alert + an OPTIONAL auto-reply mode). Unlike email
# (which supports multiple accounts), there's only one X account per user,
# so this is a single config row per user rather than one per account.
#
# Storage: one dedicated SQLite file per human user:
#   {DATA_DIR}/users/{username}/social_media/monitor.sqlite

from __future__ import annotations

import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from core.runtime.runtime import get_runtime


class SocialMediaMonitorError(Exception):
    pass


def _root_dir(username: str) -> Path:
    runtime = get_runtime()
    root = runtime.env.DATA_DIR / "users" / username / "social_media"
    root.mkdir(parents=True, exist_ok=True)
    return root


def _db_path(username: str) -> Path:
    return _root_dir(username) / "monitor.sqlite"


def _connect(username: str) -> sqlite3.Connection:
    conn = sqlite3.connect(_db_path(username))
    conn.row_factory = sqlite3.Row
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS config (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            character TEXT NOT NULL,
            instructions TEXT,
            enabled INTEGER NOT NULL DEFAULT 1,
            auto_reply_enabled INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS pending_replies (
            id TEXT PRIMARY KEY,
            kind TEXT NOT NULL,
            character TEXT NOT NULL,
            source_id TEXT NOT NULL,
            sender TEXT,
            content TEXT,
            draft_reply TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """
    )
    return conn


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _row_to_config(row: sqlite3.Row) -> Dict[str, Any]:
    d = dict(row)
    d["enabled"] = bool(d["enabled"])
    d["auto_reply_enabled"] = bool(d["auto_reply_enabled"])
    return d


def set_config(
    username: str,
    character: str,
    instructions: Optional[str] = None,
    enabled: bool = True,
    auto_reply_enabled: bool = False,
) -> Dict[str, Any]:
    if not character:
        raise SocialMediaMonitorError("'character' is required.")

    now = _now()
    with _connect(username) as conn:
        existing = conn.execute("SELECT * FROM config WHERE id = 1").fetchone()
        if existing:
            conn.execute(
                """
                UPDATE config
                SET character = ?, instructions = ?, enabled = ?, auto_reply_enabled = ?, updated_at = ?
                WHERE id = 1
                """,
                (character, instructions, int(enabled), int(auto_reply_enabled), now),
            )
        else:
            conn.execute(
                """
                INSERT INTO config (id, character, instructions, enabled, auto_reply_enabled, created_at, updated_at)
                VALUES (1, ?, ?, ?, ?, ?, ?)
                """,
                (character, instructions, int(enabled), int(auto_reply_enabled), now, now),
            )
        row = conn.execute("SELECT * FROM config WHERE id = 1").fetchone()
    return _row_to_config(row)


def get_config(username: str) -> Optional[Dict[str, Any]]:
    with _connect(username) as conn:
        row = conn.execute("SELECT * FROM config WHERE id = 1").fetchone()
    return _row_to_config(row) if row else None


def delete_config(username: str) -> None:
    with _connect(username) as conn:
        cur = conn.execute("DELETE FROM config WHERE id = 1")
        if cur.rowcount == 0:
            raise SocialMediaMonitorError("No X monitoring config exists.")


# ------------------------------------------------------------
# Pending replies (drafted by the monitoring agent, awaiting the user's
# approve/edit/deny decision -- used whenever auto_reply_enabled is False
# but monitoring is on, i.e. the "agent drafts it, I approve it" gate, and
# the agent's way to refer anything it can't confidently handle to the
# user instead of guessing).
# ------------------------------------------------------------

def create_pending_reply(
    username: str,
    kind: str,
    character: str,
    source_id: str,
    sender: str,
    content: str,
    draft_reply: str,
) -> Dict[str, Any]:
    import uuid

    reply_id = uuid.uuid4().hex[:12]
    with _connect(username) as conn:
        conn.execute(
            """
            INSERT INTO pending_replies
                (id, kind, character, source_id, sender, content, draft_reply, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (reply_id, kind, character, source_id, sender, content, draft_reply, _now()),
        )
        row = conn.execute("SELECT * FROM pending_replies WHERE id = ?", (reply_id,)).fetchone()
    return dict(row)


def list_pending_replies(username: str) -> List[Dict[str, Any]]:
    with _connect(username) as conn:
        rows = conn.execute("SELECT * FROM pending_replies ORDER BY created_at ASC").fetchall()
    return [dict(r) for r in rows]


def get_pending_reply(username: str, reply_id: str) -> Optional[Dict[str, Any]]:
    with _connect(username) as conn:
        row = conn.execute("SELECT * FROM pending_replies WHERE id = ?", (reply_id,)).fetchone()
    return dict(row) if row else None


def delete_pending_reply(username: str, reply_id: str) -> None:
    with _connect(username) as conn:
        cur = conn.execute("DELETE FROM pending_replies WHERE id = ?", (reply_id,))
        if cur.rowcount == 0:
            raise SocialMediaMonitorError(f"No pending reply '{reply_id}'.")
