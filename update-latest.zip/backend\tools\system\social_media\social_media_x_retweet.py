# AthenaUI -- Social Media X (Twitter) Repost Tool
# File: backend/tools/system/social_media/social_media_x_retweet.py
#
# Reposts (retweets) a specific tweet on the user's configured X account.
# Publicly visible and attributable to the account, so this is flagged
# dangerous/requires_approval -- the executor's approval gate will surface
# an Allow/Deny prompt before this ever actually runs. Per X's automation
# rules, repost content relevant to the account's purpose sparingly and
# naturally, never in bulk or as engagement manipulation.

from typing import Any, Dict

capabilities = {
    "needs_bridge": False,
    "needs_filesystem": False,
    "needs_network": True,
    "needs_user": True,
    "is_dangerous": True,
    "requires_approval": True,
}


async def run(args: Dict[str, Any]):
    username = args.get("username")
    tweet_id = (args.get("tweet_id") or "").strip()
    if not tweet_id:
        return {"error": "Missing 'tweet_id' argument (the tweet to repost)."}

    from social_media import settings as social_media_settings
    from social_media.x_client import XClient, XError

    creds = social_media_settings.get_x_credentials(username)
    if not creds:
        return {"error": "No X credentials configured. Ask the user to add them in Social Media settings."}

    client = XClient(**creds)
    try:
        me = await client.get_me()
    except XError as e:
        return {"error": str(e)}

    user_id = (me.get("data") or {}).get("id")
    if not user_id:
        return {"error": "Could not resolve the account's own X user id."}

    try:
        result = await client.retweet(user_id, tweet_id)
    except XError as e:
        return {"error": str(e)}

    return {"ok": True, "result": result}
