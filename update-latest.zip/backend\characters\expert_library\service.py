# AthenaUI v3.7 — Expert Library Service
# File: backend/characters/expert_library/service.py
#
# "Build an Expert": lets a user turn any of their OWN (non-system) characters
# into a subject-matter expert for their business/product -- same private,
# character-gated reference-file pattern as atlas_system_specs_lookup (see
# tools/system/atlas/atlas_system_specs_lookup.py), just user-buildable
# instead of hardcoded to Atlas. The user pastes/uploads source material
# (and optionally a web-search topic to fill gaps), an LLM pass organizes it
# into a categorized markdown reference file private to that character, and
# a matching tool (expert_library_lookup) lets the character actually look
# it up instead of bluffing from general persona knowledge.
#
# Storage:
# - The knowledge file itself: DATA_DIR/users/<username>/characters/<name>/
#   expert_library.md (plain text, same dir convention as gallery/avatar).
# - Metadata (enabled flag, timestamps, source label): a per-character vault
#   preference key "expert_library.<name>" (VaultService.set_preference/
#   get_preference) -- deliberately NOT a new vault_characters SQL column,
#   since that table is a fixed SQLite schema with no migration path for
#   existing users' vault.db files; preferences are the existing safe,
#   schema-free place for this kind of metadata.

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, Optional

from core.runtime.runtime import get_runtime
from vault.service import VaultService

MAX_SOURCE_CHARS = 60000


class ExpertLibraryError(Exception):
    pass


def _preference_key(character: str) -> str:
    return f"expert_library.{character}"


def _library_dir(username: str, character: str):
    runtime = get_runtime()
    return runtime.env.DATA_DIR / "users" / username / "characters" / character


def _library_path(username: str, character: str):
    return _library_dir(username, character) / "expert_library.md"


def get_status(username: str, character: str) -> Dict[str, Any]:
    meta = VaultService.get_preference(username, _preference_key(character), None) or {}
    path = _library_path(username, character)
    return {
        "enabled": bool(meta.get("enabled")) and path.exists(),
        "source_label": meta.get("source_label") or "",
        "used_web_search": bool(meta.get("used_web_search")),
        "updated_at": meta.get("updated_at") or "",
        "char_count": meta.get("char_count") or 0,
    }


def get_content(username: str, character: str) -> Optional[str]:
    status = get_status(username, character)
    if not status["enabled"]:
        return None
    path = _library_path(username, character)
    if not path.exists():
        return None
    return path.read_text(encoding="utf-8")


def delete_library(username: str, character: str) -> None:
    path = _library_path(username, character)
    if path.exists():
        path.unlink()
    VaultService.set_preference(username, _preference_key(character), {"enabled": False})


def _build_prompt(character: str, source_text: str, web_findings: str) -> str:
    parts = [
        f"You are building a private reference library that makes the character '{character}' "
        "a genuine subject-matter expert on a specific business/product, so they can answer "
        "customer questions accurately instead of guessing.",
        "Organize the material below into a clear, well-structured markdown document using "
        "top-level '## Heading' sections (one per topic/category -- e.g. product lines, "
        "specs, pricing, policies, FAQs, whatever the source material actually covers). "
        "Keep real facts, numbers, and specifics intact -- do not invent details that aren't "
        "supported by the material. If something is unclear or missing, note it briefly under "
        "a '## Gaps / Unverified' section instead of making it up.",
        "--- USER-PROVIDED SOURCE MATERIAL ---",
        source_text.strip() or "(none provided)",
    ]
    if web_findings.strip():
        parts.append("--- SUPPLEMENTARY WEB SEARCH FINDINGS ---")
        parts.append(web_findings.strip())
    parts.append(
        "Return ONLY the finished markdown document -- no preamble, no commentary about what "
        "you did."
    )
    return "\n\n".join(parts)


async def build_library(
    username: str,
    character: str,
    source_text: str,
    source_label: str,
    website_query: str = "",
) -> Dict[str, Any]:
    source_text = (source_text or "").strip()
    website_query = (website_query or "").strip()
    if not source_text and not website_query:
        raise ExpertLibraryError("Provide source text/a file, a web-search topic, or both.")

    source_text = source_text[:MAX_SOURCE_CHARS]

    web_findings = ""
    used_web_search = False
    if website_query:
        try:
            from tools.system.search.service import web_search as web_search_impl

            result = await web_search_impl({"query": website_query, "top_k": 6})
            items = result.get("items") or [] if isinstance(result, dict) else []
            if items:
                web_findings = "\n".join(
                    f"- {it.get('title') or ''}: {it.get('snippet') or ''} ({it.get('link') or ''})"
                    for it in items
                )
            elif isinstance(result, dict) and result.get("error"):
                web_findings = f"(Web search returned no results: {result['error']})"
            used_web_search = True
        except Exception as e:
            web_findings = f"(Web search failed, continuing with uploaded material only: {e})"

    from characters.backstory_engine.generator import call_llm

    prompt = _build_prompt(character, source_text, web_findings)
    document = call_llm(prompt, username).strip()
    if not document:
        raise ExpertLibraryError("The AI builder pass returned no content -- try again.")

    path = _library_path(username, character)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(document, encoding="utf-8")

    meta = {
        "enabled": True,
        "source_label": source_label or "Pasted text",
        "used_web_search": used_web_search,
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "char_count": len(document),
    }
    VaultService.set_preference(username, _preference_key(character), meta)

    return {"status": "ok", **meta}
