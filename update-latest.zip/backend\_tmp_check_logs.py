import sqlite3
import json

con = sqlite3.connect("logs_system/db/tail_logs.db")
cur = con.cursor()
cur.execute("select name from sqlite_master where type='table'")
print("TABLES:", cur.fetchall())

cur.execute("PRAGMA table_info(tail_log_entries)")
print("COLUMNS:", cur.fetchall())

cur.execute("select count(*) from tail_log_entries")
print("COUNT:", cur.fetchone())

cur.execute("select timestamp, level, event, details from tail_log_entries order by id desc limit 40")
for row in cur.fetchall():
    ts, level, event, details = row
    print("----")
    print(ts, level, event)
    try:
        d = json.loads(details) if details else {}
        print(json.dumps(d)[:500])
    except Exception:
        print(str(details)[:500])
