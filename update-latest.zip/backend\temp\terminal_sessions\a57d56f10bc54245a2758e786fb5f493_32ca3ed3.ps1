$ErrorActionPreference = 'Continue'
Set-Location -LiteralPath 'C:\AthenaWorkspace'
$host.UI.RawUI.WindowTitle = 'AthenaUI Agent Terminal'
Remove-Module PSReadLine -Force -ErrorAction SilentlyContinue
foreach ($__athena_scope in 'Machine','User') {
  [System.Environment]::GetEnvironmentVariables($__athena_scope).GetEnumerator() | ForEach-Object {
    if ($_.Key -ieq 'Path') { return }
    Set-Item -Path ("Env:" + $_.Key) -Value $_.Value -ErrorAction SilentlyContinue
  }
}
$__athena_machine_path = [System.Environment]::GetEnvironmentVariable('Path','Machine')
$__athena_user_path = [System.Environment]::GetEnvironmentVariable('Path','User')
$env:Path = @($__athena_machine_path, $__athena_user_path, $env:Path) -join ';'
Start-Transcript -Path 'C:\AthenaUi\backend\temp\terminal_sessions\a57d56f10bc54245a2758e786fb5f493.log' -Append | Out-Null
$__athena_ok = $true
Write-Host '> echo test-access'
try {
    Invoke-Expression 'echo test-access'
    $__athena_ok = $? -and ($LASTEXITCODE -eq $null -or $LASTEXITCODE -eq 0)
} catch {
    $__athena_ok = $false
    Write-Host $_.Exception.Message
}
$__athena_code = if ($LASTEXITCODE -ne $null) { $LASTEXITCODE } elseif ($__athena_ok) { 0 } else { 1 }
Write-Host "##ATHENA_TERMINAL_DONE## exit=$__athena_code"
