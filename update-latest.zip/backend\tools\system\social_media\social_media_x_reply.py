# AthenaUI -- Social Media X (Twitter) Reply Tool
# File: backend/tools/system/social_media/social_media_x_reply.py
#
# Replies to a specific tweet on the user's configured X account. Publicly
# visible and irreversible once posted, so this is flagged dangerous/
# requires_approval -- the executor's approval gate will surface an
# Allow/Deny prompt before this ever actually runs. Per X's automation
# rules, only use this for a tweet from someone who has already mentioned
# or replied to this account first (see social_media_x_check_mentions).

from typing import Any, Dict

capabilities = {
    "needs_bridge": False,
    "needs_filesystem": False,
    "needs_network": True,
    "needs_user": True,
    "is_dangerous": True,
    "requires_approval": True,
}


async def run(args: Dict[str, Any]):
    username = args.get("username")
    tweet_id = (args.get("tweet_id") or "").strip()
    content = (args.get("content") or "").strip()
    if not tweet_id:
        return {"error": "Missing 'tweet_id' argument (the tweet to reply to)."}
    if not content:
        return {"error": "Missing 'content' argument."}

    from social_media import settings as social_media_settings
    from social_media.x_client import XClient, XError

    creds = social_media_settings.get_x_credentials(username)
    if not creds:
        return {"error": "No X credentials configured. Ask the user to add them in Social Media settings."}

    client = XClient(**creds)
    try:
        result = await client.reply_tweet(content, tweet_id)
    except XError as e:
        return {"error": str(e)}

    return {"ok": True, "result": result}
