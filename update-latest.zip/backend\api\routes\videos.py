# AthenaUI v3.5 — Video Generation API
# File: backend/api/routes/videos.py
"""
Routes for the standalone Video Generation page. Backed by xAI and Gemini
(Gemini Omni Flash) -- see llm/video_generation/service.py for details/limits.
"""

import asyncio
from typing import Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile

from auth.service import get_current_user
from llm.video_generation.service import VideoGenerationService

router = APIRouter(prefix="/videos", tags=["videos"])

service = VideoGenerationService()


@router.get("/capabilities")
async def get_video_capabilities(provider_id: Optional[str] = None, user: dict = Depends(get_current_user)):
    return await service.check_capability_for_user(user["username"], provider_id=provider_id)


@router.get("/gallery")
async def get_video_gallery(user: dict = Depends(get_current_user)):
    return {"videos": service.list_videos(user["username"])}


@router.post("/generate")
async def generate_video(
    prompt: str = Form(...),
    duration: int = Form(6),
    provider_id: Optional[str] = Form(None),
    model_id: Optional[str] = Form(None),
    image: Optional[UploadFile] = File(None),
    user: dict = Depends(get_current_user),
):
    if not prompt or not prompt.strip():
        raise HTTPException(status_code=400, detail="prompt is required.")

    image_bytes = None
    image_content_type = None
    if image is not None:
        image_bytes = await image.read()
        image_content_type = image.content_type

    return await asyncio.to_thread(
        service.generate,
        username=user["username"],
        prompt=prompt,
        provider_id=provider_id,
        model_id=model_id,
        duration=duration,
        image_bytes=image_bytes,
        image_content_type=image_content_type,
    )
