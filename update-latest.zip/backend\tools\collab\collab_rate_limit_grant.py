# AthenaUI v3.7 — Collab Rate Limit Grant (internal, approval-only)
# File: backend/tools/collab/collab_rate_limit_grant.py
#
# NOT meant to be called directly by an agent's own judgment -- this is the
# tool_name collab_start_discussion.py registers a pending approval under
# once a character hits its Collab "slow mode" limit. It only actually runs
# when the user clicks Allow on that sidebar card (code_suite/changes/
# service.py's ChangesetService.apply() replays it). Marked requires_approval
# too, so even a direct call still has to go through the same Allow/Deny gate
# instead of silently self-granting.

from typing import Any, Dict

from chat.collab import rate_limit

capabilities = {
    "needs_filesystem": False,
    "needs_bridge": False,
    "needs_network": False,
    "needs_user": True,
    "requires_approval": True,
}


async def run(args: Dict[str, Any]) -> str:
    username = args.get("username")
    character = args.get("character")

    if not username:
        return "[ERROR] Missing 'username' argument."
    if not character:
        return "[ERROR] Missing 'character' argument."

    new_limit = rate_limit.grant_bonus(username, character)
    return f"Granted {character} +{rate_limit.GRANT_SIZE} more Collab discussions (new limit: {new_limit} for this burst)."
