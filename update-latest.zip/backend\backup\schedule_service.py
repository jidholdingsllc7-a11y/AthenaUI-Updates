# AthenaUI v3.5 — Scheduled (Automatic) Backup Configuration
# File: backend/backup/schedule_service.py
#
# Stores each user's recurring-backup configuration in their Vault's
# app-key store (same encrypted-at-rest storage tier as any other saved
# secret/API key -- see vault/controller.py's set_app_key/get_app_key,
# already used by scheduler/service.py for agent-proposed jobs). This is
# deliberately a SEPARATE, simpler mechanism from that agent-task
# scheduler: a scheduled backup isn't an agent action requiring approval,
# it's just "run this backup automatically every so often."
#
# The passphrase is stored here too (encrypted at rest via the same vault
# key) so an unattended scheduled run doesn't need to prompt anyone -- the
# user explicitly opted into that tradeoff when setting up the schedule
# (on-demand/manual backups from the Backup page never store the
# passphrase; it's only ever entered there to encrypt/decrypt in memory).

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional

from vault.controller import VaultController

SCHEDULE_APP_NAME = "backup_schedule"

VALID_FREQUENCIES = {"daily", "weekly", "monthly"}


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _compute_next_run(frequency: str, time_of_day: str, after: Optional[datetime] = None) -> str:
    after = after or _now()
    try:
        hour, minute = (int(p) for p in time_of_day.split(":", 1))
    except Exception:
        hour, minute = 3, 0

    candidate = after.replace(hour=hour, minute=minute, second=0, microsecond=0)
    if candidate <= after:
        candidate += timedelta(days=1)

    if frequency == "weekly":
        while candidate.weekday() != 0:  # next Monday
            candidate += timedelta(days=1)
    elif frequency == "monthly":
        candidate = candidate.replace(day=1)
        if candidate <= after:
            year = candidate.year + (1 if candidate.month == 12 else 0)
            month = 1 if candidate.month == 12 else candidate.month + 1
            candidate = candidate.replace(year=year, month=month)

    return candidate.isoformat().replace("+00:00", "Z")


def get_schedule(username: str) -> Dict[str, Any]:
    data = VaultController.get_app_key(username, SCHEDULE_APP_NAME) or {}
    return {
        "enabled": bool(data.get("enabled")),
        "frequency": data.get("frequency") or "weekly",
        "time_of_day": data.get("time_of_day") or "03:00",
        "destination_folder": data.get("destination_folder") or "",
        "selection": data.get("selection") or {"full_system": True},
        "has_passphrase": bool(data.get("passphrase")),
        "last_run_at": data.get("last_run_at"),
        "next_run_at": data.get("next_run_at"),
        "last_status": data.get("last_status"),
    }


def set_schedule(
    username: str,
    *,
    enabled: bool,
    frequency: str,
    time_of_day: str,
    destination_folder: str,
    selection: Dict[str, Any],
    passphrase: Optional[str] = None,
) -> Dict[str, Any]:
    if frequency not in VALID_FREQUENCIES:
        raise ValueError(f"Invalid frequency: {frequency}")
    if enabled and not destination_folder:
        raise ValueError("A destination folder is required to enable scheduled backups.")

    existing = VaultController.get_app_key(username, SCHEDULE_APP_NAME) or {}
    effective_passphrase = passphrase if passphrase else existing.get("passphrase")
    if enabled and not effective_passphrase:
        raise ValueError("A passphrase is required to enable scheduled backups.")

    next_run_at = _compute_next_run(frequency, time_of_day) if enabled else None

    payload: Dict[str, Any] = {
        "enabled": bool(enabled),
        "frequency": frequency,
        "time_of_day": time_of_day,
        "destination_folder": destination_folder,
        "selection": selection,
        "passphrase": effective_passphrase,
        "last_run_at": existing.get("last_run_at"),
        "last_status": existing.get("last_status"),
        "next_run_at": next_run_at,
    }
    VaultController.set_app_key(username, SCHEDULE_APP_NAME, payload)
    return get_schedule(username)


def clear_schedule(username: str) -> None:
    VaultController.set_app_key(username, SCHEDULE_APP_NAME, {
        "enabled": False,
        "frequency": "weekly",
        "time_of_day": "03:00",
        "destination_folder": "",
        "selection": {"full_system": True},
        "passphrase": None,
        "last_run_at": None,
        "next_run_at": None,
        "last_status": None,
    })


def record_run(username: str, *, ok: bool, message: str) -> None:
    data = VaultController.get_app_key(username, SCHEDULE_APP_NAME) or {}
    if not data:
        return
    data["last_run_at"] = _now().isoformat().replace("+00:00", "Z")
    data["last_status"] = ("ok: " if ok else "failed: ") + message
    if data.get("enabled"):
        data["next_run_at"] = _compute_next_run(data.get("frequency") or "weekly", data.get("time_of_day") or "03:00")
    VaultController.set_app_key(username, SCHEDULE_APP_NAME, data)


def due_schedules() -> Dict[str, Dict[str, Any]]:
    """Returns {username: schedule_dict} for every user whose scheduled
    backup is enabled and due to run now."""
    from backup.service import _load_users_json  # local import avoids a cycle at module load

    due: Dict[str, Dict[str, Any]] = {}
    now = _now()
    for username in _load_users_json().keys():
        data = VaultController.get_app_key(username, SCHEDULE_APP_NAME) or {}
        if not data.get("enabled"):
            continue
        next_run_at = data.get("next_run_at")
        if not next_run_at:
            continue
        try:
            due_at = datetime.fromisoformat(str(next_run_at).replace("Z", "+00:00"))
        except Exception:
            continue
        if due_at <= now:
            due[username] = data
    return due
