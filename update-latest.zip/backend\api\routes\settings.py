﻿# AthenaUI v3.5 — Settings API Routes
# File: backend/api/routes/settings.py
# Updated: 2026-07-27 19:49 CDT

from __future__ import annotations

import asyncio
import json
import re
from pathlib import Path
from typing import Any, Dict, List

from fastapi import APIRouter, Body, Depends, HTTPException

from api.deps.auth_middleware import get_current_user
from config.loader import Config
from llm.registry.registry import LLMRegistry
from llm.provider_detection.provider_auto_detector import detect_provider
from llm.provider_detection.pricing_data import get_static_pricing, format_price_label
from llm.routers.providers import ALL_PROVIDERS
from vault.service import VaultService
from emailing.service import EmailAccountsService, EmailServiceError
from settings.service import SettingsService
from settings.schema import SettingsSchemaError

router = APIRouter(prefix="/settings", tags=["settings"])
ALLOWED_PIPELINES = {"chat", "image", "code", "code_b", "analyze", "video"}


def _provider_label(provider_id: str) -> str:
    return provider_id.replace("_", " ").title()


def _username_from_user(user: Any) -> str:
    if isinstance(user, dict):
        username = user.get("username")
    else:
        username = getattr(user, "username", None)

    if not username:
        raise HTTPException(status_code=401, detail="Authentication required.")

    return str(username)


def _normalize_pipeline(value: Any) -> str:
    pipeline = str(value or "chat").strip().lower()
    if pipeline not in ALLOWED_PIPELINES:
        raise HTTPException(status_code=400, detail=f"Unsupported pipeline: {pipeline}")
    return pipeline


def _resolve_provider_api_key(username: str, provider_id: str) -> str:
    for pipeline in ["chat", "image", "code", "code_b", "analyze"]:
        key_data = VaultService.get_provider_key(username, pipeline, provider_id)
        if isinstance(key_data, dict):
            api_key = str(key_data.get("api_key", "")).strip()
            if api_key:
                return api_key

    return ""


def _pricing_for_model(provider_id: str, model_id: str, live_pricing: Dict[str, Dict[str, float]]) -> Any:
    return live_pricing.get(model_id) or get_static_pricing(provider_id, model_id)


def _resolve_provider_key_data(username: str, provider_id: str) -> Dict[str, Any]:
    for pipeline in ["chat", "image", "code", "code_b", "analyze"]:
        key_data = VaultService.get_provider_key(username, pipeline, provider_id)
        if isinstance(key_data, dict) and str(key_data.get("api_key", "")).strip():
            return key_data
    return {}


def _build_detection_config(provider_id: str, key_data: Dict[str, Any]) -> Dict[str, Any]:
    api_key = str(key_data.get("api_key", "")).strip()

    if provider_id == "bedrock":
        region = str(key_data.get("region", "")).strip() or "us-east-1"
        if str(key_data.get("auth_mode", "iam")).strip().lower() == "api_key":
            return {"bearer_token": api_key, "region": region}
        return {
            "aws_access_key": api_key,
            "aws_secret_key": str(key_data.get("secret", "")).strip(),
            "region": region,
        }

    return {"api_key": api_key}


async def _detect_model_options_live(username: str, provider_id: str) -> List[Dict[str, Any]]:
    if provider_id == "bedrock":
        key_data = _resolve_provider_key_data(username, provider_id)
        if not key_data:
            return []
        detection_config = _build_detection_config(provider_id, key_data)
    else:
        api_key = _resolve_provider_api_key(username, provider_id)
        if not api_key:
            return []
        detection_config = _build_detection_config(provider_id, {"api_key": api_key})

    def _run_detection() -> List[Dict[str, Any]]:
        result = detect_provider(provider_id, detection_config)
        if not result.available:
            return []

        unique_ids = sorted({str(model_id).strip() for model_id in result.models if str(model_id).strip()})
        options = []
        for model_id in unique_ids:
            pricing = _pricing_for_model(provider_id, model_id, result.model_pricing)
            options.append(
                {
                    "id": model_id,
                    "label": model_id,
                    "pricing": pricing,
                    "price_label": format_price_label(pricing),
                }
            )
        return options

    return await asyncio.to_thread(_run_detection)


def _ensure_llm_registry_loaded() -> bool:
    try:
        Config.load()
        LLMRegistry.load()
        return True
    except Exception:
        return False


def _model_label(model_id: str) -> str:
    try:
        model_cfg = LLMRegistry.get_model(model_id)
        return str(model_cfg.get("name") or model_cfg.get("display_name") or model_id)
    except Exception:
        return model_id


def _get_model_options(provider_id: str, capability: str) -> List[Dict[str, Any]]:
    if not _ensure_llm_registry_loaded():
        return []

    model_ids = LLMRegistry.list_models(provider_id)
    options: List[Dict[str, Any]] = []

    for model_id in model_ids:
        if capability == "image" and not LLMRegistry.model_supports_images(model_id):
            continue

        pricing = get_static_pricing(provider_id, model_id)
        options.append(
            {
                "id": model_id,
                "label": _model_label(model_id),
                "pricing": pricing,
                "price_label": format_price_label(pricing),
            }
        )

    return options


@router.get("/providers")
async def list_providers(user: Dict[str, Any] = Depends(get_current_user)):
    _ = _username_from_user(user)
    return {
        "providers": [
            {
                "id": provider_id,
                "label": _provider_label(provider_id),
            }
            for provider_id in ALL_PROVIDERS
        ]
    }


@router.get("/provider-key/{provider_id}")
async def get_provider_key(
    provider_id: str,
    pipeline: str = "chat",
    user: Dict[str, Any] = Depends(get_current_user),
):
    username = _username_from_user(user)
    normalized_pipeline = _normalize_pipeline(pipeline)
    key_data = VaultService.get_provider_key(username, normalized_pipeline, provider_id)
    return {
        "pipeline": normalized_pipeline,
        "provider_id": provider_id,
        "has_key": bool(key_data and key_data.get("api_key")),
        "key_data": key_data or {},
    }


@router.post("/provider-key")
async def set_provider_key(payload: Dict[str, Any] = Body(...), user: Dict[str, Any] = Depends(get_current_user)):
    username = _username_from_user(user)

    pipeline = _normalize_pipeline(payload.get("pipeline", "chat"))
    provider_id = str(payload.get("provider_id", "")).strip().lower()
    api_key = str(payload.get("api_key", "")).strip()

    if not provider_id:
        raise HTTPException(status_code=400, detail="provider_id is required")
    if not api_key:
        raise HTTPException(status_code=400, detail="api_key is required")

    if provider_id not in ALL_PROVIDERS:
        raise HTTPException(status_code=400, detail=f"Unsupported provider_id: {provider_id}")

    # Bedrock needs either a full AWS credential set (IAM access key +
    # mandatory secret) or a single bearer-token API key -- "api_key" above
    # holds the Access Key ID in IAM mode, or the bearer token itself in
    # api_key mode, which needs no secret/session token at all.
    bedrock_auth_mode = str(payload.get("auth_mode", "iam")).strip().lower()
    if provider_id == "bedrock" and bedrock_auth_mode != "api_key" and not str(payload.get("secret", "")).strip():
        raise HTTPException(status_code=400, detail="AWS Secret Access Key is required for Bedrock (IAM mode).")

    existing_key_data = VaultService.get_provider_key(username, pipeline, provider_id) or {}
    key_data = dict(existing_key_data)
    key_data["api_key"] = api_key
    if provider_id == "bedrock":
        key_data["auth_mode"] = bedrock_auth_mode
        if bedrock_auth_mode == "api_key":
            # No access key/secret pair in this mode -- drop any stale IAM
            # fields left over from a previous save in the other mode.
            key_data.pop("secret", None)
            key_data.pop("session_token", None)

    # Optional fields for providers that need them
    if payload.get("secret"):
        key_data["secret"] = str(payload.get("secret"))
    if payload.get("endpoint"):
        key_data["endpoint"] = str(payload.get("endpoint"))
    if payload.get("session_token"):
        key_data["session_token"] = str(payload.get("session_token"))
    if payload.get("region"):
        key_data["region"] = str(payload.get("region"))

    VaultService.set_provider_key(username, pipeline, provider_id, key_data)

    return {
        "ok": True,
        "pipeline": pipeline,
        "provider_id": provider_id,
    }


@router.get("/provider-keys")
async def list_provider_keys(user: Dict[str, Any] = Depends(get_current_user)):
    username = _username_from_user(user)
    vault = VaultService.get_vault(username)

    # Each pipeline (chat/image/code) can have its own independent key per
    # provider -- a provider saved under "code" must NOT show up as
    # available/configured under "chat" just because *some* pipeline has a
    # key for it (that previously made the Settings dropdowns claim a
    # provider was ready for a pipeline it actually had no key for).
    result: Dict[str, List[Dict[str, str]]] = {}
    for pipeline in ALLOWED_PIPELINES:
        providers_map = getattr(vault.api_keys, pipeline, {}) or {}
        providers_with_keys = {
            provider_id
            for provider_id, key_data in providers_map.items()
            if isinstance(key_data, dict) and key_data.get("api_key")
        }

        saved = [{"id": provider_id, "label": _provider_label(provider_id)} for provider_id in providers_with_keys]
        result[pipeline] = sorted(saved, key=lambda item: item["id"])

    return {"pipelines": result}


@router.get("/billing-fallback")
async def get_billing_fallback_settings(user: Dict[str, Any] = Depends(get_current_user)):
    username = _username_from_user(user)
    settings = SettingsService.get_settings(username)
    return settings.get("billing_fallback") or {}


@router.post("/billing-fallback")
async def set_billing_fallback_settings(payload: Dict[str, Any] = Body(...), user: Dict[str, Any] = Depends(get_current_user)):
    username = _username_from_user(user)

    enabled = bool(payload.get("enabled"))
    notify_channel = str(payload.get("notify_channel") or "email").strip().lower()
    if notify_channel not in ("email", "sms", "none"):
        raise HTTPException(status_code=400, detail="notify_channel must be one of: email, sms, none.")
    notify_phone_number = str(payload.get("notify_phone_number") or "").strip()

    raw_chain = payload.get("chain")
    if not isinstance(raw_chain, list):
        raise HTTPException(status_code=400, detail="chain must be a list.")

    chain: List[Dict[str, str]] = []
    for entry in raw_chain:
        if not isinstance(entry, dict):
            raise HTTPException(status_code=400, detail="Each chain entry must be an object.")
        provider_id = str(entry.get("provider_id") or "").strip().lower()
        model_id = str(entry.get("model_id") or "").strip()
        if not provider_id or not model_id:
            continue
        if provider_id not in ALL_PROVIDERS:
            raise HTTPException(status_code=400, detail=f"Unsupported provider_id in chain: {provider_id}")
        chain.append({"provider_id": provider_id, "model_id": model_id})

    try:
        SettingsService.update_setting(username, "billing_fallback", {
            "enabled": enabled,
            "notify_channel": notify_channel,
            "notify_phone_number": notify_phone_number,
            "chain": chain,
        })
    except SettingsSchemaError as e:
        raise HTTPException(status_code=400, detail=str(e))

    return SettingsService.get_settings(username).get("billing_fallback") or {}


@router.get("/models")
async def list_models_for_provider(
    provider_id: str,
    capability: str = "chat",
    user: Dict[str, Any] = Depends(get_current_user),
):
    username = _username_from_user(user)
    normalized_provider = str(provider_id or "").strip().lower()
    normalized_capability = _normalize_pipeline(capability)

    if normalized_provider not in ALL_PROVIDERS:
        raise HTTPException(status_code=400, detail=f"Unsupported provider_id: {normalized_provider}")

    options = _get_model_options(normalized_provider, normalized_capability)
    if not options:
        options = await _detect_model_options_live(username, normalized_provider)

    return {
        "provider_id": normalized_provider,
        "capability": normalized_capability,
        "models": options,
    }


@router.get("/llm-selections")
async def get_llm_selections(user: Dict[str, Any] = Depends(get_current_user)):
    username = _username_from_user(user)
    vault = VaultService.get_vault(username)

    chat_provider = VaultService.get_preference(username, "llm.provider_id", "") or vault.api_keys.chat_default_provider or ""
    image_provider = VaultService.get_preference(username, "llm.image_provider_id", "") or vault.api_keys.image_default_provider or ""
    code_provider = VaultService.get_preference(username, "llm.code_provider_id", "") or vault.api_keys.code_default_provider or ""
    code_b_provider = VaultService.get_preference(username, "llm.code_b_provider_id", "") or vault.api_keys.code_b_default_provider or ""
    # No system-wide default fallback for analyze -- an unset analyze
    # provider means "use the chat pipeline's own model" (see
    # ChatEngine._get_active_analyze_model), so leave it genuinely blank
    # here rather than implying a dedicated one is already configured.
    analyze_provider = VaultService.get_preference(username, "llm.analyze_provider_id", "") or vault.api_keys.analyze_default_provider or ""

    return {
        "selections": {
            "chat": {
                "provider_id": chat_provider,
                "model_id": VaultService.get_preference(username, "llm.chat_model", "") or "",
            },
            "image": {
                "provider_id": image_provider,
                "model_id": VaultService.get_preference(username, "llm.image_model", "") or "",
            },
            "code": {
                "provider_id": code_provider,
                "model_id": VaultService.get_preference(username, "llm.code_model", "") or "",
            },
            "code_b": {
                "provider_id": code_b_provider,
                "model_id": VaultService.get_preference(username, "llm.code_b_model", "") or "",
            },
            "analyze": {
                "provider_id": analyze_provider,
                "model_id": VaultService.get_preference(username, "llm.analyze_model", "") or "",
            },
        }
    }


@router.post("/llm-selections")
async def save_llm_selections(payload: Dict[str, Any] = Body(...), user: Dict[str, Any] = Depends(get_current_user)):
    username = _username_from_user(user)

    chat = payload.get("chat", {}) if isinstance(payload.get("chat"), dict) else {}
    image = payload.get("image", {}) if isinstance(payload.get("image"), dict) else {}
    code = payload.get("code", {}) if isinstance(payload.get("code"), dict) else {}
    # Code Model B -- the second model in a Synergy discussion (optional;
    # Synergy mode is simply unavailable until both A and B are configured).
    code_b = payload.get("code_b", {}) if isinstance(payload.get("code_b"), dict) else {}
    # Optional: an unset analyze provider means "use the chat model for
    # image analysis too" (ChatEngine._get_active_analyze_model already
    # falls back that way) -- this section exists purely so a user CAN
    # pick a dedicated vision model instead, never a requirement.
    analyze = payload.get("analyze", {}) if isinstance(payload.get("analyze"), dict) else {}

    chat_provider = str(chat.get("provider_id", "")).strip().lower()
    image_provider = str(image.get("provider_id", "")).strip().lower()
    code_provider = str(code.get("provider_id", "")).strip().lower()
    code_b_provider = str(code_b.get("provider_id", "")).strip().lower()
    analyze_provider = str(analyze.get("provider_id", "")).strip().lower()
    chat_model = str(chat.get("model_id", "")).strip()
    image_model = str(image.get("model_id", "")).strip()
    code_model = str(code.get("model_id", "")).strip()
    code_b_model = str(code_b.get("model_id", "")).strip()
    analyze_model = str(analyze.get("model_id", "")).strip()

    for provider_id in [chat_provider, image_provider, code_provider, code_b_provider, analyze_provider]:
        if provider_id and provider_id not in ALL_PROVIDERS:
            raise HTTPException(status_code=400, detail=f"Unsupported provider_id: {provider_id}")

    if chat_provider and not chat_model:
        options = _get_model_options(chat_provider, "chat")
        if not options:
            options = await _detect_model_options_live(username, chat_provider)
        if options:
            chat_model = options[0]["id"]

    if image_provider and not image_model:
        options = _get_model_options(image_provider, "image")
        if not options:
            options = await _detect_model_options_live(username, image_provider)
        if options:
            image_model = options[0]["id"]

    if code_provider and not code_model:
        options = _get_model_options(code_provider, "code")
        if not options:
            options = await _detect_model_options_live(username, code_provider)
        if options:
            code_model = options[0]["id"]

    if code_b_provider and not code_b_model:
        options = _get_model_options(code_b_provider, "code")
        if not options:
            options = await _detect_model_options_live(username, code_b_provider)
        if options:
            code_b_model = options[0]["id"]

    if analyze_provider and not analyze_model:
        options = _get_model_options(analyze_provider, "analyze")
        if not options:
            options = await _detect_model_options_live(username, analyze_provider)
        if options:
            analyze_model = options[0]["id"]

    if _ensure_llm_registry_loaded():
        validation_sets = [
            (chat_provider, chat_model),
            (image_provider, image_model),
            (code_provider, code_model),
            (code_b_provider, code_b_model),
            (analyze_provider, analyze_model),
        ]
        for provider_id, model_id in validation_sets:
            if provider_id and model_id:
                try:
                    LLMRegistry.validate_provider_and_model(provider_id, model_id)
                except Exception as exc:
                    raise HTTPException(status_code=400, detail=str(exc))

    VaultService.set_preference(username, "llm.provider_id", chat_provider)
    VaultService.set_preference(username, "llm.chat_model", chat_model)
    VaultService.set_preference(username, "llm.image_provider_id", image_provider)
    VaultService.set_preference(username, "llm.image_model", image_model)
    VaultService.set_preference(username, "llm.code_provider_id", code_provider)
    VaultService.set_preference(username, "llm.code_model", code_model)
    VaultService.set_preference(username, "llm.code_b_provider_id", code_b_provider)
    VaultService.set_preference(username, "llm.code_b_model", code_b_model)
    VaultService.set_preference(username, "llm.analyze_provider_id", analyze_provider)
    VaultService.set_preference(username, "llm.analyze_model", analyze_model)

    vault = VaultService.get_vault(username)
    vault.api_keys.chat_default_provider = chat_provider or None
    vault.api_keys.image_default_provider = image_provider or None
    vault.api_keys.code_default_provider = code_provider or None
    vault.api_keys.code_b_default_provider = code_b_provider or None
    vault.api_keys.analyze_default_provider = analyze_provider or None
    VaultService.save_vault(username, vault)

    return {"ok": True}


@router.get("/app-keys")
async def list_app_keys(user: Dict[str, Any] = Depends(get_current_user)):
    username = _username_from_user(user)
    vault = VaultService.get_vault(username)
    apps = vault.api_keys.apps or {}

    return {
        "items": [
            {
                "name": name,
                "has_value_1": bool(data.get("value_1")),
                "has_value_2": bool(data.get("value_2")),
                "has_value_3": bool(data.get("value_3")),
                "has_secret": bool(data.get("secret")),
            }
            for name, data in apps.items()
        ]
    }


@router.post("/app-key")
async def save_app_key(payload: Dict[str, Any] = Body(...), user: Dict[str, Any] = Depends(get_current_user)):
    username = _username_from_user(user)

    name = str(payload.get("name", "")).strip().lower()
    value_1 = str(payload.get("value_1", "")).strip()
    value_2 = str(payload.get("value_2", "")).strip()
    value_3 = str(payload.get("value_3", "")).strip()

    if not name:
        raise HTTPException(status_code=400, detail="name is required")
    if not value_1:
        raise HTTPException(status_code=400, detail="value_1 is required")

    key_data: Dict[str, Any] = {
        "value_1": value_1,
    }

    if value_2:
        key_data["value_2"] = value_2
    if value_3:
        key_data["value_3"] = value_3

    # Optional alias fields for clarity in external integrations.
    if payload.get("api_key"):
        key_data["api_key"] = str(payload.get("api_key"))
    if payload.get("secret"):
        key_data["secret"] = str(payload.get("secret"))
    if payload.get("endpoint"):
        key_data["endpoint"] = str(payload.get("endpoint"))

    VaultService.set_app_api_key(username, name, key_data)

    return {
        "ok": True,
        "name": name,
    }


# ---------------------------------------------------------------------
#  EMAIL ACCOUNTS (multi-account, per-agent shareable "system email")
#
#  Lets the user (re-)enter the Gmail App Password credentials originally
#  captured (or meant to be captured) during onboarding's Step1SystemEmail,
#  and optionally add MORE accounts -- each independently shared with either
#  every agent ("all") or one specific named character, matching the same
#  owner/share model as the agent SQL database tool.
# ---------------------------------------------------------------------

@router.get("/email-accounts")
async def list_email_accounts(user: Dict[str, Any] = Depends(get_current_user)):
    username = _username_from_user(user)
    return {"accounts": EmailAccountsService.list_accounts_public(username)}


@router.post("/email-accounts")
async def add_email_account(payload: Dict[str, Any] = Body(...), user: Dict[str, Any] = Depends(get_current_user)):
    username = _username_from_user(user)

    try:
        account = EmailAccountsService.add_account(
            username=username,
            label=str(payload.get("label", "")),
            email=str(payload.get("email", "")),
            app_password=str(payload.get("app_password", "")),
            access=payload.get("access", "all"),
            smtp_host=payload.get("smtp_host"),
            smtp_port=payload.get("smtp_port"),
            imap_host=payload.get("imap_host"),
            imap_port=payload.get("imap_port"),
        )
    except EmailServiceError as e:
        raise HTTPException(status_code=400, detail=str(e))

    return {"ok": True, "id": account["id"]}


@router.put("/email-accounts/{account_id}")
async def update_email_account(
    account_id: str,
    payload: Dict[str, Any] = Body(...),
    user: Dict[str, Any] = Depends(get_current_user),
):
    username = _username_from_user(user)

    fields: Dict[str, Any] = {}
    for key in ("label", "email", "app_password", "access", "smtp_host", "smtp_port", "imap_host", "imap_port"):
        if key in payload:
            fields[key] = payload[key]

    try:
        EmailAccountsService.update_account(username, account_id, **fields)
    except EmailServiceError as e:
        raise HTTPException(status_code=404, detail=str(e))

    return {"ok": True}


@router.delete("/email-accounts/{account_id}")
async def delete_email_account(account_id: str, user: Dict[str, Any] = Depends(get_current_user)):
    username = _username_from_user(user)

    try:
        EmailAccountsService.delete_account(username, account_id)
    except EmailServiceError as e:
        raise HTTPException(status_code=404, detail=str(e))

    return {"ok": True}


@router.get("/theme")
async def get_theme(user: Dict[str, Any] = Depends(get_current_user)):
    """Returns the user's saved theme preference (preset name + any custom
    color overrides), or an empty default if none has been saved yet."""
    username = _username_from_user(user)
    theme = VaultService.get_preference(username, "ui.theme", default=None)
    if not isinstance(theme, dict):
        theme = {"preset": "day", "overrides": {}}
    return theme


@router.post("/theme")
async def save_theme(payload: Dict[str, Any] = Body(...), user: Dict[str, Any] = Depends(get_current_user)):
    """Saves the user's theme preference: `preset` ("day" | "dark") plus an
    `overrides` dict of any custom-picked color values keyed by role name."""
    username = _username_from_user(user)
    preset = payload.get("preset") if payload.get("preset") in ("day", "dark") else "day"
    overrides = payload.get("overrides")
    theme = {
        "preset": preset,
        "overrides": overrides if isinstance(overrides, dict) else {},
    }
    VaultService.set_preference(username, "ui.theme", theme)
    return {"ok": True, **theme}


# ---------------------------------------------------------------------
#  NAMED / SAVED THEMES -- a small personal library of custom themes the
#  user has explicitly named and saved (separate from the single "active"
#  theme above), so they can switch between several looks they've built.
#  Each theme is saved as its own JSON file, named after the title the user
#  gave it, under DATA_DIR/users/{username}/themes/ -- rather than one big
#  list crammed into a single vault preference key.
# ---------------------------------------------------------------------

def _themes_dir(username: str) -> Path:
    from core.runtime.runtime import get_runtime

    d = get_runtime().env.DATA_DIR / "users" / username / "themes"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _slugify_theme_name(name: str) -> str:
    slug = re.sub(r"[^a-zA-Z0-9]+", "_", name.strip()).strip("_").lower()
    return slug or "theme"


@router.get("/themes")
async def list_saved_themes(user: Dict[str, Any] = Depends(get_current_user)):
    username = _username_from_user(user)
    themes: List[Dict[str, Any]] = []
    for path in sorted(_themes_dir(username).glob("*.json")):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        if isinstance(data, dict):
            data.setdefault("id", path.stem)
            themes.append(data)
    return {"themes": themes}


@router.post("/themes")
async def save_named_theme(payload: Dict[str, Any] = Body(...), user: Dict[str, Any] = Depends(get_current_user)):
    """Saves the current preset + overrides as a new theme file named after
    the title the user gave it. Returns the created entry (including its
    id, which is the file's slugified name). Saving again under the same
    name overwrites that theme file."""
    username = _username_from_user(user)
    name = str(payload.get("name", "")).strip()
    if not name:
        raise HTTPException(status_code=400, detail="Theme name is required.")

    preset = payload.get("preset") if payload.get("preset") in ("day", "dark") else "day"
    overrides = payload.get("overrides")
    overrides = overrides if isinstance(overrides, dict) else {}

    theme_id = _slugify_theme_name(name)
    entry = {"id": theme_id, "name": name, "preset": preset, "overrides": overrides}
    path = _themes_dir(username) / f"{theme_id}.json"
    path.write_text(json.dumps(entry, indent=2), encoding="utf-8")
    return entry


@router.delete("/themes/{theme_id}")
async def delete_saved_theme(theme_id: str, user: Dict[str, Any] = Depends(get_current_user)):
    username = _username_from_user(user)
    path = _themes_dir(username) / f"{theme_id}.json"
    if path.exists():
        path.unlink()
    return {"ok": True}


# ---------------------------------------------------------------------------
#  AGENT TURNS -- the user's preferred default number of tool-calling/agent
#  turns granted per run (Task Builder "Agent Goal" steps default to this
#  value). Always clamped to [1, 100] -- 100 is also the hard ceiling a
#  running agent can ask to be topped up to mid-task (see
#  tasks/engine/service.py's AGENT_GOAL_HARD_CAP).
# ---------------------------------------------------------------------------

AGENT_TURNS_MAX = 100
AGENT_TURNS_DEFAULT = 20


@router.get("/agent-turns")
async def get_agent_turns_setting(user: Dict[str, Any] = Depends(get_current_user)):
    username = _username_from_user(user)
    raw = VaultService.get_preference(username, "agent.default_max_turns", AGENT_TURNS_DEFAULT)
    try:
        value = int(raw)
    except (TypeError, ValueError):
        value = AGENT_TURNS_DEFAULT
    return {"max_turns": max(1, min(value, AGENT_TURNS_MAX))}


@router.post("/agent-turns")
async def set_agent_turns_setting(payload: Dict[str, Any] = Body(...), user: Dict[str, Any] = Depends(get_current_user)):
    username = _username_from_user(user)
    try:
        value = int(payload.get("max_turns"))
    except (TypeError, ValueError):
        raise HTTPException(status_code=400, detail="max_turns must be a whole number.")

    value = max(1, min(value, AGENT_TURNS_MAX))
    VaultService.set_preference(username, "agent.default_max_turns", value)
    return {"max_turns": value}


