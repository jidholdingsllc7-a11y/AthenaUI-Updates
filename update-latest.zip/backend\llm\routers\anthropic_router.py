﻿# AthenaUI v3.5 — Anthropic Router
# File: backend/llm/routers/anthropic_router.py
# Created: 2026-03-28 20:36 CDT
# Updated: 2026-07-27 19:49 CDT

import json
import requests
from typing import Any, Dict, List, Optional

from llm.routers.base import BaseLLMRouter, anthropic_model_rejects_custom_temperature
from core.runtime.runtime import get_runtime

from tools.registry.tool_examples import TOOL_EXAMPLES


class AnthropicRouter(BaseLLMRouter):
    """
    Provider-specific router for Anthropic Claude 3.x models.
    Supports:
    - chat
    - tool calling (Anthropic format)
    - streaming (stub)
    """

    API_URL = "https://api.anthropic.com/v1/messages"

    # ---------------------------------------------------------
    # Build system prompt with tool examples
    # ---------------------------------------------------------

    def _build_system_prompt(self, base_prompt: Optional[str], *, include_tool_examples: bool = True) -> str:
        # Skip the tool-examples block entirely for calls that don't pass
        # any tools -- it was previously injected unconditionally, telling a
        # call with zero real tool access "you have tools, use them, don't
        # explain, just call it", which the model has no real way to honor
        # (no payload["tools"] ever reaches the Anthropic API for it), so it
        # hallucinates a fake pseudo tool-call as plain text instead of
        # correctly saying it has no tool access (confirmed live: Synergy's
        # discussion phase with no directory selected).
        if not include_tool_examples:
            return base_prompt if base_prompt else "You are AthenaUI v3.1."

        examples_json = json.dumps(TOOL_EXAMPLES, indent=2)

        tool_usage_block = f"""
You have access to a set of tools. Use them whenever needed.

Here are examples of correct tool usage:
{examples_json}

Anthropic tool calling format:
- Tools are declared in "tools"
- Tool calls appear as content blocks of type "tool_use"
- Arguments appear in "input"

If you need to call a tool, do NOT explain — just call it.
"""

        if base_prompt:
            return base_prompt + "\n\n" + tool_usage_block

        return "You are AthenaUI v3.1.\n\n" + tool_usage_block

    # ---------------------------------------------------------
    # Chat Completion
    # ---------------------------------------------------------

    def chat(
        self,
        messages: List[Dict[str, Any]],
        *,
        tools: Optional[List[Dict[str, Any]]] = None,
        tool_choice: Optional[str] = None,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> Dict[str, Any]:

        runtime = get_runtime()
        api_key = runtime.env.ANTHROPIC_API_KEY

        if not api_key:
            raise RuntimeError("Anthropic API key not set.")

        headers = {
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json",
        }

        # Build system prompt with examples
        extracted_prompt, remaining_messages = self._extract_system_prompt(messages)
        final_system_prompt = self._build_system_prompt(
            system_prompt or extracted_prompt, include_tool_examples=bool(tools)
        )

        # Anthropic message format -- system prompt and tools are cached
        # (cache_control breakpoints) since both are identical on nearly
        # every call for a given persona/conversation.
        payload: Dict[str, Any] = {
            "model": self.model_id,
            "messages": self._to_anthropic_messages(remaining_messages),
            "max_tokens": max_tokens or 2048,
            "system": self._anthropic_system_with_cache(final_system_prompt),
        }
        if not anthropic_model_rejects_custom_temperature(self.model_id):
            payload["temperature"] = temperature

        # Tool calling (Anthropic format)
        if tools:
            payload["tools"] = self._anthropic_tools_with_cache(self._to_anthropic_tools(tools))
            anthropic_tool_choice = self._to_anthropic_tool_choice(tool_choice)
            if anthropic_tool_choice:
                payload["tool_choice"] = anthropic_tool_choice

        # Send request
        response = requests.post(self.API_URL, json=payload, headers=headers, timeout=280)
        response.raise_for_status()
        data = response.json()

        # Normalize Anthropic response
        content_blocks = data.get("content", [])
        text_content = None
        tool_calls = []

        for block in content_blocks:
            block_type = block.get("type")

            if block_type == "text":
                text_content = block.get("text")

            elif block_type == "tool_use":
                tool_calls.append({
                    "id": block.get("id"),
                    "type": "function",
                    "function": {
                        "name": block.get("name"),
                        "arguments": json.dumps(block.get("input") or {}),
                    },
                })

        result = {
            "id": data.get("id"),
            "model": data.get("model"),
            "content": text_content,
            "tool_calls": tool_calls or None,
            "finish_reason": data.get("stop_reason"),
            "raw": data,
        }

        return result

    # ---------------------------------------------------------
    # Streaming (stub)
    # ---------------------------------------------------------

    def stream_chat(
        self,
        messages: List[Dict[str, Any]],
        *,
        tools: Optional[List[Dict[str, Any]]] = None,
        tool_choice: Optional[str] = None,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ):
        raise NotImplementedError("Anthropic streaming not implemented yet.")


