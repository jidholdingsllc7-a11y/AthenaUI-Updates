# AthenaUI v3.5 — troubleshooting_tip_add Tool
# File: backend/tools/troubleshooting/troubleshooting_tip_add.py
#
# Appends a new trick/tip to the shared troubleshooting tips library so any
# character/agent (and any LLM provider behind it) can benefit from it later,
# without needing it baked into every persona's system prompt.

from typing import Any, Dict

from troubleshooting_tips.service import TroubleshootingTipsError, add_tip

capabilities = {
    "needs_filesystem": True,
    "needs_bridge": False,
    "needs_network": False,
    "needs_user": True,
}


async def run(args: Dict[str, Any]) -> str:
    try:
        username = args.get("username")
        character = args.get("character")
        title = args.get("title")
        tip = args.get("tip")

        if not username:
            return "[ERROR] Missing 'username' argument."
        if not title:
            return "[ERROR] Missing 'title' argument."
        if not tip:
            return "[ERROR] Missing 'tip' argument."

        result = add_tip(
            username,
            title=title,
            tip=tip,
            tags=args.get("tags"),
            program=args.get("program"),
            character=character,
        )
        return f"Tip added to the troubleshooting library: '{result['title']}' (id={result['id']})."
    except TroubleshootingTipsError as e:
        return f"[ERROR] {e}"
    except Exception as e:
        return f"[ERROR] Failed to add troubleshooting tip: {str(e)}"
