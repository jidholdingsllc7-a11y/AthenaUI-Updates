# AthenaUI -- Twilio Voice Call Tool
# File: backend/tools/twilio/call_place.py
#
# Places a real outbound phone call via the user's configured Twilio
# account, which reads the given message aloud using text-to-speech. Real,
# costs money, and reaches a real person -- flagged dangerous/requires_approval,
# same as sms_send.py.

from typing import Any, Dict

from twilio_integration.service import TwilioServiceError, place_call

capabilities = {
    "needs_bridge": False,
    "needs_filesystem": False,
    "needs_network": True,
    "needs_user": True,
    "is_dangerous": True,
    "requires_approval": True,
}


async def run(args: Dict[str, Any]):
    import asyncio

    username = args.get("username")
    to = (args.get("to") or "").strip()
    message = (args.get("message") or "").strip()
    if not username:
        return {"error": "Missing 'username' argument."}
    if not to:
        return {"error": "Missing 'to' argument."}
    if not message:
        return {"error": "Missing 'message' argument."}

    try:
        result = await asyncio.to_thread(place_call, username, to, message)
    except TwilioServiceError as e:
        return {"error": str(e)}

    return {"ok": True, "result": result}
