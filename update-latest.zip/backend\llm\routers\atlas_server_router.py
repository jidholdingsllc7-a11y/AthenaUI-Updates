# AthenaUI v3.5 — Provider-specific router for the local Atlas Server
# File: backend/llm/routers/atlas_server_router.py
#
# Atlas Server (../atlas-server) orchestrates multiple fine-tuned local
# models (Dolphin for chat, Qwen for code, etc.) behind ONE OpenAI-compatible
# `/v1/chat/completions` endpoint and does its own internal model selection,
# tool-use-fallback prompting, and `<tool_call>` tag parsing server-side --
# so, unlike ollama_router.py/lmstudio_router.py, this router does NOT need
# to inject its own tool-usage examples/system prompt. It just forwards
# messages/tools through verbatim, exactly like openai_router.py does for
# real OpenAI, and lets Atlas Server's own orchestrator do the prompting.

import requests
from typing import Any, Dict, List, Optional

from llm.routers.base import BaseLLMRouter
from llm.router_selector.router_selector import RouterSelector
from llm.routers.providers import PROVIDER_ATLAS_SERVER
from core.runtime.runtime import get_runtime


class AtlasServerRouter(BaseLLMRouter):
    """
    Provider-specific router for the local Atlas Server.
    Supports:
    - chat (OpenAI-compatible)
    - tool calling (native, server-side `<tool_call>` protocol normalized
      to OpenAI's `tool_calls` shape by Atlas Server itself)
    - streaming (not yet implemented -- Phase 2 on the Atlas Server side)
    """

    API_URL_TEMPLATE = "{base_url}/v1/chat/completions"

    def chat(
        self,
        messages: List[Dict[str, Any]],
        *,
        tools: Optional[List[Dict[str, Any]]] = None,
        tool_choice: Optional[str] = None,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> Dict[str, Any]:

        runtime = get_runtime()
        base_url = runtime.env.ATLAS_SERVER_API_BASE or "http://127.0.0.1:8090"
        api_key = runtime.env.ATLAS_SERVER_API_KEY

        if not api_key:
            raise RuntimeError("Atlas Server API key not set.")

        url = self.API_URL_TEMPLATE.format(base_url=base_url)
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }

        # Atlas Server already handles tool-use-fallback prompting and
        # per-request model selection server-side, so the only thing this
        # router needs to do is make sure any upstream persona/memory system
        # message(s) are present in `messages` -- no extra injection needed.
        if system_prompt:
            payload_messages = [{"role": "system", "content": system_prompt}] + messages
        else:
            payload_messages = messages

        payload: Dict[str, Any] = {
            "model": self.model_id,
            "messages": payload_messages,
        }

        if max_tokens is not None:
            payload["max_tokens"] = max_tokens

        if tools:
            payload["tools"] = tools
            if tool_choice:
                payload["tool_choice"] = tool_choice

        response = requests.post(url, json=payload, headers=headers, timeout=280)
        response.raise_for_status()
        data = response.json()

        choice = data["choices"][0]
        message = choice.get("message", {})

        return {
            "id": data.get("id"),
            "model": data.get("model"),
            "content": message.get("content"),
            "tool_calls": message.get("tool_calls"),
            "finish_reason": choice.get("finish_reason"),
            "raw": data,
        }

    def stream_chat(self, *args, **kwargs):
        raise NotImplementedError("Atlas Server streaming not implemented yet.")


RouterSelector.register_router(PROVIDER_ATLAS_SERVER, AtlasServerRouter)
