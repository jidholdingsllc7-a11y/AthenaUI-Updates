# AthenaUI v3.5 — Pair Photo Generate Tool
# File: backend/tools/system/images/image_generate_pair.py
# Purpose: Lets an agent generate a single combined photo of themselves and
# another character together (e.g. "a photo of me and Maximos at a cafe"),
# using each character's own reference photo so identities stay consistent.
# The resulting image is saved to both characters' gallery/pair/ folders.
# Created: 2026-08-01

from typing import Any, Dict
from llm.image_generation.service import ImageGenerationService

capabilities = {
    "needs_bridge": False,
    "needs_filesystem": False,
    "needs_network": True,
    "needs_user": True,
}

async def run(args: Dict[str, Any]):
    username = args.get("username", "system")
    character_a = args.get("character") or args.get("character_id")
    character_b = args.get("other_character")
    prompt = args.get("prompt")
    reference_image_a = args.get("reference_image")
    reference_image_b = args.get("other_reference_image")

    if not character_a or not character_b:
        return {"error": "Missing character or other_character for pair photo generation"}
    if not prompt:
        return {"error": "Missing prompt describing the scene"}

    try:
        service = ImageGenerationService()
        return await service.generate_pair_image(
            username=username,
            character_a=character_a,
            character_b=character_b,
            prompt=prompt,
            reference_image_a=reference_image_a,
            reference_image_b=reference_image_b,
        )
    except Exception as e:
        return {"error": str(e)}
