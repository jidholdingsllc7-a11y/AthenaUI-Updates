# AthenaUI v3.5 � Chat API (Single + Group Chat)
# File: backend/api/routes/chat.py
# Created: 2026-04-06 21:10 CDT
# Updated: 2026-07-30 22:10 CDT

from __future__ import annotations

from typing import Any, Dict, List, AsyncGenerator, Optional
import asyncio
import base64
import json
import logging
import re
from datetime import datetime
from pathlib import Path

import requests

from fastapi import APIRouter, Depends, HTTPException, File, UploadFile, Form
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from auth.service import get_current_user
from chat.engine.service import ChatEngine, _looks_like_troubleshooting_request
from chat.group.router import GroupChatRouter
from chat.synergy.service import SYNERGY_CHARACTER_NAME
from tools.registry.categories import tool_catalog_payload
from chat.history.service import ChatHistoryService
from chat.history.service import (
    CHANNEL_BROKERAGE_CHAT,
    CHANNEL_MARKETING_CHAT,
    CHANNEL_PRIVATE_CHAT,
    CHANNEL_TASKS_CHAT,
    CHANNEL_VOICE_CALL,
    normalize_channel,
)
from characters.system.list import list_all_characters
from characters.system.load import load_character
from vault.service import VaultService
from code_suite.changes.service import changeset_service
from users.service import UserService
from logs_system.system.service import system_logger

router = APIRouter(prefix="/chat", tags=["chat"])
logger = logging.getLogger(__name__)

# Reserved provider_id for the (not-yet-built) Atlas Server local TLM
# hosting layer. Reply-feedback (thumbs up/down) is only meaningful when
# WE control the model's weights -- for every third-party provider
# (OpenAI/Anthropic/xAI/OpenRouter/etc.) there is no way to act on the
# feedback, so the frontend gates the buttons on this exact provider_id
# and simply won't show them for anything else. Nothing registers this
# provider_id yet, so the buttons are correctly invisible everywhere until
# Atlas Server actually exists as a real provider.
ATLAS_SERVER_PROVIDER_ID = "atlas_server"

# ---------------------------------------------------------
# Chat file-upload: text vs. image vs. unsupported classification
# ---------------------------------------------------------
# Recognized plain-text/source-code extensions -- these (and anything else
# that decodes cleanly as strict UTF-8, see `_is_probably_text`) get inlined
# into the chat message as plain text, regardless of their original
# extension: the LLM only ever sees text, never a raw binary/extension-
# specific parse of these.
TEXT_FILE_EXTENSIONS = {
    ".txt", ".md", ".markdown", ".py", ".js", ".jsx", ".ts", ".tsx", ".json",
    ".css", ".scss", ".html", ".htm", ".xml", ".yml", ".yaml", ".csv", ".log",
    ".sh", ".ps1", ".bat", ".java", ".c", ".h", ".cpp", ".hpp", ".cs", ".go",
    ".rs", ".rb", ".php", ".sql", ".ini", ".toml", ".cfg", ".env", ".vue",
    ".svelte", ".kt", ".swift", ".r", ".lua", ".gitignore", ".dockerfile",
}

# Supported image extensions -> MIME type, for building a base64 data URI.
IMAGE_FILE_EXTENSIONS = {
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".webp": "image/webp",
    ".bmp": "image/bmp",
}

def _is_probably_text(content: bytes) -> bool:
    """Best-effort binary/text sniff for files with an unrecognized
    extension: a NUL byte or a strict-UTF-8 decode failure means this is
    real binary data (e.g. an image, PDF, zip) that must NOT be blindly
    force-decoded into garbled pseudo-text."""
    if b"\x00" in content:
        return False
    try:
        content.decode("utf-8", errors="strict")
        return True
    except UnicodeDecodeError:
        return False


async def _describe_image_via_analyze_model(engine: ChatEngine, data_uri: str) -> str | None:
    """Describes an uploaded image via the user's dedicated image-analysis
    provider/model (Settings -> Image Analysis), decoupled from whatever
    chat model/provider the active persona is using -- falls back to the
    chat pipeline automatically when no dedicated analyze model has been
    configured (see ChatEngine._get_active_analyze_model). Returns None
    only when no usable provider/API key is available at all, so the
    caller can tell the user honestly instead of fabricating a description.
    """
    try:
        provider_id, model_id = engine._get_active_analyze_model()
        api_key = engine._get_api_key(provider_id, category="analyze")
    except Exception:
        return None

    try:
        engine._inject_provider_api_key(provider_id, api_key, category="analyze")
        router = engine.router_selector.select(provider_id=provider_id, model_id=model_id, mode="chat")
        response = await asyncio.to_thread(
            router.chat,
            [{
                "role": "user",
                "content": [
                    {"type": "text", "text": "Describe this image in detail -- what's in it, the setting, and anything notable."},
                    {"type": "image_url", "image_url": {"url": data_uri}},
                ],
            }],
        )
        return ChatEngine._normalize_assistant_text(response) if isinstance(response, dict) else str(response)
    except Exception:
        logger.debug("Image analysis via %s failed", provider_id, exc_info=True)
        return None


def _normalize_character(value: Any, username: str | None = None) -> str:
    """Trims whitespace and, when a username is supplied, canonicalizes the
    name's case to match the real registered character key (e.g.
    "sol_lumos" -> "Sol_Lumos"). Character/agent ids are used verbatim as
    Vault keys and Maximos Memory Server pipeline keys everywhere downstream,
    so a case mismatch (stale bookmarked URL, manually typed name, an old
    browser tab left open, etc.) silently creates a different, unrelated
    identity -- fragmenting vault/persona/history lookups. Falls back to the
    trimmed value unchanged if no case-insensitive match is found (e.g. a
    brand-new character not yet registered).
    """
    name = str(value or "").strip()
    if not name or not username:
        return name

    try:
        known = list_all_characters(username)
    except Exception:
        return name

    if name in known:
        return name

    lowered = name.lower()
    for real_name in known:
        if real_name.lower() == lowered:
            return real_name

    return name


def _describe_pending_change(change: Any) -> Dict[str, Any]:
    """Renders a single PendingChange into the shape the sidebar chat's
    Keep/Revert (file-change) or Allow/Deny (approval) UI already knows how
    to display. Shared by `_build_pending_action()` (whole batch) and
    anything that needs just one item's wording."""
    if change.type == "edit":
        return {
            "type": "file-change",
            "change_id": change.id,
            "path": change.rel_path,
            "prompt": f"{change.rel_path} was edited live. Keep to finalize (archives the previous version), or Revert to restore it.",
            "actions": ["keep", "revert"],
        }

    if change.type == "delete":
        return {
            "type": "approval",
            "change_id": change.id,
            "path": change.rel_path,
            "prompt": f"A file deletion request is pending for {change.rel_path}.",
            "actions": ["allow", "deny"],
        }

    if change.type == "tool_call":
        args_preview = ", ".join(
            f"{k}={v!r}" for k, v in (change.tool_arguments or {}).items() if k != "username"
        )
        return {
            "type": "approval",
            "change_id": change.id,
            "path": change.tool_name,
            "prompt": (
                f"Agent wants to run '{change.tool_name}'"
                + (f" with {args_preview}" if args_preview else "")
                + ". Allow or Deny?"
            ),
            "actions": ["allow", "allow_session", "deny"],
        }

    return {
        "type": "approval",
        "change_id": change.id,
        "path": change.rel_path,
        "prompt": "An unrecognized pending change is awaiting review.",
        "actions": ["allow", "deny"],
    }


def _build_pending_action(username: str, character: Optional[str] = None) -> Optional[Dict[str, Any]]:
    pending = changeset_service.list_pending_for_user(username)
    # A change attributed to a DIFFERENT character (e.g. Atlas edited a file
    # via file_write) must not surface as a Keep/Revert prompt in some other
    # character's chat (e.g. Meera's) -- only show changes with no character
    # attribution (genuinely global/Code-Suite-direct) or ones matching the
    # character this conversation is actually with.
    pending = [c for c in pending if c.character is None or c.character == character]
    if not pending:
        return None

    # All matching pending changes are bundled into one batch instead of
    # trickling out one at a time as each is resolved -- so the user sees
    # (and can act on) the whole backlog from a multi-file task in a single
    # prompt instead of it looking like repeated new/unrequested writes.
    ordered = sorted(pending, key=lambda x: x.created_at)
    return {
        "type": "batch",
        "items": [_describe_pending_change(c) for c in ordered],
    }

# ---------------------------------------------------------
# Request models
# ---------------------------------------------------------

class ChatMessage(BaseModel):
    role: str
    content: str


class ChatRequest(BaseModel):
    messages: List[ChatMessage]
    character: str | None = None


class GroupChatStartRequest(BaseModel):
    name: str = ""
    characters: List[str]
    provider: Optional[str] = None
    model: Optional[str] = None
    scene_description: Optional[str] = None


class GroupChatUserMessage(BaseModel):
    message: str


class GroupChatAddMemberRequest(BaseModel):
    character: str
    scene_setup: Optional[str] = None


# ---------------------------------------------------------
# In-memory group chat session store
# ---------------------------------------------------------

GROUP_CHAT_SESSIONS: Dict[str, GroupChatRouter] = {}


def get_group_session(username: str) -> Optional[GroupChatRouter]:
    return GROUP_CHAT_SESSIONS.get(username)


def set_group_session(username: str, session: GroupChatRouter) -> None:
    GROUP_CHAT_SESSIONS[username] = session


def delete_group_session(username: str) -> None:
    GROUP_CHAT_SESSIONS.pop(username, None)


# ---------------------------------------------------------
# Saved (on-disk) group chat sessions -- survive server restarts
# ---------------------------------------------------------

def _group_chat_save_dir(username: str) -> Path:
    from core.runtime.runtime import get_runtime

    save_dir = get_runtime().env.DATA_DIR / "users" / username / "group_chats"
    save_dir.mkdir(parents=True, exist_ok=True)
    return save_dir


def _slugify_group_name(name: str) -> str:
    slug = re.sub(r"[^a-zA-Z0-9]+", "_", name.strip()).strip("_").lower()
    return slug or "group_chat"


# ---------------------------------------------------------
# In-memory agentic (multi-round tool use) state store, private chat
# ---------------------------------------------------------
# Lets a reply that needs more than one tool-calling round be driven one
# round at a time by the frontend (via /chat/continue), so it can show
# per-round progress, let the user interrupt (/chat/interrupt), or send a
# new message mid-loop that gets woven into the very next round instead of
# starting a brand-new reply.

AGENTIC_STATE: Dict[str, Dict[str, Any]] = {}


def _agentic_key(username: str, character: str | None) -> str:
    return f"{username}:{character or '__default__'}"


# Every provider phrases a "you're out of money" error differently (only
# OpenRouter gives us a clean machine-readable metadata.limit_source), so the
# generic fallback below matches on common wording seen across provider docs
# (OpenAI "insufficient_quota", Anthropic "credit balance is too low",
# DeepSeek "Insufficient Balance", etc.) instead of hardcoding each provider's
# exact schema, which would silently miss any provider not explicitly listed.
_LOW_BALANCE_KEYWORDS = (
    "insufficient balance", "insufficient credit", "insufficient_quota",
    "insufficient funds", "credit balance is too low", "out of credits",
    "add credits", "add more credits", "purchase credits", "top up",
    "topup", "no credits", "exceeded your current quota", "quota exceeded",
    "billing", "payment required",
)


def _friendly_low_balance_message(e: requests.HTTPError) -> Optional[str]:
    """Returns a plain-English "top up your balance" message for a 402/429
    that looks like an out-of-credits/billing error from ANY provider, else
    None (so callers fall back to the generic "Upstream provider error" or
    plain rate-limit detail)."""
    response = getattr(e, "response", None)
    if response is None:
        return None
    status_code = getattr(response, "status_code", None)
    try:
        body = response.json()
    except (ValueError, TypeError):
        body = None

    if isinstance(body, dict):
        error_obj = body.get("error") or {}
        metadata = error_obj.get("metadata") or {}
        # OpenRouter: exact, machine-readable, non-transient balance error.
        if metadata.get("limit_source") == "openrouter_credits":
            return (
                "Chat provider is out of credits. Please top up your OpenRouter "
                "balance at https://openrouter.ai/settings/credits, then try again."
            )
        provider_message = error_obj.get("message") or body.get("message")
    else:
        provider_message = None

    raw_text = provider_message or getattr(response, "text", "") or ""
    lowered = raw_text.lower()
    if status_code == 402 or any(keyword in lowered for keyword in _LOW_BALANCE_KEYWORDS):
        quoted = f' ("{provider_message}")' if provider_message else ""
        return (
            f"Chat provider reports a low balance / billing issue{quoted}. "
            "Please check your account balance or billing plan with your chat "
            "provider, top it up if needed, then try again."
        )
    return None


def _friendly_rate_limit_message(e: requests.HTTPError) -> str:
    """Plain-English 429 message for a rate limit that ISN'T a low-balance
    issue (those are already caught by _friendly_low_balance_message first).
    Makes explicit that this is the AI provider throttling requests on
    their end -- not an AthenaUI bug and not the user's account balance --
    since a raw "429" reads to most users like something is broken here.
    Also nudges toward switching chat models, since popular models can
    share a busier upstream capacity pool with every other user of that
    model/provider regardless of whether the model is paid or free."""
    response = getattr(e, "response", None)
    provider_message = None
    if response is not None:
        try:
            body = response.json()
            if isinstance(body, dict):
                provider_message = (body.get("error") or {}).get("message") or body.get("message")
        except (ValueError, TypeError):
            pass
    quoted = f' ("{provider_message}")' if provider_message else ""
    return (
        f"The chat model's provider is temporarily rate-limiting requests{quoted}. "
        "This is a provider-side capacity limit, not a problem with AthenaUI, and "
        "it isn't related to your account balance -- popular models can get busy "
        "and briefly throttle everyone using them. It usually clears up within a "
        "minute or two, so you can just retry. If it keeps happening, try "
        "switching this character to a different chat model in Settings."
    )


def _friendly_generic_error_message(e: Exception) -> Optional[str]:
    """Plain-English message for error types that aren't requests.HTTPError
    (so they skip the 402/429/400 handling above) but still have a known,
    non-technical explanation -- currently just a malformed/non-JSON
    response body, which retry.call_with_retry already retries a few times
    before giving up, so seeing this means it genuinely kept happening."""
    if isinstance(e, json.JSONDecodeError):
        return (
            "Chat provider sent back an unreadable response (possibly a "
            "temporary hiccup on their end). Please try again."
        )
    return None


def _http_error_status_and_detail(e: requests.HTTPError, raw_body: Optional[str]) -> tuple[int, str]:
    """Shared status/detail resolution for the three agentic-loop endpoints
    (send/continue/grant-more-turns) that all forward a real upstream
    requests.HTTPError to the user. Handles 402/429 (existing friendly
    balance/rate-limit messages) plus a catch-all for every other 4xx
    (400, 404, 422, ...) that surfaces the provider's own error message
    instead of a bare "Upstream provider error (404)." -- this is exactly
    what caught a real OpenRouter case: some models are listed as available
    but don't support tool calling on their currently routed backend, and
    OpenRouter returns 404 "No endpoints found that support tool use" only
    when tools are actually included in the request, so the raw status code
    alone is meaningless to the user without this text."""
    status_code = getattr(getattr(e, "response", None), "status_code", 502)
    detail = f"Upstream provider error ({status_code})."
    if status_code in (402, 429):
        detail = _friendly_low_balance_message(e) or (
            _friendly_rate_limit_message(e) if status_code == 429 else detail
        )
    elif getattr(e, "response", None) is not None:
        try:
            err_payload = e.response.json()
            provider_msg = err_payload.get("error", {}).get("message")
            if provider_msg:
                detail = f"Provider rejected request: {provider_msg}"
        except Exception:
            pass
    return status_code, detail


async def resume_after_tool_approval(
    username: str, character: str | None, tool_name: str, tool_result: Any
) -> Dict[str, Any]:
    """
    Called by /code_suite/changes/apply right after the user clicks Allow and
    the tool actually runs, so the character can react and keep going on its
    own -- the user shouldn't have to type "ok" / paste the result back in to
    get the conversation moving again. By the time the user gets to click
    Allow, the turn that asked for approval has already finished (its final
    reply told the user a prompt was waiting), so there is no in-progress
    AGENTIC_STATE left to resume: instead this starts a fresh agentic turn
    seeded with a system-style note describing what just happened, exactly
    like a new incoming message, and drives/stores it the same way
    /chat/send does.
    """
    engine = ChatEngine(username=username)
    try:
        result_text = json.dumps(tool_result, default=str)[:4000]
    except Exception:
        result_text = str(tool_result)[:4000]

    synthetic_message = (
        f"[System note: the user just clicked Allow -- '{tool_name}' has finished running "
        f"in a visible terminal window they can see. Result:\n{result_text}\n"
        "Continue helping them based on this result now, without waiting for them to repeat "
        "themselves or ask you to continue.]"
    )

    key = _agentic_key(username, character)
    try:
        result = await engine.start_agentic(synthetic_message, character=character)
    except Exception as e:
        logger.exception("Auto-continue after tool approval failed for user=%s", username)
        return {"reply": f"(The tool ran, but I couldn't continue automatically: {e})", "done": True}
    state = result.pop("state")

    if result["status"] == "final":
        AGENTIC_STATE.pop(key, None)
        return {
            "reply": result["reply"],
            "done": True,
            "provider_id": result.get("provider_id"),
            "model_id": result.get("model_id"),
            "pending_action": _build_pending_action(username, character),
        }

    AGENTIC_STATE[key] = state
    if result["status"] == "needs_more_turns":
        return {
            "done": False,
            "needs_more_turns": True,
            "round": result["round"],
            "max_rounds": result["max_rounds"],
        }
    return {
        "done": False,
        "round": result["round"],
        "max_rounds": result["max_rounds"],
        "tool_name": result["tool_name"],
    }


def _resolve_interface_channel(interface: Any, *, is_call: bool) -> str:
    if is_call:
        return CHANNEL_VOICE_CALL
    normalized = str(interface or "").strip().lower()
    if normalized in {"brokerage", "trading", "alpaca"}:
        return CHANNEL_BROKERAGE_CHAT
    if normalized in {"task", "tasks", "task_builder", "scheduled_tasks"}:
        return CHANNEL_TASKS_CHAT
    if normalized in {"marketing", "social", "social_media"}:
        return CHANNEL_MARKETING_CHAT
    return CHANNEL_PRIVATE_CHAT




# ---------------------------------------------------------
# SINGLE-CHARACTER CHAT (REAL ENDPOINTS)
# ---------------------------------------------------------

@router.get("/tool_catalog")
async def chat_tool_catalog(user: Dict[str, Any] = Depends(get_current_user)):
    """Categorized tool list for the dedicated /chat page's tool picker
    (see ChatPage.tsx). Memory is flagged always_on=True (can't be opted out
    of -- the agent needs MMS access to function) and pre-selected/disabled
    client-side; everything else is opt-in."""
    return tool_catalog_payload()


@router.get("/history")
async def chat_history(character: str | None = None, user: Dict[str, Any] = Depends(get_current_user)):
    """
    Returns real chat history for the logged-in user (Maximos-backed).
    """
    character_name = _normalize_character(character, user["username"])

    history_service = ChatHistoryService(username=user["username"], character=character_name or None)
    history = history_service.get_history()

    messages = [
        {
            "id": m.id,
            "role": m.role,
            "content": m.content,
            "timestamp": m.timestamp,
            "sender": m.sender,
        }
        for m in history
    ]

    return {"messages": messages}


@router.post("/history/clear")
async def clear_chat_history(payload: Dict[str, Any], user: Dict[str, Any] = Depends(get_current_user)):
    username = user["username"]
    character = _normalize_character(payload.get("character"), username)

    history_service = ChatHistoryService(username=username, character=character or None)
    history_service.clear()

    return {
        "ok": True,
        "character": character,
        "cleared": "character" if character else "default",
    }


@router.post("/send")
async def chat_send(payload: dict, user: Dict[str, Any] = Depends(get_current_user)):
    """
    Sends a message to the agent and returns the assistant reply.
    Uses ChatEngine for real LLM responses.

    A reply that needs more than one tool-calling round is driven one round
    at a time (see /chat/continue): this call only ever runs a single round
    and returns {"done": false, ...} if more rounds remain, instead of
    blocking through the whole loop. If the agent is already mid-loop for
    this character when this is called again, the new message is woven
    into the next round instead of starting a fresh reply (this is how a
    user can redirect/steer an in-progress multi-turn reply).
    """
    message = payload.get("message", "")
    character = _normalize_character(payload.get("character", None), user["username"])
    editor_context = payload.get("editor_context")
    if not isinstance(editor_context, dict) or not editor_context.get("path"):
        editor_context = None

    # Sidebar Chat sends page_context (one of "code_suite", "browser",
    # "marketing", or "general" -- see SidebarChat.tsx) on every /chat/send
    # call it makes; the dedicated /chat page never sends one. Passed
    # through to ChatEngine.start_agentic() so it can narrow tool access to
    # whatever's relevant on that page (see _agent_tool_names). Separately,
    # when the user is asking for help troubleshooting/fixing a program in
    # Code Suite specifically, route that turn to the CODE model instead of
    # the character/chat model -- debugging real code and terminal output is
    # a coding task, not a persona conversation. Scoped to Code Suite
    # specifically so an ordinary "this isn't working" in normal character
    # chat never triggers it. `force_code_mode` is the explicit Chat/Code
    # switch at the top of the sidebar (see SidebarChat.tsx) -- when the user
    # has it set to "Code", every turn routes to the code model regardless
    # of page or heuristic.
    page_context = payload.get("page_context")
    force_code_mode = bool(payload.get("force_code_mode"))
    use_code_model = force_code_mode or (
        page_context == "code_suite" and _looks_like_troubleshooting_request(message)
    )

    # Synergy mode: selecting the reserved "Synergy" entry from the agent
    # list (see SidebarChat.tsx) routes this turn to a bounded Code-Model-A
    # vs Code-Model-B discussion (chat/synergy/service.py) instead of the
    # normal single-router agentic tool loop. Character personas are
    # irrelevant in this mode (it's plain "Agent Mode", no persona
    # injection) -- `character` is only ever used as the bucket this turn's
    # user-visible history is saved under, and since it's set to the
    # reserved Synergy name here, that history is naturally its own,
    # separate from any real character's. The character name is the source
    # of truth; the `synergy` payload flag (set by the frontend alongside
    # it) is honored too for safety but never required on its own.
    synergy = character == SYNERGY_CHARACTER_NAME or bool(payload.get("synergy"))

    # The dedicated /chat page's tool picker (see ChatPage.tsx + GET
    # /chat/tool_catalog) sends an explicit list of tool names the user
    # opted into for this conversation -- distinct from `[]` (nothing extra
    # opted in, memory-only) vs. omitted entirely (no picker touched yet,
    # preserve today's character/provider-based access resolution).
    raw_tool_names = payload.get("tool_names")
    explicit_tool_names = frozenset(raw_tool_names) if isinstance(raw_tool_names, list) else None

    # Simulated phone call support: `call` tags this turn (and its reply) in
    # the agent's memory as voice-call metadata (channel="voice_call") rather
    # than a normal text message -- no separate memory pipeline, just a
    # different channel value on the same store_chat_turn/search calls.
    # `call_start` (only true on the very first turn of a call) additionally
    # prepends a one-off system note so the agent knows this exchange is
    # happening over a live voice call, not text.
    is_call = bool(payload.get("call"))
    call_start = bool(payload.get("call_start"))
    channel = _resolve_interface_channel(payload.get("interface"), is_call=is_call)
    channel = normalize_channel(channel)
    reasoning_effort = payload.get("reasoning_effort") or None

    if not message:
        raise HTTPException(400, "message is required")

    key = _agentic_key(user["username"], character)
    engine = ChatEngine(username=user["username"])

    system_logger.log(
        event="Chat send",
        agent_state=character,
        details={"channel": channel, "message_length": len(message)},
    )

    try:
        existing = AGENTIC_STATE.get(key)
        if existing and isinstance(existing, dict) and existing.get("kind") == "synergy":
            # A Synergy diagnostic pass is paused awaiting the user's
            # Grant/Deny More Rounds choice -- typing a new message instead
            # discards the pause and starts a fresh Synergy run with it,
            # same as if no pause existed. inject_agentic_message() below
            # assumes the NORMAL agentic state shape and would KeyError on
            # this wrapper otherwise.
            AGENTIC_STATE.pop(key, None)
            existing = None
        if existing:
            # Agent is already mid-loop -- weave this in as a steering
            # message for the next round instead of starting a new reply.
            engine.inject_agentic_message(existing, message)
            return {"done": False, "injected": True}

        if synergy:
            has_directory = bool(editor_context and editor_context.get("is_directory") and editor_context.get("path"))
            if not has_directory:
                # No Code Suite directory selected -- this is a normal
                # conversation, not a coding task, so run the discuss-and-
                # reply pipeline (general tool access, plain-text reply,
                # optional plan) instead of the file/terminal diagnostic ->
                # plan -> apply pipeline below. See chat/synergy/service.py's
                # SynergyChatOrchestrator. No round cap here -- it pauses on
                # a wall-clock time budget instead (status="needs_more_turns"
                # with pause_reason="time_limit"), same response shape as
                # the Code Suite branch below so the frontend needs no
                # separate wiring for this case.
                chat_result = await engine.run_synergy_chat(
                    message, character=character, channel=channel,
                    editor_context=editor_context, page_context=page_context,
                )
                if chat_result["status"] == "needs_more_turns":
                    AGENTIC_STATE[key] = {"kind": "synergy", "resume_state": chat_result["resume_state"]}
                    system_logger.log(
                        event="Synergy needs more rounds", agent_state=character,
                        details={"round": chat_result["round"], "pause_reason": chat_result.get("pause_reason")},
                    )
                    return {
                        "done": False,
                        "needs_more_turns": True,
                        "round": chat_result["round"],
                        "max_rounds": chat_result["max_rounds"],
                        "pause_reason": chat_result.get("pause_reason"),
                    }
                if chat_result["status"] == "tool_call":
                    AGENTIC_STATE[key] = {"kind": "synergy", "resume_state": chat_result["resume_state"]}
                    system_logger.log(
                        event="Synergy round in progress", agent_state=character,
                        details={"round": chat_result["round"], "tool_name": chat_result["tool_name"]},
                    )
                    return {
                        "done": False,
                        "round": chat_result["round"],
                        "max_rounds": chat_result["max_rounds"],
                        "tool_name": chat_result["tool_name"],
                        "artifact_id": chat_result.get("artifact_id"),
                    }
                system_logger.log(event="Chat return: ok (synergy chat)", agent_state=character)
                return {
                    "reply": chat_result["reply"],
                    "done": True,
                    "provider_id": chat_result.get("provider_id"),
                    "model_id": chat_result.get("model_id"),
                    "synergy_plan": chat_result.get("synergy_plan"),
                    "synergy_context": chat_result.get("synergy_context"),
                    "pending_action": _build_pending_action(user["username"], character),
                }

            result = await engine.run_synergy(message, character=character, channel=channel, editor_context=editor_context)
            if result["status"] == "needs_more_turns":
                AGENTIC_STATE[key] = {"kind": "synergy", "resume_state": result["resume_state"]}
                system_logger.log(
                    event="Synergy needs more rounds", agent_state=character,
                    details={"round": result["round"], "max_rounds": result["max_rounds"]},
                )
                return {
                    "done": False,
                    "needs_more_turns": True,
                    "round": result["round"],
                    "max_rounds": result["max_rounds"],
                }
            if result["status"] == "tool_call":
                # One Synergy step just completed (diagnostic round,
                # discussion turn, or apply round) and more remain within
                # the existing budget -- continues automatically, same as
                # the normal agentic loop's in-progress rounds, with no user
                # action needed. artifact_id lets the frontend show/keep
                # showing the live "Synergy Discussion" artifact as soon as
                # the very first round comes back.
                AGENTIC_STATE[key] = {"kind": "synergy", "resume_state": result["resume_state"]}
                system_logger.log(
                    event="Synergy round in progress", agent_state=character,
                    details={"round": result["round"], "max_rounds": result["max_rounds"], "tool_name": result["tool_name"]},
                )
                return {
                    "done": False,
                    "round": result["round"],
                    "max_rounds": result["max_rounds"],
                    "tool_name": result["tool_name"],
                    "artifact_id": result.get("artifact_id"),
                }
            system_logger.log(event="Chat return: ok (synergy)", agent_state=character)
            return {
                "reply": result["reply"],
                "done": True,
                "provider_id": result.get("provider_id"),
                "model_id": result.get("model_id"),
                "pending_action": _build_pending_action(user["username"], character),
            }

        state_holder: Dict[str, Any] = {}
        result = await engine.start_agentic(
            message, character=character, editor_context=editor_context,
            channel=channel, call_start=call_start, reasoning_effort=reasoning_effort,
            use_code_model=use_code_model, page_context=page_context,
            explicit_tool_names=explicit_tool_names,
        )
        state = result.pop("state")

        if result["status"] == "final":
            system_logger.log(event="Chat return: ok", agent_state=character)
            return {
                "reply": result["reply"],
                "done": True,
                "provider_id": result.get("provider_id"),
                "model_id": result.get("model_id"),
                "pending_action": _build_pending_action(user["username"], character),
            }

        AGENTIC_STATE[key] = state
        if result["status"] == "needs_more_turns":
            system_logger.log(
                event="Chat needs more turns", agent_state=character,
                details={"round": result["round"], "max_rounds": result["max_rounds"]},
            )
            return {
                "done": False,
                "needs_more_turns": True,
                "round": result["round"],
                "max_rounds": result["max_rounds"],
            }
        system_logger.log(
            event="Chat round in progress",
            agent_state=character,
            details={"round": result["round"], "max_rounds": result["max_rounds"], "tool_name": result["tool_name"]},
        )
        return {
            "done": False,
            "round": result["round"],
            "max_rounds": result["max_rounds"],
            "tool_name": result["tool_name"],
        }
    except requests.HTTPError as e:
        AGENTIC_STATE.pop(key, None)
        raw_body = None
        if getattr(e, "response", None) is not None:
            try:
                raw_body = e.response.text[:2000]
            except Exception:
                pass
        status_code, detail = _http_error_status_and_detail(e, raw_body)
        logger.exception("Chat provider HTTP error for user=%s", user["username"])
        system_logger.log(event="Chat return: error", level="error", agent_state=character, details={"detail": detail, "raw_body": raw_body})
        raise HTTPException(status_code=status_code, detail=detail)
    except Exception as e:
        AGENTIC_STATE.pop(key, None)
        logger.exception("Chat execution failed for user=%s", user["username"])
        system_logger.log(event="Chat return: error", level="error", agent_state=character, details={"error": str(e)})
        raise HTTPException(status_code=500, detail=_friendly_generic_error_message(e) or f"Chat execution failed: {e}")


@router.post("/synergy_execute_plan")
async def chat_synergy_execute_plan(payload: dict, user: Dict[str, Any] = Depends(get_current_user)):
    """"Execute Plan" button for Synergy's chat-discussion mode (see
    ChatEngine.run_synergy_chat/SynergyChatOrchestrator) -- the frontend
    round-trips the exact `synergy_plan`/`synergy_context` it received from
    a prior agreed reply, and this carries that plan out directly without
    re-running the A/B discussion. Natural-language "go ahead" still works
    too (Model A/B can set execute=true themselves mid-discussion); this is
    just the reliable button fallback."""
    character = _normalize_character(payload.get("character", None), user["username"])
    channel = normalize_channel(_resolve_interface_channel(payload.get("interface"), is_call=False))
    plan = payload.get("plan")
    context_text = payload.get("context") or ""
    if not isinstance(plan, dict):
        raise HTTPException(400, "plan is required")

    key = _agentic_key(user["username"], character)
    engine = ChatEngine(username=user["username"])
    system_logger.log(event="Synergy execute plan", agent_state=character)
    try:
        result = await engine.execute_synergy_chat_plan(plan, context_text, character=character, channel=channel)
    except Exception as e:
        logger.exception("Synergy execute plan failed for user=%s", user["username"])
        system_logger.log(event="Synergy execute plan: error", level="error", agent_state=character, details={"error": str(e)})
        raise HTTPException(status_code=500, detail=_friendly_generic_error_message(e) or f"Execute plan failed: {e}")

    # A real execute pass can run long (web search / memory / image tool
    # calls) -- same in_progress/needs_more_turns contract as every other
    # Synergy entry point, so a slow "Execute Plan" click behaves exactly
    # like a slow normal chat reply (auto-continues, pauses on the 10-min
    # time budget with the same Yes/No prompt, real interrupt available).
    if result["status"] == "needs_more_turns":
        AGENTIC_STATE[key] = {"kind": "synergy", "resume_state": result["resume_state"]}
        return {
            "done": False,
            "needs_more_turns": True,
            "round": result["round"],
            "max_rounds": result["max_rounds"],
            "pause_reason": result.get("pause_reason"),
        }
    if result["status"] == "tool_call":
        AGENTIC_STATE[key] = {"kind": "synergy", "resume_state": result["resume_state"]}
        return {
            "done": False,
            "round": result["round"],
            "max_rounds": result["max_rounds"],
            "tool_name": result["tool_name"],
            "artifact_id": result.get("artifact_id"),
        }

    return {
        "reply": result["reply"],
        "done": True,
        "provider_id": result.get("provider_id"),
        "model_id": result.get("model_id"),
        "pending_action": _build_pending_action(user["username"], character),
    }


@router.post("/continue")
async def chat_continue(payload: dict, user: Dict[str, Any] = Depends(get_current_user)):
    """
    Advances an in-progress multi-round tool-calling reply by exactly one
    round. Returns {"done": true, "reply": ...} once the agent has produced
    its final text answer, or {"done": false, ...} if more rounds remain.
    """
    character = _normalize_character(payload.get("character", None), user["username"])
    key = _agentic_key(user["username"], character)
    state = AGENTIC_STATE.get(key)

    if not state:
        # Nothing in progress (already finished, interrupted, or the server
        # restarted mid-loop) -- nothing more to continue.
        return {"done": True, "reply": ""}

    engine = ChatEngine(username=user["username"])

    if isinstance(state, dict) and state.get("kind") == "synergy":
        # A Synergy run is mid-flight with status="in_progress" (NOT a true
        # pause -- that goes through /chat/grant-more-turns instead) --
        # automatically continue it one more step, same policy as the
        # normal agentic loop's own in-progress rounds. Normal-chat Synergy
        # (phase starts with "chat_") has no directory/round-cap pipeline --
        # route it to SynergyChatOrchestrator instead.
        is_chat_synergy = str(state["resume_state"].get("phase", "")).startswith("chat_")
        try:
            if is_chat_synergy:
                result = await engine.continue_synergy_chat(state["resume_state"], character=character)
            else:
                result = await engine.continue_synergy(state["resume_state"], character=character)
        except requests.HTTPError as e:
            AGENTIC_STATE.pop(key, None)
            raw_body = None
            if getattr(e, "response", None) is not None:
                try:
                    raw_body = e.response.text[:2000]
                except Exception:
                    pass
            status_code, detail = _http_error_status_and_detail(e, raw_body)
            logger.exception("Synergy continue HTTP error for user=%s", user["username"])
            system_logger.log(
                event="Chat return: error", level="error", agent_state=character,
                details={"detail": detail, "raw_body": raw_body},
            )
            raise HTTPException(status_code=status_code, detail=detail)
        except Exception as e:
            AGENTIC_STATE.pop(key, None)
            logger.exception("Synergy continue failed for user=%s", user["username"])
            system_logger.log(event="Chat return: error", level="error", agent_state=character, details={"error": str(e)})
            raise HTTPException(status_code=500, detail=_friendly_generic_error_message(e) or f"Synergy execution failed: {e}")

        if result["status"] == "needs_more_turns":
            AGENTIC_STATE[key] = {"kind": "synergy", "resume_state": result["resume_state"]}
            system_logger.log(
                event="Synergy needs more rounds", agent_state=character,
                details={"round": result["round"], "max_rounds": result["max_rounds"]},
            )
            return {
                "done": False,
                "needs_more_turns": True,
                "round": result["round"],
                "max_rounds": result["max_rounds"],
                "pause_reason": result.get("pause_reason"),
            }
        if result["status"] == "tool_call":
            AGENTIC_STATE[key] = {"kind": "synergy", "resume_state": result["resume_state"]}
            system_logger.log(
                event="Synergy round in progress", agent_state=character,
                details={"round": result["round"], "max_rounds": result["max_rounds"], "tool_name": result["tool_name"]},
            )
            return {
                "done": False,
                "round": result["round"],
                "max_rounds": result["max_rounds"],
                "tool_name": result["tool_name"],
                "artifact_id": result.get("artifact_id"),
            }
        AGENTIC_STATE.pop(key, None)
        system_logger.log(event="Chat return: ok (synergy)", agent_state=character)
        return {
            "reply": result["reply"],
            "done": True,
            "provider_id": result.get("provider_id"),
            "model_id": result.get("model_id"),
            "pending_action": _build_pending_action(user["username"], character),
        }

    try:
        result = await engine.continue_agentic(state)
    except requests.HTTPError as e:
        AGENTIC_STATE.pop(key, None)
        raw_body = None
        if getattr(e, "response", None) is not None:
            try:
                raw_body = e.response.text[:2000]
            except Exception:
                pass
        status_code, detail = _http_error_status_and_detail(e, raw_body)
        logger.exception("Chat provider HTTP error for user=%s", user["username"])
        system_logger.log(
            event="Chat return: error", level="error", agent_state=character,
            details={"detail": detail, "raw_body": raw_body},
        )
        raise HTTPException(status_code=status_code, detail=detail)
    except Exception as e:
        AGENTIC_STATE.pop(key, None)
        logger.exception("Chat continuation failed for user=%s", user["username"])
        system_logger.log(event="Chat return: error", level="error", agent_state=character, details={"error": str(e)})
        raise HTTPException(status_code=500, detail=_friendly_generic_error_message(e) or f"Chat execution failed: {e}")

    if result["status"] == "final":
        AGENTIC_STATE.pop(key, None)
        system_logger.log(event="Chat return: ok", agent_state=character)
        return {
            "reply": result["reply"],
            "done": True,
            "provider_id": result.get("provider_id"),
            "model_id": result.get("model_id"),
            "pending_action": _build_pending_action(user["username"], character),
        }

    if result["status"] == "needs_more_turns":
        system_logger.log(
            event="Chat needs more turns", agent_state=character,
            details={"round": result["round"], "max_rounds": result["max_rounds"]},
        )
        return {
            "done": False,
            "needs_more_turns": True,
            "round": result["round"],
            "max_rounds": result["max_rounds"],
        }

    system_logger.log(
        event="Chat round in progress",
        agent_state=character,
        details={"round": result["round"], "max_rounds": result["max_rounds"], "tool_name": result["tool_name"]},
    )
    return {
        "done": False,
        "round": result["round"],
        "max_rounds": result["max_rounds"],
        "tool_name": result["tool_name"],
    }


@router.post("/grant-more-turns")
async def chat_grant_more_turns(payload: dict, user: Dict[str, Any] = Depends(get_current_user)):
    """Called when the user clicks "grant more turns" after an agentic reply
    hit MAX_TOOL_ROUNDS (surfaced as {"needs_more_turns": true, ...} from
    /chat/send or /chat/continue). Extends the paused reply's round budget
    and immediately advances one more round, same response shape as
    /chat/continue."""
    character = _normalize_character(payload.get("character", None), user["username"])
    key = _agentic_key(user["username"], character)
    state = AGENTIC_STATE.get(key)

    if not state:
        return {"done": True, "reply": ""}

    additional_turns = payload.get("additional_turns", 50)
    engine = ChatEngine(username=user["username"])

    if isinstance(state, dict) and state.get("kind") == "synergy":
        # Synergy's own round-cap pause (currently only the diagnostic
        # pre-pass can pause this way -- see chat/synergy/service.py). Reuses
        # the SAME AGENTIC_STATE slot/key and this SAME route as the normal
        # agentic loop so the existing frontend "Grant More Turns" UI needs
        # no Synergy-specific changes.
        is_chat_synergy = str(state["resume_state"].get("phase", "")).startswith("chat_")
        try:
            if is_chat_synergy:
                # Normal-chat Synergy has no round count to grant -- "Yes"
                # just extends the wall-clock time budget by another full
                # _CHAT_TIME_BUDGET_SECONDS (additional_turns is ignored).
                result = await engine.resume_synergy_chat(state["resume_state"], character=character)
            else:
                result = await engine.resume_synergy(state["resume_state"], additional_turns, character=character)
        except requests.HTTPError as e:
            AGENTIC_STATE.pop(key, None)
            raw_body = None
            if getattr(e, "response", None) is not None:
                try:
                    raw_body = e.response.text[:2000]
                except Exception:
                    pass
            status_code, detail = _http_error_status_and_detail(e, raw_body)
            logger.exception("Synergy resume HTTP error for user=%s", user["username"])
            system_logger.log(
                event="Chat return: error", level="error", agent_state=character,
                details={"detail": detail, "raw_body": raw_body},
            )
            raise HTTPException(status_code=status_code, detail=detail)
        except Exception as e:
            AGENTIC_STATE.pop(key, None)
            logger.exception("Synergy resume failed for user=%s", user["username"])
            system_logger.log(event="Chat return: error", level="error", agent_state=character, details={"error": str(e)})
            raise HTTPException(status_code=500, detail=_friendly_generic_error_message(e) or f"Synergy execution failed: {e}")

        if result["status"] == "needs_more_turns":
            AGENTIC_STATE[key] = {"kind": "synergy", "resume_state": result["resume_state"]}
            system_logger.log(
                event="Synergy needs more rounds", agent_state=character,
                details={"round": result["round"], "max_rounds": result["max_rounds"]},
            )
            return {
                "done": False,
                "needs_more_turns": True,
                "round": result["round"],
                "max_rounds": result["max_rounds"],
                "pause_reason": result.get("pause_reason"),
            }
        if result["status"] == "tool_call":
            AGENTIC_STATE[key] = {"kind": "synergy", "resume_state": result["resume_state"]}
            system_logger.log(
                event="Synergy round in progress", agent_state=character,
                details={"round": result["round"], "max_rounds": result["max_rounds"], "tool_name": result["tool_name"]},
            )
            return {
                "done": False,
                "round": result["round"],
                "max_rounds": result["max_rounds"],
                "tool_name": result["tool_name"],
                "artifact_id": result.get("artifact_id"),
            }

        AGENTIC_STATE.pop(key, None)
        system_logger.log(event="Chat return: ok (synergy)", agent_state=character)
        return {
            "reply": result["reply"],
            "done": True,
            "provider_id": result.get("provider_id"),
            "model_id": result.get("model_id"),
            "pending_action": _build_pending_action(user["username"], character),
        }

    engine.grant_more_turns(state, additional_turns)

    try:
        result = await engine.continue_agentic(state)
    except requests.HTTPError as e:
        AGENTIC_STATE.pop(key, None)
        raw_body = None
        if getattr(e, "response", None) is not None:
            try:
                raw_body = e.response.text[:2000]
            except Exception:
                pass
        status_code, detail = _http_error_status_and_detail(e, raw_body)
        logger.exception("Chat provider HTTP error for user=%s", user["username"])
        system_logger.log(
            event="Chat return: error", level="error", agent_state=character,
            details={"detail": detail, "raw_body": raw_body},
        )
        raise HTTPException(status_code=status_code, detail=detail)
    except Exception as e:
        AGENTIC_STATE.pop(key, None)
        logger.exception("Chat continuation failed for user=%s", user["username"])
        system_logger.log(event="Chat return: error", level="error", agent_state=character, details={"error": str(e)})
        raise HTTPException(status_code=500, detail=_friendly_generic_error_message(e) or f"Chat execution failed: {e}")

    if result["status"] == "final":
        AGENTIC_STATE.pop(key, None)
        system_logger.log(event="Chat return: ok", agent_state=character)
        return {
            "reply": result["reply"],
            "done": True,
            "provider_id": result.get("provider_id"),
            "model_id": result.get("model_id"),
            "pending_action": _build_pending_action(user["username"], character),
        }

    if result["status"] == "needs_more_turns":
        system_logger.log(
            event="Chat needs more turns", agent_state=character,
            details={"round": result["round"], "max_rounds": result["max_rounds"]},
        )
        return {
            "done": False,
            "needs_more_turns": True,
            "round": result["round"],
            "max_rounds": result["max_rounds"],
        }

    system_logger.log(
        event="Chat round in progress",
        agent_state=character,
        details={"round": result["round"], "max_rounds": result["max_rounds"], "tool_name": result["tool_name"]},
    )
    return {
        "done": False,
        "round": result["round"],
        "max_rounds": result["max_rounds"],
        "tool_name": result["tool_name"],
    }


@router.post("/deny-more-turns")
async def chat_deny_more_turns(payload: dict, user: Dict[str, Any] = Depends(get_current_user)):
    """Called when the user declines to grant more turns after an agentic
    reply hit MAX_TOOL_ROUNDS -- accepts progress made so far as final,
    same as /chat/interrupt but produces a proper wrap-up reply instead of
    a bare "Stopped."""
    character = _normalize_character(payload.get("character", None), user["username"])
    key = _agentic_key(user["username"], character)
    state = AGENTIC_STATE.pop(key, None)

    if not state:
        return {"done": True, "reply": ""}

    engine = ChatEngine(username=user["username"])

    if isinstance(state, dict) and state.get("kind") == "synergy":
        is_chat_synergy = str(state["resume_state"].get("phase", "")).startswith("chat_")
        if is_chat_synergy:
            result = await engine.deny_synergy_chat_more_rounds(state["resume_state"], character=character)
        else:
            result = await engine.deny_synergy_more_rounds(state["resume_state"], character=character)
        if result["status"] == "needs_more_turns":
            # Shouldn't normally happen (the discussion phase after a denied
            # diagnostic pass doesn't itself pause), but handled defensively
            # for consistency with the grant-more-turns path.
            AGENTIC_STATE[key] = {"kind": "synergy", "resume_state": result["resume_state"]}
            return {
                "done": False,
                "needs_more_turns": True,
                "round": result["round"],
                "max_rounds": result["max_rounds"],
                "pause_reason": result.get("pause_reason"),
            }
        if result["status"] == "tool_call":
            # Denying the diagnostic pass's extra rounds moves straight into
            # the (likely multi-step) A/B discussion phase -- surface that as
            # an in-progress round too instead of forcing it to finish
            # within this one request.
            AGENTIC_STATE[key] = {"kind": "synergy", "resume_state": result["resume_state"]}
            return {
                "done": False,
                "round": result["round"],
                "max_rounds": result["max_rounds"],
                "tool_name": result["tool_name"],
                "artifact_id": result.get("artifact_id"),
            }
        system_logger.log(event="Chat return: ok (synergy)", agent_state=character)
        return {
            "reply": result["reply"],
            "done": True,
            "provider_id": result.get("provider_id"),
            "model_id": result.get("model_id"),
            "pending_action": _build_pending_action(user["username"], character),
        }

    finalized = await engine.finalize_after_denied_more_turns(state)
    system_logger.log(event="Chat return: ok", agent_state=character)
    return {
        "reply": finalized["reply"],
        "done": True,
        "provider_id": finalized.get("provider_id"),
        "model_id": finalized.get("model_id"),
        "pending_action": _build_pending_action(user["username"], character),
    }


@router.post("/interrupt")
async def chat_interrupt(payload: dict, user: Dict[str, Any] = Depends(get_current_user)):
    """Stops an in-progress multi-round reply for this character, discarding
    any further tool-calling rounds. The current partial state is dropped;
    the next /chat/send starts a brand new reply."""
    character = _normalize_character(payload.get("character", None), user["username"])
    key = _agentic_key(user["username"], character)
    was_active = AGENTIC_STATE.pop(key, None) is not None
    return {"status": "interrupted", "was_active": was_active}


@router.post("/upload")
async def chat_upload(
    file: UploadFile = File(...),
    character_id: str | None = Form(None),
    user: Dict[str, Any] = Depends(get_current_user),
):
    """
    Uploads a file and sends it to the agent:
    - Plain-text/source-code files (by extension, or anything else that
      decodes cleanly as strict UTF-8) are inlined into the chat message as
      plain text -- the LLM only ever sees text, never a raw
      extension-specific parse.
    - Image files are automatically routed through the dedicated
      image-analysis pipeline (Settings -> Image Analysis) to get a
      description, regardless of whether the active chat persona's own
      model happens to support vision -- keeps behavior consistent/
      predictable and never dependent on the user's chat model choice.
      The description is then inlined as text so the persona still answers
      in character, as if reacting to what it was just shown.
    - Any other binary file type is rejected with a clear explanation
      instead of being silently mangled into garbled pseudo-text.
    """
    content = await file.read()
    filename = file.filename or "upload"
    ext = Path(filename).suffix.lower()
    character = _normalize_character(character_id, user["username"])

    engine = ChatEngine(username=user["username"])

    if ext in IMAGE_FILE_EXTENSIONS:
        mime = IMAGE_FILE_EXTENSIONS[ext]
        data_uri = f"data:{mime};base64,{base64.b64encode(content).decode('ascii')}"

        description = await _describe_image_via_analyze_model(engine, data_uri)
        if description is None:
            return {
                "message": (
                    f"I couldn't analyze \"{filename}\" -- no usable image-analysis "
                    "provider/API key is configured. Set one in Settings under "
                    "Image Analysis (or Chat)."
                )
            }
        user_message = (
            f"[Uploaded Image: {filename}]\n"
            f"(Auto-analyzed by the image-analysis model.)\n\n{description}"
        )
        messages = [{"role": "user", "content": user_message}]
    elif ext in TEXT_FILE_EXTENSIONS or _is_probably_text(content):
        text = content.decode("utf-8", errors="ignore")
        user_message = f"[Uploaded File: {filename} -- converted to plain text]\n\n{text}"
        messages = [{"role": "user", "content": user_message}]
    else:
        return {
            "message": (
                f"I can't process \"{filename}\" -- it doesn't look like a "
                "plain-text file or a supported image format "
                "(png/jpg/jpeg/gif/webp/bmp)."
            )
        }

    # Run completion
    result = await engine.chat(
        messages=messages,
        character=character or None,
        channel=normalize_channel(CHANNEL_PRIVATE_CHAT),
    )

    reply = (
        result.get("reply")
        or result.get("content")
        or result.get("text")
        or ""
    )

    return {"message": reply}


# ---------------------------------------------------------
# STREAMING CHAT (REAL)
# ---------------------------------------------------------

async def _stream_generator(
    engine: ChatEngine,
    messages: List[Dict[str, Any]],
    character: str | None,
) -> AsyncGenerator[bytes, None]:
    async for event in engine.stream(
        messages=messages,
        character=character,
        channel=normalize_channel(CHANNEL_PRIVATE_CHAT),
    ):
        import json
        yield (json.dumps(event) + "\n").encode("utf-8")


@router.post("/stream")
async def chat_stream(
    payload: ChatRequest,
    user: Dict[str, Any] = Depends(get_current_user),
):
    character = _normalize_character(payload.character, user["username"])
    engine = ChatEngine(username=user["username"])
    messages = [m.model_dump() for m in payload.messages]

    return StreamingResponse(
        _stream_generator(engine, messages, character or None),
        media_type="application/json",
    )


# ---------------------------------------------------------
# GROUP CHAT (UNCHANGED)
# ---------------------------------------------------------

@router.post("/group/start")
async def group_chat_start(
    payload: GroupChatStartRequest,
    user: Dict[str, Any] = Depends(get_current_user),
):
    username = user["username"]

    # Re-entering the SAME group chat (same participant roster) should
    # resume the live session in place -- history, scene setup, and
    # introduction progress intact -- rather than silently discarding it
    # and starting over just because the frontend re-opened the page.
    existing = get_group_session(username)
    if existing and {p.name for p in existing.state.participants} == set(payload.characters):
        return {
            "status": "resumed",
            "message": "Resumed existing group chat",
            "name": existing.state.name,
            "participants": [p.name for p in existing.state.sorted_participants()],
        }

    # Use the user's actual onboarding display name (e.g. "Darryl Smith")
    # instead of the raw login username, so group chat transcripts/prompts
    # address the user by the name they gave during onboarding.
    profile = UserService.get_user(username)
    user_display_name = (profile.display_name if profile and profile.display_name else username)

    def get_safety_role(name: str) -> int:
        # `load_character` (merge-aware: vault override, falling back to a
        # system agent's .base.json) rather than a raw vault-only lookup --
        # a system character not yet backfilled into this user's vault (e.g.
        # one added after the user onboarded) still resolves correctly here.
        # Synergy is a reserved, characterless participant (see chat/synergy/
        # service.py) -- it has no vault/persona entry, so it never goes
        # through load_character at all.
        if name == SYNERGY_CHARACTER_NAME:
            return 0
        char = load_character(username, name)
        if not char:
            raise HTTPException(400, f"Character '{name}' does not exist")
        return char.get("safety_role", 0)

    def get_delay_seconds() -> float:
        prefs = VaultService.get_preferences(username)
        return 5.0

    def voice_wait_stub(character_name: str):
        pass

    provider, model = payload.provider, payload.model
    if not provider or not model:
        engine = ChatEngine(username=username)
        try:
            resolved_provider, resolved_model = engine._get_active_chat_model()
        except Exception as e:
            raise HTTPException(400, f"Could not resolve an active chat model: {e}")
        provider = provider or resolved_provider
        model = model or resolved_model

    session = GroupChatRouter(
        username=username,
        user_display_name=user_display_name,
        character_names=payload.characters,
        provider=provider,
        model=model,
        get_safety_role=get_safety_role,
        get_delay_seconds=get_delay_seconds,
        voice_wait_hook=voice_wait_stub,
        is_introduction=True,
        name=payload.name.strip() or ", ".join(payload.characters),
        scene_description=(payload.scene_description or "").strip() or None,
    )

    set_group_session(username, session)

    return {
        "status": "ok",
        "message": "Group chat started",
        "name": session.state.name,
        "participants": [p.name for p in session.state.sorted_participants()],
    }


@router.post("/group/user_message")
async def group_chat_user_message(
    payload: GroupChatUserMessage,
    user: Dict[str, Any] = Depends(get_current_user),
):
    session = get_group_session(user["username"])
    if not session:
        raise HTTPException(400, "No active group chat session")

    await session.user_message(payload.message)
    return {"status": "ok"}


@router.get("/group/active")
async def group_chat_active(
    user: Dict[str, Any] = Depends(get_current_user),
):
    """Lets the frontend check for a still-running session (e.g. on page
    load) so it can offer to resume it instead of always starting fresh."""
    session = get_group_session(user["username"])
    if not session:
        return {"active": False}
    return {
        "active": True,
        "name": session.state.name,
        "participants": [p.name for p in session.state.sorted_participants()],
    }


@router.post("/group/add_member")
async def group_chat_add_member(
    payload: GroupChatAddMemberRequest,
    user: Dict[str, Any] = Depends(get_current_user),
):
    """Adds a new character to the currently active group chat without
    ending it and starting a new one, optionally announcing the arrival
    with a scene-setup message visible to every participant."""
    session = get_group_session(user["username"])
    if not session:
        raise HTTPException(400, "No active group chat session")

    session.add_participant(payload.character, scene_setup=payload.scene_setup)

    return {
        "status": "ok",
        "participants": [p.name for p in session.state.sorted_participants()],
    }


@router.post("/group/next_turn")
async def group_chat_next_turn(
    user: Dict[str, Any] = Depends(get_current_user),
):
    session = get_group_session(user["username"])
    if not session:
        raise HTTPException(400, "No active group chat session")

    result = await session.next_turn()
    return result or {"status": "waiting_for_user"}


@router.post("/group/auto")
async def group_chat_auto(
    user: Dict[str, Any] = Depends(get_current_user),
):
    session = get_group_session(user["username"])
    if not session:
        raise HTTPException(400, "No active group chat session")

    await session.run_auto_mode()
    return {"status": "auto_mode_complete"}


@router.post("/group/interrupt")
async def group_chat_interrupt(
    user: Dict[str, Any] = Depends(get_current_user),
):
    session = get_group_session(user["username"])
    if not session:
        raise HTTPException(400, "No active group chat session")

    session.interrupt()
    return {"status": "interrupted"}


@router.get("/group/state")
async def group_chat_state(
    user: Dict[str, Any] = Depends(get_current_user),
):
    session = get_group_session(user["username"])
    if not session:
        raise HTTPException(400, "No active group chat session")

    return {
        "name": session.state.name,
        "user_name": session.state.user_name,
        "participants": [p.name for p in session.state.sorted_participants()],
        "history": [
            {
                "timestamp": m.timestamp,
                "sender": m.sender,
                "message": m.message,
            }
            for m in session.state.history
        ],
        "auto_mode": session.state.auto_mode,
        "turn_index": session.state.turn_index,
        "is_introduction": session.state.is_introduction,
    }


@router.post("/group/end")
async def group_chat_end(
    user: Dict[str, Any] = Depends(get_current_user),
):
    delete_group_session(user["username"])
    return {"status": "ended"}


@router.post("/group/save")
async def group_chat_save(
    user: Dict[str, Any] = Depends(get_current_user),
):
    """Persists the active group chat session to disk so it can be resumed
    later -- e.g. after a server restart, which otherwise silently drops
    every live session (they only ever lived in GROUP_CHAT_SESSIONS)."""
    username = user["username"]
    session = get_group_session(username)
    if not session:
        raise HTTPException(400, "No active group chat session")

    data = session.to_dict()
    data["saved_at"] = datetime.utcnow().isoformat() + "Z"

    slug = _slugify_group_name(session.state.name or "group_chat")
    save_path = _group_chat_save_dir(username) / f"{slug}.json"
    save_path.write_text(json.dumps(data, indent=2), encoding="utf-8")

    return {"status": "saved", "id": slug, "name": session.state.name}


@router.get("/group/saved")
async def group_chat_list_saved(
    user: Dict[str, Any] = Depends(get_current_user),
):
    """Lists group chats previously saved via /group/save, so the setup
    page can offer to resume one instead of always starting fresh."""
    saved = []
    for save_path in sorted(_group_chat_save_dir(user["username"]).glob("*.json")):
        try:
            data = json.loads(save_path.read_text(encoding="utf-8"))
        except Exception:
            continue
        saved.append({
            "id": save_path.stem,
            "name": data.get("name") or save_path.stem,
            "participants": data.get("character_names", []),
            "saved_at": data.get("saved_at"),
            "message_count": len(data.get("history", [])),
        })

    saved.sort(key=lambda s: s.get("saved_at") or "", reverse=True)
    return {"saved": saved}


@router.post("/group/resume")
async def group_chat_resume(
    payload: Dict[str, Any],
    user: Dict[str, Any] = Depends(get_current_user),
):
    """Loads a previously-saved group chat back into memory as the active
    session (replacing any current one), picking up where it left off."""
    save_id = str(payload.get("id") or "").strip()
    if not save_id:
        raise HTTPException(400, "id is required")

    username = user["username"]
    save_path = _group_chat_save_dir(username) / f"{save_id}.json"
    if not save_path.exists():
        raise HTTPException(404, "Saved group chat not found")

    data = json.loads(save_path.read_text(encoding="utf-8"))

    def get_safety_role(name: str) -> int:
        if name == SYNERGY_CHARACTER_NAME:
            return 0
        char = load_character(username, name)
        if not char:
            raise HTTPException(400, f"Character '{name}' does not exist")
        return char.get("safety_role", 0)

    def get_delay_seconds() -> float:
        return 5.0

    def voice_wait_stub(character_name: str):
        pass

    session = GroupChatRouter.from_saved_state(
        data,
        get_safety_role=get_safety_role,
        get_delay_seconds=get_delay_seconds,
        voice_wait_hook=voice_wait_stub,
    )
    set_group_session(username, session)

    return {
        "status": "resumed",
        "name": session.state.name,
        "participants": [p.name for p in session.state.sorted_participants()],
    }


# ---------------------------------------------------------
# Reply feedback (thumbs up/down) -- only meaningful, and only ever shown
# in the frontend, for replies produced by our own Atlas Server TLM (see
# ATLAS_SERVER_PROVIDER_ID above). Rejects anything else server-side too,
# not just via frontend gating, since there is nowhere for feedback on a
# third-party provider's reply to actually go.
# ---------------------------------------------------------

@router.post("/reply-feedback")
async def chat_reply_feedback(
    payload: Dict[str, Any],
    user: Dict[str, Any] = Depends(get_current_user),
):
    rating = str(payload.get("rating") or "").strip().lower()
    provider_id = str(payload.get("provider_id") or "").strip()

    if rating not in ("up", "down"):
        raise HTTPException(400, "'rating' must be 'up' or 'down'.")
    if provider_id != ATLAS_SERVER_PROVIDER_ID:
        raise HTTPException(400, "Reply feedback is only supported for Atlas Server replies.")

    from chat.feedback_store import record_reply_feedback

    entry = record_reply_feedback(
        user["username"],
        rating=rating,
        provider_id=provider_id,
        model_id=payload.get("model_id"),
        character=payload.get("character"),
        channel=payload.get("channel"),
        message_excerpt=payload.get("message_excerpt"),
    )
    return {"ok": True, "id": entry["id"]}


# ---------------------------------------------------------
# Chat background images -- a single custom background image per private
# (1:1 character) chat and per group chat, stored under DATA_DIR and served
# through the existing unauthenticated /data static mount (same convention
# already used by character avatars/gallery images, see characters.py).
# ---------------------------------------------------------

def _chat_background_dir(username: str, scope: str, key: str) -> Path:
    from core.runtime.runtime import get_runtime

    base = get_runtime().env.DATA_DIR / "users" / username / "chat_backgrounds" / scope / key
    base.mkdir(parents=True, exist_ok=True)
    return base


def _chat_background_data_url(path: Path) -> str:
    from core.runtime.runtime import get_runtime

    rel = path.resolve().relative_to(get_runtime().env.DATA_DIR.resolve())
    return "/data/" + str(rel).replace("\\", "/")


def _read_existing_background(base: Path) -> Optional[str]:
    if not base.exists():
        return None
    for f in sorted(base.iterdir()):
        if f.is_file() and f.suffix.lower() in IMAGE_FILE_EXTENSIONS:
            return _chat_background_data_url(f)
    return None


def _clear_background_dir(base: Path) -> None:
    if not base.exists():
        return
    for f in base.iterdir():
        if f.is_file():
            f.unlink(missing_ok=True)


def _background_meta_path(base: Path) -> Path:
    return base / "background.meta.json"


def _normalize_chat_text_color(value: Any) -> Optional[str]:
    if value is None:
        return None
    if not isinstance(value, str):
        return None
    color = value.strip()
    if not color:
        return None
    if re.fullmatch(r"#[0-9a-fA-F]{6}", color):
        return color.lower()
    return None


def _normalize_background_position(position: Any) -> Optional[Dict[str, float]]:
    if not isinstance(position, dict):
        return None
    try:
        x = float(position.get("x", 50))
        y = float(position.get("y", 50))
    except (TypeError, ValueError):
        return None
    return {
        "x": max(0.0, min(100.0, x)),
        "y": max(0.0, min(100.0, y)),
    }


def _read_background_meta(base: Path) -> Dict[str, Any]:
    meta = _background_meta_path(base)
    if not meta.exists():
        return {}
    try:
        data = json.loads(meta.read_text(encoding="utf-8"))
    except Exception:
        return {}
    if not isinstance(data, dict):
        return {}

    normalized: Dict[str, Any] = {}
    position = _normalize_background_position(data.get("position"))
    text_color = _normalize_chat_text_color(data.get("text_color"))
    if position is not None:
        normalized["position"] = position
    if text_color is not None:
        normalized["text_color"] = text_color
    return normalized


def _read_background_position(base: Path) -> Optional[Dict[str, float]]:
    return _read_background_meta(base).get("position")


def _read_background_text_color(base: Path) -> Optional[str]:
    return _read_background_meta(base).get("text_color")


def _write_background_meta(
    base: Path,
    *,
    position: Any = None,
    text_color: Any = None,
) -> None:
    meta = _background_meta_path(base)
    existing = _read_background_meta(base)

    normalized_position = _normalize_background_position(position)
    if normalized_position is None:
        existing.pop("position", None)
    else:
        existing["position"] = normalized_position

    normalized_text_color = _normalize_chat_text_color(text_color)
    if text_color is None:
        existing.pop("text_color", None)
    elif normalized_text_color is None:
        existing.pop("text_color", None)
    else:
        existing["text_color"] = normalized_text_color

    if not existing:
        meta.unlink(missing_ok=True)
        return

    meta.write_text(json.dumps(existing, indent=2), encoding="utf-8")


def _background_response(base: Path) -> Dict[str, Any]:
    return {
        "url": _read_existing_background(base),
        "position": _read_background_position(base) or {"x": 50.0, "y": 50.0},
        "text_color": _read_background_text_color(base),
    }


async def _upload_chat_background(
    scope: str,
    key: str,
    file: UploadFile,
    username: str,
    position: Any = None,
) -> Dict[str, Any]:
    ext = Path(file.filename or "").suffix.lower()
    if ext not in IMAGE_FILE_EXTENSIONS:
        raise HTTPException(status_code=400, detail="Only image files (png/jpg/jpeg/gif/webp/bmp) are supported.")

    import shutil

    base = _chat_background_dir(username, scope, key)
    existing_text_color = _read_background_text_color(base)
    _clear_background_dir(base)
    dest = base / f"background{ext}"
    with dest.open("wb") as out:
        shutil.copyfileobj(file.file, out)

    _write_background_meta(base, position=position, text_color=existing_text_color)

    return {"status": "ok", **_background_response(base)}


class SetBackgroundFromGalleryRequest(BaseModel):
    path: str  # e.g. "/data/users/{username}/characters/{character}/gallery/modern/x.png"
    position: Optional[Dict[str, float]] = None


class UpdateChatBackgroundSettingsRequest(BaseModel):
    position: Optional[Dict[str, float]] = None
    text_color: Optional[str] = None


def _set_chat_background_from_gallery(
    scope: str,
    key: str,
    gallery_path: str,
    username: str,
    position: Any = None,
) -> Dict[str, Any]:
    from core.runtime.runtime import get_runtime

    runtime = get_runtime()
    # Only allow paths that resolve to somewhere inside this user's OWN data
    # directory -- prevents path traversal or reading another user's files.
    prefix = f"/data/users/{username}/"
    if not gallery_path.startswith(prefix):
        raise HTTPException(status_code=400, detail="Invalid image path.")

    src = (runtime.env.DATA_DIR / gallery_path[len("/data/"):]).resolve()
    data_root = runtime.env.DATA_DIR.resolve()
    if data_root not in src.parents or not src.is_file():
        raise HTTPException(status_code=400, detail="Image not found.")
    if src.suffix.lower() not in IMAGE_FILE_EXTENSIONS:
        raise HTTPException(status_code=400, detail="Only image files (png/jpg/jpeg/gif/webp/bmp) are supported.")

    import shutil

    base = _chat_background_dir(username, scope, key)
    existing_text_color = _read_background_text_color(base)
    _clear_background_dir(base)
    dest = base / f"background{src.suffix.lower()}"
    shutil.copyfile(src, dest)

    _write_background_meta(base, position=position, text_color=existing_text_color)

    return {"status": "ok", **_background_response(base)}


@router.get("/background/private/{character}")
async def get_private_chat_background(character: str, user: Dict[str, Any] = Depends(get_current_user)):
    username = user["username"]
    character = _normalize_character(character, username) or "global"
    base = _chat_background_dir(username, "private", character)
    return _background_response(base)


@router.post("/background/private/{character}/settings")
async def update_private_chat_background_settings(
    character: str,
    payload: UpdateChatBackgroundSettingsRequest,
    user: Dict[str, Any] = Depends(get_current_user),
):
    username = user["username"]
    character = _normalize_character(character, username) or "global"
    base = _chat_background_dir(username, "private", character)
    _write_background_meta(base, position=payload.position, text_color=payload.text_color)
    return {"status": "ok", **_background_response(base)}


@router.post("/background/private/{character}/upload")
async def upload_private_chat_background(
    character: str,
    file: UploadFile = File(...),
    user: Dict[str, Any] = Depends(get_current_user),
):
    username = user["username"]
    character = _normalize_character(character, username) or "global"
    return await _upload_chat_background("private", character, file, username)


@router.post("/background/private/{character}/from_gallery")
async def set_private_chat_background_from_gallery(
    character: str,
    payload: SetBackgroundFromGalleryRequest,
    user: Dict[str, Any] = Depends(get_current_user),
):
    username = user["username"]
    character = _normalize_character(character, username) or "global"
    return _set_chat_background_from_gallery("private", character, payload.path, username, payload.position)


@router.delete("/background/private/{character}")
async def delete_private_chat_background(character: str, user: Dict[str, Any] = Depends(get_current_user)):
    username = user["username"]
    character = _normalize_character(character, username) or "global"
    _clear_background_dir(_chat_background_dir(username, "private", character))
    return {"status": "ok"}


@router.get("/background/group/{group_name}")
async def get_group_chat_background(group_name: str, user: Dict[str, Any] = Depends(get_current_user)):
    username = user["username"]
    base = _chat_background_dir(username, "group", _slugify_group_name(group_name))
    return _background_response(base)


@router.post("/background/group/{group_name}/settings")
async def update_group_chat_background_settings(
    group_name: str,
    payload: UpdateChatBackgroundSettingsRequest,
    user: Dict[str, Any] = Depends(get_current_user),
):
    username = user["username"]
    base = _chat_background_dir(username, "group", _slugify_group_name(group_name))
    _write_background_meta(base, position=payload.position, text_color=payload.text_color)
    return {"status": "ok", **_background_response(base)}


@router.post("/background/group/{group_name}/upload")
async def upload_group_chat_background(
    group_name: str,
    file: UploadFile = File(...),
    user: Dict[str, Any] = Depends(get_current_user),
):
    username = user["username"]
    return await _upload_chat_background("group", _slugify_group_name(group_name), file, username)


@router.delete("/background/group/{group_name}")
async def delete_group_chat_background(group_name: str, user: Dict[str, Any] = Depends(get_current_user)):
    username = user["username"]
    _clear_background_dir(_chat_background_dir(username, "group", _slugify_group_name(group_name)))
    return {"status": "ok"}

