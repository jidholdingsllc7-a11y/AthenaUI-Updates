﻿# AthenaUI v3.5 — Screenshot Full Tool (Bridge Wrapper)
# File: backend/tools/system/ui/ui_screenshot_full.py
# Created: 2026-04-12 14:30 CDT
# Updated: 2026-07-27 19:49 CDT

import httpx
from typing import Dict, Any

from ._screen_vision import describe_screenshot

BRIDGE_URL = "http://localhost:9000"

capabilities = {
    "needs_bridge": True,
    "needs_filesystem": False,
    "needs_network": False,
    "needs_user": False,
}

async def run(args: Dict[str, Any]) -> Dict[str, Any]:
    async with httpx.AsyncClient() as client:
        resp = await client.get(f"{BRIDGE_URL}/ui/screenshot_full")
        data = resp.json()

    if isinstance(data, dict) and data.get("status") == "ok" and data.get("path"):
        description = describe_screenshot(args.get("username", "system"), data["path"])
        if description:
            data["description"] = description

    return data
