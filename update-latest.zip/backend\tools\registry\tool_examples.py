﻿# AthenaUI v3.5 — Tool Usage Examples
# File: backend/tools/registry/tool_examples.py
# Created: 2026-04-09 12:39 CDT
# Updated: 2026-07-27 19:49 CDT

TOOL_EXAMPLES = [
    # ---------------------------------------------------------
    # FILE SYSTEM
    # ---------------------------------------------------------

    {
        "description": "Read a file from the workspace.",
        "call": {
            "tool": "file_read",
            "arguments": {
                "path": "src/app/main.py",
                "username": "darryl"
            }
        }
    },
    {
        "description": "Write a file -- live immediately; a Keep/Revert prompt appears automatically if it already existed.",
        "call": {
            "tool": "file_write",
            "arguments": {
                "path": "src/app/config.json",
                "content": "{ \"debug\": true }",
                "username": "darryl"
            }
        }
    },
    {
        "description": "Edit just a few lines of an existing file instead of resending the whole file.",
        "call": {
            "tool": "file_edit_lines",
            "arguments": {
                "path": "src/app/main.py",
                "start_line": 10,
                "end_line": 10,
                "new_text": "print('Hello World')\n",
                "username": "darryl"
            }
        }
    },

    # ---------------------------------------------------------
    # TERMINAL
    # ---------------------------------------------------------

    {
        "description": "Run a terminal command.",
        "call": {
            "tool": "terminal_run",
            "arguments": {
                "command": "pip install fastapi",
                "username": "darryl"
            }
        }
    },

    # ---------------------------------------------------------
    # HTTP
    # ---------------------------------------------------------

    {
        "description": "Make an HTTP GET request.",
        "call": {
            "tool": "http_request",
            "arguments": {
                "method": "GET",
                "url": "https://api.github.com/repos/AthenaUI/Athena",
                "timeout": 10
            }
        }
    },

    # ---------------------------------------------------------
    # UI / BRIDGE
    # ---------------------------------------------------------

    {
        "description": "Inspect a UI element by CSS selector.",
        "call": {
            "tool": "ui_inspect",
            "arguments": {
                "selector": "#login-button"
            }
        }
    },
    {
        "description": "Extract the full DOM tree of the active page.",
        "call": {
            "tool": "ui_dom_tree",
            "arguments": {}
        }
    },
    {
        "description": "Navigate the browser to a URL.",
        "call": {
            "tool": "ui_navigate",
            "arguments": {
                "url": "https://example.com"
            }
        }
    },
    {
        "description": "Move the mouse to a coordinate.",
        "call": {
            "tool": "mouse_move",
            "arguments": {
                "x": 400,
                "y": 300
            }
        }
    },
    {
        "description": "Click the left mouse button.",
        "call": {
            "tool": "mouse_click",
            "arguments": {
                "button": "left"
            }
        }
    },
    {
        "description": "Type text into the active field.",
        "call": {
            "tool": "keyboard_type",
            "arguments": {
                "text": "Hello world!"
            }
        }
    },
    {
        "description": "Take an annotated screenshot of a submit button.",
        "call": {
            "tool": "ui_screenshot_annotated",
            "arguments": {
                "selector": "#submit"
            }
        }
    },
    {
        "description": "Start UI recording.",
        "call": {
            "tool": "record_start",
            "arguments": {}
        }
    },
    {
        "description": "Stop UI recording.",
        "call": {
            "tool": "record_stop",
            "arguments": {}
        }
    },
    {
        "description": "Scroll down the page.",
        "call": {
            "tool": "scroll",
            "arguments": {
                "dx": 0,
                "dy": -500
            }
        }
    },
    {
        "description": "Highlight a region on screen.",
        "call": {
            "tool": "ui_highlight",
            "arguments": {
                "x": 100,
                "y": 200,
                "width": 300,
                "height": 150,
                "duration": 0.75
            }
        }
    },

    # ---------------------------------------------------------
    # BUILD MAP
    # ---------------------------------------------------------

    {
        "description": "Create a new Build Map for the user's project.",
        "call": {
            "tool": "build_map.create",
            "arguments": {
                "project": {
                    "id": "my_app",
                    "name": "My App",
                    "description": "A new program.",
                    "workspace_root": "."
                },
                "constraints": {
                    "languages": ["python"],
                    "frameworks": ["fastapi"],
                    "max_file_lines": 300,
                    "avoid_absolute_paths": True
                },
                "architecture": {
                    "overview": "Simple backend app.",
                    "modules": []
                },
                "directory_tree": [],
                "files": [],
                "build_order": [],
                "execution_rules": {
                    "create_missing_directories": True,
                    "overwrite_existing_files": False,
                    "validate_dependencies": True,
                    "stop_on_error": True
                },
                "verification": {
                    "checks": []
                }
            }
        }
    },
    {
        "description": "Update an existing Build Map.",
        "call": {
            "tool": "build_map.update",
            "arguments": {
                "architecture": {
                    "overview": "Updated architecture."
                }
            }
        }
    },
    {
        "description": "Retrieve the current Build Map.",
        "call": {
            "tool": "build_map.get",
            "arguments": {}
        }
    },
    {
        "description": "Execute the Build Map and create all planned directories and files.",
        "call": {
            "tool": "build_map.execute",
            "arguments": {}
        }
    },
    {
        "description": "Verify the Build Map for consistency, missing files, and path safety.",
        "call": {
            "tool": "build_map.verify",
            "arguments": {}
        }
    },

]

