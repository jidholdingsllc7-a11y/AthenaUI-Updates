# AthenaUI v3.5 — email_cleanup_rule_add Tool
# File: backend/tools/email/email_cleanup_rule_add.py
#
# Saves a reusable inbox cleanup rule the user just taught in conversation
# (e.g. "always delete emails from this sender", "keep emails with this
# subject") so future cleanup passes -- by you or any other agent -- follow
# it automatically. For acting on ONE specific email right now, just use
# email_delete_message/email_delete_messages instead -- this tool is only
# for the reusable "from now on..." pattern rules.

from typing import Any, Dict

from email_rules.service import EmailRulesError, add_rule

capabilities = {
    "needs_filesystem": True,
    "needs_bridge": False,
    "needs_network": False,
    "needs_user": True,
}


async def run(args: Dict[str, Any]) -> str:
    try:
        username = args.get("username")
        character = args.get("character")
        action = args.get("action")
        match_type = args.get("match_type")
        match_value = args.get("match_value")

        if not username:
            return "[ERROR] Missing 'username' argument."
        if not action:
            return "[ERROR] Missing 'action' argument (must be 'keep' or 'delete')."
        if not match_type:
            return "[ERROR] Missing 'match_type' argument (must be 'sender', 'subject', or 'similar_content')."
        if not match_value:
            return "[ERROR] Missing 'match_value' argument."

        rule = add_rule(
            username,
            action=action,
            match_type=match_type,
            match_value=match_value,
            account_label=args.get("account_label"),
            note=args.get("note"),
            character=character,
        )
        return (
            f"Cleanup rule saved: {rule['action']} emails where {rule['match_type']} matches "
            f"'{rule['match_value']}' (id={rule['id']})."
        )
    except EmailRulesError as e:
        return f"[ERROR] {e}"
    except Exception as e:
        return f"[ERROR] Failed to save cleanup rule: {str(e)}"
