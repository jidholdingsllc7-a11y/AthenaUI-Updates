# AthenaUI v3.5 — Marketing Email Dashboard API Routes
# File: backend/api/routes/marketing_email.py
#
# Authenticated REST endpoints backing the Marketing Email dashboard page:
# reviewing/sending agent-proposed newsletter drafts, and configuring which
# agent "monitors" a given email account (new-mail notifications + optional
# auto-reply following user-authored instructions).

from __future__ import annotations

from typing import Any, Dict

from fastapi import APIRouter, Body, Depends, HTTPException, Query

from api.deps.auth_middleware import get_current_user
from emailing.service import EmailAccountsService, EmailServiceError
from newsletter.service import (
    NewsletterError,
    delete_draft,
    get_draft,
    list_drafts,
    list_subscribers,
    mark_draft_sent,
)
from auto_reply.service import (
    AutoReplyError,
    delete_config,
    delete_pending_reply,
    get_config,
    get_pending_reply,
    list_configs,
    list_pending_replies,
    set_config,
)

router = APIRouter(prefix="/marketing_email", tags=["marketing_email"])


def _username_from_user(user: Any) -> str:
    username = user.get("username") if isinstance(user, dict) else getattr(user, "username", None)
    if not username:
        raise HTTPException(status_code=401, detail="Authentication required.")
    return str(username)


def _label_for_account(username: str, account_id: str) -> str:
    account = EmailAccountsService.get_account_by_id(username, account_id)
    if not account:
        raise HTTPException(status_code=404, detail=f"Email account '{account_id}' not found.")
    return account["label"]


# ---------------------------------------------------------
# Newsletter drafts
# ---------------------------------------------------------

@router.get("/drafts")
async def get_drafts(status: str | None = Query(None), user: Dict[str, Any] = Depends(get_current_user)):
    username = _username_from_user(user)
    return {"drafts": list_drafts(username, status=status)}


@router.post("/drafts/{draft_id}/send")
async def send_draft(
    draft_id: str,
    payload: Dict[str, Any] = Body(default={}),
    user: Dict[str, Any] = Depends(get_current_user),
):
    username = _username_from_user(user)
    character = str(payload.get("character", ""))
    account_id = payload.get("account_id")
    if not character:
        raise HTTPException(status_code=400, detail="'character' is required.")

    try:
        draft = get_draft(username, draft_id)
    except NewsletterError as e:
        raise HTTPException(status_code=404, detail=str(e))

    account_label = _label_for_account(username, account_id) if account_id else None

    subscribers = list_subscribers(username, status="subscribed")
    if not subscribers:
        raise HTTPException(status_code=400, detail="No subscribed newsletter recipients -- nothing to send.")

    sent, failed = 0, []
    for sub in subscribers:
        try:
            EmailAccountsService.send_email(
                username=username, character=character, to=sub["email"],
                subject=draft["subject"], body=draft["body"], account_label=account_label,
            )
            sent += 1
        except EmailServiceError as e:
            failed.append({"email": sub["email"], "error": str(e)})

    mark_draft_sent(username, draft_id)
    return {"ok": True, "sent": sent, "failed": failed}


@router.delete("/drafts/{draft_id}")
async def remove_draft(draft_id: str, user: Dict[str, Any] = Depends(get_current_user)):
    username = _username_from_user(user)
    try:
        delete_draft(username, draft_id)
    except NewsletterError as e:
        raise HTTPException(status_code=404, detail=str(e))
    return {"ok": True}


# ---------------------------------------------------------
# Inbox monitoring / auto-reply configuration
# ---------------------------------------------------------

@router.get("/auto-reply")
async def get_auto_reply_configs(user: Dict[str, Any] = Depends(get_current_user)):
    username = _username_from_user(user)
    return {"configs": list_configs(username)}


@router.post("/auto-reply")
async def save_auto_reply_config(
    payload: Dict[str, Any] = Body(...),
    user: Dict[str, Any] = Depends(get_current_user),
):
    username = _username_from_user(user)
    account_id = str(payload.get("account_id", ""))
    if not account_id:
        raise HTTPException(status_code=400, detail="'account_id' is required.")
    label = _label_for_account(username, account_id)
    try:
        config = set_config(
            username,
            account_id=account_id,
            account_label=label,
            character=str(payload.get("character", "")),
            instructions=payload.get("instructions"),
            enabled=bool(payload.get("enabled", True)),
            auto_reply_enabled=bool(payload.get("auto_reply_enabled", False)),
        )
    except AutoReplyError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"ok": True, "config": config}


@router.delete("/auto-reply/{account_id}")
async def remove_auto_reply_config(account_id: str, user: Dict[str, Any] = Depends(get_current_user)):
    username = _username_from_user(user)
    try:
        delete_config(username, account_id)
    except AutoReplyError as e:
        raise HTTPException(status_code=404, detail=str(e))
    return {"ok": True}


# ---------------------------------------------------------
# Pending replies (agent-drafted, awaiting approve/edit/deny)
# ---------------------------------------------------------

@router.get("/pending-replies")
async def get_pending_replies(user: Dict[str, Any] = Depends(get_current_user)):
    username = _username_from_user(user)
    return {"pending_replies": list_pending_replies(username)}


@router.post("/pending-replies/{reply_id}/approve")
async def approve_pending_reply(
    reply_id: str,
    payload: Dict[str, Any] = Body(default={}),
    user: Dict[str, Any] = Depends(get_current_user),
):
    username = _username_from_user(user)
    reply = get_pending_reply(username, reply_id)
    if not reply:
        raise HTTPException(status_code=404, detail=f"No pending reply '{reply_id}'.")

    body = str(payload.get("body") or reply["draft_reply"])
    try:
        EmailAccountsService.send_email(
            username=username,
            character=reply["character"],
            to=reply["sender"],
            subject=f"Re: {reply['subject']}" if reply["subject"] else "Re: your message",
            body=body,
            account_label=reply["account_label"],
        )
    except EmailServiceError as e:
        raise HTTPException(status_code=400, detail=str(e))

    delete_pending_reply(username, reply_id)
    return {"ok": True}


@router.delete("/pending-replies/{reply_id}")
async def deny_pending_reply(reply_id: str, user: Dict[str, Any] = Depends(get_current_user)):
    username = _username_from_user(user)
    try:
        delete_pending_reply(username, reply_id)
    except AutoReplyError as e:
        raise HTTPException(status_code=404, detail=str(e))
    return {"ok": True}
