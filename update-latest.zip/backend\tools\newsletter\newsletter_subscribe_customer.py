# AthenaUI v3.5 — newsletter_subscribe_customer Tool
# File: backend/tools/newsletter/newsletter_subscribe_customer.py
#
# Adds a customer to the opt-in email newsletter list -- use this after a
# customer AGREES in conversation to receive the newsletter. For a customer
# opting in on their own (via the public opt-in webpage), see
# api/routes/newsletter.py instead -- that path needs no agent involvement.

from typing import Any, Dict

from newsletter.service import NewsletterError, subscribe

capabilities = {
    "needs_filesystem": True,
    "needs_bridge": False,
    "needs_network": False,
    "needs_user": True,
}


async def run(args: Dict[str, Any]) -> str:
    try:
        username = args.get("username")
        email = args.get("email")
        if not username:
            return "[ERROR] Missing 'username' argument."
        if not email:
            return "[ERROR] Missing 'email' argument."

        result = subscribe(
            username,
            email=email,
            name=args.get("name"),
            customer_id=args.get("customer_id"),
            source="agent",
        )
        return f"'{result['email']}' is now subscribed to the newsletter."
    except NewsletterError as e:
        return f"[ERROR] {e}"
    except Exception as e:
        return f"[ERROR] Failed to subscribe customer: {str(e)}"
