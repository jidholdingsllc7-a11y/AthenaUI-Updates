# AthenaUI v3.5 — Inbox Monitoring / Auto-Reply Config Service
# File: backend/auto_reply/service.py
#
# Per-account "assign an agent to monitor this inbox" configuration for the
# Marketing Email dashboard: which character watches an email account, an
# always-on notification-bell alert for new mail, and an OPTIONAL auto-reply
# mode where the agent drafts + sends a reply following user-authored
# instructions (e.g. "if it's a compliment, thank them; if it's a bug
# report, apologize and say the team is on it"). The background loop in
# auto_reply/monitor.py polls using this config and the `last_processed_uid`
# cursor to avoid re-processing/re-notifying about the same message twice.
#
# Storage: one dedicated SQLite file per human user:
#   {DATA_DIR}/users/{username}/auto_reply/configs.sqlite

from __future__ import annotations

import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from core.runtime.runtime import get_runtime


class AutoReplyError(Exception):
    pass


def _root_dir(username: str) -> Path:
    runtime = get_runtime()
    root = runtime.env.DATA_DIR / "users" / username / "auto_reply"
    root.mkdir(parents=True, exist_ok=True)
    return root


def _db_path(username: str) -> Path:
    return _root_dir(username) / "configs.sqlite"


def _connect(username: str) -> sqlite3.Connection:
    conn = sqlite3.connect(_db_path(username))
    conn.row_factory = sqlite3.Row
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS configs (
            account_id TEXT PRIMARY KEY,
            account_label TEXT,
            character TEXT NOT NULL,
            instructions TEXT,
            enabled INTEGER NOT NULL DEFAULT 1,
            auto_reply_enabled INTEGER NOT NULL DEFAULT 0,
            last_processed_uid INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS pending_replies (
            id TEXT PRIMARY KEY,
            account_id TEXT NOT NULL,
            account_label TEXT,
            character TEXT NOT NULL,
            uid TEXT NOT NULL,
            sender TEXT,
            subject TEXT,
            draft_reply TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """
    )
    return conn


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _row_to_config(row: sqlite3.Row) -> Dict[str, Any]:
    d = dict(row)
    d["enabled"] = bool(d["enabled"])
    d["auto_reply_enabled"] = bool(d["auto_reply_enabled"])
    return d


def set_config(
    username: str,
    account_id: str,
    account_label: str,
    character: str,
    instructions: Optional[str] = None,
    enabled: bool = True,
    auto_reply_enabled: bool = False,
) -> Dict[str, Any]:
    if not account_id:
        raise AutoReplyError("'account_id' is required.")
    if not character:
        raise AutoReplyError("'character' is required.")

    now = _now()
    with _connect(username) as conn:
        existing = conn.execute("SELECT * FROM configs WHERE account_id = ?", (account_id,)).fetchone()
        if existing:
            conn.execute(
                """
                UPDATE configs
                SET account_label = ?, character = ?, instructions = ?, enabled = ?,
                    auto_reply_enabled = ?, updated_at = ?
                WHERE account_id = ?
                """,
                (account_label, character, instructions, int(enabled), int(auto_reply_enabled), now, account_id),
            )
        else:
            conn.execute(
                """
                INSERT INTO configs
                    (account_id, account_label, character, instructions, enabled,
                     auto_reply_enabled, last_processed_uid, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?)
                """,
                (account_id, account_label, character, instructions, int(enabled), int(auto_reply_enabled), now, now),
            )
        row = conn.execute("SELECT * FROM configs WHERE account_id = ?", (account_id,)).fetchone()
    return _row_to_config(row)


def get_config(username: str, account_id: str) -> Optional[Dict[str, Any]]:
    with _connect(username) as conn:
        row = conn.execute("SELECT * FROM configs WHERE account_id = ?", (account_id,)).fetchone()
    return _row_to_config(row) if row else None


def list_configs(username: str, enabled_only: bool = False) -> List[Dict[str, Any]]:
    with _connect(username) as conn:
        if enabled_only:
            rows = conn.execute("SELECT * FROM configs WHERE enabled = 1").fetchall()
        else:
            rows = conn.execute("SELECT * FROM configs ORDER BY updated_at DESC").fetchall()
    return [_row_to_config(r) for r in rows]


def delete_config(username: str, account_id: str) -> None:
    with _connect(username) as conn:
        cur = conn.execute("DELETE FROM configs WHERE account_id = ?", (account_id,))
        if cur.rowcount == 0:
            raise AutoReplyError(f"No monitoring config for account '{account_id}'.")


def update_cursor(username: str, account_id: str, last_processed_uid: int) -> None:
    with _connect(username) as conn:
        conn.execute(
            "UPDATE configs SET last_processed_uid = ?, updated_at = ? WHERE account_id = ?",
            (last_processed_uid, _now(), account_id),
        )


# ------------------------------------------------------------
# Pending replies (drafted by the monitoring agent, awaiting the user's
# approve/edit/deny decision -- used whenever auto_reply_enabled is False
# but monitoring is on, i.e. the "agent drafts it, I approve it" gate).
# ------------------------------------------------------------

def create_pending_reply(
    username: str,
    account_id: str,
    account_label: str,
    character: str,
    uid: str,
    sender: str,
    subject: str,
    draft_reply: str,
) -> Dict[str, Any]:
    import uuid

    reply_id = uuid.uuid4().hex[:12]
    with _connect(username) as conn:
        conn.execute(
            """
            INSERT INTO pending_replies
                (id, account_id, account_label, character, uid, sender, subject, draft_reply, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (reply_id, account_id, account_label, character, str(uid), sender, subject, draft_reply, _now()),
        )
        row = conn.execute("SELECT * FROM pending_replies WHERE id = ?", (reply_id,)).fetchone()
    return dict(row)


def list_pending_replies(username: str) -> List[Dict[str, Any]]:
    with _connect(username) as conn:
        rows = conn.execute("SELECT * FROM pending_replies ORDER BY created_at ASC").fetchall()
    return [dict(r) for r in rows]


def get_pending_reply(username: str, reply_id: str) -> Optional[Dict[str, Any]]:
    with _connect(username) as conn:
        row = conn.execute("SELECT * FROM pending_replies WHERE id = ?", (reply_id,)).fetchone()
    return dict(row) if row else None


def delete_pending_reply(username: str, reply_id: str) -> None:
    with _connect(username) as conn:
        cur = conn.execute("DELETE FROM pending_replies WHERE id = ?", (reply_id,))
        if cur.rowcount == 0:
            raise AutoReplyError(f"No pending reply '{reply_id}'.")
