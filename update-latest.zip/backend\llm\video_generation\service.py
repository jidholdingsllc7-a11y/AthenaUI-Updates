# AthenaUI v3.5 — Video Generation Service
# File: backend/llm/video_generation/service.py
"""
Provider-aware video generation. Modeled on
llm/image_generation/service.py::ImageGenerationService, but video
generation isn't part of the standard chat/router pipeline (none of the
20 LLM routers implement a `generate_video` method), so this service talks
to each supported provider's REST API directly instead of going through
RouterSelector.

Two of AthenaUI's 20 supported LLM providers currently offer video
generation:

- xAI: purely visual, text prompt + an OPTIONAL single starting image,
  rendered into a short (<=15s) silent video clip, with an explicit
  `duration` control. Submit-then-poll (request_id -> /v1/videos/{id}).
- Gemini (Gemini Omni Flash, "gemini-omni-1.1-flash"): multimodal
  text/image-to-video via the Interactions API
  (https://generativelanguage.googleapis.com/v1beta/interactions),
  natively generates audio, and does NOT expose a duration control (the
  model decides the clip length from the prompt) -- requested
  synchronously (background/store/stream all false) so the finished
  video's base64 bytes come back directly in the same HTTP response, no
  polling needed.

Which specific model ids show up for either provider is NOT hardcoded
here -- `list_video_models()` calls the provider's own model-listing
endpoint with the user's real API key and filters for video-capable
model ids, so the dropdown always reflects exactly what that key
currently has access to. If another provider ever adds video generation,
add a new entry to `_SUPPORTED_PROVIDERS`/`_PROVIDER_LABELS` + a
submit/poll (or single-call) method below rather than special-casing the
frontend.
"""

from __future__ import annotations

import base64
import logging
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests
from fastapi import HTTPException

from vault.service import VaultService

logger = logging.getLogger(__name__)

_XAI_API_BASE = "https://api.x.ai/v1"
_GEMINI_API_BASE = "https://generativelanguage.googleapis.com/v1beta"

_MAX_DURATION_SECONDS = 15
_MIN_DURATION_SECONDS = 1
_DEFAULT_DURATION_SECONDS = 6
_POLL_INTERVAL_SECONDS = 3
_POLL_TIMEOUT_SECONDS = 600  # 10 minutes -- video generation can be slow.
_GEMINI_MODEL = "gemini-omni-1.1-flash"

# Supported video-generation providers, in dropdown display order.
_SUPPORTED_PROVIDERS: List[str] = ["xai", "gemini"]
_PROVIDER_LABELS: Dict[str, str] = {"xai": "xAI (Grok)", "gemini": "Gemini"}


class VideoGenerationService:

    # ---------------------------------------------------------
    # Provider / credential resolution
    # ---------------------------------------------------------
    @staticmethod
    def _resolve_api_key(username: str, provider_id: str) -> Optional[str]:
        for pipeline in ["video", "chat", "code", "image"]:
            key_data = VaultService.get_provider_key(username, pipeline, provider_id)
            if isinstance(key_data, dict):
                api_key = str(key_data.get("api_key", "")).strip()
                if api_key:
                    return api_key

        return None

    @classmethod
    def list_configured_providers(cls, username: str) -> List[Dict[str, str]]:
        """
        Which of the video-capable providers does this user have a usable
        API key for (checked across the same pipeline fallback chain as
        `_resolve_api_key`) -- drives the frontend's provider dropdown.
        """
        configured = []
        for provider_id in _SUPPORTED_PROVIDERS:
            if cls._resolve_api_key(username, provider_id):
                configured.append({"id": provider_id, "label": _PROVIDER_LABELS[provider_id]})
        return configured

    @staticmethod
    def list_video_models(provider_id: str, api_key: str) -> List[str]:
        """
        Queries the provider's own model-listing endpoint with the caller's
        real API key and returns only the video-capable model ids it
        actually reports -- deliberately NOT a hardcoded list.
        """
        if provider_id == "xai":
            resp = requests.get(
                f"{_XAI_API_BASE}/models",
                headers={"Authorization": f"Bearer {api_key}"},
                timeout=15,
            )
            resp.raise_for_status()
            data = resp.json()
            model_ids = [m["id"] for m in data.get("data", []) if "id" in m]
            return sorted(m for m in model_ids if "video" in m.lower())

        if provider_id == "gemini":
            resp = requests.get(
                f"{_GEMINI_API_BASE}/models",
                params={"key": api_key},
                timeout=15,
            )
            resp.raise_for_status()
            data = resp.json()
            model_ids = []
            for m in data.get("models", []):
                name = str(m.get("name", ""))
                if name.startswith("models/"):
                    name = name[len("models/"):]
                if name:
                    model_ids.append(name)
            return sorted(m for m in model_ids if "omni" in m.lower() or "veo" in m.lower())

        raise HTTPException(status_code=400, detail=f"Unsupported video provider: {provider_id}")

    @staticmethod
    def _supports_duration_control(provider_id: str) -> bool:
        # Gemini Omni Flash decides the clip length from the prompt itself
        # and exposes no duration knob -- xAI requires one.
        return provider_id == "xai"

    async def check_capability_for_user(self, username: str, provider_id: Optional[str] = None) -> Dict[str, Any]:
        configured_providers = self.list_configured_providers(username)

        if not provider_id:
            provider_id = configured_providers[0]["id"] if configured_providers else _SUPPORTED_PROVIDERS[0]

        if not configured_providers:
            return {
                "provider_id": provider_id,
                "configured_providers": [],
                "supported": False,
                "reason": (
                    "No video-capable provider API key is configured for your account. "
                    "Add an xAI or Gemini API key for Video Generation in Settings."
                ),
            }

        api_key = self._resolve_api_key(username, provider_id)
        if not api_key:
            return {
                "provider_id": provider_id,
                "configured_providers": configured_providers,
                "supported": False,
                "reason": f"No API key is configured for {_PROVIDER_LABELS.get(provider_id, provider_id)}.",
            }

        try:
            available_models = self.list_video_models(provider_id, api_key)
        except Exception as e:
            return {
                "provider_id": provider_id,
                "configured_providers": configured_providers,
                "supported": False,
                "reason": f"Could not reach {_PROVIDER_LABELS.get(provider_id, provider_id)} to list available video models: {e}",
            }

        if not available_models:
            return {
                "provider_id": provider_id,
                "configured_providers": configured_providers,
                "supported": False,
                "reason": f"Your {_PROVIDER_LABELS.get(provider_id, provider_id)} account/key does not currently have access to any video models.",
            }

        return {
            "provider_id": provider_id,
            "configured_providers": configured_providers,
            "available_models": available_models,
            "default_model_id": available_models[-1],
            "supported": True,
            "supports_image_input": True,
            "max_images": 1,
            "supports_voice_input": False,
            "supports_duration_control": self._supports_duration_control(provider_id),
            "min_duration_seconds": _MIN_DURATION_SECONDS,
            "max_duration_seconds": _MAX_DURATION_SECONDS,
            "default_duration_seconds": _DEFAULT_DURATION_SECONDS,
        }

    # ---------------------------------------------------------
    # Storage
    # ---------------------------------------------------------
    @staticmethod
    def _user_video_dir(username: str) -> Path:
        target_dir = Path("data") / "users" / username / "generated_videos"
        target_dir.mkdir(parents=True, exist_ok=True)
        return target_dir

    @classmethod
    def _save_generated_video(cls, username: str, video_bytes: bytes) -> Path:
        target_dir = cls._user_video_dir(username)
        file_path = target_dir / f"video_{uuid.uuid4().hex}.mp4"
        file_path.write_bytes(video_bytes)
        return file_path

    def list_videos(self, username: str) -> List[Dict[str, Any]]:
        target_dir = self._user_video_dir(username)
        entries = []
        for p in sorted(target_dir.iterdir(), key=lambda x: x.stat().st_mtime, reverse=True):
            if p.is_file() and p.suffix.lower() == ".mp4":
                entries.append({
                    "url": f"/data/users/{username}/generated_videos/{p.name}",
                    "created_at": p.stat().st_mtime,
                })
        return entries

    # ---------------------------------------------------------
    # xAI — submit-then-poll (blocking HTTP calls; caller should run this
    # via asyncio.to_thread so it doesn't block the event loop)
    # ---------------------------------------------------------
    @staticmethod
    def _xai_submit(api_key: str, model_id: str, prompt: str, image_data_uri: Optional[str], duration: int) -> str:
        payload: Dict[str, Any] = {
            "model": model_id,
            "prompt": prompt,
            "duration": duration,
        }
        if image_data_uri:
            payload["image"] = {"url": image_data_uri}

        resp = requests.post(
            f"{_XAI_API_BASE}/videos/generations",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json=payload,
            timeout=60,
        )
        try:
            resp.raise_for_status()
        except requests.HTTPError as exc:
            detail = resp.text[:500] if resp.text else str(exc)
            raise HTTPException(status_code=502, detail=f"xAI rejected the video request: {detail}") from exc

        data = resp.json()
        request_id = data.get("request_id") or data.get("id")
        if not request_id:
            raise HTTPException(status_code=502, detail="xAI did not return a video request id.")
        return request_id

    @staticmethod
    def _xai_poll(api_key: str, request_id: str) -> bytes:
        deadline = time.monotonic() + _POLL_TIMEOUT_SECONDS
        while True:
            resp = requests.get(
                f"{_XAI_API_BASE}/videos/{request_id}",
                headers={"Authorization": f"Bearer {api_key}"},
                timeout=30,
            )
            try:
                resp.raise_for_status()
            except requests.HTTPError as exc:
                detail = resp.text[:500] if resp.text else str(exc)
                raise HTTPException(status_code=502, detail=f"xAI video status check failed: {detail}") from exc

            data = resp.json()
            status = str(data.get("status", "")).lower()

            if status == "done":
                video = data.get("video") or {}
                video_url = video.get("url") if isinstance(video, dict) else None
                if not video_url:
                    raise HTTPException(status_code=502, detail="xAI reported the video as done but returned no url.")
                video_resp = requests.get(video_url, timeout=120)
                video_resp.raise_for_status()
                return video_resp.content

            if status in ("failed", "expired"):
                raise HTTPException(status_code=502, detail=f"xAI video generation {status}.")

            if time.monotonic() >= deadline:
                raise HTTPException(
                    status_code=504,
                    detail=(
                        "Video generation is taking longer than expected. It may still "
                        "complete on xAI's side -- try again in a bit."
                    ),
                )

            time.sleep(_POLL_INTERVAL_SECONDS)

    @classmethod
    def _generate_xai(
        cls,
        api_key: str,
        model_id: str,
        prompt: str,
        duration: int,
        image_bytes: Optional[bytes],
        image_content_type: Optional[str],
    ) -> bytes:
        image_data_uri = None
        if image_bytes:
            mime = image_content_type or "image/png"
            encoded = base64.b64encode(image_bytes).decode("ascii")
            image_data_uri = f"data:{mime};base64,{encoded}"

        request_id = cls._xai_submit(api_key, model_id, prompt, image_data_uri, duration)
        return cls._xai_poll(api_key, request_id)

    # ---------------------------------------------------------
    # Gemini (Omni Flash) — single synchronous call via the Interactions
    # API; no duration control, no polling (background/store/stream=false
    # forces a synchronous unary response per Gemini's own docs).
    # ---------------------------------------------------------
    @staticmethod
    def _generate_gemini(
        api_key: str,
        model_id: str,
        prompt: str,
        image_bytes: Optional[bytes],
        image_content_type: Optional[str],
    ) -> bytes:
        input_items: List[Dict[str, Any]] = []
        if image_bytes:
            mime = image_content_type or "image/png"
            input_items.append({
                "type": "image",
                "data": base64.b64encode(image_bytes).decode("ascii"),
                "mime_type": mime,
            })
        input_items.append({"type": "text", "text": prompt})

        payload = {
            "model": model_id or _GEMINI_MODEL,
            "input": input_items,
            "response_format": {"type": "video"},
            "background": False,
            "store": False,
            "stream": False,
        }

        resp = requests.post(
            f"{_GEMINI_API_BASE}/interactions",
            params={"key": api_key},
            json=payload,
            timeout=_POLL_TIMEOUT_SECONDS,
        )
        try:
            resp.raise_for_status()
        except requests.HTTPError as exc:
            detail = resp.text[:500] if resp.text else str(exc)
            raise HTTPException(status_code=502, detail=f"Gemini rejected the video request: {detail}") from exc

        data = resp.json()
        for step in data.get("steps", []):
            if step.get("type") != "model_output":
                continue
            for item in step.get("content", []):
                if item.get("type") == "video" and item.get("data"):
                    return base64.b64decode(item["data"])

        raise HTTPException(status_code=502, detail="Gemini did not return a generated video.")

    # ---------------------------------------------------------
    # Core video generation (blocking HTTP calls; caller should run this
    # via asyncio.to_thread so it doesn't block the event loop)
    # ---------------------------------------------------------
    def generate(
        self,
        username: str,
        prompt: str,
        provider_id: Optional[str] = None,
        model_id: Optional[str] = None,
        duration: int = _DEFAULT_DURATION_SECONDS,
        image_bytes: Optional[bytes] = None,
        image_content_type: Optional[str] = None,
    ) -> Dict[str, Any]:
        if not prompt or not prompt.strip():
            raise HTTPException(status_code=400, detail="prompt is required.")

        if not provider_id:
            configured = self.list_configured_providers(username)
            if not configured:
                raise HTTPException(
                    status_code=400,
                    detail="No video-capable provider API key is configured. Add one in Settings.",
                )
            provider_id = configured[0]["id"]
        elif provider_id not in _SUPPORTED_PROVIDERS:
            raise HTTPException(status_code=400, detail=f"Unsupported video provider: {provider_id}")

        duration = max(_MIN_DURATION_SECONDS, min(_MAX_DURATION_SECONDS, int(duration or _DEFAULT_DURATION_SECONDS)))

        api_key = self._resolve_api_key(username, provider_id)
        if not api_key:
            raise HTTPException(
                status_code=400,
                detail=f"No {_PROVIDER_LABELS.get(provider_id, provider_id)} API key is configured for your account. Add one in Settings.",
            )

        try:
            available_models = self.list_video_models(provider_id, api_key)
        except Exception as e:
            raise HTTPException(status_code=502, detail=f"Could not verify available video models with {provider_id}: {e}")
        if not available_models:
            raise HTTPException(status_code=400, detail=f"Your {provider_id} account/key has no video models available.")

        if model_id:
            if model_id not in available_models:
                raise HTTPException(
                    status_code=400,
                    detail=f"'{model_id}' is not one of the video models your {provider_id} key currently has access to.",
                )
        else:
            model_id = available_models[-1]

        prompt = prompt.strip()
        if provider_id == "xai":
            video_bytes = self._generate_xai(api_key, model_id, prompt, duration, image_bytes, image_content_type)
        else:
            video_bytes = self._generate_gemini(api_key, model_id, prompt, image_bytes, image_content_type)

        saved_path = self._save_generated_video(username, video_bytes)
        public_url = f"/data/users/{username}/generated_videos/{saved_path.name}"

        return {
            "provider_id": provider_id,
            "model_id": model_id,
            "prompt": prompt,
            "duration": duration if self._supports_duration_control(provider_id) else None,
            "used_image": bool(image_bytes),
            "path": str(saved_path),
            "url": public_url,
            "chat_message": f"Generated video saved: {public_url}",
        }
