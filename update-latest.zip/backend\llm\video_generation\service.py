# AthenaUI v3.5 — Video Generation Service
# File: backend/llm/video_generation/service.py
"""
Provider-aware video generation. Modeled on
llm/image_generation/service.py::ImageGenerationService, but video
generation isn't part of the standard chat/router pipeline (none of the
20 LLM routers implement a `generate_video` method), so this service talks
to xAI's Video Generations REST API directly instead of going through
RouterSelector.

xAI is currently the ONLY one of AthenaUI's 20 supported LLM providers that
offers video generation, and its API is purely visual: a text prompt plus
an OPTIONAL single starting image, rendered into a short (<=15s) silent
video clip. There is no voice/audio/script input of any kind on xAI's
video endpoint (confirmed directly against xAI's own docs) -- so this
service intentionally never asks for or sends any voice/narration data.

Which specific model ids show up (e.g. "grok-imagine-video",
"grok-imagine-video-1.5", or whatever xAI adds/removes next) is NOT
hardcoded here -- `list_video_models()` calls xAI's own `/v1/models`
endpoint with the user's real API key (same approach as
llm/provider_detection/detectors/xai_detector.py) and filters for ids
containing "video", so the dropdown always reflects exactly what that
key currently has access to. If another provider ever adds video
generation, extend `_PROVIDER_ID`/the request-building logic below
rather than special-casing the frontend.
"""

from __future__ import annotations

import base64
import logging
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests
from fastapi import HTTPException

from vault.service import VaultService

logger = logging.getLogger(__name__)

_PROVIDER_ID = "xai"
_API_BASE = "https://api.x.ai/v1"
_MAX_DURATION_SECONDS = 15
_MIN_DURATION_SECONDS = 1
_DEFAULT_DURATION_SECONDS = 6
_POLL_INTERVAL_SECONDS = 3
_POLL_TIMEOUT_SECONDS = 600  # 10 minutes -- video generation can be slow.


class VideoGenerationService:

    # ---------------------------------------------------------
    # Provider / credential resolution
    # ---------------------------------------------------------
    @staticmethod
    def _resolve_api_key(username: str) -> Optional[str]:
        for pipeline in ["video", "chat", "code", "image"]:
            key_data = VaultService.get_provider_key(username, pipeline, _PROVIDER_ID)
            if isinstance(key_data, dict):
                api_key = str(key_data.get("api_key", "")).strip()
                if api_key:
                    return api_key

        return None

    @staticmethod
    def list_video_models(api_key: str) -> List[str]:
        """
        Queries xAI's own /v1/models endpoint with the caller's real API key
        and returns only the video-capable model ids it actually reports --
        mirrors llm/provider_detection/detectors/xai_detector.py::list_models,
        but filtered to video models instead of all Grok models. This is
        deliberately NOT a hardcoded list: which models show up here depends
        entirely on what xAI's API says this specific key has access to.
        """
        resp = requests.get(
            f"{_API_BASE}/models",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=15,
        )
        resp.raise_for_status()
        data = resp.json()
        model_ids = [m["id"] for m in data.get("data", []) if "id" in m]
        return sorted(m for m in model_ids if "video" in m.lower())

    async def check_capability_for_user(self, username: str) -> Dict[str, Any]:
        api_key = self._resolve_api_key(username)
        if not api_key:
            return {
                "provider_id": _PROVIDER_ID,
                "supported": False,
                "reason": (
                    "No xAI API key is configured for your account. Add an xAI API key "
                    "in Settings to enable video generation."
                ),
            }

        try:
            available_models = self.list_video_models(api_key)
        except Exception as e:
            return {
                "provider_id": _PROVIDER_ID,
                "supported": False,
                "reason": f"Could not reach xAI to list available video models: {e}",
            }

        if not available_models:
            return {
                "provider_id": _PROVIDER_ID,
                "supported": False,
                "reason": "Your xAI account/key does not currently have access to any video models.",
            }

        return {
            "provider_id": _PROVIDER_ID,
            "available_models": available_models,
            "default_model_id": available_models[-1],
            "supported": True,
            "supports_image_input": True,
            "max_images": 1,
            "supports_voice_input": False,
            "min_duration_seconds": _MIN_DURATION_SECONDS,
            "max_duration_seconds": _MAX_DURATION_SECONDS,
            "default_duration_seconds": _DEFAULT_DURATION_SECONDS,
        }

    # ---------------------------------------------------------
    # Storage
    # ---------------------------------------------------------
    @staticmethod
    def _user_video_dir(username: str) -> Path:
        target_dir = Path("data") / "users" / username / "generated_videos"
        target_dir.mkdir(parents=True, exist_ok=True)
        return target_dir

    @classmethod
    def _save_generated_video(cls, username: str, video_bytes: bytes) -> Path:
        target_dir = cls._user_video_dir(username)
        file_path = target_dir / f"video_{uuid.uuid4().hex}.mp4"
        file_path.write_bytes(video_bytes)
        return file_path

    def list_videos(self, username: str) -> List[Dict[str, Any]]:
        target_dir = self._user_video_dir(username)
        entries = []
        for p in sorted(target_dir.iterdir(), key=lambda x: x.stat().st_mtime, reverse=True):
            if p.is_file() and p.suffix.lower() == ".mp4":
                entries.append({
                    "url": f"/data/users/{username}/generated_videos/{p.name}",
                    "created_at": p.stat().st_mtime,
                })
        return entries

    # ---------------------------------------------------------
    # Core video generation (blocking HTTP calls; caller should run this
    # via asyncio.to_thread so it doesn't block the event loop)
    # ---------------------------------------------------------
    @staticmethod
    def _submit(api_key: str, model_id: str, prompt: str, image_data_uri: Optional[str], duration: int) -> str:
        payload: Dict[str, Any] = {
            "model": model_id,
            "prompt": prompt,
            "duration": duration,
        }
        if image_data_uri:
            payload["image"] = {"url": image_data_uri}

        resp = requests.post(
            f"{_API_BASE}/videos/generations",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json=payload,
            timeout=60,
        )
        try:
            resp.raise_for_status()
        except requests.HTTPError as exc:
            detail = resp.text[:500] if resp.text else str(exc)
            raise HTTPException(status_code=502, detail=f"xAI rejected the video request: {detail}") from exc

        data = resp.json()
        request_id = data.get("request_id") or data.get("id")
        if not request_id:
            raise HTTPException(status_code=502, detail="xAI did not return a video request id.")
        return request_id

    @staticmethod
    def _poll(api_key: str, request_id: str) -> str:
        deadline = time.monotonic() + _POLL_TIMEOUT_SECONDS
        while True:
            resp = requests.get(
                f"{_API_BASE}/videos/{request_id}",
                headers={"Authorization": f"Bearer {api_key}"},
                timeout=30,
            )
            try:
                resp.raise_for_status()
            except requests.HTTPError as exc:
                detail = resp.text[:500] if resp.text else str(exc)
                raise HTTPException(status_code=502, detail=f"xAI video status check failed: {detail}") from exc

            data = resp.json()
            status = str(data.get("status", "")).lower()

            if status == "done":
                video = data.get("video") or {}
                video_url = video.get("url") if isinstance(video, dict) else None
                if not video_url:
                    raise HTTPException(status_code=502, detail="xAI reported the video as done but returned no url.")
                return video_url

            if status in ("failed", "expired"):
                raise HTTPException(status_code=502, detail=f"xAI video generation {status}.")

            if time.monotonic() >= deadline:
                raise HTTPException(
                    status_code=504,
                    detail=(
                        "Video generation is taking longer than expected. It may still "
                        "complete on xAI's side -- try again in a bit."
                    ),
                )

            time.sleep(_POLL_INTERVAL_SECONDS)

    def generate(
        self,
        username: str,
        prompt: str,
        model_id: Optional[str] = None,
        duration: int = _DEFAULT_DURATION_SECONDS,
        image_bytes: Optional[bytes] = None,
        image_content_type: Optional[str] = None,
    ) -> Dict[str, Any]:
        if not prompt or not prompt.strip():
            raise HTTPException(status_code=400, detail="prompt is required.")

        duration = max(_MIN_DURATION_SECONDS, min(_MAX_DURATION_SECONDS, int(duration or _DEFAULT_DURATION_SECONDS)))

        api_key = self._resolve_api_key(username)
        if not api_key:
            raise HTTPException(
                status_code=400,
                detail="No xAI API key is configured for your account. Add one in Settings.",
            )

        try:
            available_models = self.list_video_models(api_key)
        except Exception as e:
            raise HTTPException(status_code=502, detail=f"Could not verify available video models with xAI: {e}")
        if not available_models:
            raise HTTPException(status_code=400, detail="Your xAI account/key has no video models available.")

        if model_id:
            if model_id not in available_models:
                raise HTTPException(
                    status_code=400,
                    detail=f"'{model_id}' is not one of the video models your xAI key currently has access to.",
                )
        else:
            model_id = available_models[-1]

        image_data_uri = None
        if image_bytes:
            mime = image_content_type or "image/png"
            encoded = base64.b64encode(image_bytes).decode("ascii")
            image_data_uri = f"data:{mime};base64,{encoded}"

        request_id = self._submit(api_key, model_id, prompt.strip(), image_data_uri, duration)
        video_url = self._poll(api_key, request_id)

        video_resp = requests.get(video_url, timeout=120)
        video_resp.raise_for_status()

        saved_path = self._save_generated_video(username, video_resp.content)
        public_url = f"/data/users/{username}/generated_videos/{saved_path.name}"

        return {
            "provider_id": _PROVIDER_ID,
            "model_id": model_id,
            "prompt": prompt.strip(),
            "duration": duration,
            "used_image": bool(image_bytes),
            "path": str(saved_path),
            "url": public_url,
            "chat_message": f"Generated video saved: {public_url}",
        }
