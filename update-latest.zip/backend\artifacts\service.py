# AthenaUI v3.5 — Chat Artifacts Service
# File: backend/artifacts/service.py
#
# Backs the full-chat "artifact" feature: an agent can render a
# self-contained interactive mini web page (HTML/CSS/JS) inline in the chat
# window. The HTML itself is opaque to this service -- it's just stored and
# handed back by id -- all isolation happens on the frontend (a sandboxed
# iframe, with no access to AthenaUI's cookies/session/APIs).
#
# Storage: {DATA_DIR}/users/{username}/artifacts/artifacts.sqlite

from __future__ import annotations

import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

from core.runtime.runtime import get_runtime

# Generous but bounded -- keeps a single chat turn from writing an
# unreasonably large blob to disk.
MAX_HTML_LENGTH = 200_000


def _root_dir(username: str) -> Path:
    runtime = get_runtime()
    root = runtime.env.DATA_DIR / "users" / username / "artifacts"
    root.mkdir(parents=True, exist_ok=True)
    return root


def _db_path(username: str) -> Path:
    return _root_dir(username) / "artifacts.sqlite"


def _connect(username: str) -> sqlite3.Connection:
    conn = sqlite3.connect(_db_path(username))
    conn.row_factory = sqlite3.Row
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS artifacts (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            html TEXT NOT NULL,
            character TEXT,
            created_at TEXT NOT NULL
        )
        """
    )
    return conn


def save_artifact(username: str, *, title: str, html: str, character: Optional[str] = None) -> Dict[str, Any]:
    title = (title or "").strip()
    html = html or ""
    if not title:
        raise ValueError("'title' is required.")
    if not html.strip():
        raise ValueError("'html' is required.")
    if len(html) > MAX_HTML_LENGTH:
        raise ValueError(f"'html' is too large (max {MAX_HTML_LENGTH} characters).")

    artifact_id = uuid.uuid4().hex[:12]
    now = datetime.now(timezone.utc).isoformat()

    with _connect(username) as conn:
        conn.execute(
            "INSERT INTO artifacts (id, title, html, character, created_at) VALUES (?, ?, ?, ?, ?)",
            (artifact_id, title, html, character, now),
        )

    return {"id": artifact_id, "title": title, "created_at": now}


def get_artifact(username: str, artifact_id: str) -> Optional[Dict[str, Any]]:
    with _connect(username) as conn:
        row = conn.execute("SELECT * FROM artifacts WHERE id = ?", (artifact_id,)).fetchone()
    return dict(row) if row else None
