﻿# AthenaUI v3.5 — Notification Service
# File: backend/notifications/service/service.py
# Created: 2026-04-11 18:57 CDT
# Updated: 2026-10-09 CDT

from __future__ import annotations

import logging
import uuid
from datetime import datetime
from typing import Dict, Any, Optional

from vault.service import VaultService
from notifications.email.service import EmailService

logger = logging.getLogger(__name__)


class NotificationService:
    """
    Unified notification system for AthenaUI.
    Supports:
      - in-app notifications (stored in vault, always)
      - email notifications (optional)
      - SMS notifications via Twilio (optional, requires the user to have
        Twilio configured and a notify_phone_number on file)
    """

    @staticmethod
    def _now_iso() -> str:
        return datetime.utcnow().isoformat() + "Z"

    @staticmethod
    def send(
        username: str,
        *,
        type: str,
        message: str,
        metadata: Optional[Dict[str, Any]] = None,
        email: bool = False,
        channel: Optional[str] = None,
        subject: str = "AthenaUI Notification",
        phone_number: Optional[str] = None,
    ) -> None:
        """
        Send a notification to the user.
        type: "info" | "success" | "warning" | "error" (matches the
        NotificationsBar frontend's rendering styles).

        `channel` ("email" | "sms" | "none"/None) additionally dispatches
        the SAME message through a real out-of-band channel on top of the
        always-on in-app entry -- used by features (e.g. billing fallback)
        where the user explicitly configured a preferred channel so they
        notice even if they're not actively looking at the app. `email=True`
        is kept as a back-compat alias for `channel="email"`.
        """

        entry = {
            "id": str(uuid.uuid4()),
            "timestamp": NotificationService._now_iso(),
            "type": type,
            "message": message,
            "metadata": metadata or {},
        }

        # Store in vault
        NotificationService._append_to_vault(username, entry)

        effective_channel = channel or ("email" if email else None)
        if effective_channel == "email":
            EmailService.send_notification_email(username, message, subject=subject)
        elif effective_channel == "sms":
            if not phone_number:
                logger.warning("Skipping SMS notification for user=%s: no phone_number provided.", username)
            else:
                try:
                    from twilio_integration.service import send_sms
                    send_sms(username, phone_number, message, include_stop_notice=False)
                except Exception as exc:
                    logger.warning("Failed to send SMS notification to user=%s: %s", username, exc)

    @staticmethod
    def _append_to_vault(username: str, entry: Dict[str, Any]) -> None:
        vault = VaultService.get_vault(username)
        user_data = vault.user or {}

        notifications = user_data.get("notifications", [])
        notifications.append(entry)

        user_data["notifications"] = notifications
        vault.user = user_data

        VaultService.save_vault(username, vault)

    @staticmethod
    def list_notifications(username: str):
        vault = VaultService.get_vault(username)
        return vault.user.get("notifications", [])

    @staticmethod
    def clear_notifications(username: str) -> None:
        vault = VaultService.get_vault(username)
        user_data = vault.user or {}
        user_data["notifications"] = []
        vault.user = user_data
        VaultService.save_vault(username, vault)
