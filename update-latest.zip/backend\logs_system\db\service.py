# AthenaUI v3.5 — Persistent Tail Log Database
# File: backend/logs_system/db/service.py
# Created: 2026-08-09
#
# SQLite-backed, append-only store for Tail Log entries. The in-memory
# `tail_logger` buffer (see logs_system/tail/service.py) is capped at 1000
# entries and wiped on every backend restart -- this gives the same entries
# a durable home so history (and the PDF range-export feature) survives
# restarts and isn't bounded by the ring buffer size.

from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path
from threading import Lock
from typing import Any, Dict, List, Optional

from core.env.env_loader import Env

# Entries older than this are purged automatically on write (see append()) --
# keeps the log permanent but bounded, instead of growing forever.
RETENTION_DAYS = 30

# Writable per-user location, not the module's own directory -- a packaged
# install lives under "Program Files", which a standard user can't write to.
BASE_DIR = Env.WRITABLE_ROOT / "logs_system"
DB_PATH = BASE_DIR / "tail_logs.db"

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS tail_log_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    level TEXT,
    agent_state TEXT,
    event TEXT,
    details TEXT,
    task_id TEXT
);
CREATE INDEX IF NOT EXISTS idx_tail_log_entries_timestamp ON tail_log_entries(timestamp);
"""


class TailLogDb:
    """
    Persistent, append-only SQLite backing for the Tail Log.

    Inserts are serialized behind a lock so the autoincrement `id` always
    matches call/emit order -- this is what range queries sort by, not
    `timestamp`, since two entries can share the same timestamp (or, in
    theory, be logged from different threads out of strict time order) but
    `id` order always matches the order log() was actually called.
    """

    def __init__(self) -> None:
        self._lock = Lock()
        self._append_count = 0
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        BASE_DIR.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(DB_PATH))
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        return conn

    def _init_db(self) -> None:
        conn = self._connect()
        try:
            conn.executescript(_SCHEMA_SQL)
            conn.commit()
        finally:
            conn.close()

    def append(self, entry: Dict[str, Any]) -> None:
        """Append one entry to the end of the log, in the order this is called."""
        with self._lock:
            conn = self._connect()
            try:
                conn.execute(
                    "INSERT INTO tail_log_entries "
                    "(timestamp, level, agent_state, event, details, task_id) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (
                        entry.get("timestamp", ""),
                        entry.get("level"),
                        entry.get("agent_state"),
                        entry.get("event"),
                        json.dumps(entry.get("details") or {}),
                        entry.get("task_id"),
                    ),
                )
                conn.commit()
            finally:
                conn.close()

            # Throttled auto-purge (every 50 writes, not every single one) --
            # a DELETE against an indexed timestamp column is cheap, but no
            # need to run it on every append.
            self._append_count += 1
            if self._append_count % 50 == 0:
                self._purge_older_than_locked(RETENTION_DAYS)

    def purge_older_than(self, days: int = RETENTION_DAYS) -> int:
        """Deletes entries older than `days` days. Returns the number removed."""
        with self._lock:
            return self._purge_older_than_locked(days)

    def _purge_older_than_locked(self, days: int) -> int:
        """Must be called with self._lock already held."""
        cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat() + "Z"
        conn = self._connect()
        try:
            cur = conn.execute("DELETE FROM tail_log_entries WHERE timestamp < ?", (cutoff,))
            conn.commit()
            return cur.rowcount
        finally:
            conn.close()

    def get_range(
        self,
        start: Optional[str] = None,
        end: Optional[str] = None,
        limit: Optional[int] = None,
        agent_state: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Return persisted entries with timestamp in [start, end] (either bound
        optional), ordered oldest-to-newest by insertion order (`id`).
        """
        clauses: List[str] = []
        params: List[Any] = []
        if start:
            clauses.append("timestamp >= ?")
            params.append(start)
        if end:
            clauses.append("timestamp <= ?")
            params.append(end)
        if agent_state:
            clauses.append("agent_state = ?")
            params.append(agent_state)

        query = "SELECT timestamp, level, agent_state, event, details, task_id FROM tail_log_entries"
        if clauses:
            query += " WHERE " + " AND ".join(clauses)
        query += " ORDER BY id ASC"
        if limit is not None:
            query += " LIMIT ?"
            params.append(limit)

        conn = self._connect()
        try:
            rows = conn.execute(query, params).fetchall()
        finally:
            conn.close()

        return [self._row_to_entry(row) for row in rows]

    def get_recent(self, limit: int = 200, agent_state: Optional[str] = None) -> List[Dict[str, Any]]:
        """Return the most recent `limit` entries, oldest-to-newest."""
        query = "SELECT timestamp, level, agent_state, event, details, task_id FROM tail_log_entries"
        params: List[Any] = []
        if agent_state:
            query += " WHERE agent_state = ?"
            params.append(agent_state)
        query += " ORDER BY id DESC LIMIT ?"
        params.append(limit)

        conn = self._connect()
        try:
            rows = conn.execute(query, params).fetchall()
        finally:
            conn.close()

        entries = [self._row_to_entry(row) for row in rows]
        entries.reverse()
        return entries

    @staticmethod
    def _row_to_entry(row: sqlite3.Row) -> Dict[str, Any]:
        try:
            details = json.loads(row["details"]) if row["details"] else {}
        except json.JSONDecodeError:
            details = {}
        return {
            "timestamp": row["timestamp"],
            "level": row["level"],
            "agent_state": row["agent_state"],
            "event": row["event"],
            "details": details,
            "task_id": row["task_id"],
        }


# Singleton instance
tail_log_db = TailLogDb()
