# AthenaUI v3.5 — Email Accounts Service
# File: backend/emailing/service.py
#
# Manages user-configured "system" email accounts (Gmail App Password based,
# same mechanism as onboarding's Step1SystemEmail) that agent characters can
# use to send email. Supports MULTIPLE named accounts per user, each
# independently shared with either every agent ("all") or one specific
# character -- mirrors how the SQL database tool shares access.
#
# Storage: vault.user["email_accounts"] (list of dicts), via VaultService.
# One-time migration: if a legacy single "system_email_credentials" entry
# exists (set by the onboarding flow) and no email_accounts list exists yet,
# it's folded in as the first account with access="all".

from __future__ import annotations

import email as email_lib
import imaplib
import mimetypes
import smtplib
import uuid
from email.header import decode_header
from email.message import EmailMessage
from pathlib import Path
from typing import Any, Dict, List, Optional

from core.runtime.runtime import get_runtime
from vault.service import VaultService

DEFAULT_SMTP_HOST = "smtp.gmail.com"
DEFAULT_SMTP_PORT = 465
DEFAULT_IMAP_HOST = "imap.gmail.com"
DEFAULT_IMAP_PORT = 993

_ACCOUNT_FIELDS = (
    "label", "email", "app_password", "access",
    "smtp_host", "smtp_port", "imap_host", "imap_port",
)
_MAX_BODY_CHARS = 6000


class EmailServiceError(Exception):
    pass


class EmailAccountsService:
    # ------------------------------------------------------------
    # Storage
    # ------------------------------------------------------------
    @staticmethod
    def _load_accounts(username: str) -> List[Dict[str, Any]]:
        vault = VaultService.get_vault(username)
        user_data = vault.user or {}
        accounts = user_data.get("email_accounts")
        if isinstance(accounts, list):
            return accounts

        # One-time migration from the legacy single system-email slot.
        legacy = user_data.get("system_email_credentials")
        if isinstance(legacy, dict) and legacy.get("email") and legacy.get("app_password"):
            migrated = [{
                "id": uuid.uuid4().hex[:12],
                "label": "System Email",
                "email": legacy["email"],
                "app_password": legacy["app_password"],
                "smtp_host": DEFAULT_SMTP_HOST,
                "smtp_port": DEFAULT_SMTP_PORT,
                "imap_host": DEFAULT_IMAP_HOST,
                "imap_port": DEFAULT_IMAP_PORT,
                "access": "all",
            }]
            EmailAccountsService._save_accounts(username, migrated)
            return migrated

        return []

    @staticmethod
    def _save_accounts(username: str, accounts: List[Dict[str, Any]]) -> None:
        vault = VaultService.get_vault(username)
        user_data = vault.user or {}
        user_data["email_accounts"] = accounts
        vault.user = user_data
        VaultService.save_vault(username, vault)

    # ------------------------------------------------------------
    # CRUD (used by Settings API)
    # ------------------------------------------------------------
    @staticmethod
    def list_accounts_public(username: str) -> List[Dict[str, Any]]:
        """Redacted view -- never exposes app_password to the frontend."""
        return [
            {
                "id": a.get("id"),
                "label": a.get("label"),
                "email": a.get("email"),
                "access": a.get("access"),
                "smtp_host": a.get("smtp_host"),
                "smtp_port": a.get("smtp_port"),
                "imap_host": a.get("imap_host", DEFAULT_IMAP_HOST),
                "imap_port": a.get("imap_port", DEFAULT_IMAP_PORT),
                "has_password": bool(a.get("app_password")),
            }
            for a in EmailAccountsService._load_accounts(username)
        ]

    @staticmethod
    def _normalize_access(access: Any) -> Any:
        """Access is either the string "all", or a list of specific character
        names (multi-select). A single legacy string character name is also
        still accepted for backward compatibility with existing saved data."""
        if isinstance(access, list):
            cleaned = [str(a).strip() for a in access if str(a).strip()]
            return cleaned or "all"
        access_str = str(access or "all").strip()
        return access_str or "all"

    @staticmethod
    def add_account(
        username: str,
        label: str,
        email: str,
        app_password: str,
        access: Any = "all",
        smtp_host: Optional[str] = None,
        smtp_port: Optional[int] = None,
        imap_host: Optional[str] = None,
        imap_port: Optional[int] = None,
    ) -> Dict[str, Any]:
        email = (email or "").strip()
        app_password = (app_password or "").strip()
        label = (label or "").strip() or email
        access = EmailAccountsService._normalize_access(access)

        if not email:
            raise EmailServiceError("Email address is required.")
        if not app_password:
            raise EmailServiceError("App password is required.")

        accounts = EmailAccountsService._load_accounts(username)
        account = {
            "id": uuid.uuid4().hex[:12],
            "label": label,
            "email": email,
            "app_password": app_password,
            "smtp_host": (smtp_host or DEFAULT_SMTP_HOST).strip(),
            "smtp_port": int(smtp_port or DEFAULT_SMTP_PORT),
            "imap_host": (imap_host or DEFAULT_IMAP_HOST).strip(),
            "imap_port": int(imap_port or DEFAULT_IMAP_PORT),
            "access": access,
        }
        accounts.append(account)
        EmailAccountsService._save_accounts(username, accounts)
        return account

    @staticmethod
    def update_account(username: str, account_id: str, **fields: Any) -> Dict[str, Any]:
        accounts = EmailAccountsService._load_accounts(username)
        for account in accounts:
            if account.get("id") == account_id:
                for key in _ACCOUNT_FIELDS:
                    if key not in fields:
                        continue
                    value = fields[key]
                    if key == "access":
                        if value in (None, "") or (isinstance(value, list) and not value):
                            continue
                        account[key] = EmailAccountsService._normalize_access(value)
                    elif value not in (None, ""):
                        account[key] = value
                EmailAccountsService._save_accounts(username, accounts)
                return account
        raise EmailServiceError(f"Email account '{account_id}' not found.")

    @staticmethod
    def delete_account(username: str, account_id: str) -> None:
        accounts = EmailAccountsService._load_accounts(username)
        remaining = [a for a in accounts if a.get("id") != account_id]
        if len(remaining) == len(accounts):
            raise EmailServiceError(f"Email account '{account_id}' not found.")
        EmailAccountsService._save_accounts(username, remaining)

    @staticmethod
    def get_account_by_id(username: str, account_id: str) -> Optional[Dict[str, Any]]:
        """Internal helper (not exposed raw to the frontend) -- used by
        server-side code (dashboard REST routes, the inbox-monitor loop) that
        needs the full account record (including its label) from an id."""
        for a in EmailAccountsService._load_accounts(username):
            if a.get("id") == account_id:
                return a
        return None

    # ------------------------------------------------------------
    # Access resolution (agent tool use)
    # ------------------------------------------------------------
    @staticmethod
    def _access_includes_character(access: Any, character_norm: str) -> bool:
        if isinstance(access, list):
            normalized = [str(a).strip().lower() for a in access]
            return "all" in normalized or character_norm in normalized
        return str(access or "").strip().lower() in ("all", character_norm)

    @staticmethod
    def accounts_for_character(username: str, character: str) -> List[Dict[str, Any]]:
        character_norm = (character or "").strip().lower()
        return [
            a for a in EmailAccountsService._load_accounts(username)
            if EmailAccountsService._access_includes_character(a.get("access", ""), character_norm)
        ]

    @staticmethod
    def _resolve_account(username: str, character: str, account_label: Optional[str]) -> Dict[str, Any]:
        accessible = EmailAccountsService.accounts_for_character(username, character)
        if not accessible:
            raise EmailServiceError(
                f"No email account is available to '{character}'. Ask the user to add one "
                "in Settings > Email Accounts and share it with this agent (or with 'all agents')."
            )

        if account_label:
            wanted = account_label.strip().lower()
            account = next(
                (a for a in accessible if str(a.get("label", "")).strip().lower() == wanted),
                None,
            )
            if account is None:
                labels = ", ".join(a.get("label", "") for a in accessible)
                raise EmailServiceError(
                    f"No accessible email account named '{account_label}'. Available: {labels}"
                )
            return account
        if len(accessible) == 1:
            return accessible[0]

        labels = ", ".join(a.get("label", "") for a in accessible)
        raise EmailServiceError(
            f"Multiple email accounts are available ({labels}). Pass 'account_label' to choose one."
        )

    # ------------------------------------------------------------
    # Attachments
    # ------------------------------------------------------------
    @staticmethod
    def _resolve_attachment_path(username: str, raw_path: str) -> Path:
        """Resolves an attachment reference to a real file on disk, scoped to
        this user's own data (e.g. a gallery image path/URL returned by the
        image_gallery_list tool, such as
        "/data/users/<username>/characters/<character>/gallery/modern/x.png").
        Rejects anything that doesn't stay within DATA_DIR/users/<username>,
        so an agent can't be tricked into attaching/exfiltrating arbitrary
        files elsewhere on disk."""
        cleaned = (raw_path or "").strip().lstrip("/")
        if cleaned.startswith("data/"):
            cleaned = cleaned[len("data/"):]

        user_root = (get_runtime().env.DATA_DIR / "users" / username).resolve()
        candidate = (get_runtime().env.DATA_DIR / cleaned).resolve()
        try:
            candidate.relative_to(user_root)
        except ValueError:
            raise EmailServiceError(f"Attachment path is not accessible: {raw_path}")
        if not candidate.is_file():
            raise EmailServiceError(f"Attachment file not found: {raw_path}")
        return candidate

    # ------------------------------------------------------------
    # Sending
    # ------------------------------------------------------------
    @staticmethod
    def send_email(
        username: str,
        character: str,
        to: str,
        subject: str,
        body: str,
        account_label: Optional[str] = None,
        attachment_paths: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        to = (to or "").strip()
        subject = (subject or "").strip()
        if not to:
            raise EmailServiceError("A recipient 'to' address is required.")

        account = EmailAccountsService._resolve_account(username, character, account_label)

        msg = EmailMessage()
        msg["From"] = account["email"]
        msg["To"] = to
        msg["Subject"] = subject
        msg.set_content(f"{body}\n\n-- sent by {character} via AthenaUI")

        attached_names: List[str] = []
        for raw_path in (attachment_paths or []):
            file_path = EmailAccountsService._resolve_attachment_path(username, raw_path)
            mime_type, _ = mimetypes.guess_type(file_path.name)
            maintype, _, subtype = (mime_type or "application/octet-stream").partition("/")
            msg.add_attachment(
                file_path.read_bytes(),
                maintype=maintype or "application",
                subtype=subtype or "octet-stream",
                filename=file_path.name,
            )
            attached_names.append(file_path.name)

        host = account.get("smtp_host") or DEFAULT_SMTP_HOST
        port = int(account.get("smtp_port") or DEFAULT_SMTP_PORT)

        try:
            with smtplib.SMTP_SSL(host, port, timeout=20) as smtp:
                smtp.login(account["email"], account["app_password"])
                smtp.send_message(msg)
        except Exception as exc:
            raise EmailServiceError(f"Failed to send email: {exc}") from exc

        return {
            "from": account["email"],
            "to": to,
            "subject": subject,
            "account_label": account.get("label"),
            "attachments": attached_names,
        }

    @staticmethod
    def send_system_notification_email(username: str, to: str, subject: str, body: str) -> Dict[str, Any]:
        """Like send_email, but for system-initiated notifications (e.g. the
        billing-fallback alert) rather than an agent acting on a character's
        behalf -- no character/access-control check, just uses the user's
        first connected account as the sender."""
        to = (to or "").strip()
        if not to:
            raise EmailServiceError("No destination email address is available for this user.")

        accounts = EmailAccountsService._load_accounts(username)
        if not accounts:
            raise EmailServiceError("No connected email account to send the notification from.")
        account = accounts[0]

        msg = EmailMessage()
        msg["From"] = account["email"]
        msg["To"] = to
        msg["Subject"] = subject
        msg.set_content(body)

        host = account.get("smtp_host") or DEFAULT_SMTP_HOST
        port = int(account.get("smtp_port") or DEFAULT_SMTP_PORT)

        try:
            with smtplib.SMTP_SSL(host, port, timeout=20) as smtp:
                smtp.login(account["email"], account["app_password"])
                smtp.send_message(msg)
        except Exception as exc:
            raise EmailServiceError(f"Failed to send notification email: {exc}") from exc

        return {"from": account["email"], "to": to, "subject": subject}

    # ------------------------------------------------------------
    # Inbox reading / cleanup (IMAP)
    # ------------------------------------------------------------
    @staticmethod
    def _imap_connect(account: Dict[str, Any]) -> "imaplib.IMAP4_SSL":
        host = account.get("imap_host") or DEFAULT_IMAP_HOST
        port = int(account.get("imap_port") or DEFAULT_IMAP_PORT)
        try:
            imap = imaplib.IMAP4_SSL(host, port, timeout=20)
            imap.login(account["email"], account["app_password"])
        except Exception as exc:
            raise EmailServiceError(
                f"Failed to connect to {host}:{port} for {account['email']}: {exc}. "
                "Make sure IMAP is enabled for this account and the app password is correct."
            ) from exc
        return imap

    @staticmethod
    def _decode_header_value(raw: Optional[str]) -> str:
        if not raw:
            return ""
        parts = decode_header(raw)
        decoded = ""
        for text, charset in parts:
            if isinstance(text, bytes):
                decoded += text.decode(charset or "utf-8", errors="replace")
            else:
                decoded += text
        return decoded

    @staticmethod
    def _find_trash_mailbox(imap: "imaplib.IMAP4_SSL") -> str:
        try:
            status, mailboxes = imap.list()
            if status == "OK" and mailboxes:
                for raw in mailboxes:
                    line = raw.decode(errors="replace") if isinstance(raw, bytes) else str(raw)
                    if "\\Trash" in line:
                        # Mailbox name is the last quoted or bare token on the line.
                        if '"' in line:
                            return line.split('"')[-2]
                        return line.split(" ")[-1]
        except Exception:
            pass
        return "[Gmail]/Trash"

    @staticmethod
    def list_inbox(
        username: str,
        character: str,
        account_label: Optional[str] = None,
        mailbox: str = "INBOX",
        limit: int = 25,
        unread_only: bool = False,
    ) -> List[Dict[str, Any]]:
        account = EmailAccountsService._resolve_account(username, character, account_label)
        limit = max(1, min(int(limit or 25), 100))

        imap = EmailAccountsService._imap_connect(account)
        try:
            status, _ = imap.select(mailbox, readonly=True)
            if status != "OK":
                raise EmailServiceError(f"Could not open mailbox '{mailbox}'.")

            criterion = "UNSEEN" if unread_only else "ALL"
            status, data = imap.search(None, criterion)
            if status != "OK":
                raise EmailServiceError("IMAP search failed.")

            ids = data[0].split()
            recent_ids = ids[-limit:] if ids else []
            recent_ids.reverse()  # newest first

            messages: List[Dict[str, Any]] = []
            for msg_id in recent_ids:
                status, uid_data = imap.fetch(msg_id, "(UID BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE)])")
                if status != "OK" or not uid_data or not isinstance(uid_data[0], tuple):
                    continue
                header_meta, header_bytes = uid_data[0]
                uid_match = header_meta.decode(errors="replace") if isinstance(header_meta, bytes) else str(header_meta)
                uid = None
                if "UID" in uid_match:
                    try:
                        uid = uid_match.split("UID")[1].split(")")[0].strip().split()[0]
                    except Exception:
                        uid = None
                parsed = email_lib.message_from_bytes(header_bytes)
                messages.append({
                    "uid": uid,
                    "from": EmailAccountsService._decode_header_value(parsed.get("From")),
                    "subject": EmailAccountsService._decode_header_value(parsed.get("Subject")),
                    "date": parsed.get("Date"),
                })
            return messages
        except EmailServiceError:
            raise
        except Exception as exc:
            raise EmailServiceError(f"Failed to list inbox: {exc}") from exc
        finally:
            try:
                imap.close()
            except Exception:
                pass
            imap.logout()

    @staticmethod
    def list_inbox_page(
        username: str,
        character: str,
        account_label: Optional[str] = None,
        mailbox: str = "INBOX",
        limit: int = 50,
        offset: int = 0,
        newest_first: bool = True,
    ) -> Dict[str, Any]:
        """Paginated inbox listing for the Personal/Marketing email dashboards
        (direct UI browsing) -- NOT used by the agent tool, which keeps using
        the simpler `list_inbox()` above. `offset` counts from the newest
        message when `newest_first=True` (default -- "next 50" pages forward
        through newest-to-oldest), or from the oldest message when
        `newest_first=False` (used for an explicit "oldest first" view).
        Returns {"messages": [...], "total": int, "offset": int, "limit": int}."""
        account = EmailAccountsService._resolve_account(username, character, account_label)
        limit = max(1, min(int(limit or 50), 100))
        offset = max(0, int(offset or 0))

        imap = EmailAccountsService._imap_connect(account)
        try:
            status, _ = imap.select(mailbox, readonly=True)
            if status != "OK":
                raise EmailServiceError(f"Could not open mailbox '{mailbox}'.")

            status, data = imap.search(None, "ALL")
            if status != "OK":
                raise EmailServiceError("IMAP search failed.")

            ids = data[0].split()
            total = len(ids)
            ordered = list(reversed(ids)) if newest_first else list(ids)
            page_ids = ordered[offset: offset + limit]

            messages: List[Dict[str, Any]] = []
            for msg_id in page_ids:
                status, uid_data = imap.fetch(msg_id, "(UID BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE)] FLAGS)")
                if status != "OK" or not uid_data or not isinstance(uid_data[0], tuple):
                    continue
                header_meta, header_bytes = uid_data[0]
                uid_match = header_meta.decode(errors="replace") if isinstance(header_meta, bytes) else str(header_meta)
                uid = None
                if "UID" in uid_match:
                    try:
                        uid = uid_match.split("UID")[1].split(")")[0].strip().split()[0]
                    except Exception:
                        uid = None
                unread = "\\Seen" not in uid_match
                parsed = email_lib.message_from_bytes(header_bytes)
                messages.append({
                    "uid": uid,
                    "from": EmailAccountsService._decode_header_value(parsed.get("From")),
                    "subject": EmailAccountsService._decode_header_value(parsed.get("Subject")),
                    "date": parsed.get("Date"),
                    "unread": unread,
                })
            return {"messages": messages, "total": total, "offset": offset, "limit": limit}
        except EmailServiceError:
            raise
        except Exception as exc:
            raise EmailServiceError(f"Failed to list inbox: {exc}") from exc
        finally:
            try:
                imap.close()
            except Exception:
                pass
            imap.logout()

    @staticmethod
    def mark_seen(
        username: str,
        character: str,
        uid: str,
        account_label: Optional[str] = None,
        mailbox: str = "INBOX",
    ) -> None:
        """Flags a message \\Seen without changing any of its other state --
        used internally by the inbox-monitor loop to remember it already
        processed a message, independent of whether the human user has
        actually opened/read it in their own mail client."""
        account = EmailAccountsService._resolve_account(username, character, account_label)
        imap = EmailAccountsService._imap_connect(account)
        try:
            status, _ = imap.select(mailbox, readonly=False)
            if status != "OK":
                raise EmailServiceError(f"Could not open mailbox '{mailbox}'.")
            imap.uid("STORE", str(uid), "+FLAGS", "(\\Seen)")
        except EmailServiceError:
            raise
        except Exception as exc:
            raise EmailServiceError(f"Failed to mark message '{uid}' seen: {exc}") from exc
        finally:
            try:
                imap.close()
            except Exception:
                pass
            imap.logout()

    @staticmethod
    def get_message(
        username: str,
        character: str,
        uid: str,
        account_label: Optional[str] = None,
        mailbox: str = "INBOX",
    ) -> Dict[str, Any]:
        account = EmailAccountsService._resolve_account(username, character, account_label)

        imap = EmailAccountsService._imap_connect(account)
        try:
            status, _ = imap.select(mailbox, readonly=True)
            if status != "OK":
                raise EmailServiceError(f"Could not open mailbox '{mailbox}'.")

            status, data = imap.uid("fetch", uid, "(BODY.PEEK[])")
            if status != "OK" or not data or not isinstance(data[0], tuple):
                raise EmailServiceError(f"No message found with uid '{uid}'.")

            raw = data[0][1]
            parsed = email_lib.message_from_bytes(raw)

            body_text = ""
            if parsed.is_multipart():
                for part in parsed.walk():
                    if part.get_content_type() == "text/plain" and not part.get_filename():
                        charset = part.get_content_charset() or "utf-8"
                        body_text = part.get_payload(decode=True).decode(charset, errors="replace")
                        break
            else:
                charset = parsed.get_content_charset() or "utf-8"
                payload = parsed.get_payload(decode=True)
                body_text = payload.decode(charset, errors="replace") if payload else ""

            return {
                "uid": uid,
                "from": EmailAccountsService._decode_header_value(parsed.get("From")),
                "to": EmailAccountsService._decode_header_value(parsed.get("To")),
                "subject": EmailAccountsService._decode_header_value(parsed.get("Subject")),
                "date": parsed.get("Date"),
                "body": body_text[:_MAX_BODY_CHARS],
            }
        except EmailServiceError:
            raise
        except Exception as exc:
            raise EmailServiceError(f"Failed to read message '{uid}': {exc}") from exc
        finally:
            try:
                imap.close()
            except Exception:
                pass
            imap.logout()

    @staticmethod
    def delete_message(
        username: str,
        character: str,
        uid: str,
        account_label: Optional[str] = None,
        mailbox: str = "INBOX",
    ) -> Dict[str, Any]:
        """Moves a message to Trash (NOT a permanent expunge) so the user can
        still recover it from their mail provider's Trash folder if this was
        a mistake."""
        result = EmailAccountsService.delete_messages(
            username, character, [uid], account_label=account_label, mailbox=mailbox
        )
        if result["failed"]:
            raise EmailServiceError(result["failed"][0]["error"])
        return {"uid": uid, "moved_to": result["moved_to"]}

    @staticmethod
    def _move_uid_to_trash(imap: "imaplib.IMAP4_SSL", uid: str, trash: str) -> None:
        status, _ = imap.uid("MOVE", uid, trash)
        if status != "OK":
            # Fallback for servers without the MOVE extension.
            status, _ = imap.uid("COPY", uid, trash)
            if status != "OK":
                raise EmailServiceError(f"No message found with uid '{uid}', or the mailbox rejected the move.")
            imap.uid("STORE", uid, "+FLAGS", "(\\Deleted)")
            imap.expunge()

    @staticmethod
    def delete_messages(
        username: str,
        character: str,
        uids: List[str],
        account_label: Optional[str] = None,
        mailbox: str = "INBOX",
    ) -> Dict[str, Any]:
        """Moves MULTIPLE messages to Trash in a single connection/tool call --
        use this (not repeated single delete_message calls) whenever cleaning
        up more than one message, since each agent reply only gets a limited
        number of tool round trips. Never permanent: everything lands in
        Trash and is recoverable. One bad uid does not abort the rest of the
        batch -- failures are collected and returned alongside successes so
        the caller can honestly report exactly what happened."""
        if not uids:
            raise EmailServiceError("No uids provided to delete.")

        account = EmailAccountsService._resolve_account(username, character, account_label)

        imap = EmailAccountsService._imap_connect(account)
        try:
            status, _ = imap.select(mailbox, readonly=False)
            if status != "OK":
                raise EmailServiceError(f"Could not open mailbox '{mailbox}'.")

            trash = EmailAccountsService._find_trash_mailbox(imap)

            moved: List[str] = []
            failed: List[Dict[str, str]] = []
            for uid in uids:
                uid = str(uid)
                try:
                    EmailAccountsService._move_uid_to_trash(imap, uid, trash)
                    moved.append(uid)
                except Exception as exc:
                    failed.append({"uid": uid, "error": str(exc)})

            return {
                "requested": len(uids),
                "moved": moved,
                "failed": failed,
                "moved_to": trash,
            }
        except EmailServiceError:
            raise
        except Exception as exc:
            raise EmailServiceError(f"Failed to delete messages: {exc}") from exc
        finally:
            try:
                imap.close()
            except Exception:
                pass
            imap.logout()


