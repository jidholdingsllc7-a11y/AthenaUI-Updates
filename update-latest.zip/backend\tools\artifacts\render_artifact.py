# AthenaUI v3.5 — render_artifact Tool
# File: backend/tools/artifacts/render_artifact.py
#
# Saves a self-contained HTML/CSS/JS "artifact" for live rendering inline in
# the full chat window (a sandboxed iframe on the frontend -- no access to
# the user's cookies/session/AthenaUI's APIs). This tool only stores the
# content and returns its id; the caller must reference it in their reply
# using the Markdown-like syntax described in the schema so the UI renders
# it.

from typing import Any, Dict

from artifacts.service import save_artifact

capabilities = {
    "needs_filesystem": True,
    "needs_bridge": False,
    "needs_network": False,
    "needs_user": True,
}


async def run(args: Dict[str, Any]) -> str:
    try:
        username = args.get("username")
        character = args.get("character")
        title = str(args.get("title") or "").strip()
        html = str(args.get("html") or "")

        if not username:
            return "[ERROR] Missing 'username' argument."
        if not title:
            return "[ERROR] Missing 'title' argument."
        if not html.strip():
            return "[ERROR] Missing 'html' argument."

        artifact = save_artifact(username, title=title, html=html, character=character)
        return (
            f"Artifact saved (id={artifact['id']}). To show it to the user, include exactly this "
            f"once in your reply: [Artifact: {title}](artifact:{artifact['id']})"
        )
    except ValueError as e:
        return f"[ERROR] {e}"
    except Exception as e:
        return f"[ERROR] Failed to save artifact: {str(e)}"
