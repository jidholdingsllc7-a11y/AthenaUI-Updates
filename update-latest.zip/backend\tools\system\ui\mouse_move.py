﻿# AthenaUI v3.5 — Mouse Move Tool (Bridge Wrapper)
# File: backend/tools/system/ui/mouse_move.py
# Created: 2026-04-12 14:30 CDT
# Updated: 2026-10-01 (added post-move visual verification)
# Updated: 2026-10-01 (later) -- added an optional `target` param that does
# the coarse-to-fine vision grounding (same logic as ui_locate_element)
# INSIDE this tool. Previously this tool only accepted raw x/y and relied on
# the orchestrating model to have called ui_locate_element first -- in
# practice, live testing showed the model routinely skipped that step and
# instead guessed x/y via its own mental arithmetic off a previous
# screenshot description (e.g. "move 30px left of the bell"), landing on the
# wrong element entirely. Accepting `target` here means correct grounding no
# longer depends on the model remembering/choosing to call a separate tool.

import httpx
from typing import Dict, Any

from ._screen_vision import describe_screenshot, locate_target

BRIDGE_URL = "http://localhost:9000"

capabilities = {
    "needs_bridge": True,
    "needs_filesystem": False,
    "needs_network": False,
    "needs_user": False,
}

async def run(args: Dict[str, Any]) -> Dict[str, Any]:
    username = args.get("username", "system")
    target = args.get("target")
    x = args.get("x")
    y = args.get("y")

    locate_info: Dict[str, Any] = {}
    if target:
        # A text target was given -- always (re-)ground it with a fresh
        # vision pass rather than trusting any x/y the model may have also
        # guessed alongside it.
        locate_info = await locate_target(username, target)
        if locate_info.get("status") != "ok" or locate_info.get("found") is False or "x" not in locate_info:
            return {
                "status": "error",
                "message": (
                    f"Could not visually locate target '{target}' -- not moving the mouse. "
                    "Try a more specific description, or supply explicit x/y if you already "
                    "have verified coordinates."
                ),
                "locate_result": locate_info,
            }
        x = locate_info["x"]
        y = locate_info["y"]
    elif x is None or y is None:
        return {
            "status": "error",
            "message": "Either `target` (a text description to locate) or both `x` and `y` are required.",
        }

    async with httpx.AsyncClient() as client:
        resp = await client.post(f"{BRIDGE_URL}/ui/mouse_move", json={
            "x": x,
            "y": y
        })
        result = resp.json()

        if locate_info:
            result["located_via"] = "target"
            result["target"] = target

        try:
            info_resp = await client.get(f"{BRIDGE_URL}/ui/screen_info")
            info = info_resp.json()
            if info.get("status") == "ok":
                result["screen_width"] = info["width"]
                result["screen_height"] = info["height"]
        except Exception:
            pass

        try:
            shot_resp = await client.get(f"{BRIDGE_URL}/ui/cursor_screenshot")
            shot = shot_resp.json()
        except Exception:
            shot = None

    # Marked screenshot shows the REAL cursor position (a red crosshair) on
    # top of the actual screen, so the agent can see whether the move landed
    # where intended instead of just trusting the requested x/y back.
    if shot and shot.get("status") == "ok" and shot.get("path"):
        question = (
            "A red crosshair marks the current real mouse cursor position "
            f"(reported as x={shot.get('cursor_x')}, y={shot.get('cursor_y')} "
            f"out of a {result.get('screen_width', '?')}x{result.get('screen_height', '?')} screen). "
            "Describe exactly what UI element the crosshair is on or nearest to."
        )
        description = describe_screenshot(username, shot["path"], question=question)
        if description:
            result["verification"] = description
            result["verification_hint"] = (
                "Do not compute your own pixel offset from this description to pick the next "
                "x/y -- if the cursor is not on the intended target, call mouse_move again with "
                "`target` set to a fresh, specific description of that target so it can be "
                "re-grounded visually."
            )

    return result

