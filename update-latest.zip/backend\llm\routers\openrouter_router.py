﻿# AthenaUI v3.5 — Provider-specific router for OpenRouter models
# File: backend/llm/routers/openrouter_router.py
# Created: 2026-03-28 21:36 CDT
# Updated: 2026-07-27 19:49 CDT

import json
import requests
from typing import Any, Dict, List, Optional

from llm.routers.base import BaseLLMRouter
from llm.router_selector.router_selector import RouterSelector
from llm.routers.providers import PROVIDER_OPENROUTER
from core.runtime.runtime import get_runtime

from tools.registry.tool_examples import TOOL_EXAMPLES



class OpenRouterRouter(BaseLLMRouter):
    """
    Provider-specific router for OpenRouter.
    Supports:
    - chat
    - tool calling (OpenAI v2-style)
    - streaming (stub)
    """

    API_URL = "https://openrouter.ai/api/v1/chat/completions"

    # ---------------------------------------------------------
    # Build system prompt with tool examples
    # ---------------------------------------------------------

    def _build_system_prompt(self, base_prompt: Optional[str], *, include_tool_examples: bool = True) -> str:
        # Skip the tool-examples block entirely for calls that don't pass
        # any tools (e.g. Build Map planner/file-generation calls) -- it was
        # previously injected unconditionally, wasting ~1200 prompt tokens
        # and, worse, telling a plain-text/code-only call "you have tools,
        # use them, don't explain, just call it" when it has none, which can
        # crowd out the actual completion budget for the real content.
        if not include_tool_examples:
            return base_prompt if base_prompt else "You are AthenaUI v3.1."

        examples_json = json.dumps(TOOL_EXAMPLES, indent=2)

        tool_usage_block = f"""
You have access to a set of tools. Use them whenever needed.

Here are examples of correct tool usage:
{examples_json}

OpenRouter tool calling rules (OpenAI v2 compatible):
- Tools are declared in "tools"
- Tool calls appear in "message.tool_calls"
- Use "tool_choice" to force a tool

If you need to call a tool, do NOT explain â€” just call it.
"""

        if base_prompt:
            return base_prompt + "\n\n" + tool_usage_block

        return "You are AthenaUI v3.1.\n\n" + tool_usage_block

    # ---------------------------------------------------------
    # Chat Completion
    # ---------------------------------------------------------

    def chat(
        self,
        messages: List[Dict[str, Any]],
        *,
        tools: Optional[List[Dict[str, Any]]] = None,
        tool_choice: Optional[str] = None,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> Dict[str, Any]:

        runtime = get_runtime()
        api_key = runtime.env.OPENROUTER_API_KEY

        if not api_key:
            raise RuntimeError("OpenRouter API key not set.")

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }

        # Optional routing metadata
        if runtime.env.OPENROUTER_SITE_URL:
            headers["HTTP-Referer"] = runtime.env.OPENROUTER_SITE_URL

        if runtime.env.OPENROUTER_APP_NAME:
            headers["X-Title"] = runtime.env.OPENROUTER_APP_NAME

        # Extract any upstream persona/memory system prompt already present
        extracted_prompt, remaining_messages = self._extract_system_prompt(messages)
        final_system_prompt = self._build_system_prompt(
            system_prompt or extracted_prompt, include_tool_examples=bool(tools)
        )

        # Inject system message
        full_messages = [{"role": "system", "content": final_system_prompt}] + remaining_messages

        payload: Dict[str, Any] = {
            "model": self.model_id,
            "messages": full_messages,
            "temperature": temperature,
        }

        if max_tokens is not None:
            payload["max_tokens"] = max_tokens

        # Auto-compress prompts that exceed the model's context window
        # (OpenRouter drops/truncates middle messages instead of erroring
        # out) -- long agentic tool-calling runs (file reads, grep results,
        # etc.) are exactly the case where perfect recall of every old tool
        # result isn't required, and this is a second safety net beyond our
        # own compact_tool_history() trimming.
        payload["plugins"] = [{"id": "context-compression"}]

        # Reasoning/thinking effort (OpenRouter's unified `reasoning` param --
        # see https://openrouter.ai/docs/use-cases/reasoning-tokens). Opt-in
        # only: OpenRouter does NOT enable/scale reasoning automatically, so
        # omit the key entirely unless the user picked a real effort level
        # ("default"/"none"/unset all mean "don't ask for it").
        effort = self.reasoning_effort
        if effort and effort not in ("default", "none"):
            payload["reasoning"] = {"effort": effort}

        # Tool calling (OpenAI v2-style)
        if tools:
            payload["tools"] = tools
            if tool_choice:
                payload["tool_choice"] = tool_choice

        # Send request
        response = requests.post(self.API_URL, json=payload, headers=headers)
        response.raise_for_status()
        data = response.json()

        # Normalize OpenRouter response
        choice = data["choices"][0]
        message = choice.get("message", {})

        return {
            "id": data.get("id"),
            "model": data.get("model"),
            "content": message.get("content"),
            "tool_calls": message.get("tool_calls"),
            "finish_reason": choice.get("finish_reason"),
            "raw": data,
        }

    # ---------------------------------------------------------
    # Streaming (stub)
    # ---------------------------------------------------------

    def stream_chat(self, *args, **kwargs):
        raise NotImplementedError("OpenRouter streaming not implemented yet.")


# ---------------------------------------------------------
# Register Router
# ---------------------------------------------------------

RouterSelector.register_router(PROVIDER_OPENROUTER, OpenRouterRouter)

