# AthenaUI v3.5 — Screenshot Vision Helper
# File: backend/tools/system/ui/_screen_vision.py
# Purpose: Shared helper for the ui_screenshot_* bridge-wrapper tools --
# describes a screenshot file via the dedicated image-analysis pipeline
# (Settings -> Image Analysis), so these tools actually work regardless of
# whether the active chat persona's own model supports vision (previously
# they only ever returned a raw local file path as text, which no model --
# vision-capable or not -- could do anything useful with).

import base64
import re
from pathlib import Path
from typing import Any, Dict, Optional

import httpx
from PIL import Image, ImageDraw

_EXT_MIME = {
    ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
    ".gif": "image/gif", ".webp": "image/webp", ".bmp": "image/bmp",
}

BRIDGE_URL = "http://localhost:9000"
_GRID_COLS = 4
_GRID_ROWS = 3
_CROP_PADDING_FRAC = 0.2  # expand crop beyond the cell so edge-straddling targets aren't clipped

_CELL_RE = re.compile(r"(-?\d+)\s*,\s*(-?\d+)")
_COORD_RE = re.compile(r"x\s*=\s*(-?\d+)\s*,?\s*y\s*=\s*(-?\d+)", re.IGNORECASE)


def describe_screenshot(username: str, image_path: str, question: Optional[str] = None) -> Optional[str]:
    path = Path(image_path)
    if not path.is_file():
        return None

    mime = _EXT_MIME.get(path.suffix.lower(), "image/png")
    data_uri = f"data:{mime};base64,{base64.b64encode(path.read_bytes()).decode('ascii')}"

    # Imported lazily to avoid a circular import (chat.engine.service ->
    # chat.tools.executor -> tools.registry.loader -> this module at
    # package-load time).
    from chat.engine.service import ChatEngine

    engine = ChatEngine(username)
    try:
        provider_id, model_id = engine._get_active_analyze_model()
        api_key = engine._get_api_key(provider_id, category="analyze")
        engine._inject_provider_api_key(provider_id, api_key, category="analyze")
        router = engine.router_selector.select(provider_id=provider_id, model_id=model_id, mode="chat")
        response = router.chat([{
            "role": "user",
            "content": [
                {
                    "type": "text",
                    "text": question or (
                        "Describe what's visible in this screenshot in detail -- "
                        "layout, visible text, buttons/controls, and anything notable."
                    ),
                },
                {"type": "image_url", "image_url": {"url": data_uri, "detail": "high"}},
            ],
        }])
    except Exception as e:
        # Surface the real failure (e.g. a provider 403/permission error)
        # instead of silently returning None -- callers like locate_target()
        # put this straight into their result's raw_response/error field, so
        # the orchestrating model (and the user) can see WHY grounding
        # failed instead of guessing at causes ("DOM issue", "hidden icon").
        return f"VISION_ANALYSIS_ERROR: {e}"

    return ChatEngine._normalize_assistant_text(response) if isinstance(response, dict) else str(response)


async def locate_target(username: str, target: str) -> Dict[str, Any]:
    """Ground a natural-language UI target description to real pixel
    coordinates via a coarse-to-fine vision pass (shared by ui_locate_element
    and mouse_move's optional `target` parameter -- see mouse_move.py for why
    this needs to be callable from inside another tool, not just exposed as
    its own separate tool the orchestrating model has to remember to call).

    Asking directly for exact pixel coordinates of a small icon in a full
    1920x1080 screenshot is too hard for smaller/cheaper vision models (verified
    live: the configured analyze model, gpt-4o-mini, returned NOT_FOUND for an
    icon that is clearly visible). So this does two passes: first a coarse
    "which grid cell is it in" pass on the full screenshot, then crops to that
    cell (with padding) and asks again for exact pixels within the much
    smaller, zoomed-in crop, which is a far easier task for the same model.

    The coarse pass sends an image with real gridlines + "col,row" labels
    drawn on it (not the raw screenshot) -- verified live that asking a model
    to silently divide an un-annotated 1920x1080 screenshot into a mental
    grid produces wrong cells even for a strong model (Claude Sonnet via
    OpenRouter picked cell 1,0 for a bell/clock icon that was actually in
    cell 2,0), which then dooms the fine crop stage to NOT_FOUND since the
    target isn't even in the cropped region. Drawing the grid so the model
    can literally read off the labeled cell instead of estimating fixes this.
    """
    async with httpx.AsyncClient() as client:
        shot_resp = await client.get(f"{BRIDGE_URL}/ui/screenshot_full")
        shot = shot_resp.json()
        info_resp = await client.get(f"{BRIDGE_URL}/ui/screen_info")
        info = info_resp.json()

    if not (isinstance(shot, dict) and shot.get("status") == "ok" and shot.get("path")):
        return {"status": "error", "message": "Failed to capture a screenshot from the bridge."}

    width = info.get("width") if isinstance(info, dict) else None
    height = info.get("height") if isinstance(info, dict) else None
    full_path = shot["path"]

    result: Dict[str, Any] = {
        "status": "ok",
        "screen_width": width,
        "screen_height": height,
    }

    if not (isinstance(width, int) and isinstance(height, int)):
        result["found"] = False
        result["raw_response"] = None
        return result

    # Draw real gridlines + "col,row" labels onto a copy of the screenshot so
    # the coarse pass can read off the cell instead of estimating it blind --
    # see the docstring above for why (verified live failure without this).
    grid_path = f"{full_path}.grid.png"
    grid_img = Image.open(full_path).convert("RGB")
    grid_draw = ImageDraw.Draw(grid_img)
    cell_w, cell_h = width / _GRID_COLS, height / _GRID_ROWS
    for c in range(1, _GRID_COLS):
        x = int(c * cell_w)
        grid_draw.line([(x, 0), (x, height)], fill=(255, 0, 0), width=3)
    for r in range(1, _GRID_ROWS):
        y = int(r * cell_h)
        grid_draw.line([(0, y), (width, y)], fill=(255, 0, 0), width=3)
    for c in range(_GRID_COLS):
        for r in range(_GRID_ROWS):
            label_x, label_y = int(c * cell_w) + 6, int(r * cell_h) + 4
            grid_draw.rectangle(
                [label_x - 2, label_y - 2, label_x + 46, label_y + 16],
                fill=(255, 255, 255),
            )
            grid_draw.text((label_x, label_y), f"{c},{r}", fill=(255, 0, 0))
    grid_img.save(grid_path)

    coarse_question = (
        f"This screenshot is {width}x{height} pixels. Red gridlines divide it "
        f"into a {_GRID_COLS} columns x {_GRID_ROWS} rows grid, and each cell "
        "is labeled 'col,row' in its top-left corner (e.g. '0,0' is the "
        "top-left cell; column increases rightward, row increases downward). "
        f"Find the UI element described as: \"{target}\". Respond with ONLY "
        "one line in the exact format 'col,row' giving the label of the "
        "single grid cell that contains it -- no other text. If you cannot "
        "find it anywhere, respond with exactly NOT_FOUND and nothing else."
    )
    coarse = describe_screenshot(username, grid_path, question=coarse_question)
    if coarse and coarse.startswith("VISION_ANALYSIS_ERROR:"):
        result["status"] = "error"
        result["found"] = False
        result["error"] = coarse
        return result
    cell_match = _CELL_RE.search(coarse) if coarse else None

    if not cell_match:
        result["found"] = False
        result["raw_response"] = coarse
        return result

    col = max(0, min(_GRID_COLS - 1, int(cell_match.group(1))))
    row = max(0, min(_GRID_ROWS - 1, int(cell_match.group(2))))

    cell_w = width / _GRID_COLS
    cell_h = height / _GRID_ROWS
    pad_x = cell_w * _CROP_PADDING_FRAC
    pad_y = cell_h * _CROP_PADDING_FRAC

    crop_left = max(0, int(col * cell_w - pad_x))
    crop_top = max(0, int(row * cell_h - pad_y))
    crop_right = min(width, int((col + 1) * cell_w + pad_x))
    crop_bottom = min(height, int((row + 1) * cell_h + pad_y))

    img = Image.open(full_path)
    crop = img.crop((crop_left, crop_top, crop_right, crop_bottom))
    crop_path = f"{full_path}.crop_{col}_{row}.png"
    crop.save(crop_path)

    crop_w = crop_right - crop_left
    crop_h = crop_bottom - crop_top

    fine_question = (
        "This is a cropped, zoomed-in region of a larger screenshot, exactly "
        f"{crop_w}x{crop_h} pixels (origin 0,0 at THIS CROP's own top-left "
        "corner; x increases rightward, y increases downward). Find the UI "
        f"element described as: \"{target}\". Respond with ONLY one line in the "
        "exact format 'x=<int>, y=<int>' giving the pixel coordinates of the "
        "CENTER of that element, relative to this crop's own top-left corner -- "
        "no other text. If you cannot find it in this crop, respond with "
        "exactly NOT_FOUND and nothing else."
    )
    fine = describe_screenshot(username, crop_path, question=fine_question)

    result["coarse_cell"] = f"{col},{row}"
    result["raw_response"] = fine

    if fine and fine.startswith("VISION_ANALYSIS_ERROR:"):
        result["status"] = "error"
        result["found"] = False
        result["error"] = fine
        return result

    coord_match = _COORD_RE.search(fine) if fine else None
    if coord_match:
        result["x"] = crop_left + int(coord_match.group(1))
        result["y"] = crop_top + int(coord_match.group(2))
    else:
        result["found"] = False

    return result
