# AthenaUI v3.5 — Marketing Tips Library Service
# File: backend/marketing_tips/service.py
#
# A shared, appendable library of marketing know-how -- how/when to use the
# CRM, email, newsletter, and SMS/call tools together, plus any tricks an
# agent discovers while actually marketing a product. ANY character/agent
# (any LLM provider) can search it before starting marketing work, and
# append to it when it learns something worth remembering -- keeping
# persona prompts light instead of baking marketing playbooks into them.
#
# Storage: ONE global SQLite file, NOT per human user account -- every
# character/agent on every account on this install shares the same
# library, and it ships pre-created, unencrypted, with every install:
#   {DATA_DIR}/global/marketing_tips/tips.sqlite

from __future__ import annotations

import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from core.runtime.runtime import get_runtime


class MarketingTipsError(Exception):
    pass


def _root_dir(username: str) -> Path:
    # Global, not per-user -- `username` is accepted only for call-site
    # compatibility and is no longer used to partition storage.
    runtime = get_runtime()
    root = runtime.env.DATA_DIR / "global" / "marketing_tips"
    root.mkdir(parents=True, exist_ok=True)
    return root


def _db_path(username: str) -> Path:
    return _root_dir(username) / "tips.sqlite"


def _connect(username: str) -> sqlite3.Connection:
    conn = sqlite3.connect(_db_path(username))
    conn.row_factory = sqlite3.Row
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS tips (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            tip TEXT NOT NULL,
            tags TEXT,
            tool_name TEXT,
            source_character TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
        """
    )
    return conn


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _normalize_tags(tags: Optional[Any]) -> str:
    if not tags:
        return ""
    if isinstance(tags, (list, tuple, set)):
        parts = [str(t).strip().lower() for t in tags if str(t).strip()]
    else:
        parts = [p.strip().lower() for p in str(tags).split(",") if p.strip()]
    return ",".join(dict.fromkeys(parts))


def _row_to_tip(row: sqlite3.Row) -> Dict[str, Any]:
    return dict(row)


def add_tip(
    username: str,
    title: str,
    tip: str,
    tags: Optional[Any] = None,
    tool_name: Optional[str] = None,
    character: Optional[str] = None,
) -> Dict[str, Any]:
    title = (title or "").strip()
    tip = (tip or "").strip()
    if not title:
        raise MarketingTipsError("'title' is required.")
    if not tip:
        raise MarketingTipsError("'tip' is required.")

    tip_id = uuid.uuid4().hex[:12]
    now = _now()
    with _connect(username) as conn:
        conn.execute(
            """
            INSERT INTO tips
                (id, title, tip, tags, tool_name, source_character, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (tip_id, title, tip, _normalize_tags(tags), (tool_name or "").strip() or None,
             character, now, now),
        )
        row = conn.execute("SELECT * FROM tips WHERE id = ?", (tip_id,)).fetchone()
    return _row_to_tip(row)


def search_tips(
    username: str,
    query: Optional[str] = None,
    tags: Optional[Any] = None,
    tool_name: Optional[str] = None,
    limit: int = 10,
) -> List[Dict[str, Any]]:
    limit = max(1, min(int(limit or 10), 50))

    clauses: List[str] = []
    params: List[Any] = []

    query = (query or "").strip()
    if query:
        clauses.append("(title LIKE ? OR tip LIKE ? OR tags LIKE ? OR tool_name LIKE ?)")
        like = f"%{query}%"
        params.extend([like, like, like, like])

    for tag in _normalize_tags(tags).split(",") if tags else []:
        if tag:
            clauses.append("tags LIKE ?")
            params.append(f"%{tag}%")

    tool_name = (tool_name or "").strip()
    if tool_name:
        clauses.append("tool_name LIKE ?")
        params.append(f"%{tool_name}%")

    where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
    sql = f"SELECT * FROM tips {where} ORDER BY created_at DESC LIMIT ?"
    params.append(limit)

    with _connect(username) as conn:
        rows = conn.execute(sql, params).fetchall()
    return [_row_to_tip(r) for r in rows]
