# AthenaUI v3.5 — Collab Group Chat Storage
# File: backend/chat/collab/service.py
#
# Disk storage for "Collab Group Chat" sessions -- autonomous, agent-
# initiated discussions between two or more agents (no user required to be
# present). Unlike regular Group Chat (single in-memory session per user,
# GROUP_CHAT_SESSIONS in api/routes/chat.py), Collab sessions are keyed by
# the exact set of participating agents so the same combination of agents
# always reuses the same persistent thread (e.g. "Maximos + Sol" is always
# the same ongoing channel, whether they're discussing an email or just
# talking), and are loaded from / saved back to disk on every use rather
# than being kept resident in memory.
#
# Storage: one JSON file per session:
#   {DATA_DIR}/users/{username}/collab_chats/{session_id}.json
# The file contains everything from GroupChatRouter.to_dict() plus the
# collab-specific metadata below (id, title, origin, turn_cap, status,
# concluded_reason, created_at, last_activity_at).

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

from core.runtime.runtime import get_runtime


def _dir(username: str) -> Path:
    root = get_runtime().env.DATA_DIR / "users" / username / "collab_chats"
    root.mkdir(parents=True, exist_ok=True)
    return root


def _path(username: str, session_id: str) -> Path:
    return _dir(username) / f"{session_id}.json"


def session_id_for_participants(participants: List[str]) -> str:
    """Same set of agents (regardless of order or the topic at hand) always
    resolves to the same session id, so 'Maximos + Sol' is one continuous
    thread rather than a new one every time something triggers a chat
    between them."""
    names = sorted({str(p).strip().lower() for p in participants if str(p).strip()})
    slug = "_".join(re.sub(r"[^a-z0-9]+", "", n) for n in names)
    return slug or "collab"


def get_session(username: str, session_id: str) -> Optional[Dict[str, Any]]:
    path = _path(username, session_id)
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def save_session(username: str, session_id: str, data: Dict[str, Any]) -> None:
    _path(username, session_id).write_text(json.dumps(data, indent=2), encoding="utf-8")


def list_sessions(username: str) -> List[Dict[str, Any]]:
    """Summaries for the Collab list view, newest activity first."""
    summaries: List[Dict[str, Any]] = []
    for path in _dir(username).glob("*.json"):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        history = data.get("history", [])
        last_message = history[-1] if history else None
        summaries.append({
            "id": data.get("id", path.stem),
            "title": data.get("title") or path.stem,
            "participants": data.get("character_names", []),
            "origin": data.get("origin", "manual"),
            "status": data.get("status", "active"),
            "concluded_reason": data.get("concluded_reason"),
            "created_at": data.get("created_at"),
            "last_activity_at": data.get("last_activity_at"),
            "message_count": len(history),
            "last_message": (
                {"sender": last_message.get("sender"), "message": last_message.get("message")}
                if last_message else None
            ),
        })

    summaries.sort(key=lambda s: s.get("last_activity_at") or "", reverse=True)
    return summaries
