# AthenaUI v3.6 — coin_toss Tool
# File: backend/tools/artifacts/coin_toss.py
#
# Flips a fair coin using a cryptographically secure RNG (secrets module, not
# left to the LLM) and renders the result as an animated artifact. The
# server-determined result is baked directly into the HTML, so the model
# cannot alter it. A "flip again" button lets the user replay the animation
# client-side (crypto.getRandomValues) purely for fun -- the authoritative
# result is the one this tool returns in its text response.

import secrets
from typing import Any, Dict

from artifacts.service import save_artifact

capabilities = {
    "needs_filesystem": False,
    "needs_bridge": False,
    "needs_network": False,
    "needs_user": True,
}

_HTML_TEMPLATE = """<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<style>
  body { margin:0; display:flex; flex-direction:column; align-items:center; justify-content:center;
         height:100vh; font-family:system-ui,sans-serif; background:#0f1115; color:#eee; }
  .scene { perspective: 800px; margin-bottom: 20px; }
  .coin { width:140px; height:140px; position:relative; transform-style:preserve-3d;
          transition: transform 1.6s cubic-bezier(.2,.8,.2,1); }
  .coin.spin { transform: rotateY(calc(360deg * var(--spins) + var(--end))); }
  .face { position:absolute; width:100%; height:100%; border-radius:50%; backface-visibility:hidden;
          display:flex; align-items:center; justify-content:center; font-size:28px; font-weight:700;
          border:4px solid #c9a227; box-shadow: inset 0 0 20px rgba(0,0,0,.3); }
  .heads { background:radial-gradient(circle at 35% 30%, #ffe9a8, #d4a017); color:#4a3b00; }
  .tails { background:radial-gradient(circle at 35% 30%, #d8d8d8, #9a9a9a); color:#333; transform: rotateY(180deg); }
  #result { font-size:22px; font-weight:600; min-height:32px; }
  button { margin-top:16px; padding:10px 18px; font-size:15px; border:none; border-radius:8px;
           background:#c9a227; color:#1a1a1a; font-weight:600; cursor:pointer; }
  button:active { transform: scale(.97); }
  .note { opacity:.6; font-size:12px; margin-top:6px; }
</style>
</head>
<body>
  <div class="scene"><div class="coin" id="coin">
    <div class="face heads">H</div>
    <div class="face tails">T</div>
  </div></div>
  <div id="result">Flipping...</div>
  <button id="again">Flip again (for fun)</button>
  <div class="note">The first flip is the official result.</div>
<script>
  const official = "__RESULT__"; // "heads" | "tails", chosen server-side
  const coin = document.getElementById("coin");
  const resultEl = document.getElementById("result");

  function animateTo(side, spins) {
    const end = side === "tails" ? 180 : 0;
    coin.style.setProperty("--spins", spins);
    coin.style.setProperty("--end", end + "deg");
    coin.classList.remove("spin");
    void coin.offsetWidth; // restart animation
    coin.classList.add("spin");
    setTimeout(() => {
      resultEl.textContent = side === "heads" ? "Heads!" : "Tails!";
    }, 1600);
  }

  function secureSide() {
    const arr = new Uint32Array(1);
    crypto.getRandomValues(arr);
    return (arr[0] % 2 === 0) ? "heads" : "tails";
  }

  animateTo(official, 5);

  document.getElementById("again").addEventListener("click", () => {
    resultEl.textContent = "Flipping...";
    animateTo(secureSide(), 5);
  });
</script>
</body>
</html>"""

# Narrower variant for a sidebar-width surface (Code Suite/Build Map's
# assistant panel, incl. Synergy's tie-break toss) -- smaller coin, tighter
# padding, no reliance on 100vh (the sidebar's artifact strip is short), and
# no "flip again" button (Synergy's toss is an official one-shot result,
# replaying it there would be misleading).
_HTML_TEMPLATE_COMPACT = """<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<style>
  body { margin:0; padding:10px 0; display:flex; flex-direction:column; align-items:center;
         justify-content:center; font-family:system-ui,sans-serif; background:#0f1115; color:#eee; }
  .scene { perspective: 600px; margin-bottom: 10px; }
  .coin { width:72px; height:72px; position:relative; transform-style:preserve-3d;
          transition: transform 1.4s cubic-bezier(.2,.8,.2,1); }
  .coin.spin { transform: rotateY(calc(360deg * var(--spins) + var(--end))); }
  .face { position:absolute; width:100%; height:100%; border-radius:50%; backface-visibility:hidden;
          display:flex; align-items:center; justify-content:center; font-size:16px; font-weight:700;
          border:3px solid #c9a227; box-shadow: inset 0 0 10px rgba(0,0,0,.3); }
  .heads { background:radial-gradient(circle at 35% 30%, #ffe9a8, #d4a017); color:#4a3b00; }
  .tails { background:radial-gradient(circle at 35% 30%, #d8d8d8, #9a9a9a); color:#333; transform: rotateY(180deg); }
  #result { font-size:13px; font-weight:600; min-height:18px; }
</style>
</head>
<body>
  <div class="scene"><div class="coin" id="coin">
    <div class="face heads">H</div>
    <div class="face tails">T</div>
  </div></div>
  <div id="result">Flipping...</div>
<script>
  const official = "__RESULT__";
  const coin = document.getElementById("coin");
  const resultEl = document.getElementById("result");
  const end = official === "tails" ? 180 : 0;
  coin.style.setProperty("--spins", 4);
  coin.style.setProperty("--end", end + "deg");
  requestAnimationFrame(() => coin.classList.add("spin"));
  setTimeout(() => {
    resultEl.textContent = official === "heads" ? "Heads!" : "Tails!";
  }, 1400);
</script>
</body>
</html>"""


def flip(username: str, *, character: Any = None, title: str = "Coin Toss", compact: bool = False) -> Dict[str, Any]:
    """Shared, programmatic coin-flip helper -- used by both this tool's
    `run()` (LLM-facing) and callers that need the structured result
    directly (e.g. chat/synergy/service.py's tie-break), without going
    through a tool-call round trip. Returns {"result", "artifact_id",
    "title"}; raises ValueError if the artifact couldn't be saved."""
    result = secrets.choice(["heads", "tails"])
    template = _HTML_TEMPLATE_COMPACT if compact else _HTML_TEMPLATE
    html = template.replace("__RESULT__", result)
    artifact = save_artifact(username, title=title, html=html, character=character)
    return {"result": result, "artifact_id": artifact["id"], "title": title}


async def run(args: Dict[str, Any]) -> str:
    try:
        username = args.get("username")
        character = args.get("character")
        title = str(args.get("title") or "").strip() or "Coin Toss"
        compact = bool(args.get("compact") or False)

        if not username:
            return "[ERROR] Missing 'username' argument."

        flipped = flip(username, character=character, title=title, compact=compact)
        return (
            f"Result: {flipped['result']}. Artifact saved (id={flipped['artifact_id']}). To show it to the user, "
            f"include exactly this once in your reply: [Artifact: {title}](artifact:{flipped['artifact_id']})"
        )
    except ValueError as e:
        return f"[ERROR] {e}"
    except Exception as e:
        return f"[ERROR] Failed to flip coin: {str(e)}"
