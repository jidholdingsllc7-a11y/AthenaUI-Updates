# AthenaUI v3.5 — UI Locate Element Tool (Bridge Wrapper)
# File: backend/tools/system/ui/ui_locate_element.py
# Created: 2026-10-01
# Updated: 2026-10-01 (coarse-to-fine grid localization)
# Updated: 2026-10-01 (later) -- moved the actual coarse-to-fine grounding
# logic into _screen_vision.locate_target() so mouse_move can call it
# directly via an optional `target` param, instead of relying on the
# orchestrating model to separately remember to call this tool first (it
# frequently didn't -- see mouse_move.py for the full story). This tool is
# now a thin wrapper around that shared helper, kept for explicit/standalone
# use and backward compatibility.

from typing import Any, Dict

from ._screen_vision import locate_target

capabilities = {
    "needs_bridge": True,
    "needs_filesystem": False,
    "needs_network": False,
    "needs_user": False,
}


async def run(args: Dict[str, Any]) -> Dict[str, Any]:
    target = args.get("target", "")
    username = args.get("username", "system")
    return await locate_target(username, target)

