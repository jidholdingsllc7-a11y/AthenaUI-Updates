# AthenaUI v3.5 — troubleshooting_tip_search Tool
# File: backend/tools/troubleshooting/troubleshooting_tip_search.py
#
# Searches the shared troubleshooting tips library before/while debugging a
# program -- lets any character/agent check for tricks another LLM already
# found, instead of re-discovering (or being pre-loaded with) them every time.

from typing import Any, Dict

from troubleshooting_tips.service import TroubleshootingTipsError, search_tips

capabilities = {
    "needs_filesystem": True,
    "needs_bridge": False,
    "needs_network": False,
    "needs_user": True,
}


async def run(args: Dict[str, Any]) -> str:
    try:
        username = args.get("username")
        if not username:
            return "[ERROR] Missing 'username' argument."

        tips = search_tips(
            username,
            query=args.get("query"),
            tags=args.get("tags"),
            program=args.get("program"),
            limit=args.get("limit", 10),
        )
        if not tips:
            return "No matching tips found in the troubleshooting tips library yet."

        lines = [f"Found {len(tips)} tip(s):"]
        for t in tips:
            tag_str = f" [tags: {t['tags']}]" if t.get("tags") else ""
            program_str = f" (program: {t['program']})" if t.get("program") else ""
            lines.append(f"- {t['title']}{program_str}{tag_str}: {t['tip']}")
        return "\n".join(lines)
    except TroubleshootingTipsError as e:
        return f"[ERROR] {e}"
    except Exception as e:
        return f"[ERROR] Failed to search troubleshooting tips: {str(e)}"
