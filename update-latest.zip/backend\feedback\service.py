# AthenaUI v3.5 — Product Feedback Service
# File: backend/feedback/service.py
#
# Backs the Settings > Feedback page: stores every submission locally (so
# nothing is ever lost even if outbound email fails/isn't configured), and
# best-effort emails it to the product team's feedback inbox using the
# user's own "All Agents"-shared email account, if one is configured.
#
# Storage: {DATA_DIR}/users/{username}/feedback/feedback.sqlite

from __future__ import annotations

import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from core.runtime.runtime import get_runtime
from emailing.service import EmailAccountsService, EmailServiceError

FEEDBACK_TO_EMAIL = "feedback@jidholdingsllc.com"


def _root_dir(username: str) -> Path:
    runtime = get_runtime()
    root = runtime.env.DATA_DIR / "users" / username / "feedback"
    root.mkdir(parents=True, exist_ok=True)
    return root


def _db_path(username: str) -> Path:
    return _root_dir(username) / "feedback.sqlite"


def _connect(username: str) -> sqlite3.Connection:
    conn = sqlite3.connect(_db_path(username))
    conn.row_factory = sqlite3.Row
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS feedback (
            id TEXT PRIMARY KEY,
            message TEXT NOT NULL,
            contact_email TEXT,
            emailed INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL
        )
        """
    )
    return conn


def submit_feedback(username: str, message: str, contact_email: Optional[str] = None) -> Dict[str, Any]:
    message = (message or "").strip()
    if not message:
        raise ValueError("'message' is required.")

    feedback_id = uuid.uuid4().hex[:12]
    now = datetime.now(timezone.utc).isoformat()

    emailed = False
    email_error: Optional[str] = None
    try:
        body = f"Feedback from AthenaUI user '{username}':\n\n{message}"
        if contact_email:
            body += f"\n\n(User provided a reply-to contact: {contact_email})"
        EmailAccountsService.send_email(
            username=username,
            character="AthenaUI",
            to=FEEDBACK_TO_EMAIL,
            subject="AthenaUI feedback submission",
            body=body,
        )
        emailed = True
    except EmailServiceError as e:
        email_error = str(e)

    with _connect(username) as conn:
        conn.execute(
            "INSERT INTO feedback (id, message, contact_email, emailed, created_at) VALUES (?, ?, ?, ?, ?)",
            (feedback_id, message, contact_email, int(emailed), now),
        )

    return {"id": feedback_id, "emailed": emailed, "email_error": email_error}


def list_feedback(username: str) -> List[Dict[str, Any]]:
    with _connect(username) as conn:
        rows = conn.execute("SELECT * FROM feedback ORDER BY created_at DESC").fetchall()
    return [dict(r) for r in rows]
