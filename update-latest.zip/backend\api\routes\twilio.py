# AthenaUI -- Twilio API Routes
# File: backend/api/routes/twilio.py
#
# REST surface for storing/verifying Twilio credentials, mirroring
# api/routes/social_media.py's credentials pattern: verify against the real
# Twilio API before persisting.

from __future__ import annotations

from typing import Any, Dict

from fastapi import APIRouter, Body, Depends, HTTPException

from api.deps.auth_middleware import get_current_user
from twilio_integration import settings as twilio_settings
from twilio_integration.service import TwilioServiceError, verify_credentials

router = APIRouter(prefix="/twilio", tags=["twilio"])


def _username(user: Any) -> str:
    username = user.get("username") if isinstance(user, dict) else getattr(user, "username", None)
    if not username:
        raise HTTPException(status_code=401, detail="Authentication required.")
    return str(username)


@router.get("/status")
async def get_status(user: Dict[str, Any] = Depends(get_current_user)):
    username = _username(user)
    return twilio_settings.capability_status(username)


@router.post("/credentials")
async def set_credentials(payload: Dict[str, Any] = Body(...), user: Dict[str, Any] = Depends(get_current_user)):
    username = _username(user)
    account_sid = str(payload.get("account_sid", "")).strip()
    api_key_sid = str(payload.get("api_key_sid", "")).strip()
    api_key_secret = str(payload.get("api_key_secret", "")).strip()
    phone_number = str(payload.get("phone_number", "")).strip()
    messaging_service_sid = str(payload.get("messaging_service_sid", "")).strip()
    if not all([account_sid, api_key_sid, api_key_secret, phone_number]):
        raise HTTPException(status_code=400, detail="account_sid, api_key_sid, api_key_secret, and phone_number are all required")

    try:
        verify_credentials(account_sid, api_key_sid, api_key_secret)
    except TwilioServiceError as e:
        raise HTTPException(status_code=400, detail=str(e))

    twilio_settings.set_credentials(username, account_sid, api_key_sid, api_key_secret, phone_number, messaging_service_sid or None)
    return {"ok": True}


@router.post("/credentials/clear")
async def clear_credentials(user: Dict[str, Any] = Depends(get_current_user)):
    username = _username(user)
    twilio_settings.clear_credentials(username)
    return {"ok": True}
