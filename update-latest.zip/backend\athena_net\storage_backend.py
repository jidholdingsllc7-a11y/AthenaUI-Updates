# AthenaUI — Athena Net: shared-directory storage backend interface
# File: backend/athena_net/storage_backend.py
# Created: 2026-11-02
#
# All shared-directory providers (Dropbox, local+sync, company server/WebDAV)
# implement this same interface so the rest of Athena Net (group chat,
# membership, permission gating) stays backend-agnostic.

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, List


class StorageBackendError(Exception):
    pass


class StorageBackend(ABC):
    @abstractmethod
    def list(self, path: str) -> List[Dict[str, Any]]:
        """Lists entries directly under `path`. Each entry has at least
        {"name": str, "path": str, "is_folder": bool, "size": int | None}."""

    @abstractmethod
    def read(self, path: str) -> bytes:
        """Returns the raw file contents at `path`."""

    @abstractmethod
    def write(self, path: str, data: bytes) -> None:
        """Creates or overwrites the file at `path` with `data`."""

    @abstractmethod
    def delete(self, path: str) -> None:
        """Deletes the file or folder at `path`."""
