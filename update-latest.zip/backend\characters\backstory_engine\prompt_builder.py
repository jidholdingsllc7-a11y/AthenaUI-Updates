﻿# AthenaUI v3.5 — Backstory Prompt Builder
# File: backend/characters/backstory_engine/prompt_builder.py
# Created: 2026-04-10 20:48 CDT
# Updated: 2026-07-27 19:49 CDT

def build_prompt(character: dict, user_prompt: str | None = None, related_characters: list[dict] | None = None) -> str:
    profile = character.get("profile", {})
    skills = character.get("skills", {})
    relationship = character.get("relationship", {})
    rel_to_user = character.get("relationship_to_user", {})

    full_name = profile.get("full_name", character.get("name", ""))
    age = profile.get("age", None)
    gender = profile.get("gender", "")
    occupation = profile.get("occupation", "")
    traits = profile.get("traits", [])
    skill_domains = skills.get("domains", [])
    rel_status = relationship.get("status", "")
    partner = relationship.get("partner", "")
    rel_mode = rel_to_user.get("mode", "professional")
    family_section = _build_family_section(related_characters)

    if user_prompt:
        return _build_user_seed_prompt(
            user_prompt=user_prompt,
            full_name=full_name,
            age=age,
            gender=gender,
            occupation=occupation,
            traits=traits,
            skill_domains=skill_domains,
            rel_status=rel_status,
            partner=partner,
            rel_mode=rel_mode,
            family_section=family_section,
        )
    else:
        return _build_auto_prompt(
            full_name=full_name,
            age=age,
            gender=gender,
            occupation=occupation,
            traits=traits,
            skill_domains=skill_domains,
            rel_status=rel_status,
            partner=partner,
            rel_mode=rel_mode,
            family_section=family_section,
        )


def build_full_character_prompt(
    character: dict,
    user_prompt: str | None = None,
    related_characters: list[dict] | None = None,
) -> str:
    """
    Builds a prompt asking the LLM to invent/fill EVERY character field in
    one shot -- gender, age, occupation, traits, a physical appearance
    description (written so it can double as an avatar image-generation
    prompt), and the backstory -- returned as a single JSON object. Used by
    auto ("Surprise Me") and partial ("Starting Point") creation so nothing
    is left blank/default just because only the backstory used to be
    generated.
    """
    profile = character.get("profile", {})
    skills = character.get("skills", {})
    relationship = character.get("relationship", {})
    rel_to_user = character.get("relationship_to_user", {})

    full_name = profile.get("full_name", character.get("name", ""))
    age = profile.get("age", None)
    gender = profile.get("gender", "")
    occupation = profile.get("occupation", "")
    traits = profile.get("traits", [])
    appearance = profile.get("appearance", "")
    skill_domains = skills.get("domains", [])
    rel_status = relationship.get("status", "")
    partner = relationship.get("partner", "")
    rel_mode = rel_to_user.get("mode", "professional")
    family_section = _build_family_section(related_characters)

    known_lines = []
    if gender:
        known_lines.append(f"- Gender: {gender} (already decided -- keep exactly as given)")
    if occupation:
        known_lines.append(f"- Occupation: {occupation} (already decided -- keep exactly as given)")
    if traits:
        known_lines.append(f"- Traits: {', '.join(traits)} (already decided -- keep exactly as given)")
    if appearance:
        known_lines.append(f"- Appearance: {appearance} (already decided -- keep exactly as given)")
    if skill_domains:
        known_lines.append(f"- Skill Domains: {', '.join(skill_domains)}")
    known_section = ("\n" + "\n".join(known_lines)) if known_lines else ""

    seed_section = (
        f'\nThe user provided this seed idea for the character:\n"""{user_prompt}"""\n'
        if user_prompt else ""
    )

    return f"""
You are inventing a grounded, modern, fictional character for a chat companion app.
The character must feel like a real person with a coherent life story and a clear,
describable physical appearance. Never mention being artificial, simulated, or code.
{seed_section}
Name: {full_name}
Age: {age if age else "invent an age, 18-65"}
Relationship to User: {rel_mode}
Relationship Status: {rel_status}, Partner: {partner}{known_section}
{family_section}
For anything NOT marked "already decided" above, invent it yourself, consistent with
everything else about this character.

Respond with ONLY a single JSON object (no markdown code fences, no commentary before
or after it) with EXACTLY these keys:
{{
  "gender": "...",
  "age": <integer, 18-65>,
  "occupation": "...",
  "traits": ["...", "...", "..."],
  "appearance": "a detailed physical description -- ethnicity/skin tone, hair color and style, eye color, build, height, and any distinguishing features or typical style of dress -- written so it can be used directly as an image-generation prompt for this character's avatar",
  "backstory": "a 3-6 paragraph modern, realistic backstory explaining how they became who they are today"
}}
"""


def _build_family_section(related_characters: list[dict] | None) -> str:
    """
    Builds a prompt section describing existing relatives so the LLM can
    weave shared family history (hometown, parents, upbringing, etc.) from
    their backstory into the new character's, while still giving the new
    character their own distinct life and voice.
    """
    if not related_characters:
        return ""

    blocks = []
    for tie in related_characters:
        name = tie.get("name", "a relative")
        relation = tie.get("relation", "relative")
        backstory = (tie.get("backstory") or "").strip()
        excerpt = backstory[:1200] + ("..." if len(backstory) > 1200 else "") if backstory else "(no backstory on file)"
        blocks.append(f"- {name} ({relation}):\n{excerpt}")

    joined = "\n\n".join(blocks)
    return f"""

This character has an existing real family connection already in the story. Use these
relatives' established backstories as shared family history -- keep facts like
hometown, parents, upbringing, and cultural background CONSISTENT with theirs, but
give this new character their own distinct personality, path, and voice rather than
retelling the relative's story:

{joined}
"""


def _build_auto_prompt(
    full_name: str,
    age: int | None,
    gender: str,
    occupation: str,
    traits: list[str],
    skill_domains: list[str],
    rel_status: str,
    partner: str,
    rel_mode: str,
    family_section: str = "",
) -> str:
    traits_str = ", ".join(traits) if traits else "none specified"
    skills_str = ", ".join(skill_domains) if skill_domains else "none specified"

    return f"""
You are writing a grounded, modern backstory for a fictional character.
The character must feel like a real person with a coherent life story.
Never mention being artificial, simulated, or code.
Write 3–6 paragraphs.

Character Profile:
- Name: {full_name}
- Age: {age}
- Gender: {gender}
- Occupation: {occupation}
- Traits: {traits_str}
- Skill Domains: {skills_str}
- Relationship to User: {rel_mode}
- Relationship Status: {rel_status}, Partner: {partner}
{family_section}
Write a modern, realistic backstory that explains how they became who they are today.
"""


def _build_user_seed_prompt(
    user_prompt: str,
    full_name: str,
    age: int | None,
    gender: str,
    occupation: str,
    traits: list[str],
    skill_domains: list[str],
    rel_status: str,
    partner: str,
    rel_mode: str,
    family_section: str = "",
) -> str:
    traits_str = ", ".join(traits) if traits else "none specified"
    skills_str = ", ".join(skill_domains) if skill_domains else "none specified"

    return f"""
The user provided this seed description for the character’s backstory:

\"\"\"{user_prompt}\"\"\"

Expand and structure this into a polished, 3–6 paragraph backstory.
Keep the user’s intent, tone, and key facts.
Add depth, history, and emotional realism.
Never mention being artificial, simulated, or code.
Use a modern, realistic setting.

Additional character context:
- Name: {full_name}
- Age: {age}
- Gender: {gender}
- Occupation: {occupation}
- Traits: {traits_str}
- Skill Domains: {skills_str}
- Relationship to User: {rel_mode}
- Relationship Status: {rel_status}, Partner: {partner}
{family_section}
"""


