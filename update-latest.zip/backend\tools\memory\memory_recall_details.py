"""
Fetches the exact original raw exchange(s) a memory_recall_summary result
points to (via its entry_ids), for verbatim quoting. Use this AFTER
memory_recall_summary has already found a relevant past interaction and
the user wants (or you judge they'd want) the exact original wording.
"""
from typing import Any, Dict

from chat.memory.maximos_client import get_client

capabilities = {"needs_filesystem": False, "needs_bridge": False, "needs_network": True, "needs_user": True}


async def run(args: Dict[str, Any]) -> str:
    try:
        username = args.get("username")
        character = args.get("character")
        entry_ids_raw = args.get("entry_ids")

        if not username:
            return "[ERROR] Missing 'username' argument."
        if not character:
            return "[ERROR] No active character -- memory recall requires an agent identity."
        if not entry_ids_raw:
            return "[ERROR] Missing 'entry_ids' argument -- pass the entry_ids from a memory_recall_summary result."

        if isinstance(entry_ids_raw, str):
            entry_ids = [e.strip() for e in entry_ids_raw.split(",") if e.strip()]
        elif isinstance(entry_ids_raw, list):
            entry_ids = [str(e).strip() for e in entry_ids_raw if str(e).strip()]
        else:
            return "[ERROR] 'entry_ids' must be a string or list of entry id strings."

        client = get_client()
        lines = []
        for entry_id in entry_ids:
            entry = client.get_memory(username, character, entry_id)
            if not entry:
                continue
            created_at = entry.get("created_at") or ""
            sender = entry.get("sender") or ""
            origin_install = entry.get("origin_install") or ""
            content = entry.get("content") or ""
            prefix = f"[{created_at}]" if created_at else ""
            if origin_install:
                prefix += f" [from: {origin_install}]"
            if sender:
                prefix += f" {sender}:"
            lines.append(f"{prefix} {content}".strip())

        if not lines:
            return "None of the referenced entries could be found (they may have aged out or been deleted)."

        return "\n".join(lines)
    except Exception as e:
        return f"[ERROR] Failed to fetch memory details: {str(e)}"
