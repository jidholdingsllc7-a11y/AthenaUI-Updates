# AthenaUI v3.5 — Inbox Monitoring / Auto-Reply Background Runner
# File: backend/auto_reply/monitor.py
#
# A single global asyncio loop (started once from main.py's startup event,
# mirroring scheduler/runner.py's pattern) that wakes up periodically and,
# for every registered user, checks every email account that has an
# "assign an agent to monitor this inbox" config (auto_reply/service.py):
#   1. Lists the account's inbox and finds messages newer than the saved
#      `last_processed_uid` cursor (NOT the IMAP \Seen flag -- so this never
#      marks messages read in the human's real mail client).
#   2. For each new message: always raises a notification-bell alert saying
#      new mail arrived on that inbox.
#   3. If auto_reply_enabled, asks the assigned character (via a trusted
#      system-authorization prompt, same framing as scheduled jobs) to read
#      the message and, following the user-authored `instructions`, compose
#      and send a reply using its normal email_send tool -- no further
#      approval popup, since the user explicitly configured this to run
#      autonomously.
#      Otherwise (monitoring on, auto-reply off), the character still drafts
#      a reply -- but with all tools disabled so it can only return text --
#      and it's queued as a `pending_reply` (auto_reply/service.py) for the
#      user to approve/edit/deny from the Marketing Email dashboard. This is
#      the "let them build trust before going fully autonomous" gate.
#   4. Advances the cursor so nothing is processed twice.

from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, List

from auto_reply import service as auto_reply_service
from emailing.service import EmailAccountsService, EmailServiceError
from notifications.service.service import NotificationService
from users.service import UserService

logger = logging.getLogger(__name__)

POLL_SECONDS = 120


async def _handle_new_message(username: str, config: Dict[str, Any], message: Dict[str, Any]) -> None:
    account_label = config["account_label"]
    character = config["character"]
    sender = message.get("from") or "unknown sender"
    subject = message.get("subject") or "(no subject)"

    NotificationService.send(
        username,
        type="info",
        message=f"New email on '{account_label}': \"{subject}\" from {sender}",
        metadata={"account_id": config["account_id"], "account_label": account_label, "from": sender, "subject": subject},
    )

    try:
        detail = EmailAccountsService.get_message(
            username, character, uid=message["uid"], account_label=account_label,
        )
    except EmailServiceError as e:
        logger.warning(f"Auto-reply: failed to read message uid={message.get('uid')} for {username}: {e}")
        return

    from chat.engine.service import ChatEngine  # local import: avoid import-order cycles at startup

    instructions = config.get("instructions") or "(none given -- reply politely and helpfully)"

    # If this inbox is shared with more than one agent (Settings > Email
    # Accounts "access" list), have all of them hold a brief Collab Group
    # Chat discussion about how to respond before the assigned `character`
    # drafts/sends -- rather than that one agent deciding alone. Skipped
    # entirely for single-agent (or access="all") accounts, where there's no
    # specific second agent to loop in.
    collab_note = ""
    account = EmailAccountsService.get_account_by_id(username, config["account_id"])
    access = account.get("access") if account else None
    if isinstance(access, list) and len(access) > 1:
        from chat.collab.orchestrator import run_collab_discussion

        try:
            collab_result = await run_collab_discussion(
                username,
                participants=access,
                context=(
                    f"New email on the shared inbox '{account_label}': subject \"{detail.get('subject')}\" "
                    f"from {detail.get('from')}.\n\n{detail.get('body')}\n\n"
                    f"Discuss how {character} should respond, following these user-given instructions: {instructions}"
                ),
                turn_cap=3,
                origin="email",
                title=f"{account_label} inbox",
            )
            if collab_result.get("turns"):
                discussion_text = "\n".join(f"{t['sender']}: {t['message']}" for t in collab_result["turns"])
                collab_note = f"\n\nYour team already discussed this internally:\n{discussion_text}\n"
        except Exception as e:
            logger.warning(f"Collab discussion failed for {username}/{account_label}: {e}")

    if config.get("auto_reply_enabled"):
        # User has flipped this account to fully autonomous -- let the agent
        # actually call its email_send tool, no approval needed.
        prompt = (
            "You are assigned to monitor the email inbox "
            f"'{account_label}' and auto-reply to new messages on the user's behalf. This is "
            "standing, pre-approved authorization the user set up in the Marketing Email dashboard -- "
            "it does not need fresh confirmation.\n\n"
            f"Instructions the user gave you for how to reply: {instructions}\n\n"
            f"New message received:\nFrom: {detail.get('from')}\nSubject: {detail.get('subject')}\n\n{detail.get('body')}\n"
            f"{collab_note}\n"
            f"Follow the instructions above to decide what the reply should say, then use your email_send tool to send "
            f"the reply to {detail.get('from')} using the '{account_label}' account. Keep it natural and on-brand -- "
            "don't just repeat the instructions verbatim."
        )
        try:
            engine = ChatEngine(username=username)
            await engine.chat_with_billing_fallback(
                messages=[{"role": "system", "content": prompt}],
                character=character,
                tool_trace=[],
            )
        except Exception as e:
            logger.error(f"Auto-reply failed for {username}/{character} on '{account_label}': {e}")
        return

    # Not yet trusted to send on its own -- draft the reply and queue it for
    # the user to approve/edit/deny (Marketing Email dashboard), instead of
    # sending. tool_allowlist=frozenset() blocks ALL tool calls (including
    # email_send) so the model can only return plain drafted text.
    prompt = (
        f"You monitor the email inbox '{account_label}' and are drafting a reply for the user "
        "to review before it's sent -- you are NOT sending this yourself.\n\n"
        f"Instructions the user gave you for how to reply: {instructions}\n\n"
        f"New message received:\nFrom: {detail.get('from')}\nSubject: {detail.get('subject')}\n\n{detail.get('body')}\n"
        f"{collab_note}\n"
        "Write ONLY the reply text you'd send back to this sender, following the instructions above. "
        "Do not include a subject line or any commentary about what you're doing -- just the reply body."
    )
    try:
        engine = ChatEngine(username=username)
        result = await engine.chat_with_billing_fallback(
            messages=[{"role": "system", "content": prompt}],
            character=character,
            tool_trace=[],
            tool_allowlist=frozenset(),
        )
        draft_text = str(result.get("reply") or "").strip()
        if not draft_text:
            return
        auto_reply_service.create_pending_reply(
            username,
            account_id=config["account_id"],
            account_label=account_label,
            character=character,
            uid=message["uid"],
            sender=detail.get("from") or sender,
            subject=detail.get("subject") or subject,
            draft_reply=draft_text,
        )
        NotificationService.send(
            username,
            type="info",
            message=f"{character} drafted a reply on '{account_label}' -- review it in Marketing Email.",
            metadata={"account_id": config["account_id"], "account_label": account_label},
        )
    except Exception as e:
        logger.error(f"Draft-reply generation failed for {username}/{character} on '{account_label}': {e}")


async def _check_account(username: str, config: Dict[str, Any]) -> None:
    account_label = config["account_label"]
    character = config["character"]
    cursor = int(config.get("last_processed_uid") or 0)

    try:
        page = EmailAccountsService.list_inbox_page(
            username, character, account_label=account_label, limit=50, offset=0, newest_first=True,
        )
    except EmailServiceError as e:
        logger.warning(f"Inbox monitor: could not check '{account_label}' for {username}: {e}")
        return

    messages: List[Dict[str, Any]] = page.get("messages", [])
    new_messages = []
    max_uid = cursor
    for m in messages:
        try:
            uid_int = int(m["uid"])
        except (TypeError, ValueError):
            continue
        if uid_int > cursor:
            new_messages.append((uid_int, m))
            max_uid = max(max_uid, uid_int)

    if not new_messages:
        return

    # Process oldest-first so notifications/replies arrive in a sensible order.
    new_messages.sort(key=lambda pair: pair[0])
    for _, message in new_messages:
        await _handle_new_message(username, config, message)

    auto_reply_service.update_cursor(username, config["account_id"], max_uid)


async def _tick() -> None:
    for username in UserService._load_registered_usernames():
        try:
            configs = auto_reply_service.list_configs(username, enabled_only=True)
        except Exception as e:
            logger.warning(f"Inbox monitor: failed to load configs for {username}: {e}")
            continue
        for config in configs:
            try:
                await _check_account(username, config)
            except Exception as e:
                logger.error(f"Inbox monitor: error checking account for {username}: {e}")


async def run_monitor_loop() -> None:
    """Runs forever (until backend exits)."""
    logger.info("Inbox monitor background loop starting.")
    while True:
        try:
            await _tick()
        except Exception as e:
            logger.error(f"Inbox monitor loop tick failed: {e}")
        await asyncio.sleep(POLL_SECONDS)
