# AthenaUI -- hardware capability detection
# Currently only answers one question: is there a dedicated/discrete GPU
# available, as opposed to CPU-integrated graphics only? Used to decide
# whether local llama.cpp-based inference (the "atlas_server" provider) is
# actually practical on this machine -- confirmed via direct testing that
# CPU-only inference on integrated graphics (no CUDA/Metal/Vulkan) takes
# minutes per reply even for a trimmed prompt, far too slow for interactive
# chat/tool-calling use.

import platform
import re
import subprocess
from functools import lru_cache

# Name substrings that indicate CPU-integrated graphics, not a usable
# dedicated accelerator -- anything else reported by the OS is treated as a
# real (likely CUDA/ROCm-capable) GPU.
_INTEGRATED_GPU_HINTS = (
    "intel", "uhd graphics", "iris", "microsoft basic display",
    "microsoft remote display", "parsec virtual display",
)


@lru_cache(maxsize=1)
def has_dedicated_gpu() -> bool:
    """
    Best-effort detection of a dedicated/discrete GPU. Returns False (assume
    no usable GPU) if detection fails for any reason -- defaulting away from
    slow local inference is the safer choice than silently hanging a chat
    request for minutes.
    """
    try:
        system = platform.system()
        if system == "Windows":
            names = _windows_gpu_names()
        elif system == "Linux":
            names = _linux_gpu_names()
        else:
            return False
    except Exception:
        return False

    for name in names:
        lowered = name.lower()
        if any(hint in lowered for hint in _INTEGRATED_GPU_HINTS):
            continue
        return True
    return False


def _windows_gpu_names() -> list:
    result = subprocess.run(
        [
            "powershell", "-NoProfile", "-NonInteractive", "-Command",
            "Get-CimInstance Win32_VideoController | Select-Object -ExpandProperty Name",
        ],
        capture_output=True, text=True, timeout=10, check=False,
    )
    return [line.strip() for line in result.stdout.splitlines() if line.strip()]


def _linux_gpu_names() -> list:
    result = subprocess.run(["lspci"], capture_output=True, text=True, timeout=10, check=False)
    return [
        line.split(":", 2)[-1].strip()
        for line in result.stdout.splitlines()
        if re.search(r"VGA compatible controller|3D controller", line)
    ]
