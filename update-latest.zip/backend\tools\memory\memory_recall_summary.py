"""
Searches this character's "agent summary" layer -- durable, timestamped-to-
the-original-interaction recollections of past exchanges (see
MemoryManager.append_summary) -- so the agent can answer "do you remember
when we talked about X?" without re-reading raw chat transcript text. Each
result includes the summary text, the REAL date the exchange happened, and
an entry_ids field the agent can pass to memory_recall_details to fetch and
quote the original exchange verbatim.
"""
from typing import Any, Dict

from chat.memory.maximos_client import get_client

capabilities = {"needs_filesystem": False, "needs_bridge": False, "needs_network": True, "needs_user": True}


async def run(args: Dict[str, Any]) -> str:
    try:
        username = args.get("username")
        character = args.get("character")
        query = (args.get("query") or "").strip()
        limit = args.get("limit") or 10

        if not username:
            return "[ERROR] Missing 'username' argument."
        if not character:
            return "[ERROR] No active character -- memory recall requires an agent identity."

        client = get_client()
        entries = client.search(username, character, query, limit=int(limit), channel="agent_summary")

        if not entries:
            if not client.is_reachable():
                return (
                    "[ERROR] The Maximos Memory Server is not reachable right now -- "
                    "please let the user know long-term recall is unavailable until it's back up."
                )
            return "No matching past interactions found." if query else "No summarized interactions found yet."

        lines = []
        for e in entries:
            created_at = e.get("created_at") or ""
            summary = e.get("content") or ""
            entry_id = e.get("id") or ""
            source_ids = e.get("source_entry_ids") or []
            ids_str = ",".join(str(i) for i in source_ids) if source_ids else ""
            lines.append(f"[{created_at}] {summary} (entry_ids: {ids_str or entry_id})")

        return "\n".join(lines)
    except Exception as e:
        return f"[ERROR] Failed to recall summaries: {str(e)}"
