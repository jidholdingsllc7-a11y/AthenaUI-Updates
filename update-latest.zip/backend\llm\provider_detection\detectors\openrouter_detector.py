# AthenaUI v3.5 — OpenRouter Provider Auto-Detection
# File: backend/llm/provider_detection/detectors/openrouter_detector.py

import requests
from typing import List, Optional

from llm.provider_detection.detector_base import (
    ProviderDetectorBase,
    ProviderDetectionResult,
)
from llm.routers.providers import PROVIDER_OPENROUTER


class OpenRouterDetector(ProviderDetectorBase):
    provider_id = PROVIDER_OPENROUTER

    def __init__(self, api_key: Optional[str]):
        self.api_key = api_key
        self._last_pricing: dict = {}

    def detect(self) -> ProviderDetectionResult:
        if not self.api_key:
            return ProviderDetectionResult(
                available=False,
                error="No OpenRouter API key provided.",
            )

        try:
            models = self.list_models()
        except Exception as e:
            return ProviderDetectionResult(
                available=False,
                error=str(e),
            )

        return ProviderDetectionResult(
            available=True,
            models=models,
            model_pricing=self._last_pricing,
        )

    def list_models(self) -> List[str]:
        """
        Calls OpenRouter's /api/v1/models endpoint and returns a list of model IDs.
        Also captures each model's live `pricing` object (OpenRouter is the one
        provider whose /models API genuinely returns per-token pricing) into
        self._last_pricing, converted to $ per million tokens, for detect() to
        attach to the ProviderDetectionResult.
        """
        url = "https://openrouter.ai/api/v1/models"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
        }

        response = requests.get(url, headers=headers, timeout=10)

        if response.status_code == 401:
            raise RuntimeError("Invalid OpenRouter API key.")

        if response.status_code >= 500:
            raise RuntimeError("OpenRouter service is temporarily unavailable.")

        response.raise_for_status()

        data = response.json()
        entries = [m for m in data.get("data", []) if m.get("id")]

        pricing: dict = {}
        for entry in entries:
            model_id = entry["id"]
            raw_pricing = entry.get("pricing") or {}
            try:
                prompt_per_token = float(raw_pricing.get("prompt", 0) or 0)
                completion_per_token = float(raw_pricing.get("completion", 0) or 0)
            except (TypeError, ValueError):
                continue
            if prompt_per_token <= 0 and completion_per_token <= 0:
                continue
            pricing[model_id] = {
                "prompt_per_m": prompt_per_token * 1_000_000,
                "completion_per_m": completion_per_token * 1_000_000,
            }

        self._last_pricing = pricing
        return sorted([entry["id"] for entry in entries])
