# AthenaUI v3.5 — Voice Catalog Service
# File: backend/voice/service.py
# Created: 2026-08-01
"""
Loads the hand-editable general voice catalog (backend/config/voices.json --
10 male + 10 female placeholder ElevenLabs voice ids that a user picks
from for their own, non-system characters) and handles assigning a voice
to a character.

System characters (Sol/Maximos/Orion/Meera/Atlas) do NOT use this catalog --
each has its own unique voice id hardcoded directly on its own .base.json
record (a "voice_id" field), separate from these 20, and is not user-
assignable (same lock as the rest of their profile).
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

from characters.system.load import load_character
from characters.system.save import save_character
from characters.system.relationships import is_system_character
from characters.system.list import SYNERGY_CHARACTER_NAME

_VOICES_PATH = Path(__file__).resolve().parent.parent / "config" / "voices.json"


class VoiceAssignmentError(Exception):
    """Raised when a voice can't be assigned (e.g. locked system character)."""


def list_voices() -> List[Dict[str, str]]:
    """Returns the 20-voice catalog, male voices first then female voices
    (each block alphabetical by name) -- purely an organizational aid for
    the dropdown, not a restriction on which gender can use which voice."""
    try:
        raw = json.loads(_VOICES_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []

    voices = [v for v in raw.get("voices", []) if isinstance(v, dict)]
    order = {"male": 0, "female": 1}

    def _sort_key(v: Dict[str, Any]):
        name = str(v.get("name", ""))
        match = re.search(r"(\d+)$", name)
        number = int(match.group(1)) if match else 0
        return (order.get(str(v.get("gender", "")).lower(), 2), number, name)

    voices.sort(key=_sort_key)
    return voices


def get_voice(voice_id: str) -> Optional[Dict[str, str]]:
    for voice in list_voices():
        if voice.get("id") == voice_id:
            return voice
    return None


def assign_character_voice(username: str, name: str, voice_id: str) -> Dict[str, Any]:
    """Sets a (non-system) character's voice_id to one of the catalog entries."""
    char = load_character(username, name)
    if not char:
        raise VoiceAssignmentError(f"Character '{name}' not found.")

    if name == SYNERGY_CHARACTER_NAME or is_system_character(char, name):
        raise VoiceAssignmentError(
            "System characters have a permanent, built-in voice and can't be reassigned."
        )

    if voice_id and not get_voice(voice_id):
        raise VoiceAssignmentError(f"'{voice_id}' is not a recognized voice id.")

    char["voice_id"] = voice_id or None
    save_character(username, char, key=name)
    return char
