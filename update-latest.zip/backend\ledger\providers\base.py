# AthenaUI -- Ledger provider interface
# File: backend/ledger/providers/base.py

from __future__ import annotations

from typing import Any, Dict


class LedgerProvider:
    """Abstract push target for an external compliance ledger (e.g. SCDO)."""

    def push(self, record: Dict[str, Any]) -> Dict[str, Any]:
        raise NotImplementedError
