# AthenaUI v3.5 — Newsletter Subscriber Service
# File: backend/newsletter/service.py
#
# A shared, opt-in email newsletter list -- customers subscribe either
# through the public opt-in/opt-out webpage (see api/routes/newsletter.py,
# unauthenticated) or because an agent adds them after they agree in
# conversation. Any marketing agent/character can list subscribers and send
# a campaign to everyone currently opted in.
#
# Storage: one dedicated SQLite file per human user, shared across all
# characters/agents (same pattern as crm.sqlite):
#   {DATA_DIR}/users/{username}/newsletter/subscribers.sqlite

from __future__ import annotations

import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from core.runtime.runtime import get_runtime


class NewsletterError(Exception):
    pass


def _root_dir(username: str) -> Path:
    runtime = get_runtime()
    root = runtime.env.DATA_DIR / "users" / username / "newsletter"
    root.mkdir(parents=True, exist_ok=True)
    return root


def _db_path(username: str) -> Path:
    return _root_dir(username) / "subscribers.sqlite"


def _connect(username: str) -> sqlite3.Connection:
    conn = sqlite3.connect(_db_path(username))
    conn.row_factory = sqlite3.Row
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS subscribers (
            id TEXT PRIMARY KEY,
            email TEXT NOT NULL UNIQUE,
            name TEXT,
            customer_id TEXT,
            status TEXT NOT NULL DEFAULT 'subscribed',
            source TEXT,
            subscribed_at TEXT NOT NULL,
            unsubscribed_at TEXT
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS drafts (
            id TEXT PRIMARY KEY,
            character TEXT,
            subject TEXT NOT NULL,
            body TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'draft',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            sent_at TEXT
        )
        """
    )
    return conn


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _row_to_subscriber(row: sqlite3.Row) -> Dict[str, Any]:
    return dict(row)


def subscribe(
    username: str,
    email: str,
    name: Optional[str] = None,
    customer_id: Optional[str] = None,
    source: Optional[str] = None,
) -> Dict[str, Any]:
    email = (email or "").strip().lower()
    if not email or "@" not in email:
        raise NewsletterError("A valid 'email' is required.")

    now = _now()
    with _connect(username) as conn:
        existing = conn.execute("SELECT * FROM subscribers WHERE email = ?", (email,)).fetchone()
        if existing:
            conn.execute(
                "UPDATE subscribers SET status = 'subscribed', name = COALESCE(?, name), "
                "customer_id = COALESCE(?, customer_id), subscribed_at = ?, unsubscribed_at = NULL "
                "WHERE email = ?",
                (name, customer_id, now, email),
            )
        else:
            conn.execute(
                """
                INSERT INTO subscribers (id, email, name, customer_id, status, source, subscribed_at)
                VALUES (?, ?, ?, ?, 'subscribed', ?, ?)
                """,
                (uuid.uuid4().hex[:12], email, name, customer_id, source, now),
            )
        row = conn.execute("SELECT * FROM subscribers WHERE email = ?", (email,)).fetchone()
    return _row_to_subscriber(row)


def unsubscribe(username: str, email: str) -> Dict[str, Any]:
    email = (email or "").strip().lower()
    if not email:
        raise NewsletterError("A valid 'email' is required.")

    now = _now()
    with _connect(username) as conn:
        existing = conn.execute("SELECT * FROM subscribers WHERE email = ?", (email,)).fetchone()
        if not existing:
            raise NewsletterError(f"'{email}' is not on the newsletter list.")
        conn.execute(
            "UPDATE subscribers SET status = 'unsubscribed', unsubscribed_at = ? WHERE email = ?",
            (now, email),
        )
        row = conn.execute("SELECT * FROM subscribers WHERE email = ?", (email,)).fetchone()
    return _row_to_subscriber(row)


def list_subscribers(username: str, status: Optional[str] = "subscribed") -> List[Dict[str, Any]]:
    with _connect(username) as conn:
        if status:
            rows = conn.execute(
                "SELECT * FROM subscribers WHERE status = ? ORDER BY subscribed_at DESC", (status,)
            ).fetchall()
        else:
            rows = conn.execute("SELECT * FROM subscribers ORDER BY subscribed_at DESC").fetchall()
    return [_row_to_subscriber(r) for r in rows]


# ------------------------------------------------------------
# Drafts -- agent-proposed newsletters awaiting the user's review before
# being sent to the subscriber list, surfaced on the Marketing Email page.
# ------------------------------------------------------------

def _row_to_draft(row: sqlite3.Row) -> Dict[str, Any]:
    return dict(row)


def save_draft(username: str, subject: str, body: str, character: Optional[str] = None) -> Dict[str, Any]:
    subject = (subject or "").strip()
    body = (body or "").strip()
    if not subject:
        raise NewsletterError("'subject' is required.")
    if not body:
        raise NewsletterError("'body' is required.")

    draft_id = uuid.uuid4().hex[:12]
    now = _now()
    with _connect(username) as conn:
        conn.execute(
            """
            INSERT INTO drafts (id, character, subject, body, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, 'draft', ?, ?)
            """,
            (draft_id, character, subject, body, now, now),
        )
        row = conn.execute("SELECT * FROM drafts WHERE id = ?", (draft_id,)).fetchone()
    return _row_to_draft(row)


def list_drafts(username: str, status: Optional[str] = None) -> List[Dict[str, Any]]:
    with _connect(username) as conn:
        if status:
            rows = conn.execute(
                "SELECT * FROM drafts WHERE status = ? ORDER BY created_at DESC", (status,)
            ).fetchall()
        else:
            rows = conn.execute("SELECT * FROM drafts ORDER BY created_at DESC").fetchall()
    return [_row_to_draft(r) for r in rows]


def get_draft(username: str, draft_id: str) -> Dict[str, Any]:
    with _connect(username) as conn:
        row = conn.execute("SELECT * FROM drafts WHERE id = ?", (draft_id,)).fetchone()
    if not row:
        raise NewsletterError(f"Draft '{draft_id}' not found.")
    return _row_to_draft(row)


def delete_draft(username: str, draft_id: str) -> None:
    with _connect(username) as conn:
        cur = conn.execute("DELETE FROM drafts WHERE id = ?", (draft_id,))
        if cur.rowcount == 0:
            raise NewsletterError(f"Draft '{draft_id}' not found.")


def mark_draft_sent(username: str, draft_id: str) -> Dict[str, Any]:
    now = _now()
    with _connect(username) as conn:
        cur = conn.execute(
            "UPDATE drafts SET status = 'sent', updated_at = ?, sent_at = ? WHERE id = ?",
            (now, now, draft_id),
        )
        if cur.rowcount == 0:
            raise NewsletterError(f"Draft '{draft_id}' not found.")
        row = conn.execute("SELECT * FROM drafts WHERE id = ?", (draft_id,)).fetchone()
    return _row_to_draft(row)
