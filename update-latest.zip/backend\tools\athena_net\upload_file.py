# AthenaUI — Athena Net: agent tool to upload a text file to the shared Dropbox folder
# File: backend/tools/athena_net/upload_file.py

from typing import Any, Dict

from athena_net.dropbox_storage import DropboxStorageBackend
from athena_net.storage_backend import StorageBackendError

capabilities = {
    "needs_filesystem": False,
    "needs_bridge": False,
    "needs_network": True,
    "needs_user": True,
}


async def run(args: Dict[str, Any]) -> str:
    try:
        username = args.get("username")
        path = args.get("path")
        content = args.get("content")

        if not username:
            return "[ERROR] Missing 'username' argument."
        if not path:
            return "[ERROR] Missing 'path' argument."
        if content is None:
            return "[ERROR] Missing 'content' argument."

        backend = DropboxStorageBackend.for_user(username)
        backend.write(path, str(content).encode("utf-8"))
        return f"[OK] Uploaded '{path}' to the Athena Net shared folder."
    except StorageBackendError as e:
        return f"[ERROR] {e}"
    except Exception as e:
        return f"[ERROR] Failed to upload file: {str(e)}"
