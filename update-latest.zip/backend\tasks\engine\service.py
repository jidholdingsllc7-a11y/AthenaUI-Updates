﻿# AthenaUI v3.5 — Task Engine
# File: backend/tasks/engine/service.py
# Created: 2026-04-07 12:10 CDT
# Updated: 2026-08-02 00:00 CDT
#
# Runs a Task's Jobs sequentially in the background (non-blocking -- the
# /tasks/{id}/run route returns immediately and the frontend polls
# /tasks/{id} for live status). Supports two job types:
#
#   "tool_call"  -- run one specific tool with fixed arguments.
#   "agent_goal" -- hand a free-text instruction to the real ChatEngine (the
#                   same one that powers normal chat, full tool-calling
#                   included), for open-ended work like "research this stock
#                   and decide whether to place a trade". Runs as a real
#                   multi-turn loop: the user picks either a fixed number of
#                   turns (params.max_iterations = N) or "run until the agent
#                   marks the task complete" (params.max_iterations = None,
#                   still bounded by AGENT_GOAL_HARD_CAP as a safety ceiling).
#                   The agent is told to end its final reply with
#                   COMPLETION_TOKEN once it's truly done.
#
# Permission handling: a task's `permissions` dict is registered as a
# task-scoped grant (safety/approvals.py) for the duration of the run, via
# safety/task_context.py's contextvar. If a job hits something that wasn't
# pre-granted, the task pauses (status WAITING_APPROVAL) instead of failing,
# and can be resumed via resume_task() once the user resolves the pending
# approval (surfaced to the frontend through the serialized task's
# `pending_approval` field -- see api/routes/tasks.py).
#
# Interrupting a running task: cancel_task() sets status=CANCELLED and calls
# asyncio.Task.cancel() on the background run, which immediately raises
# CancelledError wherever it's currently awaiting (including mid-LLM-call).
# The agent_goal loop ALSO checks task.status == CANCELLED between every
# turn as a graceful stop -- so "Stop" takes effect at the very next chance
# even in the (normal) case where the in-flight turn is allowed to finish.

from __future__ import annotations

import asyncio
import logging
import re
from typing import Dict, Any, List, Optional

from tasks.models.task import Task, TaskStatus
from tasks.models.job import Job
from safety import approvals
from safety.task_context import task_scope
from code_suite.changes.service import changeset_service
from notifications.service.service import NotificationService
from chat.history.service import CHANNEL_TASKS_CHAT

logger = logging.getLogger(__name__)

# Safety ceiling for agent_goal loops even when the user selects "run until
# complete" (max_iterations = None) -- prevents a truly unbounded runaway
# loop while still allowing a very long task (100 agent turns is enormous).
# Also doubles as the per-request ceiling on how many extra turns a user can
# grant when the agent asks for more (see _TaskPausedForTurnsRequest below).
# Settings page's "Agent Turns" dropdown (api/routes/settings.py's
# agent.default_max_turns preference) is clamped to this same ceiling.
AGENT_GOAL_HARD_CAP = 100

# The agent is instructed to include this exact token at the end of its
# reply once it considers the task fully finished. Stripped from the
# displayed text before being stored.
COMPLETION_TOKEN = "[[TASK_COMPLETE]]"

# The agent can also end a reply with this token (N = its best estimate of
# additional turns needed) to explicitly ask the user for more turns before
# it runs out -- caught the same way as running out silently, both surface
# as an Allow/Deny prompt in the Task Builder UI.
TURNS_REQUEST_PATTERN = re.compile(r"\[\[REQUEST_MORE_TURNS:(\d+)\]\]")


class _TaskPausedForApproval(Exception):
    """Internal-only signal: an agent_goal turn triggered a dangerous tool
    call that needs the user's approval. Progress made so far has already
    been written to job_data['result'] by the time this is raised."""

    def __init__(self, change_id: Optional[str]):
        self.change_id = change_id


class _TaskPausedForTurnsRequest(Exception):
    """Internal-only signal: an agent_goal turn either explicitly asked for
    more turns (via TURNS_REQUEST_PATTERN) or silently ran out of its turn
    budget without finishing. Progress made so far has already been written
    to job_data['result'] by the time this is raised -- resolved via
    TaskEngine.resume_task_with_more_turns()/deny_more_turns()."""

    def __init__(self, job_index: int, requested_turns: int, turns_used: int, reason: str):
        self.job_index = job_index
        self.requested_turns = max(1, min(int(requested_turns), AGENT_GOAL_HARD_CAP))
        self.turns_used = turns_used
        self.reason = reason


class TaskEngine:

    def __init__(self):
        self.tasks: Dict[str, Task] = {}
        self._running: Dict[str, "asyncio.Task[None]"] = {}

    # ---------------------------------------------------------
    # Create / configure
    # ---------------------------------------------------------
    def create_task(
        self,
        username: str,
        name: str = "Untitled Task",
        description: str = "",
        permissions: Optional[Dict[str, bool]] = None,
    ) -> Task:
        task = Task(
            name=name,
            description=description,
            owner_username=username,
            permissions={k: bool(v) for k, v in (permissions or {}).items()},
        )
        self.tasks[task.id] = task
        return task

    def add_job(self, task_id: str, job_type: str, params: Dict[str, Any]) -> Job:
        task = self.tasks[task_id]
        job = Job(type=job_type, params=dict(params or {}))
        task.jobs.append(job.__dict__)
        self._recompute_required_categories(task)
        return job

    def add_job_from_template(self, task_id: str, template: Dict[str, Any]) -> Job:
        """Attach a saved Job Library template to this task -- copies its
        type/agent/params in as an independent job entry (editing the
        template later doesn't retroactively change already-attached jobs)."""
        task = self.tasks[task_id]
        params = dict(template.get("params") or {})
        agent = template.get("agent")
        if agent:
            params["agent"] = agent
            if template.get("type") == "agent_goal":
                params.setdefault("character", agent)
        job = Job(type=template.get("type", "agent_goal"), params=params)
        job_dict = job.__dict__
        job_dict["source_template_id"] = template.get("id")
        job_dict["source_template_name"] = template.get("name")
        task.jobs.append(job_dict)
        self._recompute_required_categories(task)
        return job

    def remove_job(self, task_id: str, job_id: str) -> Task:
        task = self.tasks[task_id]
        task.jobs = [j for j in task.jobs if j.get("id") != job_id]
        self._recompute_required_categories(task)
        return task

    def _recompute_required_categories(self, task: Task) -> None:
        """Union of permission categories the task's currently-attached
        tool_call jobs are known to need. Newly-required categories are
        auto-checked in task.permissions as a starting point (still
        editable); categories no longer required are left as-is rather than
        retroactively stripped, to avoid surprising a user mid-review."""
        from tasks.job_library.service import required_categories_for_job

        cats = set()
        for j in task.jobs:
            cats.update(required_categories_for_job(j.get("type", ""), j.get("params") or {}))
        task.required_categories = sorted(cats)
        for cat in task.required_categories:
            task.permissions.setdefault(cat, True)

    def update_permissions(self, task_id: str, permissions: Dict[str, bool]) -> Task:
        task = self.tasks[task_id]
        task.permissions = {k: bool(v) for k, v in (permissions or {}).items()}
        return task

    def list_tasks(self, username: str):
        return [t for t in self.tasks.values() if t.owner_username == username]

    def get_task(self, task_id: str) -> Optional[Task]:
        return self.tasks.get(task_id)

    # ---------------------------------------------------------
    # Run (non-blocking) / Resume / Stop
    # ---------------------------------------------------------
    def start_task(self, task_id: str) -> Task:
        """Kick off (or restart from scratch, if previously run) a task in
        the background and return immediately -- the caller does NOT wait
        for it to finish."""
        task = self.tasks[task_id]
        if task_id in self._running:
            return task

        task.pending_job_index = None
        task.pending_change_id = None
        task.error = None
        task.log = []
        for j in task.jobs:
            j["result"] = None
        task.add_log("Task started.")
        approvals.set_task_permissions(task_id, task.permissions)
        task.update_status(TaskStatus.RUNNING)

        async_task = asyncio.create_task(self._run(task_id, start_index=0))
        self._running[task_id] = async_task
        return task

    async def resume_task(self, task_id: str, resolution_result: Any = None) -> Optional[Task]:
        """Called after the user Allows/Denies the pending approval a task
        was waiting on. `resolution_result` is whatever the code_suite
        changeset apply()/revert() call returned. For a tool_call job this
        moves on to the next step; for an agent_goal job, its own multi-turn
        loop is continued (with the agent told how the request was
        resolved) rather than restarted."""
        task = self.tasks.get(task_id)
        if not task or task.status != TaskStatus.WAITING_APPROVAL:
            return task

        idx = task.pending_job_index if task.pending_job_index is not None else 0
        job_data = task.jobs[idx] if idx < len(task.jobs) else None

        task.add_log(f"Step {idx + 1} resumed after user decision.")
        task.pending_job_index = None
        task.pending_change_id = None
        task.update_status(TaskStatus.RUNNING)

        if job_data is not None and job_data.get("type") == "agent_goal":
            async_task = asyncio.create_task(
                self._run(task_id, start_index=idx, resume_note=resolution_result)
            )
        else:
            if job_data is not None:
                job_data["result"] = resolution_result
            async_task = asyncio.create_task(self._run(task_id, start_index=idx + 1))

        self._running[task_id] = async_task
        return task

    async def resume_task_with_more_turns(self, task_id: str, additional_turns: int) -> Optional[Task]:
        """Called after the user clicks Allow on the "agent wants/needs more
        turns" prompt. Extends the paused agent_goal job's turn budget by
        `additional_turns` (clamped to [1, AGENT_GOAL_HARD_CAP]) and
        continues its loop from where it left off -- the agent keeps its
        full conversation history, it just gets more turns to keep working."""
        task = self.tasks.get(task_id)
        if not task or task.status != TaskStatus.WAITING_APPROVAL or not task.pending_turns_request:
            return task

        request = task.pending_turns_request
        idx = int(request.get("job_index", 0))
        job_data = task.jobs[idx] if idx < len(task.jobs) else None
        if job_data is None:
            return task

        turns_used = int(request.get("turns_used", 0))
        grant = max(1, min(int(additional_turns), AGENT_GOAL_HARD_CAP))
        job_data.setdefault("params", {})["max_iterations"] = turns_used + grant

        task.add_log(f"Step {idx + 1} (agent) granted {grant} more turn(s) by the user.")
        task.pending_job_index = None
        task.pending_turns_request = None
        task.update_status(TaskStatus.RUNNING)

        async_task = asyncio.create_task(self._run(task_id, start_index=idx))
        self._running[task_id] = async_task
        return task

    async def deny_more_turns(self, task_id: str) -> Optional[Task]:
        """Called after the user clicks Deny on the "agent wants/needs more
        turns" prompt -- accepts the agent's progress so far as final for
        this step (its last reply is already saved in job_data['result'])
        and moves on to the task's next step, if any."""
        task = self.tasks.get(task_id)
        if not task or task.status != TaskStatus.WAITING_APPROVAL or not task.pending_turns_request:
            return task

        idx = int(task.pending_turns_request.get("job_index", 0))
        task.add_log(f"Step {idx + 1} (agent) turn request denied by the user -- moving on.")
        task.pending_job_index = None
        task.pending_turns_request = None
        task.update_status(TaskStatus.RUNNING)

        async_task = asyncio.create_task(self._run(task_id, start_index=idx + 1))
        self._running[task_id] = async_task
        return task

    def _notify_task_completed(self, task: Task) -> None:
        """Best-effort in-app notification so the NotificationsBar bell
        reflects real activity -- must never break the run loop."""
        try:
            NotificationService.send(
                task.owner_username,
                type="success",
                message=f'Task "{task.name}" completed.',
                metadata={"task_id": task.id},
            )
        except Exception:
            pass

    def cancel_task(self, task_id: str) -> Task:
        """Stop an active task. Takes effect immediately if possible
        (cancels the background asyncio task, interrupting an in-flight
        await), and at the very latest between the current and next
        turn/job (checked explicitly in the run loops below)."""
        task = self.tasks[task_id]
        task.update_status(TaskStatus.CANCELLED)
        task.add_log("Task stopped by user.")
        approvals.clear_task_permissions(task_id)
        running = self._running.pop(task_id, None)
        if running:
            running.cancel()
        return task

    # ---------------------------------------------------------
    # Internal: the actual background run loop
    # ---------------------------------------------------------
    async def _run(self, task_id: str, start_index: int = 0, resume_note: Any = None) -> None:
        task = self.tasks[task_id]
        try:
            with task_scope(task_id):
                for idx in range(start_index, len(task.jobs)):
                    if task.status == TaskStatus.CANCELLED:
                        return

                    job_data = task.jobs[idx]
                    job_type = job_data.get("type")
                    agent_label = (job_data.get("params") or {}).get("agent")
                    task.add_log(
                        f"Running step {idx + 1}/{len(task.jobs)}: {job_type}"
                        + (f" (agent: {agent_label})" if agent_label else "")
                    )

                    if job_type == "agent_goal":
                        try:
                            await self._execute_agent_goal(
                                task, job_data, idx, resume_note if idx == start_index else None
                            )
                        except _TaskPausedForApproval as e:
                            task.pending_job_index = idx
                            task.pending_change_id = e.change_id
                            task.update_status(TaskStatus.WAITING_APPROVAL)
                            return
                        except _TaskPausedForTurnsRequest as e:
                            task.pending_job_index = e.job_index
                            task.pending_turns_request = {
                                "job_index": e.job_index,
                                "requested_turns": e.requested_turns,
                                "turns_used": e.turns_used,
                                "reason": e.reason,
                                "max_grantable": AGENT_GOAL_HARD_CAP,
                            }
                            task.update_status(TaskStatus.WAITING_APPROVAL)
                            return
                        except Exception as e:
                            job_data["result"] = {"status": "error", "error": str(e)}
                            task.add_log(f"Step {idx + 1} failed: {e}")
                            task.error = str(e)
                            task.update_status(TaskStatus.FAILED)
                            return

                        if task.status == TaskStatus.CANCELLED:
                            return
                        task.add_log(f"Step {idx + 1} complete.")
                        continue

                    job = Job(**job_data)
                    try:
                        job.result = await self._execute_job(task, job)
                    except approvals.ApprovalRequiredError as e:
                        task.add_log(f"Step {idx + 1} needs your approval: {e}")
                        task.pending_job_index = idx
                        task.pending_change_id = getattr(e, "change_id", None)
                        task.update_status(TaskStatus.WAITING_APPROVAL)
                        return
                    except Exception as e:
                        job.result = {"status": "error", "error": str(e)}
                        job_data["result"] = job.result
                        task.add_log(f"Step {idx + 1} failed: {e}")
                        task.error = str(e)
                        task.update_status(TaskStatus.FAILED)
                        return

                    job_data["result"] = job.result
                    task.add_log(f"Step {idx + 1} complete.")

                task.result = [j.get("result") for j in task.jobs]
                task.pending_job_index = None
                task.pending_change_id = None
                task.pending_turns_request = None
                task.add_log("Task completed.")
                task.update_status(TaskStatus.COMPLETED)
                self._notify_task_completed(task)
        finally:
            self._running.pop(task_id, None)
            if task.status in (TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED):
                approvals.clear_task_permissions(task_id)

    async def _execute_agent_goal(
        self,
        task: Task,
        job_data: Dict[str, Any],
        idx: int,
        resume_note: Any = None,
    ) -> None:
        """
        Run an agent_goal job as a real multi-turn loop against the same
        ChatEngine that powers normal chat (full tool-calling included).

        params:
          - goal: str                        -- the free-text instruction.
          - character: Optional[str]         -- which character to run as.
          - max_iterations: Optional[int]    -- None/0 = "run until the
                agent marks the task complete" (bounded by
                AGENT_GOAL_HARD_CAP); a positive int = stop after that many
                turns regardless of completion.

        Writes incremental progress into job_data['result'] after every
        single turn (so a live poll of GET /tasks/{id} shows the agent's
        work-in-progress, not just a final result), and raises
        _TaskPausedForApproval if a turn triggers a tool call that needs the
        user's approval -- with progress already saved at that point.
        """
        from chat.engine.service import ChatEngine

        params = job_data.get("params") or {}
        goal = params.get("goal", "")
        if not goal:
            raise ValueError("agent_goal job is missing 'goal'")
        character = params.get("character")
        # Prefer the library template's id (stable across every run of this
        # same saved Job) over the raw goal text (only stable for ad-hoc,
        # never-saved jobs) so notes/lookups don't drift if the goal wording
        # is later edited.
        job_key = job_data.get("source_template_id") or goal

        raw_cap = params.get("max_iterations")
        unlimited = not raw_cap
        effective_cap = AGENT_GOAL_HARD_CAP if unlimited else max(1, min(int(raw_cap), AGENT_GOAL_HARD_CAP))

        existing = job_data.get("result") or {}
        turns: List[Any] = list(existing.get("turns") or [])
        start_turn = len(turns)

        chat_engine = ChatEngine(username=task.owner_username)

        completion_hint = (
            f"When you have FULLY completed this task, end your reply with the "
            f"exact text {COMPLETION_TOKEN} on its own line. If you still have "
            f"more work left to do, do not include that text yet. If you can "
            f"tell this task will need more turns than you currently have left "
            f"to finish it properly, end your reply with "
            f"[[REQUEST_MORE_TURNS:N]] on its own line instead (replace N with "
            f"your best estimate of how many additional turns you need, up to "
            f"{AGENT_GOAL_HARD_CAP}) to ask the user for permission to keep "
            f"going -- only do this if you genuinely need it, never both "
            f"tokens in the same reply."
        )

        completed = False
        stopped_reason: Optional[str] = None

        for i in range(start_turn, effective_cap):
            if task.status == TaskStatus.CANCELLED:
                stopped_reason = "stopped"
                break

            if i == 0:
                job_notes = chat_engine.memory.load_job_notes(character, job_key)
                notes_block = (
                    "\n\n(Notes from previous times you did this job:\n"
                    + "\n".join(f"- {n}" for n in job_notes) + ")"
                ) if job_notes else ""
                message = f"{goal}{notes_block}\n\n({completion_hint})"
            elif resume_note is not None and i == start_turn:
                message = (
                    "(System note: the user responded to your pending action "
                    f"request. Result: {resume_note!r}. Continue working on "
                    f"your task. {completion_hint})"
                )
            else:
                message = f"(Continue working on your task. {completion_hint})"

            reply = await chat_engine.chat_with_billing_fallback(
                messages=[{"role": "user", "content": message}],
                character=character,
                channel=CHANNEL_TASKS_CHAT,
            )

            reply_text = str(reply.get("reply") or reply.get("content") or reply.get("text") or "")
            requested_more_turns: Optional[int] = None
            turns_match = TURNS_REQUEST_PATTERN.search(reply_text)
            if turns_match:
                requested_more_turns = int(turns_match.group(1))
                cleaned = TURNS_REQUEST_PATTERN.sub("", reply_text).strip()
                for key in ("reply", "content", "text"):
                    if key in reply:
                        reply[key] = cleaned
            elif COMPLETION_TOKEN in reply_text:
                cleaned = reply_text.replace(COMPLETION_TOKEN, "").strip()
                for key in ("reply", "content", "text"):
                    if key in reply:
                        reply[key] = cleaned
                completed = True

            turns.append(reply)
            job_data["result"] = {
                "turns": turns,
                "iterations": len(turns),
                "completed": completed,
            }
            task.add_log(
                f"Step {idx + 1} (agent) turn {len(turns)}"
                + (f"/{effective_cap}" if not unlimited else "")
                + " complete."
            )

            if completed:
                break

            if requested_more_turns is not None:
                task.add_log(
                    f"Step {idx + 1} (agent) is asking for {requested_more_turns} more turn(s) to finish."
                )
                raise _TaskPausedForTurnsRequest(
                    job_index=idx,
                    requested_turns=requested_more_turns,
                    turns_used=len(turns),
                    reason="the agent asked for more turns",
                )

            # Did this turn trigger a dangerous tool call needing approval?
            # (ChatEngine's own tool loop catches ApprovalRequiredError
            # internally, so it never raises here -- detect the pending
            # approval it left behind instead.)
            pending = [
                c
                for c in changeset_service.list_pending_for_user(task.owner_username)
                if getattr(c, "task_id", None) == task.id
            ]
            if pending:
                change = pending[-1]
                task.add_log(f"Step {idx + 1} (agent) is waiting on approval to run '{change.tool_name}'.")
                raise _TaskPausedForApproval(change.id)
        else:
            # The for loop ran out of turns without completing, being
            # cancelled, or the agent explicitly asking for more -- pause
            # and let the user decide whether to grant more turns, instead
            # of silently stopping and moving on to the next step.
            stopped_reason = "max_iterations_reached"
            task.add_log(f"Step {idx + 1} (agent) reached its {effective_cap}-turn limit without finishing.")
            raise _TaskPausedForTurnsRequest(
                job_index=idx,
                requested_turns=min(effective_cap, AGENT_GOAL_HARD_CAP),
                turns_used=len(turns),
                reason="the agent reached its turn limit and has not finished yet",
            )

        if stopped_reason == "stopped" and not completed:
            job_data["result"] = {
                "turns": turns,
                "iterations": len(turns),
                "completed": False,
                "stopped_reason": stopped_reason,
            }
            task.add_log(f"Step {idx + 1} (agent) stopped by user.")

        if completed or stopped_reason == "stopped":
            # The job has definitively finished (either way) rather than
            # merely pausing for approval/more turns -- write a durable
            # note about it now, tagged to this specific job, so the next
            # time this same job runs (or the user asks about it in private
            # chat) that outcome is reliably retrievable, instead of relying
            # on the incidental "remember"-keyword heuristic in
            # ChatEngine._finalize_reply or the finite short-history window.
            job_name = job_data.get("source_template_name") or "Untitled job"
            outcome = "completed successfully" if completed else "was stopped by the user before finishing"
            last_reply = ""
            if turns:
                last = turns[-1]
                if isinstance(last, dict):
                    last_reply = str(last.get("reply") or last.get("content") or last.get("text") or "")
                else:
                    last_reply = str(last)
            note = f'Job "{job_name}" {outcome} ({len(turns)} turn(s)). Goal: {goal[:300]}'
            if last_reply:
                note += f" Final update: {last_reply[:500]}"
            try:
                chat_engine.memory.append_job_note(character, job_key, note)
            except Exception:
                logger.warning("Failed to write job completion memory note for job %s", job_key, exc_info=True)

    async def _execute_job(self, task: Task, job: Job) -> Any:
        """
        Execute a single non-agent_goal job. Supported types:
          - "tool_call" : {"tool_name": str, "arguments": dict}
          - "echo"      : {"text": Any}                 (kept for testing)
          - "sum"       : {"values": List[float]}        (kept for testing)
        """
        params = job.params or {}

        if job.type == "tool_call":
            from tools.registry.loader import load_tools
            from tools.executor.executor import ToolExecutor

            tool_name = params.get("tool_name")
            if not tool_name:
                raise ValueError("tool_call job is missing 'tool_name'")

            registry = load_tools()
            executor = ToolExecutor(registry)
            args = dict(params.get("arguments") or {})
            args.setdefault("username", task.owner_username)
            return await executor.execute(tool_name, args)

        if job.type == "echo":
            return params.get("text")

        if job.type == "sum":
            return sum(params.get("values", []))

        # Placeholder for any other/future job types.
        return {"status": "ok", "job": job.type}


