# AthenaUI v3.5 — Email Cleanup Rules Library
# File: backend/email_rules/service.py
#
# A shared, per-account library of "how to auto-clean this inbox" rules,
# taught by the user from the Personal Email (Outlook Express-style) page:
# each rule is an (action, match_type, match_value) triple -- e.g.
# action="delete", match_type="sender", match_value="spam@example.com" --
# that any agent can consult with `email_cleanup_rule_search` before bulk
# cleaning an inbox, and add to with `email_cleanup_rule_add` when the user
# teaches it a new preference in conversation.
#
# NOTE: acting on a single specific already-open message ("keep/delete THIS
# email") is a direct one-off action (see api/routes/email_management.py),
# NOT a rule -- only the pattern-based choices ("emails like this" / "from
# this sender" / "with this subject") get recorded here.
#
# Storage: one dedicated SQLite file per human user, shared across all
# characters/agents (same pattern as marketing_tips/troubleshooting_tips):
#   {DATA_DIR}/users/{username}/email_rules/rules.sqlite

from __future__ import annotations

import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from core.runtime.runtime import get_runtime

ACTIONS = ("keep", "delete")
MATCH_TYPES = ("sender", "subject", "similar_content")


class EmailRulesError(Exception):
    pass


def _root_dir(username: str) -> Path:
    runtime = get_runtime()
    root = runtime.env.DATA_DIR / "users" / username / "email_rules"
    root.mkdir(parents=True, exist_ok=True)
    return root


def _db_path(username: str) -> Path:
    return _root_dir(username) / "rules.sqlite"


def _connect(username: str) -> sqlite3.Connection:
    conn = sqlite3.connect(_db_path(username))
    conn.row_factory = sqlite3.Row
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS rules (
            id TEXT PRIMARY KEY,
            account_id TEXT,
            account_label TEXT,
            action TEXT NOT NULL,
            match_type TEXT NOT NULL,
            match_value TEXT NOT NULL,
            note TEXT,
            source_character TEXT,
            created_at TEXT NOT NULL
        )
        """
    )
    return conn


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _row_to_rule(row: sqlite3.Row) -> Dict[str, Any]:
    return dict(row)


def add_rule(
    username: str,
    action: str,
    match_type: str,
    match_value: str,
    account_id: Optional[str] = None,
    account_label: Optional[str] = None,
    note: Optional[str] = None,
    character: Optional[str] = None,
) -> Dict[str, Any]:
    action = (action or "").strip().lower()
    match_type = (match_type or "").strip().lower()
    match_value = (match_value or "").strip()

    if action not in ACTIONS:
        raise EmailRulesError(f"'action' must be one of: {', '.join(ACTIONS)}.")
    if match_type not in MATCH_TYPES:
        raise EmailRulesError(f"'match_type' must be one of: {', '.join(MATCH_TYPES)}.")
    if not match_value:
        raise EmailRulesError("'match_value' is required (the sender, subject text, or description to match).")

    rule_id = uuid.uuid4().hex[:12]
    now = _now()
    with _connect(username) as conn:
        conn.execute(
            """
            INSERT INTO rules
                (id, account_id, account_label, action, match_type, match_value, note, source_character, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (rule_id, account_id, account_label, action, match_type, match_value, note, character, now),
        )
        row = conn.execute("SELECT * FROM rules WHERE id = ?", (rule_id,)).fetchone()
    return _row_to_rule(row)


def list_rules(
    username: str,
    account_id: Optional[str] = None,
    account_label: Optional[str] = None,
) -> List[Dict[str, Any]]:
    clauses: List[str] = []
    params: List[Any] = []
    if account_id:
        clauses.append("(account_id = ? OR account_id IS NULL)")
        params.append(account_id)
    elif account_label:
        clauses.append("(account_label = ? OR account_label IS NULL)")
        params.append(account_label)

    where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
    with _connect(username) as conn:
        rows = conn.execute(f"SELECT * FROM rules {where} ORDER BY created_at DESC", params).fetchall()
    return [_row_to_rule(r) for r in rows]


def delete_rule(username: str, rule_id: str) -> None:
    with _connect(username) as conn:
        cur = conn.execute("DELETE FROM rules WHERE id = ?", (rule_id,))
        if cur.rowcount == 0:
            raise EmailRulesError(f"Rule '{rule_id}' not found.")
