﻿# AthenaUI v3.5 — Provider-specific router for HuggingFace Inference API models
# File: backend/llm/routers/huggingface_router.py
# Created: 2026-03-28 21:38 CDT
# Updated: 2026-07-27 19:49 CDT

import json
import requests
from typing import Any, Dict, List, Optional

from llm.routers.base import BaseLLMRouter
from llm.router_selector.router_selector import RouterSelector
from llm.routers.providers import PROVIDER_HUGGINGFACE
from core.runtime.runtime import get_runtime

from tools.registry.tool_examples import TOOL_EXAMPLES



class HuggingFaceRouter(BaseLLMRouter):
    """
    Provider-specific router for HuggingFace Inference API.
    Supports:
    - chat (prompt-based)
    - no native tool calling (emulated via system prompt)
    - streaming (stub)
    """

    API_URL_TEMPLATE = "https://api-inference.huggingface.co/models/{model}"

    # ---------------------------------------------------------
    # Build system prompt with tool examples
    # ---------------------------------------------------------

    def _build_system_prompt(self, base_prompt: Optional[str], *, include_tool_examples: bool = True) -> str:
        if not include_tool_examples:
            return base_prompt if base_prompt else "You are AthenaUI v3.1."

        examples_json = json.dumps(TOOL_EXAMPLES, indent=2)

        tool_usage_block = f"""
HuggingFace Inference API does NOT support tool calling natively.
To call a tool, output ONLY a JSON object describing the tool call.

Here are examples of correct tool usage:
{examples_json}

If you need to call a tool, do NOT explain â€” just output the JSON.
"""

        if base_prompt:
            return base_prompt + "\n\n" + tool_usage_block

        return "You are AthenaUI v3.1.\n\n" + tool_usage_block

    # ---------------------------------------------------------
    # Convert messages â†’ single prompt string
    # ---------------------------------------------------------

    def _convert_messages(self, system_prompt: str, messages: List[Dict[str, Any]]):
        parts = [f"[SYSTEM]: {system_prompt}"]

        for msg in messages:
            role = msg["role"].upper()
            content = msg["content"]
            parts.append(f"[{role}]: {content}")

        return "\n".join(parts)

    # ---------------------------------------------------------
    # Chat Completion
    # ---------------------------------------------------------

    def chat(
        self,
        messages: List[Dict[str, Any]],
        *,
        tools: Optional[List[Dict[str, Any]]] = None,   # HF does NOT support tools natively
        tool_choice: Optional[str] = None,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> Dict[str, Any]:

        runtime = get_runtime()
        api_key = runtime.env.HUGGINGFACE_API_KEY

        if not api_key:
            raise RuntimeError("HuggingFace API key not set.")

        url = self.API_URL_TEMPLATE.format(model=self.model_id)

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }

        # Build system prompt with examples
        extracted_prompt, remaining_messages = self._extract_system_prompt(messages)
        final_system_prompt = self._build_system_prompt(system_prompt or extracted_prompt, include_tool_examples=bool(tools))

        # Convert conversation â†’ single prompt
        prompt = self._convert_messages(final_system_prompt, remaining_messages)

        # Emulate tool calling by injecting tool descriptions
        if tools:
            tool_desc = json.dumps(tools, indent=2)
            prompt += (
                "\n\n[SYSTEM]: Available tools:\n"
                f"{tool_desc}\n"
                "Respond ONLY with a JSON object describing the tool call."
            )

        payload: Dict[str, Any] = {
            "inputs": prompt,
            "parameters": {
                "temperature": temperature,
            },
        }

        if max_tokens is not None:
            payload["parameters"]["max_new_tokens"] = max_tokens

        # Send request
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        data = response.json()

        # HF returns a list of generated texts
        if isinstance(data, list) and len(data) > 0:
            text = data[0].get("generated_text")
        else:
            text = None

        return {
            "id": None,
            "model": self.model_id,
            "content": text,
            "tool_calls": None,  # HF cannot return structured tool calls
            "finish_reason": None,
            "raw": data,
        }

    # ---------------------------------------------------------
    # Streaming (stub)
    # ---------------------------------------------------------

    def stream_chat(self, *args, **kwargs):
        raise NotImplementedError("HuggingFace streaming not implemented yet.")


# ---------------------------------------------------------
# Register Router
# ---------------------------------------------------------

RouterSelector.register_router(PROVIDER_HUGGINGFACE, HuggingFaceRouter)

