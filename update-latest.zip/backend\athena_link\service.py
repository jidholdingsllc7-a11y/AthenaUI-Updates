# AthenaUI — Athena Link: identity registration/status/heartbeat service
# File: backend/athena_link/service.py
# Created: 2026-11-02 11:18 CST
# Updated: 2026-11-02 11:18 CST
#
# Backs the Athena Link Settings UI: register/link this install's identity
# (passphrase-derived Ed25519 keypair + AES key, see crypto.py) against the
# athena-directory Worker, enable/disable syncing, set this install's
# reachable address, and send heartbeats. Identity material is stored in
# this AthenaUI user's own Vault secret (already AES-256-GCM encrypted at
# rest by VaultController) -- the passphrase itself is NEVER stored or
# transmitted anywhere, only the derived keys.

from __future__ import annotations

import base64
import json
import logging
import re
import time
import uuid
from typing import Any, Dict, List, Optional, Tuple

import requests

logger = logging.getLogger(__name__)

from auth.service import AuthService
from characters.system.list import SYNERGY_CHARACTER_NAME, list_all_characters
from vault.service import VaultService

from . import crypto, directory_client
from .directory_client import DirectoryClientError, DirectoryUnreachableError

_IDENTITY_SECRET_KEY = "athena_link_identity"
_USERNAME_RE = re.compile(r"^[a-z0-9_]{3,32}$")
# Must match athena-directory-worker's SIGNATURE_MAX_AGE_SECONDS -- applied
# here too for peer-to-peer (install-to-install) signed requests, which
# never touch the Worker at all.
_SIGNATURE_MAX_AGE_SECONDS = 300
_PEER_TIMEOUT_SECONDS = 15

# "Synergy" is a dual-model chat mode, not an actual character with its
# own memory, so it's never offered for cross-install sync. Every real
# character IS eligible -- including built-in companions like Meera --
# because Athena Link only ever syncs Maximos memory, never the
# character's profile/identity, so there's no risk of a system
# character's profile getting overwritten by another install's copy.
_RESERVED_AGENT_NAMES = {SYNERGY_CHARACTER_NAME}


class AthenaLinkError(Exception):
    pass


def normalize_link_username(raw: str) -> str:
    """Must match athena-directory-worker's src/validation.ts
    `normalizeUsername` exactly, or a locally-"valid" username could still
    be rejected/misrouted by the Worker."""
    normalized = (raw or "").strip().lower()
    if not _USERNAME_RE.match(normalized):
        raise AthenaLinkError(
            "Athena Link username must be 3-32 characters: lowercase letters, numbers, underscore only."
        )
    return normalized


class AthenaLinkService:
    @staticmethod
    def _load_identity(app_username: str) -> Dict[str, Any]:
        identity = VaultService.get_secret(app_username, _IDENTITY_SECRET_KEY)
        return identity if isinstance(identity, dict) else {}

    @staticmethod
    def _save_identity(app_username: str, identity: Dict[str, Any]) -> None:
        VaultService.set_secret(app_username, _IDENTITY_SECRET_KEY, identity)

    @staticmethod
    def get_status(app_username: str) -> Dict[str, Any]:
        """Safe-to-return-to-the-frontend status -- deliberately excludes
        `private_seed`/`aes_key`, which never leave the backend."""
        identity = AthenaLinkService._load_identity(app_username)
        return {
            "configured": bool(identity.get("public_key")),
            "enabled": bool(identity.get("enabled")),
            "link_username": identity.get("link_username"),
            "install_id": identity.get("install_id"),
            "address": identity.get("address", ""),
            "last_heartbeat_at": identity.get("last_heartbeat_at"),
            "last_heartbeat_error": identity.get("last_heartbeat_error"),
        }

    @staticmethod
    def register_or_link(app_username: str, link_username_raw: str, passphrase: str) -> Dict[str, Any]:
        """Registers a brand-new Athena Link username, OR re-links this
        install to an already-registered one by re-entering the SAME
        passphrase (both cases hit the same Worker endpoints -- the Worker
        can't tell the difference, "first registration wins" handles new
        vs. existing transparently)."""
        if not passphrase or len(passphrase) < 8:
            raise AthenaLinkError("Passphrase must be at least 8 characters.")

        link_username = normalize_link_username(link_username_raw)

        try:
            salt_info = directory_client.get_salt(link_username)
        except DirectoryUnreachableError as e:
            raise AthenaLinkError(f"Could not reach the Athena Link directory service: {e}") from e

        salt_b64 = salt_info.get("salt")
        if not salt_b64:
            raise AthenaLinkError("Directory service did not return a salt.")

        seed, aes_key = crypto.derive_identity(passphrase, salt_b64)
        public_key_b64 = crypto.public_key_b64_from_seed(seed)

        try:
            directory_client.register(link_username, public_key_b64)
        except DirectoryClientError as e:
            if e.status_code == 409:
                raise AthenaLinkError(
                    "This username is already claimed under a different passphrase. "
                    "Double-check the username and passphrase, or pick a different username."
                ) from e
            raise AthenaLinkError(str(e)) from e
        except DirectoryUnreachableError as e:
            raise AthenaLinkError(f"Could not reach the Athena Link directory service: {e}") from e

        identity = AthenaLinkService._load_identity(app_username)
        install_id = identity.get("install_id") or str(uuid.uuid4())

        identity.update(
            {
                "link_username": link_username,
                "salt": salt_b64,
                "public_key": public_key_b64,
                "private_seed": base64.b64encode(seed).decode("ascii"),
                "aes_key": base64.b64encode(aes_key).decode("ascii"),
                "install_id": install_id,
                "enabled": True,
            }
        )
        AthenaLinkService._save_identity(app_username, identity)
        return AthenaLinkService.get_status(app_username)

    @staticmethod
    def set_enabled(app_username: str, enabled: bool) -> Dict[str, Any]:
        identity = AthenaLinkService._load_identity(app_username)
        if not identity.get("public_key"):
            raise AthenaLinkError("Register an Athena Link identity first.")
        identity["enabled"] = bool(enabled)
        AthenaLinkService._save_identity(app_username, identity)
        return AthenaLinkService.get_status(app_username)

    @staticmethod
    def set_address(app_username: str, address: str) -> Dict[str, Any]:
        address = (address or "").strip()
        if address and not (address.startswith("http://") or address.startswith("https://")):
            raise AthenaLinkError("Address must be a full http(s) URL (e.g. your Cloudflare Tunnel URL).")
        identity = AthenaLinkService._load_identity(app_username)
        if not identity.get("public_key"):
            raise AthenaLinkError("Register an Athena Link identity first.")
        identity["address"] = address
        AthenaLinkService._save_identity(app_username, identity)
        return AthenaLinkService.get_status(app_username)

    @staticmethod
    def get_lan_address() -> str:
        """Only useful when both installs are on the same local network --
        the simplest zero-setup option for that case."""
        from . import network

        return network.get_lan_address()

    @staticmethod
    def start_auto_tunnel(app_username: str) -> Dict[str, Any]:
        """Starts (or reuses) a managed Cloudflare Quick Tunnel and wires
        its address straight into `set_address` whenever cloudflared
        reports a URL -- including every time a dropped quick tunnel gets
        auto-restarted with a new one, so the saved address never goes
        stale on its own."""
        from . import tunnel_manager

        def _on_url_change(url: str) -> None:
            try:
                AthenaLinkService.set_address(app_username, url)
            except AthenaLinkError:
                pass

        try:
            tunnel_manager.start(on_url_change=_on_url_change)
        except tunnel_manager.TunnelError as e:
            raise AthenaLinkError(str(e)) from e

        # Remembered so resume_tunnels_on_startup() can bring the tunnel
        # back automatically next boot -- it's a child process of this
        # backend, so a restart (e.g. to apply an update) always kills it,
        # otherwise leaving the saved address pointed at a dead, no-longer-
        # resolving trycloudflare.com URL until the user reopens Settings.
        identity = AthenaLinkService._load_identity(app_username)
        identity["tunnel_auto_start"] = True
        AthenaLinkService._save_identity(app_username, identity)

        # Give it a few seconds to obtain the first URL so the caller
        # usually gets an immediate result; the frontend falls back to
        # polling /tunnel/status if it's still not ready after this.
        deadline = time.time() + 8
        current = tunnel_manager.status()
        while not current["url"] and time.time() < deadline:
            time.sleep(0.5)
            current = tunnel_manager.status()
        return current

    @staticmethod
    def get_tunnel_status() -> Dict[str, Any]:
        from . import tunnel_manager

        return tunnel_manager.status()

    @staticmethod
    def stop_auto_tunnel(app_username: str) -> Dict[str, Any]:
        from . import tunnel_manager

        tunnel_manager.stop()
        identity = AthenaLinkService._load_identity(app_username)
        if identity:
            identity["tunnel_auto_start"] = False
            AthenaLinkService._save_identity(app_username, identity)
        return tunnel_manager.status()

    @staticmethod
    def resume_tunnels_on_startup() -> None:
        """Called once on backend boot. A managed Cloudflare Quick Tunnel is
        a child process of this backend, so restarting the backend (e.g.
        to apply an update) always kills it -- without this, the saved
        address keeps pointing at a now-dead, no-longer-resolving
        trycloudflare.com URL until the user manually reopens Settings and
        clicks Start Tunnel again. Re-starts it for whichever user had it
        running last time (tunnel_manager is a single process-global
        singleton, so only one user's tunnel can run at a time)."""
        try:
            users = AuthService()._load_users()
        except Exception:
            logger.warning("Could not load users to resume Athena Link tunnels", exc_info=True)
            return
        for app_username in users:
            identity = AthenaLinkService._load_identity(app_username)
            if identity.get("tunnel_auto_start") and identity.get("enabled"):
                try:
                    AthenaLinkService.start_auto_tunnel(app_username)
                except AthenaLinkError:
                    logger.warning("Failed to auto-resume Athena Link tunnel for %s", app_username, exc_info=True)
                break

    @staticmethod
    def send_heartbeat(app_username: str) -> Dict[str, Any]:
        identity = AthenaLinkService._load_identity(app_username)
        if not identity.get("public_key"):
            raise AthenaLinkError("Register an Athena Link identity first.")
        if not identity.get("enabled"):
            raise AthenaLinkError("Athena Link is disabled -- enable it first.")
        address = identity.get("address")
        if not address:
            raise AthenaLinkError("Set this install's reachable address first (e.g. your tunnel URL).")

        seed = base64.b64decode(identity["private_seed"])
        link_username = identity["link_username"]
        install_id = identity["install_id"]
        timestamp = int(time.time())
        message = crypto.canonical_message(["heartbeat", link_username, install_id, address, timestamp])
        signature_b64 = crypto.sign_message(seed, message)

        try:
            directory_client.heartbeat(link_username, install_id, address, timestamp, signature_b64)
        except (DirectoryClientError, DirectoryUnreachableError) as e:
            identity["last_heartbeat_error"] = str(e)
            AthenaLinkService._save_identity(app_username, identity)
            raise AthenaLinkError(f"Heartbeat failed: {e}") from e

        identity["last_heartbeat_at"] = time.time()
        identity["last_heartbeat_error"] = None
        AthenaLinkService._save_identity(app_username, identity)
        return AthenaLinkService.get_status(app_username)

    @staticmethod
    def resolve(link_username_raw: str) -> Dict[str, Any]:
        """Public lookup (no signing needed) -- returns every known install
        for a given Athena Link username, most-recently-seen first."""
        link_username = normalize_link_username(link_username_raw)
        try:
            return directory_client.resolve(link_username)
        except DirectoryClientError as e:
            raise AthenaLinkError(str(e)) from e
        except DirectoryUnreachableError as e:
            raise AthenaLinkError(f"Could not reach the Athena Link directory service: {e}") from e

    # ---------------------------------------------------------
    # Agent discovery + import -- install-to-install only, never touches the
    # directory Worker. Both installs independently derived the IDENTICAL
    # Ed25519 keypair + AES key from the same (link_username, passphrase),
    # so a peer request is authenticated by verifying its signature against
    # THIS install's own stored public key (no round-trip to the Worker
    # needed), and the exported bundle is encrypted with the same shared
    # aes_key -- no separate key exchange required.
    # ---------------------------------------------------------

    @staticmethod
    def list_local_agents(app_username: str) -> List[Dict[str, Any]]:
        """Characters on this install eligible for cross-install export --
        excludes built-in system agents/Synergy, which ship with every
        install already."""
        characters = list_all_characters(app_username)
        agents = []
        for name, profile in characters.items():
            if name in _RESERVED_AGENT_NAMES:
                continue
            display_name = (profile or {}).get("name") or name
            agents.append({"name": name, "display_name": display_name})
        return agents

    @staticmethod
    def _find_identity_owner(link_username: str) -> Optional[Tuple[str, Dict[str, Any]]]:
        """Reverse lookup: which local AthenaUI account (if any) has this
        Athena Link username registered + enabled. An inbound peer request
        only carries the Athena Link identity, not a local login, so the
        receiving install has to find out for itself which of its own
        users it belongs to."""
        users = AuthService()._load_users()
        for app_username in users:
            identity = AthenaLinkService._load_identity(app_username)
            if (
                identity.get("link_username") == link_username
                and identity.get("enabled")
                and identity.get("public_key")
            ):
                return app_username, identity
        return None

    @staticmethod
    def verify_peer_request(
        link_username_raw: str, timestamp: int, signature_b64: str, message_parts: List[Any]
    ) -> str:
        """Verifies an inbound peer-to-peer request signed by another
        install sharing this same Athena Link identity. Returns the local
        app_username that owns the identity, or raises AthenaLinkError."""
        link_username = normalize_link_username(link_username_raw)
        now = int(time.time())
        if abs(now - int(timestamp)) > _SIGNATURE_MAX_AGE_SECONDS:
            raise AthenaLinkError("Request timestamp is too old or skewed -- rejected.")

        found = AthenaLinkService._find_identity_owner(link_username)
        if not found:
            raise AthenaLinkError("No local Athena Link identity matches this username.")
        app_username, identity = found

        message = crypto.canonical_message(message_parts)
        if not crypto.verify_signature(identity["public_key"], message, signature_b64):
            raise AthenaLinkError("Signature verification failed.")
        return app_username

    @staticmethod
    def export_agent_bundle(app_username: str, character_name: str) -> str:
        """Builds an encrypted bundle containing ONLY `character_name`'s
        Maximos memory backup (never the character's profile/identity --
        Athena Link syncs memory, it never ships or applies a changed
        agent), encrypted with this identity's shared AES key. Returns a
        base64 blob only decryptable by another install that knows the
        same Athena Link passphrase. Called from the
        `/athena_link/remote/agents/{name}/export` route after the caller's
        signature has already been verified."""
        identity = AthenaLinkService._load_identity(app_username)
        if not identity.get("public_key"):
            raise AthenaLinkError("Register an Athena Link identity first.")

        character = list_all_characters(app_username).get(character_name)
        if character is None or character_name in _RESERVED_AGENT_NAMES:
            raise AthenaLinkError(f"No local character named '{character_name}'.")

        aes_key = base64.b64decode(identity["aes_key"])
        # Reuses the already-shared aes_key as the Maximos backup passphrase
        # too -- both installs already independently hold it, so no further
        # key material needs to be exchanged for the memory backup itself.
        memory_passphrase = base64.b64encode(aes_key).decode("ascii")

        from chat.memory.maximos_client import get_client as get_maximos_client

        maximos = get_maximos_client()
        # backup_agent() fails soft (returns None) on ANY problem, including
        # the memory server simply not running -- check reachability
        # explicitly first so that case raises a clear error instead of
        # silently exporting an empty backup indistinguishable from "this
        # character genuinely has no memory yet".
        if not maximos.enabled or not maximos.is_reachable():
            raise AthenaLinkError(
                "Maximos Memory Server is not reachable on this install -- start it and try again."
            )

        backup_bytes = maximos.backup_agent(app_username, character_name, memory_passphrase)

        bundle = {
            "memory_backup_base64": base64.b64encode(backup_bytes).decode("ascii") if backup_bytes else None,
        }
        return crypto.aes_encrypt(aes_key, json.dumps(bundle).encode("utf-8"))

    @staticmethod
    def _resolve_peer_address(identity: Dict[str, Any], source_address: Optional[str]) -> str:
        if source_address:
            return source_address
        resolved = AthenaLinkService.resolve(identity["link_username"])
        candidates = [
            inst["address"]
            for inst in resolved.get("installs", [])
            if inst.get("install_id") != identity.get("install_id") and inst.get("address")
        ]
        if not candidates:
            raise AthenaLinkError("No other reachable Athena Link install found for this username.")
        return candidates[0]

    @staticmethod
    def list_remote_agents(app_username: str, source_address: Optional[str] = None) -> List[Dict[str, Any]]:
        """Asks another install sharing this identity what characters it
        has available to export."""
        identity = AthenaLinkService._load_identity(app_username)
        if not identity.get("public_key"):
            raise AthenaLinkError("Register an Athena Link identity first.")

        link_username = identity["link_username"]
        seed = base64.b64decode(identity["private_seed"])
        address = AthenaLinkService._resolve_peer_address(identity, source_address)

        timestamp = int(time.time())
        message = crypto.canonical_message(["link:agents:list", link_username, timestamp])
        signature_b64 = crypto.sign_message(seed, message)

        try:
            resp = requests.post(
                f"{address.rstrip('/')}/athena_link/remote/agents",
                json={"link_username": link_username, "timestamp": timestamp, "signature": signature_b64},
                timeout=_PEER_TIMEOUT_SECONDS,
            )
        except requests.RequestException as e:
            raise AthenaLinkError(f"Could not reach the other install at {address}: {e}") from e

        if resp.status_code != 200:
            raise AthenaLinkError(f"Could not list remote agents ({resp.status_code}): {resp.text[:200]}")
        return resp.json().get("agents", [])

    @staticmethod
    def import_agent(app_username: str, character_name: str, source_address: Optional[str] = None) -> Dict[str, Any]:
        """Pulls `character_name`'s Maximos memory from another install
        sharing this install's Athena Link identity and restores it here.
        Never creates or modifies the character's profile -- `character_name`
        must already exist locally (on both installs, independently) for
        its memory to have somewhere to attach to; Athena Link keeps the
        two in sync, it never ships one install's copy of the agent itself
        to the other. `source_address` overrides automatic discovery
        (useful when more than one other install is registered); otherwise
        the first OTHER resolved install is used."""
        identity = AthenaLinkService._load_identity(app_username)
        if not identity.get("public_key"):
            raise AthenaLinkError("Register an Athena Link identity first.")

        if character_name not in list_all_characters(app_username):
            raise AthenaLinkError(
                f"'{character_name}' does not exist on this install yet -- create/use it here first, "
                "then sync its memory."
            )

        link_username = identity["link_username"]
        seed = base64.b64decode(identity["private_seed"])
        aes_key = base64.b64decode(identity["aes_key"])
        address = AthenaLinkService._resolve_peer_address(identity, source_address)

        timestamp = int(time.time())
        message = crypto.canonical_message(["link:agents:export", link_username, character_name, timestamp])
        signature_b64 = crypto.sign_message(seed, message)

        try:
            resp = requests.post(
                f"{address.rstrip('/')}/athena_link/remote/agents/{character_name}/export",
                json={"link_username": link_username, "timestamp": timestamp, "signature": signature_b64},
                timeout=_PEER_TIMEOUT_SECONDS,
            )
        except requests.RequestException as e:
            raise AthenaLinkError(f"Could not reach the other install at {address}: {e}") from e

        if resp.status_code != 200:
            raise AthenaLinkError(f"Import failed ({resp.status_code}): {resp.text[:200]}")

        blob_b64 = resp.json().get("blob")
        if not blob_b64:
            raise AthenaLinkError("The other install returned an empty response.")

        try:
            bundle = json.loads(crypto.aes_decrypt(aes_key, blob_b64))
        except Exception as e:
            raise AthenaLinkError(f"Could not decrypt the imported agent bundle: {e}") from e

        restored_count = 0
        note = None
        memory_backup_b64 = bundle.get("memory_backup_base64")
        if memory_backup_b64:
            from chat.memory.maximos_client import get_client as get_maximos_client

            maximos = get_maximos_client()
            if not maximos.enabled or not maximos.is_reachable():
                raise AthenaLinkError(
                    "Maximos Memory Server is not reachable on this install -- start it and try again."
                )

            memory_passphrase = base64.b64encode(aes_key).decode("ascii")
            backup_bytes = base64.b64decode(memory_backup_b64)
            restored_count = (
                maximos.restore_agent(app_username, character_name, backup_bytes, memory_passphrase) or 0
            )
        else:
            # The other install's own Maximos Memory Server was reachable
            # (export_agent_bundle checks that itself and would have raised
            # otherwise) but had no memory backup for this agent -- i.e. it
            # genuinely has nothing to sync yet, not a hidden failure.
            note = "The other install reported no memory for this agent yet."

        return {
            "imported": True,
            "character_name": character_name,
            "restored_memory_count": restored_count,
            "note": note,
        }
