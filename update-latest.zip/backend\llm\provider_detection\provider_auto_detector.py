﻿# AthenaUI v3.5 — Provider Auto-Detection Orchestrator
# File: backend/llm/provider_detection/provider_auto_detector.py
# Created: 2026-04-06 11:24 CDT
# Updated: 2026-07-27 19:49 CDT

from typing import Optional, Dict, Any

from llm.provider_detection.detector_base import ProviderDetectionResult
from llm.routers.providers import *

# Import all detectors
from llm.provider_detection.detectors.openai_detector import OpenAIDetector
from llm.provider_detection.detectors.anthropic_detector import AnthropicDetector
from llm.provider_detection.detectors.groq_detector import GroqDetector
from llm.provider_detection.detectors.gemini_detector import GeminiDetector
from llm.provider_detection.detectors.mistral_detector import MistralDetector
from llm.provider_detection.detectors.fireworks_detector import FireworksDetector
from llm.provider_detection.detectors.together_detector import TogetherDetector
from llm.provider_detection.detectors.deepseek_detector import DeepSeekDetector
from llm.provider_detection.detectors.perplexity_detector import PerplexityDetector
from llm.provider_detection.detectors.cohere_detector import CohereDetector
from llm.provider_detection.detectors.ai21_detector import AI21Detector
from llm.provider_detection.detectors.azure_openai_detector import AzureOpenAIDetector
from llm.provider_detection.detectors.bedrock_detector import BedrockDetector
from llm.provider_detection.detectors.huggingface_detector import HuggingFaceDetector
from llm.provider_detection.detectors.hf_tgi_detector import HFTGIDetector
from llm.provider_detection.detectors.ollama_detector import OllamaDetector
from llm.provider_detection.detectors.lmstudio_detector import LMStudioDetector
from llm.provider_detection.detectors.xai_detector import XaiDetector
from llm.provider_detection.detectors.custom_http_detector import CustomHTTPDetector
from llm.provider_detection.detectors.openrouter_detector import OpenRouterDetector
from llm.provider_detection.detectors.transformers_local_detector import TransformersLocalDetector
from llm.provider_detection.detectors.atlas_server_detector import AtlasServerDetector


# ---------------------------------------------------------
# Detector Registry
# ---------------------------------------------------------

DETECTOR_REGISTRY = {
    PROVIDER_OPENAI: OpenAIDetector,
    PROVIDER_ANTHROPIC: AnthropicDetector,
    PROVIDER_GROQ: GroqDetector,
    PROVIDER_GEMINI: GeminiDetector,
    PROVIDER_MISTRAL: MistralDetector,
    PROVIDER_FIREWORKS: FireworksDetector,
    PROVIDER_TOGETHER: TogetherDetector,
    PROVIDER_DEEPSEEK: DeepSeekDetector,
    PROVIDER_PERPLEXITY: PerplexityDetector,
    PROVIDER_COHERE: CohereDetector,
    PROVIDER_AI21: AI21Detector,
    PROVIDER_AZURE_OPENAI: AzureOpenAIDetector,
    PROVIDER_BEDROCK: BedrockDetector,
    PROVIDER_HUGGINGFACE: HuggingFaceDetector,
    PROVIDER_HF_TGI: HFTGIDetector,
    PROVIDER_OLLAMA: OllamaDetector,
    PROVIDER_LMSTUDIO: LMStudioDetector,
    PROVIDER_XAI: XaiDetector,
    PROVIDER_CUSTOM_HTTP: CustomHTTPDetector,
    PROVIDER_OPENROUTER: OpenRouterDetector,
    PROVIDER_TRANSFORMERS_LOCAL: TransformersLocalDetector,
    PROVIDER_ATLAS_SERVER: AtlasServerDetector,
}


# ---------------------------------------------------------
# Orchestrator
# ---------------------------------------------------------

def detect_provider(provider_id: str, config: Dict[str, Any]) -> ProviderDetectionResult:
    """
    Detects a single provider using the config supplied by the user.
    This is the function used during onboarding and LLM settings.
    """

    detector_cls = DETECTOR_REGISTRY.get(provider_id)

    if not detector_cls:
        return ProviderDetectionResult(
            available=False,
            error=f"No detector registered for provider '{provider_id}'."
        )

    # Instantiate detector with the config
    try:
        detector = detector_cls(**config)
    except TypeError:
        # Some detectors only take api_key, some take base_url, etc.
        # If config doesn't match, return a clean error.
        return ProviderDetectionResult(
            available=False,
            error=f"Invalid configuration for provider '{provider_id}'."
        )

    # Run detection
    return detector.detect()


def detect_all(config_map: Dict[str, Dict[str, Any]]) -> Dict[str, ProviderDetectionResult]:
    """
    Detects all providers that have configuration entries.
    This is used for:
    - LLM Settings "Refresh All"
    - System diagnostics
    - Admin tools
    """

    results = {}

    for provider_id, provider_config in config_map.items():
        if provider_id not in DETECTOR_REGISTRY:
            continue

        result = detect_provider(provider_id, provider_config)
        results[provider_id] = result

    return results
