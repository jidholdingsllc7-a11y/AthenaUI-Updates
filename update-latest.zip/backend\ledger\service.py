# AthenaUI -- Marketing activity ledger service
# File: backend/ledger/service.py
#
# Records a signed, auditable trail of marketing activity (every published
# post, plus manual-paste posts to platforms without API access) and pushes
# each record to an external compliance ledger (currently: SCDO, see
# ledger/providers/scdo.py) once configured. Local signing + storage work
# today regardless of whether an external ledger is wired up yet.

from __future__ import annotations

import asyncio
import logging
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from ledger.db import ledger_db
from ledger.providers.scdo import SCDOProvider
from ledger.signing import sign_payload

logger = logging.getLogger(__name__)

# Tools whose execution is recorded to the ledger. "social_media_post_x"
# publishes immediately; "social_media_draft_manual_post" only creates a
# pending draft -- it becomes "published" once a human confirms it via
# confirm_manual_post() after actually pasting it to the target site.
LEDGER_TRACKED_TOOLS = {
    "social_media_post_x": "x",
    "social_media_draft_manual_post": None,  # platform comes from the tool's own args
}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _extract_external_ref(tool_name: str, result: Any) -> Optional[str]:
    try:
        if tool_name == "social_media_post_x":
            return ((result or {}).get("result") or {}).get("data", {}).get("id")
    except Exception:
        pass
    return None


def _push_to_scdo(username: str, record: Dict[str, Any]) -> None:
    try:
        push_result = SCDOProvider(username).push(record)
        ledger_db.update(record["record_id"], scdo_push_status=push_result.get("status"), scdo_response=push_result)
    except Exception:
        logger.exception("Ledger: SCDO push failed for record %s", record.get("record_id"))
        try:
            ledger_db.update(record["record_id"], scdo_push_status="push_failed")
        except Exception:
            pass


async def record_tool_execution(
    username: str,
    character: Optional[str],
    tool_name: str,
    args: Dict[str, Any],
    result: Any,
) -> None:
    """Best-effort hook called by ToolExecutor right after a ledger-tracked
    tool succeeds. Never raises -- a ledger failure must never break the
    underlying tool call."""
    try:
        if tool_name not in LEDGER_TRACKED_TOOLS:
            return

        is_manual_draft = tool_name == "social_media_draft_manual_post"
        platform = args.get("platform") if is_manual_draft else LEDGER_TRACKED_TOOLS[tool_name]
        content = args.get("content", "")
        record_id = str(uuid.uuid4())
        created_at = _now()
        status = "manual_pending_proof" if is_manual_draft else "published"

        signature = sign_payload({
            "record_id": record_id,
            "username": username,
            "character": character,
            "tool_name": tool_name,
            "platform": platform,
            "content": content,
            "status": status,
            "created_at": created_at,
        })

        record = {
            "record_id": record_id,
            "username": username,
            "character": character,
            "tool_name": tool_name,
            "platform": platform,
            "record_type": "manual_post" if is_manual_draft else "post",
            "status": status,
            "content": content,
            "external_ref": _extract_external_ref(tool_name, result),
            "signature": signature,
            "created_at": created_at,
            "published_at": None if is_manual_draft else created_at,
        }
        ledger_db.insert(record)

        if not is_manual_draft:
            await asyncio.to_thread(_push_to_scdo, username, record)
    except Exception:
        logger.exception("Ledger: failed to record tool execution for %s", tool_name)


def list_records(username: str, *, status: Optional[str] = None, limit: int = 200) -> List[Dict[str, Any]]:
    return ledger_db.list_for_user(username, status=status, limit=limit)


def confirm_manual_post(
    username: str, record_id: str, proof_url: str, screenshot_path: Optional[str] = None
) -> Dict[str, Any]:
    """Human-only confirmation step: the user pastes back the live post's URL
    (and optionally a screenshot) after actually posting it manually. Only
    then is the record signed as published and pushed to the external ledger."""
    record = ledger_db.get(record_id)
    if not record or record["username"] != username:
        raise ValueError("Ledger record not found.")
    if record["status"] != "manual_pending_proof":
        raise ValueError(f"Record is not awaiting manual-post confirmation (status: {record['status']}).")

    published_at = _now()
    signature = sign_payload({
        "record_id": record_id,
        "username": username,
        "character": record.get("character"),
        "tool_name": record.get("tool_name"),
        "platform": record.get("platform"),
        "content": record.get("content"),
        "status": "published",
        "proof_url": proof_url,
        "created_at": record["created_at"],
        "published_at": published_at,
    })

    ledger_db.update(
        record_id,
        status="published",
        proof_url=proof_url,
        proof_screenshot_path=screenshot_path,
        signature=signature,
        published_at=published_at,
    )
    updated = ledger_db.get(record_id)
    _push_to_scdo(username, updated)
    return ledger_db.get(record_id)
