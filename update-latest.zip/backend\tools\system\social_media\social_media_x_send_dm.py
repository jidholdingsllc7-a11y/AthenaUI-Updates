# AthenaUI -- Social Media X (Twitter) Send DM Tool
# File: backend/tools/system/social_media/social_media_x_send_dm.py
#
# Sends a Direct Message to a specific X user on the user's configured X
# account. Privately delivered but still an irreversible outbound message
# to a real person, so this is flagged dangerous/requires_approval -- the
# executor's approval gate will surface an Allow/Deny prompt before this
# ever actually runs. Per X's automation rules, only use this for an
# account that has already messaged or mentioned this account first (see
# social_media_x_check_dms / social_media_x_check_mentions).

from typing import Any, Dict

capabilities = {
    "needs_bridge": False,
    "needs_filesystem": False,
    "needs_network": True,
    "needs_user": True,
    "is_dangerous": True,
    "requires_approval": True,
}


async def run(args: Dict[str, Any]):
    username = args.get("username")
    participant_id = (args.get("participant_id") or "").strip()
    content = (args.get("content") or "").strip()
    if not participant_id:
        return {"error": "Missing 'participant_id' argument (the recipient's X user id)."}
    if not content:
        return {"error": "Missing 'content' argument."}

    from social_media import settings as social_media_settings
    from social_media.x_client import XClient, XError

    creds = social_media_settings.get_x_credentials(username)
    if not creds:
        return {"error": "No X credentials configured. Ask the user to add them in Social Media settings."}

    client = XClient(**creds)
    try:
        result = await client.send_dm(participant_id, content)
    except XError as e:
        return {"error": str(e)}

    return {"ok": True, "result": result}
