# AthenaUI v3.5 — marketing_tip_add Tool
# File: backend/tools/marketing/marketing_tip_add.py
#
# STEP 2 tool for marketing work -- saves a newly-discovered marketing
# trick (how to use a tool well, a customer-handling approach that worked,
# etc.) to the shared library so any character/agent benefits later.

from typing import Any, Dict

from marketing_tips.service import MarketingTipsError, add_tip

capabilities = {
    "needs_filesystem": True,
    "needs_bridge": False,
    "needs_network": False,
    "needs_user": True,
}


async def run(args: Dict[str, Any]) -> str:
    try:
        username = args.get("username")
        character = args.get("character")
        title = args.get("title")
        tip = args.get("tip")

        if not username:
            return "[ERROR] Missing 'username' argument."
        if not title:
            return "[ERROR] Missing 'title' argument."
        if not tip:
            return "[ERROR] Missing 'tip' argument."

        result = add_tip(
            username,
            title=title,
            tip=tip,
            tags=args.get("tags"),
            tool_name=args.get("tool_name"),
            character=character,
        )
        return f"Tip added to the marketing library: '{result['title']}' (id={result['id']})."
    except MarketingTipsError as e:
        return f"[ERROR] {e}"
    except Exception as e:
        return f"[ERROR] Failed to add marketing tip: {str(e)}"
