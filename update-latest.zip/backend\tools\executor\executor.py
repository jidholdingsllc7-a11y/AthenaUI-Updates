﻿# AthenaUI v3.5 — Tool Executor
# File: backend/tools/executor/executor.py
# Created: 2026-04-12 16:30 CDT
# Updated: 2026-07-27 19:49 CDT

from __future__ import annotations

from typing import Any, Dict, Optional
import inspect

from tools.registry.registry import ToolRegistry

try:
    import jsonschema
except ImportError:
    jsonschema = None


class ToolExecutor:
    """
    Central executor for all tools in AthenaUI v3.1.

    Responsibilities:
    - Look up tools in the global ToolRegistry
    - Validate arguments against JSON schema
    - Enforce capability flags (bridge, filesystem, network, user)
    - Inject username/context into tools
    - Execute the underlying implementation (async or sync)
    """

    def __init__(self, registry: ToolRegistry) -> None:
        self._registry = registry

    # ---------------------------------------------------------
    # Public API
    # ---------------------------------------------------------

    async def execute(self, name: str, args: Dict[str, Any], _map_preapproved: bool = False) -> Any:
        """
        Execute a tool by name with the given arguments.

        Expected:
            name: str
            args: dict (must include "username")
            _map_preapproved: internal-only flag set by changeset_service when
                actually running a tool call the user just clicked "Allow" on.
                Skips the general approval-gate (step 2 below) but NEVER skips
                the MAP hard-block checks (step 2a) -- those are never
                bypassable by prior approval.

        Returns:
            Tool result (any JSON-serializable structure)
        """
        tool = self._registry.get(name)
        schema = tool["schema"]
        implementation = tool["implementation"]
        capabilities = tool.get("capabilities", {})

        # Extract username (required for Google/Calendar tools)
        username = args.get("username")
        if not username:
            raise ValueError(f"Tool '{name}' requires a 'username' argument.")

        # 1) Validate arguments
        self._validate_args(name, args, schema)

        # 2) Enforce capability flags + MAP safety checks + approval gate
        await self._enforce_capabilities(name, args, capabilities, skip_approval_gate=_map_preapproved)

        # 3) Execute implementation
        # Compatibility: support both legacy run(args) and newer run(args, username=...).
        call_kwargs: Dict[str, Any] = {}
        try:
            sig = inspect.signature(implementation)
            if "username" in sig.parameters:
                call_kwargs["username"] = username
        except Exception:
            # If signature inspection fails, attempt without kwargs first.
            call_kwargs = {}

        if inspect.iscoroutinefunction(implementation):
            try:
                result = await implementation(args, **call_kwargs)
            except Exception as e:
                self._log_agent_action(name, args, ok=False, error=str(e))
                raise
        else:
            try:
                result = implementation(args, **call_kwargs)
                if inspect.isawaitable(result):
                    result = await result
            except Exception as e:
                self._log_agent_action(name, args, ok=False, error=str(e))
                raise

        self._log_agent_action(name, args, ok=True)

        try:
            from ledger.service import record_tool_execution, LEDGER_TRACKED_TOOLS

            if name in LEDGER_TRACKED_TOOLS:
                await record_tool_execution(username, args.get("character"), name, args, result)
        except Exception:
            pass  # ledger recording must never break a tool call

        return result

    def list_tools(self) -> Dict[str, Dict[str, Any]]:
        """
        Return a mapping of tool name → metadata (schema, capabilities, version).
        Useful for debugging, introspection, or frontend Build Map UI.
        """
        tools = {}
        for tool in self._registry.list():
            tools[tool["name"]] = {
                "schema": tool["schema"],
                "capabilities": tool["capabilities"],
                "version": tool["version"],
            }
        return tools

    # ---------------------------------------------------------
    # Internal helpers
    # ---------------------------------------------------------

    def _log_agent_action(self, name: str, args: Dict[str, Any], *, ok: bool, error: Optional[str] = None) -> None:
        """
        Records this tool call to the Live Tail log (Settings > Tail Log),
        so the user can see what an agent actually DID -- not chat text.
        Best-effort: a logging failure should never break a tool call.
        """
        try:
            from logs_system.system.service import system_logger
            from safety.task_context import get_current_task_id

            character = args.get("character")
            safe_args = {
                k: (v if not isinstance(v, str) or len(v) <= 200 else v[:200] + "…")
                for k, v in args.items()
                if k not in ("username", "character")
            }
            system_logger.log(
                event=f"Agent action: {name}" + (f" (failed: {error})" if not ok else ""),
                level="info" if ok else "error",
                agent_state=character,
                details={"tool": name, "args": safe_args, "success": ok},
                task_id=get_current_task_id(),
            )
        except Exception:
            pass

    def _validate_args(self, name: str, args: Dict[str, Any], schema: Dict[str, Any]) -> None:
        """
        Validate arguments against the tool's JSON schema.
        If jsonschema is not installed, validation is skipped.

        NOTE:
        Your schemas use "input_schema", not "parameters".
        """
        if jsonschema is None:
            return

        input_schema: Optional[Dict[str, Any]] = schema.get("input_schema")
        if not input_schema:
            return

        try:
            jsonschema.validate(instance=args, schema=input_schema)
        except jsonschema.ValidationError as e:
            raise ValueError(f"Invalid arguments for tool '{name}': {e.message}") from e

    async def _enforce_capabilities(
        self,
        name: str,
        args: Dict[str, Any],
        capabilities: Dict[str, Any],
        skip_approval_gate: bool = False,
    ) -> None:
        """
        Real MAP + approval-gate enforcement (Mutual Assurance Protocol).

        Step 2a (MAP hard-blocks): ALWAYS enforced, never skippable, even for
        a call that already passed the user-approval gate. Covers: wiping an
        internal drive (never allowed), formatting a USB drive (allowed only
        with a fresh user-password-confirmed override token), copying data to
        a remote device not attached to this machine (never allowed), and
        moving money out of an account by tool name (never allowed).

        Step 2b (general approval gate): if the tool is flagged
        `is_dangerous`/`requires_approval` and the user hasn't pre-approved
        this whole category of action, create a pending approval (surfaced
        via the existing Allow/Deny sidebar UI) and raise instead of running.
        """
        from safety.map.guard import (
            check_terminal_command,
            check_tool_name_for_money_transfer,
        )
        from safety import approvals
        from safety.task_context import get_current_task_id

        username = args.get("username", "")

        # 2a) MAP hard-block checks -- unconditional.
        check_tool_name_for_money_transfer(name)
        if name == "terminal_run":
            check_terminal_command(
                args.get("command", ""), username, args.get("map_override_token")
            )

        if skip_approval_gate:
            return

        # 2b) General approval gate.
        if capabilities.get("is_dangerous") or capabilities.get("requires_approval"):
            category = approvals.category_for_tool(name, capabilities)
            task_id = get_current_task_id()

            # Task-scoped grant (set once at Task Builder creation time) takes
            # priority so a long-running unattended task doesn't stall -- but
            # only while that specific task is executing.
            if task_id and approvals.is_task_category_approved(task_id, category):
                return

            if approvals.is_category_preapproved(username, category):
                return

            if approvals.is_category_session_approved(username, category):
                return

            from code_suite.changes.service import changeset_service

            safe_args = {k: v for k, v in args.items() if k != "username"}
            change = changeset_service.create_tool_approval(
                username=username,
                tool_name=name,
                arguments=safe_args,
                reason=f"Agent wants to run '{name}'.",
                task_id=task_id,
                character=args.get("character"),
            )
            raise approvals.ApprovalRequiredError(
                f"This action requires your approval. A prompt has been added "
                f"to the sidebar -- Allow or Deny it there (request id {change.id}).",
                change_id=change.id,
            )

