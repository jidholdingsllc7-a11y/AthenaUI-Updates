# AthenaUI v3.7 — Agent-Initiated Collab Discussion Tool
# File: backend/tools/collab/collab_start_discussion.py
#
# Lets a character spontaneously loop another character (or several) into a
# Collab Group Chat discussion mid-conversation -- e.g. a support agent
# relaying a customer question to a specialist -- instead of Collab only
# ever being triggered by the shared-inbox email monitor
# (chat/collab/orchestrator.py). Reuses that exact same persistent-thread
# engine, so the same set of agents always continues one ongoing thread.
#
# Rate-limited "slow mode" (chat/collab/rate_limit.py): each character gets
# a handful of discussion-starts per rolling window; going over requires
# the user's Allow/Deny approval in the sidebar (collab_rate_limit_grant.py
# is what actually executes once they click Allow).

from typing import Any, Dict

from chat.collab import rate_limit

capabilities = {
    "needs_filesystem": False,
    "needs_bridge": False,
    "needs_network": True,
    "needs_user": True,
}


async def run(args: Dict[str, Any]) -> str:
    from safety import approvals
    from code_suite.changes.service import changeset_service
    from chat.collab.orchestrator import run_collab_discussion

    username = args.get("username")
    character = args.get("character")
    participants = args.get("participants") or []
    topic = (args.get("topic") or "").strip()
    turn_cap = args.get("turn_cap") or 3

    if not username:
        return "[ERROR] Missing 'username' argument."
    if not character:
        return "[ERROR] No active character -- starting a Collab discussion requires an agent identity."
    if not isinstance(participants, list) or not participants:
        return "[ERROR] 'participants' must be a non-empty list of other character names to loop in."
    if not topic:
        return "[ERROR] Missing 'topic' -- describe what you want to discuss."

    others = [
        str(p).strip() for p in participants
        if str(p).strip() and str(p).strip().lower() != character.strip().lower()
    ]
    if not others:
        return "[ERROR] 'participants' must name at least one OTHER character besides yourself."

    # System agents (Orion_Lumos, Sol_Lumos, etc.) are keyed internally with
    # underscores, but a character referring to one in conversation naturally
    # writes the spaced display name (e.g. "Orion Lumos") -- resolve against
    # a space/underscore/case-insensitive index instead of an exact match so
    # that difference doesn't surface as a false "Unknown character" error.
    from characters.system.list import list_all_characters

    all_names = list(list_all_characters(username).keys())
    by_normalized = {n.replace("_", " ").strip().lower(): n for n in all_names}

    resolved = []
    missing = []
    for name in others:
        canonical = by_normalized.get(name.replace("_", " ").strip().lower())
        if canonical:
            resolved.append(canonical)
        else:
            missing.append(name)
    if missing:
        return f"[ERROR] Unknown character(s): {', '.join(missing)}."
    others = resolved

    try:
        turn_cap = max(1, min(int(turn_cap), 6))
    except (TypeError, ValueError):
        turn_cap = 3

    if not rate_limit.try_consume(username, character):
        hours = rate_limit.WINDOW_SECONDS // 3600
        change = changeset_service.create_tool_approval(
            username=username,
            tool_name="collab_rate_limit_grant",
            arguments={"character": character},
            reason=(
                f"{character} has reached their Collab discussion limit (slow mode: "
                f"{rate_limit.BASE_LIMIT} per {hours}h) and wants to start another one with "
                f"{', '.join(others)}. Approving grants {rate_limit.GRANT_SIZE} more."
            ),
            character=character,
        )
        raise approvals.ApprovalRequiredError(
            "You've reached your Collab discussion limit for now -- a request for "
            f"{rate_limit.GRANT_SIZE} more has been added to the sidebar for the user to Allow or "
            f"Deny (request id {change.id}).",
            change_id=change.id,
        )

    result = await run_collab_discussion(
        username,
        participants=[character, *others],
        context=topic,
        turn_cap=turn_cap,
        origin="agent",
    )

    if not result.get("turns"):
        return (
            f"Started a Collab discussion with {', '.join(others)}, but no replies came back yet "
            f"(session {result['session_id']})."
        )

    transcript = "\n".join(f"{t['sender']}: {t['message']}" for t in result["turns"])
    concluded_note = ""
    if result.get("concluded"):
        concluded_note = f"\n\n(Discussion concluded: {result.get('concluded_reason') or 'reached a natural end.'})"
    return (
        f"Collab discussion with {', '.join(others)} (session {result['session_id']}):\n{transcript}"
        f"{concluded_note}"
    )
