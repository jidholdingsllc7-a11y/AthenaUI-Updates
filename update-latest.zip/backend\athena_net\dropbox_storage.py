# AthenaUI — Athena Net: Dropbox storage backend
# File: backend/athena_net/dropbox_storage.py
# Created: 2026-11-02
#
# Implements StorageBackend against a user's connected Dropbox account
# (see dropbox_service.py for the OAuth2 connect flow). All paths passed in
# are relative to a configurable shared-folder root (default "/AthenaNet"),
# so a team's actual Team Folder name never needs to appear in application
# code -- it's just whatever root path the user configures in Settings.

from __future__ import annotations

import json
from typing import Any, Dict, List

import requests

from athena_net.dropbox_service import DropboxService, DropboxServiceError
from athena_net.storage_backend import StorageBackend, StorageBackendError

LIST_FOLDER_URL = "https://api.dropboxapi.com/2/files/list_folder"
DOWNLOAD_URL = "https://content.dropboxapi.com/2/files/download"
UPLOAD_URL = "https://content.dropboxapi.com/2/files/upload"
DELETE_URL = "https://api.dropboxapi.com/2/files/delete_v2"


class DropboxStorageBackend(StorageBackend):
    def __init__(self, username: str, root_path: str = "/AthenaNet", namespace_id: str | None = None):
        self.username = username
        self.root_path = "/" + root_path.strip("/")
        # Dropbox Business accounts: without this, file ops target the
        # member's personal "home" namespace, NOT the shared "team space"
        # namespace that contains Team Folders -- see dropbox_service.py's
        # root_info detection for where this id comes from.
        self.namespace_id = namespace_id

    def _full_path(self, path: str) -> str:
        relative = path.strip("/")
        return self.root_path if not relative else f"{self.root_path}/{relative}"

    def _headers(self) -> Dict[str, str]:
        try:
            access_token = DropboxService.get_access_token(self.username)
        except DropboxServiceError as e:
            raise StorageBackendError(str(e))
        headers = {"Authorization": f"Bearer {access_token}"}
        if self.namespace_id:
            headers["Dropbox-API-Path-Root"] = json.dumps({".tag": "root", "root": self.namespace_id})
        return headers


    def list(self, path: str = "") -> List[Dict[str, Any]]:
        full_path = self._full_path(path)
        resp = requests.post(
            LIST_FOLDER_URL,
            headers={**self._headers(), "Content-Type": "application/json"},
            data=json.dumps({"path": "" if full_path == "/" else full_path}),
            timeout=20,
        )
        if resp.status_code == 409:
            # Folder doesn't exist yet (e.g. first use) -- treat as empty.
            return []
        if resp.status_code != 200:
            raise StorageBackendError(f"Dropbox list failed: {resp.text[:500]}")

        entries = resp.json().get("entries", [])
        results = []
        for e in entries:
            display_path = e.get("path_display") or ""
            prefix = self.root_path + "/"
            relative = display_path[len(prefix):] if display_path.startswith(prefix) else display_path.lstrip("/")
            results.append(
                {
                    "name": e.get("name"),
                    "path": relative,
                    "is_folder": e.get(".tag") == "folder",
                    "size": e.get("size"),
                }
            )
        return results

    def read(self, path: str) -> bytes:
        full_path = self._full_path(path)
        resp = requests.post(
            DOWNLOAD_URL,
            headers={**self._headers(), "Dropbox-API-Arg": json.dumps({"path": full_path})},
            timeout=30,
        )
        if resp.status_code != 200:
            raise StorageBackendError(f"Dropbox read failed: {resp.text[:500]}")
        return resp.content

    def write(self, path: str, data: bytes) -> None:
        full_path = self._full_path(path)
        resp = requests.post(
            UPLOAD_URL,
            headers={
                **self._headers(),
                "Dropbox-API-Arg": json.dumps(
                    {"path": full_path, "mode": "overwrite", "autorename": False, "mute": True}
                ),
                "Content-Type": "application/octet-stream",
            },
            data=data,
            timeout=30,
        )
        if resp.status_code != 200:
            raise StorageBackendError(f"Dropbox write failed: {resp.text[:500]}")

    def delete(self, path: str) -> None:
        full_path = self._full_path(path)
        resp = requests.post(
            DELETE_URL,
            headers={**self._headers(), "Content-Type": "application/json"},
            data=json.dumps({"path": full_path}),
            timeout=20,
        )
        if resp.status_code != 200:
            raise StorageBackendError(f"Dropbox delete failed: {resp.text[:500]}")

    @classmethod
    def for_user(cls, username: str, root_path: str | None = None) -> "DropboxStorageBackend":
        """Builds a backend for `username`'s connected Dropbox account,
        raising StorageBackendError if Dropbox isn't connected yet. Used by
        both the HTTP routes and the agent-facing tools so the connect
        check + namespace lookup only lives in one place."""
        status = DropboxService.get_status(username)
        if not status["connected"]:
            raise StorageBackendError("Dropbox is not connected yet. Connect it in Settings > Athena Net Settings first.")
        namespace_id = DropboxService.get_root_namespace_id(username)
        return cls(
            username,
            root_path=root_path if root_path is not None else status["shared_folder_path"],
            namespace_id=namespace_id,
        )
