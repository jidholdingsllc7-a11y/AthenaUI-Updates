# AthenaUI v3.5 — CRM Service
# File: backend/crm/service.py
#
# A small, purpose-built CRM for agents (e.g. Meera) and their human to track
# customers/leads and the marketing activity performed on them, plus a
# lightweight analytics summary used by the live dashboard.
#
# Storage: one dedicated SQLite file per human user (NOT per-agent, so every
# agent and the human see the same shared pipeline):
#   {DATA_DIR}/users/{username}/crm/crm.sqlite

from __future__ import annotations

import sqlite3
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from core.runtime.runtime import get_runtime

STAGES = ["lead", "contacted", "qualified", "proposal", "won", "lost"]


class CrmError(Exception):
    pass


def _root_dir(username: str) -> Path:
    runtime = get_runtime()
    root = runtime.env.DATA_DIR / "users" / username / "crm"
    root.mkdir(parents=True, exist_ok=True)
    return root


def _db_path(username: str) -> Path:
    return _root_dir(username) / "crm.sqlite"


_CUSTOMER_MIGRATION_COLUMNS = {
    "preferred_contact_method": "TEXT",
    "platform_first_contact": "TEXT",
    "newsletter_opt_in": "INTEGER NOT NULL DEFAULT 0",
    "newsletter_opt_in_at": "TEXT",
}


def _migrate_customers_table(conn: sqlite3.Connection) -> None:
    existing = {row["name"] for row in conn.execute("PRAGMA table_info(customers)")}
    for column, decl in _CUSTOMER_MIGRATION_COLUMNS.items():
        if column not in existing:
            conn.execute("ALTER TABLE customers ADD COLUMN " + column + " " + decl)


def _connect(username: str) -> sqlite3.Connection:
    conn = sqlite3.connect(_db_path(username))
    conn.row_factory = sqlite3.Row
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS customers (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            company TEXT,
            email TEXT,
            phone TEXT,
            stage TEXT NOT NULL DEFAULT 'lead',
            value REAL NOT NULL DEFAULT 0,
            source TEXT,
            owner_character TEXT,
            notes TEXT,
            preferred_contact_method TEXT,
            platform_first_contact TEXT,
            newsletter_opt_in INTEGER NOT NULL DEFAULT 0,
            newsletter_opt_in_at TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
        """
    )
    _migrate_customers_table(conn)
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS activities (
            id TEXT PRIMARY KEY,
            customer_id TEXT NOT NULL,
            character TEXT,
            activity_type TEXT NOT NULL,
            description TEXT,
            created_at TEXT NOT NULL
        )
        """
    )
    return conn


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _row_to_customer(row: sqlite3.Row) -> Dict[str, Any]:
    return dict(row)


def create_customer(
    username: str,
    name: str,
    company: Optional[str] = None,
    email: Optional[str] = None,
    phone: Optional[str] = None,
    stage: str = "lead",
    value: float = 0.0,
    source: Optional[str] = None,
    owner_character: Optional[str] = None,
    notes: Optional[str] = None,
    preferred_contact_method: Optional[str] = None,
    platform_first_contact: Optional[str] = None,
) -> Dict[str, Any]:
    if not name or not name.strip():
        raise CrmError("'name' is required.")
    stage = (stage or "lead").lower()
    if stage not in STAGES:
        raise CrmError(f"Invalid stage '{stage}'. Must be one of: {', '.join(STAGES)}.")

    customer_id = uuid.uuid4().hex[:12]
    now = _now()
    with _connect(username) as conn:
        conn.execute(
            """
            INSERT INTO customers
                (id, name, company, email, phone, stage, value, source, owner_character, notes,
                 preferred_contact_method, platform_first_contact, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (customer_id, name.strip(), company, email, phone, stage, float(value or 0),
             source, owner_character, notes, preferred_contact_method, platform_first_contact, now, now),
        )
        row = conn.execute("SELECT * FROM customers WHERE id = ?", (customer_id,)).fetchone()
    return _row_to_customer(row)


def update_customer(username: str, customer_id: str, **fields: Any) -> Dict[str, Any]:
    allowed = {
        "name", "company", "email", "phone", "stage", "value", "source", "owner_character", "notes",
        "preferred_contact_method", "platform_first_contact", "newsletter_opt_in", "newsletter_opt_in_at",
    }
    updates = {k: v for k, v in fields.items() if k in allowed and v is not None}
    if "stage" in updates and updates["stage"].lower() not in STAGES:
        raise CrmError(f"Invalid stage '{updates['stage']}'. Must be one of: {', '.join(STAGES)}.")
    if "stage" in updates:
        updates["stage"] = updates["stage"].lower()

    with _connect(username) as conn:
        existing = conn.execute("SELECT * FROM customers WHERE id = ?", (customer_id,)).fetchone()
        if not existing:
            raise CrmError(f"No customer found with id '{customer_id}'.")
        if updates:
            updates["updated_at"] = _now()
            set_clause = ", ".join(f"{k} = ?" for k in updates)
            conn.execute(
                f"UPDATE customers SET {set_clause} WHERE id = ?",
                (*updates.values(), customer_id),
            )
        row = conn.execute("SELECT * FROM customers WHERE id = ?", (customer_id,)).fetchone()
    return _row_to_customer(row)


def delete_customer(username: str, customer_id: str) -> None:
    with _connect(username) as conn:
        existing = conn.execute("SELECT id FROM customers WHERE id = ?", (customer_id,)).fetchone()
        if not existing:
            raise CrmError(f"No customer found with id '{customer_id}'.")
        conn.execute("DELETE FROM customers WHERE id = ?", (customer_id,))
        conn.execute("DELETE FROM activities WHERE customer_id = ?", (customer_id,))


def get_customer(username: str, customer_id: str) -> Dict[str, Any]:
    with _connect(username) as conn:
        row = conn.execute("SELECT * FROM customers WHERE id = ?", (customer_id,)).fetchone()
    if not row:
        raise CrmError(f"No customer found with id '{customer_id}'.")
    return _row_to_customer(row)


def list_customers(username: str, stage: Optional[str] = None) -> List[Dict[str, Any]]:
    with _connect(username) as conn:
        if stage:
            rows = conn.execute(
                "SELECT * FROM customers WHERE stage = ? ORDER BY updated_at DESC", (stage.lower(),)
            ).fetchall()
        else:
            rows = conn.execute("SELECT * FROM customers ORDER BY updated_at DESC").fetchall()
    return [_row_to_customer(r) for r in rows]


def log_activity(
    username: str,
    customer_id: str,
    character: Optional[str],
    activity_type: str,
    description: str,
) -> Dict[str, Any]:
    if not activity_type or not activity_type.strip():
        raise CrmError("'activity_type' is required.")

    activity_id = uuid.uuid4().hex[:12]
    now = _now()
    with _connect(username) as conn:
        existing = conn.execute("SELECT id FROM customers WHERE id = ?", (customer_id,)).fetchone()
        if not existing:
            raise CrmError(f"No customer found with id '{customer_id}'.")
        conn.execute(
            """
            INSERT INTO activities (id, customer_id, character, activity_type, description, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (activity_id, customer_id, character, activity_type.strip(), description, now),
        )
        conn.execute("UPDATE customers SET updated_at = ? WHERE id = ?", (now, customer_id))
        row = conn.execute("SELECT * FROM activities WHERE id = ?", (activity_id,)).fetchone()
    return dict(row)


def list_activities(username: str, customer_id: Optional[str] = None, limit: int = 50) -> List[Dict[str, Any]]:
    with _connect(username) as conn:
        if customer_id:
            rows = conn.execute(
                "SELECT * FROM activities WHERE customer_id = ? ORDER BY created_at DESC LIMIT ?",
                (customer_id, limit),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM activities ORDER BY created_at DESC LIMIT ?", (limit,)
            ).fetchall()
    return [dict(r) for r in rows]


def get_analytics(username: str) -> Dict[str, Any]:
    with _connect(username) as conn:
        total = conn.execute("SELECT COUNT(*) AS n FROM customers").fetchone()["n"]

        by_stage: Dict[str, int] = {s: 0 for s in STAGES}
        value_by_stage: Dict[str, float] = {s: 0.0 for s in STAGES}
        for row in conn.execute("SELECT stage, value FROM customers"):
            stage = row["stage"] if row["stage"] in STAGES else "lead"
            by_stage[stage] += 1
            value_by_stage[stage] += float(row["value"] or 0)

        open_value = sum(v for s, v in value_by_stage.items() if s not in ("won", "lost"))
        won_value = value_by_stage.get("won", 0.0)

        week_ago = (datetime.now(timezone.utc) - timedelta(days=7)).isoformat()
        activities_last_7_days = conn.execute(
            "SELECT COUNT(*) AS n FROM activities WHERE created_at >= ?", (week_ago,)
        ).fetchone()["n"]

        recent = conn.execute(
            """
            SELECT a.id, a.activity_type, a.description, a.character, a.created_at,
                   c.name AS customer_name, c.id AS customer_id
            FROM activities a
            JOIN customers c ON c.id = a.customer_id
            ORDER BY a.created_at DESC
            LIMIT 10
            """
        ).fetchall()

    return {
        "total_customers": total,
        "by_stage": by_stage,
        "value_by_stage": value_by_stage,
        "open_pipeline_value": round(open_value, 2),
        "won_value": round(won_value, 2),
        "activities_last_7_days": activities_last_7_days,
        "recent_activities": [dict(r) for r in recent],
        "generated_at": _now(),
    }
