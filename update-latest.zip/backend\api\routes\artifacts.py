# AthenaUI v3.5 — Artifacts API Routes
# File: backend/api/routes/artifacts.py
# Serves saved chat artifact HTML back to the frontend by id, scoped to the
# requesting user (artifacts are stored per-user, so this can never leak
# another user's artifact).

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException

from api.deps.auth_middleware import get_current_user
from artifacts.service import get_artifact

router = APIRouter(prefix="/artifacts", tags=["artifacts"])


def _username_from_user(user: Any) -> str:
    username = user.get("username") if isinstance(user, dict) else getattr(user, "username", None)
    if not username:
        raise HTTPException(status_code=401, detail="Authentication required.")
    return str(username)


@router.get("/{artifact_id}")
async def get_artifact_route(artifact_id: str, user: Any = Depends(get_current_user)):
    username = _username_from_user(user)
    artifact = get_artifact(username, artifact_id)
    if not artifact:
        raise HTTPException(status_code=404, detail="Artifact not found.")
    return artifact
