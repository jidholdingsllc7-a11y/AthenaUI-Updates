# AthenaUI v3.5 — LLM call retry helper
# File: backend/llm/retry.py
#
# Bounded retry for transient 402/429 provider errors (e.g. OpenRouter's
# "in_flight_budget_exhausted" 402, or a plain rate-limit 429) -- these are
# capacity/budget hiccups, not real request failures, and the provider
# itself tells us how long to wait via the Retry-After header. Any other
# status code (400, 401, 500, etc.) is a real error and is re-raised
# immediately -- retrying those blindly would just waste time.
#
# NOT every 402 is transient though: OpenRouter also returns 402 for
# "openrouter_credits" (metadata.limit_source) when the account's actual
# balance can't cover the request's max_tokens -- that balance doesn't
# change between retries, so retrying it is guaranteed to fail every time.
# NON_TRANSIENT_LIMIT_SOURCES lets us fail fast for those instead of
# wasting up to MAX_ATTEMPTS * wait cycles on something that can never
# succeed without user action (add credits / lower max_tokens).
#
# Separately, a provider can return a 200 with a malformed/empty/keep-alive
# body (seen live: response.json() raising "Expecting value: line 3 column 1
# (char 11)") -- router .chat() implementations call response.json() right
# after raise_for_status(), so this raises json.JSONDecodeError, not
# requests.HTTPError, and previously slipped past this helper entirely with
# no retry. It's just as transient as a 429/402 (a fresh request almost
# always gets a clean body next time), so it gets the same bounded retry
# treatment below, just with a fixed backoff since there's no status code /
# Retry-After header to key off of.
#
# Separately still: some providers hard-cap how many tool schemas can be
# sent in a single request (seen live, a 400: "Invalid 'tools': array too
# long. Expected an array with maximum length 128, but got an array with
# length 138 instead."). The tool registry only grows over time, so this
# isn't a one-off -- it recurs on every single request to that provider
# once the full tool list crosses whatever cap it enforces, until a human
# notices. Rather than surface the raw rejection to the user every time,
# this is detected generically (regardless of which provider or what its
# exact cap is) and retried once with the tools list truncated to the
# provider's own stated max.

import asyncio
import json
import logging
import re
from typing import Any, Callable

import requests

logger = logging.getLogger(__name__)

RETRYABLE_STATUS_CODES = (402, 429)
NON_TRANSIENT_LIMIT_SOURCES = {"openrouter_credits"}
MAX_ATTEMPTS = 3
DEFAULT_WAIT_SECONDS = 15
MAX_WAIT_SECONDS = 120

_TOOLS_ARRAY_TOO_LONG_RE = re.compile(
    r"'tools'.*maximum length (\d+).*got an array with length (\d+)",
    re.IGNORECASE,
)


def _provider_error_message(response) -> str | None:
    """Best-effort extraction of a provider's error.message from an
    HTTPError's response, without letting a malformed/non-JSON body break
    the retry flow."""
    if response is None:
        return None
    try:
        body = response.json()
    except (ValueError, TypeError):
        return None
    return (body.get("error") or {}).get("message")


def _tools_array_max_from_error(response) -> int | None:
    """Returns the provider's stated max tools-array length from a 400's
    error message, or None if this isn't that kind of rejection."""
    match = _TOOLS_ARRAY_TOO_LONG_RE.search(_provider_error_message(response) or "")
    return int(match.group(1)) if match else None


def _limit_source(response) -> str | None:
    """Best-effort extraction of OpenRouter's error metadata.limit_source
    from an HTTPError's response, without letting a malformed/non-JSON body
    break the retry flow."""
    if response is None:
        return None
    try:
        body = response.json()
    except (ValueError, TypeError):
        return None
    return (body.get("error") or {}).get("metadata", {}).get("limit_source")


# Case-insensitive substrings seen across providers' real error messages for
# a genuine "you need to add funds / fix billing" rejection, as opposed to a
# transient rate limit -- providers are inconsistent about which HTTP status
# they use for this (OpenAI/Anthropic often use 429/400 for it, not just
# 402), so status code alone isn't a reliable signal.
_BILLING_ERROR_KEYWORDS = (
    "insufficient_quota", "insufficient quota", "billing", "payment required",
    "credit balance", "add funds", "exceeded your current quota",
    "quota exceeded", "insufficient credits", "insufficient balance",
)


def is_billing_error(exc: Exception) -> bool:
    """Best-effort, provider-agnostic detection of a 'this provider needs
    billing fixed/funds added' rejection -- used by the billing-fallback
    feature (scheduled tasks/inbox monitoring only, see
    ChatEngine.chat_with_billing_fallback) to decide whether to switch to
    the user's next configured backup provider. Matches a 402 status (the
    universal HTTP semantic for this) OR known billing-flavored wording in
    the provider's error message."""
    if not isinstance(exc, requests.HTTPError):
        return False
    response = getattr(exc, "response", None)
    if getattr(response, "status_code", None) == 402:
        return True
    message = (_provider_error_message(response) or "").lower()
    return any(keyword in message for keyword in _BILLING_ERROR_KEYWORDS)


async def call_with_retry(fn: Callable, *args: Any, **kwargs: Any) -> Any:
    """Runs the blocking `fn(*args, **kwargs)` in a thread, retrying up to
    MAX_ATTEMPTS total attempts if it raises requests.HTTPError with a
    402/429 status, or json.JSONDecodeError (a malformed/non-JSON response
    body on an otherwise-successful request). Waits for the provider's
    Retry-After header (clamped to [1, MAX_WAIT_SECONDS] seconds) before
    each 402/429 retry, or DEFAULT_WAIT_SECONDS otherwise/if missing/invalid.
    Any other status (or exhausting all attempts) re-raises the original
    exception unchanged. A 402 whose metadata.limit_source is in
    NON_TRANSIENT_LIMIT_SOURCES is re-raised immediately without retrying,
    since retrying it can never succeed. A 400 rejecting an oversized
    `tools` kwarg is retried exactly once with that list truncated to the
    provider's own stated max, regardless of status-code retryability."""
    attempt = 0
    tools_capped = False
    while True:
        attempt += 1
        try:
            return await asyncio.to_thread(fn, *args, **kwargs)
        except json.JSONDecodeError:
            if attempt >= MAX_ATTEMPTS:
                raise
            logger.warning(
                "Provider returned a malformed/non-JSON response body "
                "(attempt %d/%d) -- retrying in %.0fs",
                attempt, MAX_ATTEMPTS, DEFAULT_WAIT_SECONDS,
            )
            await asyncio.sleep(DEFAULT_WAIT_SECONDS)
        except requests.HTTPError as e:
            response = getattr(e, "response", None)
            status_code = getattr(response, "status_code", None)

            if status_code == 400 and not tools_capped and isinstance(kwargs.get("tools"), list):
                max_allowed = _tools_array_max_from_error(response)
                if max_allowed is not None and 0 < max_allowed < len(kwargs["tools"]):
                    logger.warning(
                        "Provider rejected %d tools (max %d allowed) -- "
                        "retrying once with the tools list truncated",
                        len(kwargs["tools"]), max_allowed,
                    )
                    kwargs = {**kwargs, "tools": kwargs["tools"][:max_allowed]}
                    tools_capped = True
                    continue

            if status_code not in RETRYABLE_STATUS_CODES or attempt >= MAX_ATTEMPTS:
                raise
            if _limit_source(response) in NON_TRANSIENT_LIMIT_SOURCES:
                logger.warning(
                    "Provider returned %s with non-transient limit_source -- not retrying",
                    status_code,
                )
                raise

            wait_seconds = DEFAULT_WAIT_SECONDS
            retry_after = response.headers.get("Retry-After") if response is not None else None
            if retry_after:
                try:
                    wait_seconds = float(retry_after)
                except (TypeError, ValueError):
                    pass
            wait_seconds = min(max(wait_seconds, 1), MAX_WAIT_SECONDS)

            logger.warning(
                "Provider returned %s (attempt %d/%d) -- retrying in %.0fs",
                status_code, attempt, MAX_ATTEMPTS, wait_seconds,
            )
            await asyncio.sleep(wait_seconds)
