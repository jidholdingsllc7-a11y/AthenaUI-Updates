# AthenaUI — Athena Net: agent tool to list files in the shared Dropbox folder
# File: backend/tools/athena_net/list_files.py

from typing import Any, Dict

from athena_net.dropbox_storage import DropboxStorageBackend
from athena_net.storage_backend import StorageBackendError

capabilities = {
    "needs_filesystem": False,
    "needs_bridge": False,
    "needs_network": True,
    "needs_user": True,
}


async def run(args: Dict[str, Any]) -> str:
    try:
        username = args.get("username")
        path = args.get("path") or ""

        if not username:
            return "[ERROR] Missing 'username' argument."

        backend = DropboxStorageBackend.for_user(username)
        entries = backend.list(path)
        if not entries:
            return f"No files found in the Athena Net shared folder at '{path or '/'}'."

        lines = [
            f"- {'[folder] ' if e['is_folder'] else ''}{e['path']}" + (f" ({e['size']} bytes)" if e.get("size") is not None else "")
            for e in entries
        ]
        return "Athena Net shared folder contents:\n" + "\n".join(lines)
    except StorageBackendError as e:
        return f"[ERROR] {e}"
    except Exception as e:
        return f"[ERROR] Failed to list files: {str(e)}"
