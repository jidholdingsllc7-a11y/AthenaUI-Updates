# AthenaUI — Athena Link Periodic Heartbeat Background Runner
# File: backend/athena_link/heartbeat_runner.py
# Created: 2026-11-02 CST
#
# A single global asyncio loop (started once from main.py's startup event,
# mirroring scheduler/runner.py and backup/scheduler_runner.py's established
# pattern) that wakes up periodically and sends a fresh signed heartbeat for
# every local user who has Athena Link configured + enabled + an address
# set, so the directory Worker's "best_address" for this identity stays
# current without the user needing to click "Send Heartbeat Now" by hand.

from __future__ import annotations

import asyncio
import logging

from auth.service import AuthService
from athena_link.service import AthenaLinkError, AthenaLinkService

logger = logging.getLogger(__name__)

POLL_SECONDS = 300


async def _tick() -> None:
    users = AuthService()._load_users()
    for username in users:
        status = AthenaLinkService.get_status(username)
        if not (status.get("configured") and status.get("enabled") and status.get("address")):
            continue
        try:
            await asyncio.to_thread(AthenaLinkService.send_heartbeat, username)
        except AthenaLinkError as e:
            logger.warning("Athena Link heartbeat failed for %s: %s", username, e)
        except Exception:
            logger.error("Athena Link heartbeat crashed for %s", username, exc_info=True)


async def run_athena_link_heartbeat_loop() -> None:
    """Runs forever (until backend exits)."""
    logger.info("Athena Link heartbeat background loop starting.")
    while True:
        try:
            await _tick()
        except Exception as e:
            logger.error(f"Athena Link heartbeat loop tick failed: {e}")
        await asyncio.sleep(POLL_SECONDS)
