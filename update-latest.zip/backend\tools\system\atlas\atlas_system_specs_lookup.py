# AthenaUI -- atlas_system_specs_lookup Tool
# File: backend/tools/system/atlas/atlas_system_specs_lookup.py
#
# Private reference lookup for Atlas Lumos ONLY. Reads
# characters/system/system_agents/Atlas_Lumos/system_specs.md -- a file no
# other character has a tool to access -- and returns the section(s)
# matching `query`, or the full document if no query is given. Hard-gated
# on the caller's character name (not just allowlist placement), so even if
# this tool were ever exposed to another character by mistake, it still
# refuses to serve the content to anyone but Atlas.
#
# Also merges in system_specs_internal.md (proprietary implementation
# details) when present. That file is excluded from customer installer
# builds (electron/package.json's backend extraResources filter), so on a
# real customer install it simply won't exist -- this lookup degrades
# gracefully to the public content only, no code path change needed.

from __future__ import annotations

import re
from typing import Any, Dict

from core.runtime.runtime import get_runtime

ALLOWED_CHARACTER = "Atlas Lumos"

capabilities = {
    "needs_bridge": False,
    "needs_filesystem": True,
    "needs_network": False,
    "needs_user": True,
}


def _specs_dir():
    runtime = get_runtime()
    return runtime.env.BACKEND_DIR / "characters" / "system" / "system_agents" / "Atlas_Lumos"


def _specs_path():
    return _specs_dir() / "system_specs.md"


def _specs_internal_path():
    return _specs_dir() / "system_specs_internal.md"


def _split_sections(text: str):
    """Splits on top-level (##) headings, keeping each heading with its body."""
    parts = re.split(r"(?m)^(?=## )", text)
    return [p for p in parts if p.strip()]


async def run(args: Dict[str, Any]):
    character = (args.get("character") or "").strip()
    if character.lower() != ALLOWED_CHARACTER.lower():
        return {"error": "This reference material is private to Atlas Lumos."}

    path = _specs_path()
    if not path.exists():
        return {"error": "System specs reference file is missing."}

    text = path.read_text(encoding="utf-8")
    internal_path = _specs_internal_path()
    if internal_path.exists():
        text += "\n\n" + internal_path.read_text(encoding="utf-8")

    query = (args.get("query") or "").strip().lower()
    if not query:
        return {"content": text}

    sections = _split_sections(text)
    words = [w for w in re.split(r"\W+", query) if w]
    scored = [(sum(s.lower().count(w) for w in words), s) for s in sections]
    scored = [pair for pair in scored if pair[0] > 0]
    if scored:
        scored.sort(key=lambda pair: pair[0], reverse=True)
        top_score = scored[0][0]
        best = [s for score, s in scored if score >= top_score * 0.5]
        return {"content": "\n\n".join(best[:2])}

    headings = [re.match(r"## .+", s).group(0) for s in sections if re.match(r"## .+", s)]
    return {
        "content": (
            f"No section matched '{args.get('query')}'. Available sections:\n"
            + "\n".join(f"- {h}" for h in headings)
            + "\n\nCall again with no query to get the full document, or try a different query term."
        )
    }
