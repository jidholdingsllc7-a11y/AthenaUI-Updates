﻿# AthenaUI v3.5 — Workspace Service
# File: backend/workspace/service.py
# Created: 2026-04-11 20:16 CDT
# Updated: 2026-07-27 19:49 CDT

import os
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Dict, Any, List

from core.runtime.runtime import get_runtime
from vault.controller import VaultController


class WorkspaceService:
    """
    Manages the user's workspace directory.
    """

    WORKSPACE_NAME = "AthenaWorkspace"

    def __init__(self, username: str):
        self.username = username
        self.root = self._load_workspace_root(username)

    @staticmethod
    def create_workspace(base_path: str, username: str) -> str:
        """
        base_path: directory chosen by the user (e.g., "C:\\" or "/home/darryl")
        Returns the full workspace path.
        """
        base = Path(base_path).expanduser().resolve()
        workspace = base / WorkspaceService.WORKSPACE_NAME

        # Create workspace structure
        (workspace / "projects").mkdir(parents=True, exist_ok=True)
        (workspace / "logs").mkdir(parents=True, exist_ok=True)
        (workspace / "temp").mkdir(parents=True, exist_ok=True)
        (workspace / "exports").mkdir(parents=True, exist_ok=True)

        # Save to vault
        vault = VaultController.get_vault(username)
        user_data = dict(getattr(vault, "user", {}) or {})
        user_data["workspace_path"] = str(workspace)
        user_data["workspace_directory"] = str(workspace)
        vault.user = user_data

        # Backward-compatible vault persistence across service refactors.
        if hasattr(VaultController, "save_vault"):
            VaultController.save_vault(username, vault)
        elif hasattr(VaultController, "save_user_vault"):
            VaultController.save_user_vault(username, vault)
        elif hasattr(VaultController, "save"):
            VaultController.save(username, vault)
        else:
            raise AttributeError("VaultService has no supported save method")

        return str(workspace)

    @staticmethod
    def _default_workspace_root() -> Path:
        runtime = get_runtime()
        # WRITABLE_ROOT (not ROOT_DIR) -- a packaged install's ROOT_DIR lives
        # under the app's own (read-only) resources dir.
        return (runtime.env.WRITABLE_ROOT / WorkspaceService.WORKSPACE_NAME).resolve()

    @staticmethod
    def _load_workspace_root(username: str) -> Path:
        vault = VaultController.get_vault(username)
        user_data = dict(getattr(vault, "user", {}) or {})
        prefs = dict(getattr(vault, "preferences", {}) or {})

        candidate = (
            user_data.get("workspace_path")
            or user_data.get("workspace_directory")
            or prefs.get("workspace.path")
            or prefs.get("workspace_directory")
            or ""
        )

        if candidate:
            root = Path(str(candidate)).expanduser().resolve()
        else:
            root = WorkspaceService._default_workspace_root()
            WorkspaceService.create_workspace(str(root.parent), username)
            return root

        root.mkdir(parents=True, exist_ok=True)
        return root

    def _resolve(self, rel_path: str) -> Path:
        candidate = (self.root / rel_path).resolve()
        # NOTE: a plain string startswith() check here is a path-traversal
        # bypass -- e.g. root "C:\AthenaWorkspace" would incorrectly accept
        # a sibling directory like "C:\AthenaWorkspace-evil\secret.txt"
        # since it string-prefix-matches without being a real subpath.
        # is_relative_to() (or the parents-based fallback below) does a
        # real path-segment containment check instead.
        try:
            is_inside = candidate == self.root or candidate.is_relative_to(self.root)
        except AttributeError:
            # Python < 3.9 fallback
            is_inside = candidate == self.root or self.root in candidate.parents
        if not is_inside:
            raise ValueError("Path escapes workspace root.")
        return candidate

    def get_file_path(self, rel_path: str) -> Path:
        """Public, path-traversal-safe resolver for callers (e.g. an HTTP
        download route) that need the real filesystem path rather than the
        file's text contents -- reuses the same `_resolve()` security check
        as every other method here."""
        path = self._resolve(rel_path)
        if not path.is_file():
            raise FileNotFoundError(f"File not found: {rel_path}")
        return path

    def read_file(self, rel_path: str) -> str:
        path = self._resolve(rel_path)
        if not path.is_file():
            raise FileNotFoundError(f"File not found: {rel_path}")
        return path.read_text(encoding="utf-8")

    def write_file(self, rel_path: str, content: str) -> str:
        path = self._resolve(rel_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content or "", encoding="utf-8")
        return f"[OK] Wrote file: {rel_path}"

    def write_file_tracked(self, rel_path: str, content: str, character: Optional[str] = None) -> str:
        """Writes content live immediately (so it can be run/tested right
        away, no approval step). If a file already existed at this path,
        its prior content is preserved as a pending Keep/Revert change (see
        code_suite.changes.service) instead of being silently discarded --
        Keep archives the original with a timestamp and finalizes the new
        content; Revert restores the original live and archives the
        rejected attempt instead. Brand-new files are just written
        directly since there's nothing to lose and no decision to make.
        `character`, when provided (an agent tool call, not a raw Code Suite
        edit), scopes the resulting Keep/Revert prompt to that character's
        own conversation so it doesn't surface in an unrelated character's
        chat."""
        path = self._resolve(rel_path)
        existed = path.is_file()
        original = path.read_text(encoding="utf-8") if existed else None

        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content or "", encoding="utf-8")

        if not existed:
            return f"[OK] Created new file: {rel_path}"

        from code_suite.changes.service import changeset_service

        change = changeset_service.create_live_edit(self.username, rel_path, original, character=character)
        return (
            f"[PENDING-REVIEW] {rel_path} written live (change_id={change.id}). "
            "Keep to finalize (archives the previous version) or Revert to restore it."
        )

    def write_bytes(self, rel_path: str, content: bytes) -> str:
        path = self._resolve(rel_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content or b"")
        return f"[OK] Wrote file: {rel_path}"

    def delete_file(self, rel_path: str) -> str:
        path = self._resolve(rel_path)
        if path.is_file():
            path.unlink()
            return f"[OK] Deleted file: {rel_path}"
        if path.is_dir() and not any(path.iterdir()):
            path.rmdir()
            return f"[OK] Deleted empty directory: {rel_path}"
        raise FileNotFoundError(f"Path not found or not deletable: {rel_path}")

    def mkdir(self, rel_path: str) -> str:
        path = self._resolve(rel_path)
        path.mkdir(parents=True, exist_ok=True)
        return f"[OK] Created directory: {rel_path}"

    def list_dir(self, rel_path: str = ".") -> List[Dict[str, Any]]:
        path = self._resolve(rel_path)
        if not path.is_dir():
            raise NotADirectoryError(f"Not a directory: {rel_path}")

        output: List[Dict[str, Any]] = []
        for name in sorted(os.listdir(path)):
            full = path / name
            output.append(
                {
                    "name": name,
                    "rel_path": str(full.relative_to(self.root)).replace("\\", "/"),
                    "is_dir": full.is_dir(),
                    "size": full.stat().st_size if full.is_file() else None,
                }
            )
        return output

    @staticmethod
    def _iso_mtime(path: Path) -> str:
        return datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc).isoformat()

    def list_dir_recursive(
        self, rel_path: str = ".", *, max_depth: int = 8, max_entries: int = 2000
    ) -> Dict[str, Any]:
        """Walks the directory tree from `rel_path` in one call, returning
        every entry's size and last-modified time -- so troubleshooting
        doesn't need a separate file_list_dir round trip per directory.
        Bounded by `max_depth`/`max_entries` so a huge project can't blow up
        the response; `truncated` is set if either limit was hit."""
        root = self._resolve(rel_path)
        if not root.is_dir():
            raise NotADirectoryError(f"Not a directory: {rel_path}")

        entries: List[Dict[str, Any]] = []
        truncated = False

        def walk(current: Path, depth: int) -> None:
            nonlocal truncated
            if truncated:
                return
            try:
                children = sorted(current.iterdir(), key=lambda p: p.name.lower())
            except OSError:
                return
            for child in children:
                if len(entries) >= max_entries:
                    truncated = True
                    return
                is_dir = child.is_dir()
                entries.append({
                    "rel_path": str(child.relative_to(self.root)).replace("\\", "/"),
                    "name": child.name,
                    "is_dir": is_dir,
                    "size": child.stat().st_size if not is_dir else None,
                    "modified_at": self._iso_mtime(child),
                })
                if is_dir and depth < max_depth:
                    walk(child, depth + 1)

        walk(root, 1)
        return {"root": rel_path, "entries": entries, "truncated": truncated}

    def get_workspace_overview(self, *, max_depth: int = 6, max_entries: int = 1500) -> str:
        """Returns the full project structure as an on-demand, human/agent
        -readable indented tree (like the `tree` command), rooted at the
        workspace root, so an agent can see the whole layout in one call
        instead of piecing it together from repeated single-level listings."""
        lines: List[str] = [f"{self.root.name}/"]
        count = 0
        truncated = False

        def walk(current: Path, prefix: str, depth: int) -> None:
            nonlocal count, truncated
            if truncated:
                return
            try:
                children = sorted(current.iterdir(), key=lambda p: (p.is_file(), p.name.lower()))
            except OSError:
                return
            for child in children:
                if count >= max_entries:
                    truncated = True
                    return
                count += 1
                is_dir = child.is_dir()
                label = f"{child.name}/" if is_dir else child.name
                lines.append(f"{prefix}{label}")
                if is_dir and depth < max_depth:
                    walk(child, prefix + "  ", depth + 1)

        walk(self.root, "  ", 1)
        if truncated:
            lines.append(f"... (truncated at {max_entries} entries -- narrow with file_list_dir_recursive on a subfolder)")
        return "\n".join(lines)

    def copy_file(self, source: str, destination: str) -> str:
        src = self._resolve(source)
        dst = self._resolve(destination)
        if not src.is_file():
            raise FileNotFoundError(f"Source file not found: {source}")
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        return f"[OK] Copied {source} -> {destination}"

    def move_file(self, source: str, destination: str) -> str:
        src = self._resolve(source)
        dst = self._resolve(destination)
        if not src.exists():
            raise FileNotFoundError(f"Source path not found: {source}")
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(src), str(dst))
        return f"[OK] Moved {source} -> {destination}"

    def get_metadata(self, rel_path: str) -> Dict[str, Any]:
        path = self._resolve(rel_path)
        if not path.exists():
            raise FileNotFoundError(f"Path not found: {rel_path}")

        stat = path.stat()
        return {
            "path": rel_path,
            "absolute_path": str(path),
            "exists": True,
            "is_file": path.is_file(),
            "is_dir": path.is_dir(),
            "size": stat.st_size if path.is_file() else None,
            "modified_at": stat.st_mtime,
            "created_at": stat.st_ctime,
        }

    def search(self, query: str, *, max_results: int = 200) -> List[Dict[str, Any]]:
        query_lower = query.lower()
        results: List[Dict[str, Any]] = []

        for file_path in self.root.rglob("*"):
            if len(results) >= max_results:
                break
            if not file_path.is_file():
                continue

            rel = str(file_path.relative_to(self.root)).replace("\\", "/")
            if query_lower in rel.lower():
                results.append({"path": rel, "match": "path"})
                continue

            try:
                content = file_path.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue

            idx = content.lower().find(query_lower)
            if idx >= 0:
                snippet = content[max(0, idx - 60): idx + 120].replace("\n", " ")
                results.append({"path": rel, "match": "content", "snippet": snippet})

        return results

    def propose_delete(self, rel_path: str) -> str:
        from code_suite.changes.service import changeset_service

        change = changeset_service.create_delete_change(self.username, rel_path)
        return f"[PENDING] File delete proposed for {rel_path} (change_id={change.id})"

    @staticmethod
    def get_workspace(username: str) -> Optional["WorkspaceService"]:
        try:
            return WorkspaceService(username)
        except Exception:
            return None
