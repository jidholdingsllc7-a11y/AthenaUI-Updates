# AthenaUI v3.5 — crm_update_contact_info Tool
# File: backend/tools/crm/crm_update_contact_info.py
#
# Records a customer's contact preference (phone/sms/email/x/facebook),
# updated phone number, and/or newsletter opt-in status.

from datetime import datetime, timezone
from typing import Any, Dict

from crm.service import CrmError, update_customer

capabilities = {
    "needs_filesystem": True,
    "needs_bridge": False,
    "needs_network": False,
    "needs_user": True,
}


async def run(args: Dict[str, Any]) -> str:
    try:
        username = args.get("username")
        customer_id = args.get("customer_id")
        if not username:
            return "[ERROR] Missing 'username' argument."
        if not customer_id:
            return "[ERROR] Missing 'customer_id' argument."

        updates: Dict[str, Any] = {}
        if args.get("phone"):
            updates["phone"] = args["phone"]
        if args.get("preferred_contact_method"):
            updates["preferred_contact_method"] = args["preferred_contact_method"]
        if args.get("newsletter_opt_in") is not None:
            updates["newsletter_opt_in"] = 1 if args.get("newsletter_opt_in") else 0
            if args.get("newsletter_opt_in"):
                updates["newsletter_opt_in_at"] = datetime.now(timezone.utc).isoformat()

        if not updates:
            return "[ERROR] Nothing to update -- provide at least one of phone, preferred_contact_method, or newsletter_opt_in."

        customer = update_customer(username, customer_id, **updates)
        return (
            f"Updated contact info for {customer['name']}: "
            f"preferred_contact_method={customer.get('preferred_contact_method')}, "
            f"newsletter_opt_in={bool(customer.get('newsletter_opt_in'))}."
        )
    except CrmError as e:
        return f"[ERROR] {e}"
    except Exception as e:
        return f"[ERROR] Failed to update contact info: {str(e)}"
