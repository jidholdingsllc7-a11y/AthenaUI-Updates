﻿# AthenaUI v3.5 — Logs API Routes
# File: backend/api/routes/logs.py
# Created: 2026-04-09 20:36 CDT
# Updated: 2026-07-27 19:49 CDT

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, Query, WebSocket, WebSocketDisconnect

from logs_system.viewer.service import log_viewer
from logs_system.tail.websocket import tail_ws_manager
from notifications.service.service import NotificationService
from auth.service import get_current_user

router = APIRouter(prefix="/logs", tags=["logs"])


@router.get("/recent", response_model=List[Dict[str, Any]])
def get_recent_logs(
    limit: int = Query(200, ge=1, le=1000),
    level: Optional[str] = Query(None),
    task_id: Optional[str] = Query(None),
    event: Optional[str] = Query(None),
    agent_state: Optional[str] = Query(None),
) -> List[Dict[str, Any]]:
    """
    Return recent logs from the persistent Tail Log store (survives restarts).
    """
    return log_viewer.get_recent_tail(
        limit=limit,
        level=level,
        task_id=task_id,
        event=event,
        agent_state=agent_state,
    )


@router.get("/dates", response_model=List[str])
def get_log_dates() -> List[str]:
    """
    List available date-based log files in the vault.
    """
    return log_viewer.list_dates()


@router.get("/file/{filename}", response_model=List[Dict[str, Any]])
def get_logs_from_file(
    filename: str,
    limit: Optional[int] = Query(None, ge=1, le=5000),
    level: Optional[str] = Query(None),
    task_id: Optional[str] = Query(None),
    event: Optional[str] = Query(None),
) -> List[Dict[str, Any]]:
    """
    Read logs from a specific vault log file.
    """
    return log_viewer.read_log_file(
        filename=filename,
        level=level,
        task_id=task_id,
        event=event,
        limit=limit,
    )


@router.get("/task/{task_id}", response_model=List[Dict[str, Any]])
def get_logs_for_task(
    task_id: str,
    limit: Optional[int] = Query(None, ge=1, le=5000),
    level: Optional[str] = Query(None),
    event: Optional[str] = Query(None),
) -> List[Dict[str, Any]]:
    """
    Read logs associated with a specific task_id.
    """
    return log_viewer.read_by_task_id(
        task_id=task_id,
        level=level,
        event=event,
        limit=limit,
    )


@router.websocket("/ws/live")
async def websocket_logs_live(websocket: WebSocket) -> None:
    """
    WebSocket endpoint for live log streaming.
    - Sends a snapshot of recent logs on connect.
    - Then streams new entries as they arrive.
    """
    await tail_ws_manager.connect(websocket)
    try:
        await tail_ws_manager.send_initial_snapshot(websocket, limit=200)
        while True:
            # We don't expect messages from client; keep connection open.
            await websocket.receive_text()
    except WebSocketDisconnect:
        tail_ws_manager.disconnect(websocket)
    except Exception:
        tail_ws_manager.disconnect(websocket)

@router.get("/notifications")
async def get_notifications(user=Depends(get_current_user)):
    return {"notifications": NotificationService.list_notifications(user["username"])}


@router.post("/notifications/clear")
async def clear_notifications(user=Depends(get_current_user)):
    NotificationService.clear_notifications(user["username"])
    return {"status": "cleared"}

