﻿# AthenaUI v3.5 — Router Registry
# File: backend/llm/router_selector/router_registry.py
# Created: 2026-03-28 22:36 CDT
# Updated: 2026-07-27 19:49 CDT

import importlib
import logging

# IMPORTANT:
# We import router_selector *without* pulling RouterSelector directly.
# This avoids circular imports.
import llm.router_selector.router_selector as selector

# Provider constants
from llm.routers.providers import (
    PROVIDER_OPENAI,
    PROVIDER_ANTHROPIC,
    PROVIDER_XAI,
    PROVIDER_GROQ,
    PROVIDER_MISTRAL,
    PROVIDER_FIREWORKS,
    PROVIDER_TOGETHER,
    PROVIDER_GEMINI,
    PROVIDER_DEEPSEEK,
    PROVIDER_PERPLEXITY,
    PROVIDER_COHERE,
    PROVIDER_AI21,
    PROVIDER_AZURE_OPENAI,
    PROVIDER_BEDROCK,
    PROVIDER_OPENROUTER,
    PROVIDER_HUGGINGFACE,
    PROVIDER_HF_TGI,
    PROVIDER_OLLAMA,
    PROVIDER_LMSTUDIO,
    PROVIDER_TRANSFORMERS_LOCAL,
    PROVIDER_CUSTOM_HTTP,
    PROVIDER_ATLAS_SERVER,
)

logger = logging.getLogger(__name__)


ROUTER_IMPORTS = [
    (PROVIDER_OPENAI, "llm.routers.openai_router", "OpenAIRouter"),
    (PROVIDER_ANTHROPIC, "llm.routers.anthropic_router", "AnthropicRouter"),
    (PROVIDER_XAI, "llm.routers.xai_router", "XAIRouter"),
    (PROVIDER_GROQ, "llm.routers.groq_router", "GroqRouter"),
    (PROVIDER_MISTRAL, "llm.routers.mistral_router", "MistralRouter"),
    (PROVIDER_FIREWORKS, "llm.routers.fireworks_router", "FireworksRouter"),
    (PROVIDER_TOGETHER, "llm.routers.together_router", "TogetherRouter"),
    (PROVIDER_GEMINI, "llm.routers.gemini_router", "GeminiRouter"),
    (PROVIDER_DEEPSEEK, "llm.routers.deepseek_router", "DeepSeekRouter"),
    (PROVIDER_PERPLEXITY, "llm.routers.perplexity_router", "PerplexityRouter"),
    (PROVIDER_COHERE, "llm.routers.cohere_router", "CohereRouter"),
    (PROVIDER_AI21, "llm.routers.ai21_router", "AI21Router"),
    (PROVIDER_AZURE_OPENAI, "llm.routers.azure_openai_router", "AzureOpenAIRouter"),
    (PROVIDER_BEDROCK, "llm.routers.bedrock_router", "BedrockRouter"),
    (PROVIDER_OPENROUTER, "llm.routers.openrouter_router", "OpenRouterRouter"),
    (PROVIDER_HUGGINGFACE, "llm.routers.huggingface_router", "HuggingFaceRouter"),
    (PROVIDER_HF_TGI, "llm.routers.huggingface_tgi_router", "HuggingFaceTGIRouter"),
    (PROVIDER_OLLAMA, "llm.routers.ollama_router", "OllamaRouter"),
    (PROVIDER_LMSTUDIO, "llm.routers.lmstudio_router", "LMStudioRouter"),
    (PROVIDER_TRANSFORMERS_LOCAL, "llm.routers.transformers_local_router", "TransformersLocalRouter"),
    (PROVIDER_CUSTOM_HTTP, "llm.routers.custom_http_router", "CustomHTTPRouter"),
    (PROVIDER_ATLAS_SERVER, "llm.routers.atlas_server_router", "AtlasServerRouter"),
]


def _register_available_routers() -> None:
    for provider_id, module_path, class_name in ROUTER_IMPORTS:
        try:
            module = importlib.import_module(module_path)
            router_class = getattr(module, class_name)
            selector.RouterSelector.register_router(provider_id, router_class)
        except Exception as exc:
            logger.warning(
                "Skipping router '%s' (%s.%s): %s",
                provider_id,
                module_path,
                class_name,
                exc,
            )


_register_available_routers()


