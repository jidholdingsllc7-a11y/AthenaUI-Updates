# AthenaUI -- Current-Scheduled-Job Context
# File: backend/scheduler/job_context.py
#
# A contextvar carrying "which scheduled job (if any) is currently
# executing" through nested async calls (runner -> ChatEngine -> tool loop
# -> tool run), mirroring safety/task_context.py's established pattern.
# Lets scheduler_set_recurring_pace know which job it's adjusting without
# the user/model having to pass job_id as a tool argument (they don't know
# it, and shouldn't need to).

from __future__ import annotations

import contextvars
from contextlib import contextmanager
from typing import Optional

_current_job_id: "contextvars.ContextVar[Optional[str]]" = contextvars.ContextVar(
    "current_scheduled_job_id", default=None
)


@contextmanager
def job_scope(job_id: Optional[str]):
    token = _current_job_id.set(job_id)
    try:
        yield
    finally:
        _current_job_id.reset(token)


def get_current_job_id() -> Optional[str]:
    return _current_job_id.get()
