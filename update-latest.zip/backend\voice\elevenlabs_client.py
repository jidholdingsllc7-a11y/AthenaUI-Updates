# AthenaUI v3.5 — ElevenLabs Voice Client
# File: backend/voice/elevenlabs_client.py
# Created: 2026-08-01
"""
Thin HTTP client for the ElevenLabs text-to-speech API.

Fails soft and explicitly, never with a raw traceback:
- If ElevenLabs is toggled off (or has no API key configured), every method
  returns a clear "not configured" result instead of attempting a request.
- If a voice id is still one of the catalog's placeholder strings (nothing
  real pasted in yet), returns a "placeholder voice id" result instead of
  hitting ElevenLabs with a guaranteed-to-fail id.
- Any real HTTP error from ElevenLabs (bad/expired key, no active
  subscription, quota exceeded, etc.) is translated into a friendly
  VoiceProviderError with a subscription-aware message instead of letting
  a raw `requests.HTTPError` traceback bubble up to the client.
"""

from __future__ import annotations

import re
from typing import Optional

import requests

from vault.service import VaultService

APP_NAME = "elevenlabs"
TTS_URL = "https://api.elevenlabs.io/v1/text-to-speech/{voice_id}"
PLACEHOLDER_PREFIXES = ("PASTE_", "REPLACE_")

# Markdown/code noise that reads badly (or triggers odd non-speech sounds)
# when sent to ElevenLabs as literal text -- stripped before every request.
_CODE_BLOCK_RE = re.compile(r"```.*?```", re.DOTALL)
_INLINE_CODE_RE = re.compile(r"`([^`]*)`")
_MD_IMAGE_RE = re.compile(r"!\[[^\]]*\]\([^)]*\)")
_MD_LINK_RE = re.compile(r"\[([^\]]*)\]\([^)]*\)")
_TABLE_SEPARATOR_RE = re.compile(r"^\s*\|?[\s:|-]+\|[\s:|-]*$", re.MULTILINE)
_MARKDOWN_NOISE_CHARS_RE = re.compile(r"[*#~`()]")
_EMOJI_RE = re.compile(
    "["
    "\U0001F300-\U0001FAFF"  # pictographs/emoticons/transport/supplemental symbols
    "\U00002600-\U000027BF"  # misc symbols & dingbats
    "\U0001F1E6-\U0001F1FF"  # regional indicator flags
    "]+"
)


def _sanitize_for_speech(text: str) -> str:
    """
    Strips markdown formatting and code out of a chat reply before it's
    sent to ElevenLabs. Raw asterisks/hashes/parens/backticks and literal
    code get mis-synthesized as odd noises (or outright rejected by the
    API) instead of being read naturally.
    """
    if not text:
        return text

    text = _CODE_BLOCK_RE.sub(" ", text)
    text = _INLINE_CODE_RE.sub(r"\1", text)
    text = _MD_IMAGE_RE.sub("", text)
    text = _MD_LINK_RE.sub(r"\1", text)
    text = _TABLE_SEPARATOR_RE.sub(" ", text)
    text = text.replace("|", " ")
    text = _EMOJI_RE.sub("", text)
    text = text.replace("_", " ")
    text = _MARKDOWN_NOISE_CHARS_RE.sub("", text)
    return re.sub(r"\s+", " ", text).strip()


class VoiceProviderError(Exception):
    """Raised for a clean, user-facing voice/TTS failure (never a raw traceback)."""

    def __init__(self, message: str, *, status_code: int = 400):
        super().__init__(message)
        self.status_code = status_code


def is_placeholder_voice_id(voice_id: Optional[str]) -> bool:
    if not voice_id:
        return True
    return any(voice_id.startswith(prefix) for prefix in PLACEHOLDER_PREFIXES)


def get_voice_settings(username: str) -> dict:
    """Returns {"enabled": bool, "api_key_set": bool} -- never the raw key."""
    data = VaultService.get_app_api_key(username, APP_NAME) or {}
    return {
        "enabled": bool(data.get("enabled")),
        "api_key_set": bool(str(data.get("api_key") or "").strip()),
    }


def set_voice_settings(username: str, *, enabled: Optional[bool] = None, api_key: Optional[str] = None) -> dict:
    existing = VaultService.get_app_api_key(username, APP_NAME) or {}
    if enabled is not None:
        existing["enabled"] = bool(enabled)
    if api_key is not None:
        # Empty string clears the key; None (not passed) leaves it untouched.
        existing["api_key"] = api_key.strip()
    VaultService.set_app_api_key(username, APP_NAME, existing)
    return get_voice_settings(username)


def _get_api_key(username: str) -> Optional[str]:
    data = VaultService.get_app_api_key(username, APP_NAME) or {}
    api_key = str(data.get("api_key") or "").strip()
    enabled = bool(data.get("enabled"))
    if not enabled:
        return None
    if api_key:
        return api_key

    return None


def text_to_speech(username: str, voice_id: str, text: str) -> bytes:
    """
    Returns raw MP3 bytes for `text` spoken in `voice_id`.
    Raises VoiceProviderError (never a raw exception) on any failure --
    callers should catch this and return a clean message/HTTP status to
    the frontend instead of a 500 traceback.
    """
    if is_placeholder_voice_id(voice_id):
        raise VoiceProviderError(
            "This character's voice hasn't been set up yet -- it's still using a "
            "placeholder voice id. Paste a real ElevenLabs voice id in to enable it.",
            status_code=409,
        )

    api_key = _get_api_key(username)
    if not api_key:
        raise VoiceProviderError(
            "ElevenLabs voice is turned off (or no API key is set). Turn it on and "
            "add your ElevenLabs API key in Settings to enable character voices.",
            status_code=409,
        )

    text = _sanitize_for_speech(text)
    if not text:
        raise VoiceProviderError(
            "There's no speakable text left after removing formatting/code from this message.",
            status_code=400,
        )

    # Longer text takes ElevenLabs longer to synthesize -- a flat 30s timeout
    # was getting hit (and misreported as a generic connectivity failure) on
    # long replies. Scale with text length, capped so a request can never
    # hang indefinitely.
    timeout_seconds = max(30, min(180, len(text) // 15))

    try:
        resp = requests.post(
            TTS_URL.format(voice_id=voice_id),
            headers={
                "xi-api-key": api_key,
                "Content-Type": "application/json",
                "Accept": "audio/mpeg",
            },
            json={
                "text": text,
                "model_id": "eleven_multilingual_v2",
            },
            timeout=timeout_seconds,
        )
        resp.raise_for_status()
        return resp.content
    except requests.HTTPError as exc:
        status = exc.response.status_code if exc.response is not None else 502
        if status in (401, 402, 403):
            raise VoiceProviderError(
                "ElevenLabs rejected this request -- please check that your API key is "
                "correct and that your ElevenLabs subscription/quota is active.",
                status_code=402,
            ) from exc
        if status == 429:
            raise VoiceProviderError(
                "ElevenLabs rate limit reached. Please wait a moment and try again.",
                status_code=429,
            ) from exc
        raise VoiceProviderError(
            f"ElevenLabs returned an unexpected error (HTTP {status}).",
            status_code=502,
        ) from exc
    except requests.Timeout as exc:
        raise VoiceProviderError(
            "ElevenLabs took too long to respond -- this reply may be too long to "
            "synthesize quickly. Try again, or with a shorter message.",
            status_code=504,
        ) from exc
    except requests.RequestException as exc:
        raise VoiceProviderError(
            "Could not reach ElevenLabs. Please check your internet connection and try again.",
            status_code=502,
        ) from exc
