# AthenaUI v3.5 — Shared LLM Provider API Key Resolution
# File: backend/llm/api_key_resolver.py
#
# Provider routers (openai_router.py, xai_router.py, etc.) read their API
# key from the shared process-wide `runtime.env.<PROVIDER>_API_KEY`
# attribute -- they have no per-user/per-request context of their own.
#
# This helper resolves the correct key for a given user + provider (user's
# own vault-stored key, falling back to the system default vault key) and
# injects it into `runtime.env` immediately before a router is used, so
# per-user keys entered during onboarding/Settings actually take effect.
#
# IMPORTANT: this must be called (from EVERY chat entry point -- 1:1 chat
# AND group chat) right before constructing/using a provider router for a
# given request. Historically only the 1:1 chat path (chat/engine/service.py)
# did this; group chat's router.py called RouterSelector.select() directly
# without it, so a user's own vault-stored provider key (e.g. xAI) was
# silently never used in group chat even though it was saved correctly.

from typing import Optional

from vault.service import VaultService
from core.runtime.runtime import get_runtime

# Maps a provider_id to the runtime.env attribute name provider routers
# read their API key from.
PROVIDER_ENV_KEY = {
    "openai": "OPENAI_API_KEY",
    "anthropic": "ANTHROPIC_API_KEY",
    "xai": "XAI_API_KEY",
    "groq": "GROQ_API_KEY",
    "mistral": "MISTRAL_API_KEY",
    "fireworks": "FIREWORKS_API_KEY",
    "together": "TOGETHER_API_KEY",
    "gemini": "GEMINI_API_KEY",
    "deepseek": "DEEPSEEK_API_KEY",
    "perplexity": "PERPLEXITY_API_KEY",
    "cohere": "COHERE_API_KEY",
    "ai21": "AI21_API_KEY",
    "azure_openai": "AZURE_OPENAI_API_KEY",
    "openrouter": "OPENROUTER_API_KEY",
    "huggingface": "HUGGINGFACE_API_KEY",
    "custom_http": "CUSTOM_HTTP_API_KEY",
    "atlas_server": "ATLAS_SERVER_API_KEY",
}


class ApiKeyResolutionError(Exception):
    """Raised when no usable API key can be found for a provider."""
    pass


def resolve_and_inject_api_key(username: str, provider_id: str) -> str:
    """
    Resolves API key in this order:
      1. User-specific provider key (vault)
    then injects it into runtime.env so provider routers can read it.
    Returns the resolved key, or raises ApiKeyResolutionError if none found.
    """
    key_data = VaultService.get_api_key(username, provider_id)
    api_key = key_data.get("api_key") if key_data else None

    if not api_key:
        raise ApiKeyResolutionError(f"API key missing for provider: {provider_id}")

    env_attr = PROVIDER_ENV_KEY.get(provider_id)
    if env_attr:
        runtime = get_runtime()
        setattr(runtime.env, env_attr, api_key)

    return api_key
