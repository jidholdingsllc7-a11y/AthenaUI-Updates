# AthenaUI v3.5 — Spreadsheets API Routes
# File: backend/api/routes/spreadsheets.py
#
# Web routes (session auth) for user-defined named spreadsheets: create/
# rename/delete, column schema management, template save/instantiate,
# row CRUD, and CSV/PDF export. Mirrors personal.py's auth pattern.

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from fastapi.responses import Response

from api.deps.auth_middleware import get_current_user
from personal.export_service import ExportError, rows_to_csv_bytes
from spreadsheets.pdf_export import build_spreadsheet_pdf
from spreadsheets.service import (
    SpreadsheetError,
    add_column,
    add_image_page,
    add_row,
    create_from_template,
    create_spreadsheet,
    delete_row,
    delete_spreadsheet,
    export_template,
    get_export_table,
    get_spreadsheet,
    import_template,
    list_rows,
    list_spreadsheets,
    remove_column,
    remove_image_page,
    rename_column,
    rename_spreadsheet,
    reorder_image_pages,
    save_as_template,
    update_columns,
    update_footer_table,
    update_header_text,
    update_meta_fields,
    update_row,
)

router = APIRouter(prefix="/spreadsheets", tags=["spreadsheets"])


def _username_from_user(user: Any) -> str:
    if isinstance(user, dict):
        username = user.get("username")
    else:
        username = getattr(user, "username", None)
    if not username:
        raise HTTPException(status_code=401, detail="Authentication required.")
    return str(username)


@router.get("")
async def get_spreadsheets(is_template: Optional[bool] = None, user: Any = Depends(get_current_user)):
    username = _username_from_user(user)
    return {"spreadsheets": list_spreadsheets(username, is_template=is_template)}


@router.post("")
async def post_spreadsheet(payload: Dict[str, Any], user: Any = Depends(get_current_user)):
    username = _username_from_user(user)
    try:
        sheet = create_spreadsheet(
            username,
            name=payload.get("name", ""),
            columns=payload.get("columns") or [],
            is_template=bool(payload.get("is_template", False)),
            header_text=payload.get("header_text", ""),
            meta_fields=payload.get("meta_fields"),
            footer_table=payload.get("footer_table"),
        )
    except SpreadsheetError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"spreadsheet": sheet}


@router.get("/{id_or_name}")
async def get_spreadsheet_route(id_or_name: str, user: Any = Depends(get_current_user)):
    username = _username_from_user(user)
    try:
        sheet = get_spreadsheet(username, id_or_name)
        rows = list_rows(username, id_or_name)
    except SpreadsheetError as e:
        raise HTTPException(status_code=404, detail=str(e))
    return {"spreadsheet": sheet, "rows": rows}


@router.put("/{id_or_name}")
async def put_spreadsheet(id_or_name: str, payload: Dict[str, Any], user: Any = Depends(get_current_user)):
    username = _username_from_user(user)
    try:
        sheet = get_spreadsheet(username, id_or_name)
        if payload.get("name"):
            sheet = rename_spreadsheet(username, id_or_name, payload["name"])
        if payload.get("columns") is not None:
            sheet = update_columns(username, sheet["id"], payload["columns"])
        if payload.get("header_text") is not None:
            sheet = update_header_text(username, sheet["id"], payload["header_text"])
        if payload.get("meta_fields") is not None:
            sheet = update_meta_fields(username, sheet["id"], payload["meta_fields"])
        if payload.get("footer_table") is not None:
            sheet = update_footer_table(username, sheet["id"], payload["footer_table"])
    except SpreadsheetError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"spreadsheet": sheet}


@router.delete("/{id_or_name}")
async def delete_spreadsheet_route(id_or_name: str, user: Any = Depends(get_current_user)):
    username = _username_from_user(user)
    try:
        delete_spreadsheet(username, id_or_name)
    except SpreadsheetError as e:
        raise HTTPException(status_code=404, detail=str(e))
    return {"status": "ok"}


@router.post("/{id_or_name}/save-as-template")
async def post_save_as_template(id_or_name: str, payload: Dict[str, Any], user: Any = Depends(get_current_user)):
    username = _username_from_user(user)
    try:
        template = save_as_template(username, id_or_name, payload.get("template_name", ""))
    except SpreadsheetError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"spreadsheet": template}


@router.post("/from-template")
async def post_from_template(payload: Dict[str, Any], user: Any = Depends(get_current_user)):
    username = _username_from_user(user)
    try:
        sheet = create_from_template(
            username, payload.get("template_id_or_name", ""), payload.get("new_name", "")
        )
    except SpreadsheetError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"spreadsheet": sheet}


@router.get("/{id_or_name}/export-template")
async def get_export_template(id_or_name: str, user: Any = Depends(get_current_user)):
    username = _username_from_user(user)
    try:
        template = export_template(username, id_or_name)
    except SpreadsheetError as e:
        raise HTTPException(status_code=404, detail=str(e))
    content = json.dumps(template, indent=2).encode("utf-8")
    filename = f"{template['name']}.athenatemplate.json"
    return Response(
        content=content,
        media_type="application/json",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.post("/import-template")
async def post_import_template(payload: Dict[str, Any], user: Any = Depends(get_current_user)):
    username = _username_from_user(user)
    try:
        sheet = import_template(
            username,
            name=payload.get("name", ""),
            columns=payload.get("columns") or [],
            is_template=bool(payload.get("is_template", True)),
        )
    except SpreadsheetError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"spreadsheet": sheet}


@router.post("/{id_or_name}/columns")
async def post_column(id_or_name: str, payload: Dict[str, Any], user: Any = Depends(get_current_user)):
    username = _username_from_user(user)
    try:
        sheet = add_column(username, id_or_name, payload.get("label", ""), width=payload.get("width"))
    except SpreadsheetError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"spreadsheet": sheet}


@router.put("/{id_or_name}/columns/{key}")
async def put_column(id_or_name: str, key: str, payload: Dict[str, Any], user: Any = Depends(get_current_user)):
    username = _username_from_user(user)
    try:
        sheet = rename_column(
            username, id_or_name, key, new_label=payload.get("label"), width=payload.get("width")
        )
    except SpreadsheetError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"spreadsheet": sheet}


@router.delete("/{id_or_name}/columns/{key}")
async def delete_column(id_or_name: str, key: str, user: Any = Depends(get_current_user)):
    username = _username_from_user(user)
    try:
        sheet = remove_column(username, id_or_name, key)
    except SpreadsheetError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"spreadsheet": sheet}


@router.post("/{id_or_name}/rows")
async def post_row(id_or_name: str, payload: Dict[str, Any], user: Any = Depends(get_current_user)):
    username = _username_from_user(user)
    try:
        row = add_row(username, id_or_name, payload.get("values") or {}, label=payload.get("label", ""))
    except SpreadsheetError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"row": row}


@router.put("/{id_or_name}/rows/{row_index}")
async def put_row(id_or_name: str, row_index: int, payload: Dict[str, Any], user: Any = Depends(get_current_user)):
    username = _username_from_user(user)
    try:
        row = update_row(username, id_or_name, row_index, payload.get("values") or {}, label=payload.get("label"))
    except SpreadsheetError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"row": row}


@router.delete("/{id_or_name}/rows/{row_id}")
async def delete_row_route(id_or_name: str, row_id: str, user: Any = Depends(get_current_user)):
    username = _username_from_user(user)
    try:
        delete_row(username, id_or_name, row_id)
    except SpreadsheetError as e:
        raise HTTPException(status_code=404, detail=str(e))
    return {"status": "ok"}


@router.get("/{id_or_name}/export")
async def get_export(id_or_name: str, format: str = "csv", user: Any = Depends(get_current_user)):
    username = _username_from_user(user)
    try:
        table = get_export_table(username, id_or_name)
        if format == "csv":
            content = rows_to_csv_bytes(table["rows"], table["columns"])
            media_type = "text/csv"
        elif format == "pdf":
            content = build_spreadsheet_pdf(table)
            media_type = "application/pdf"
        else:
            raise ExportError("Format must be 'csv' or 'pdf'.")
    except (SpreadsheetError, ExportError) as e:
        raise HTTPException(status_code=400, detail=str(e))

    filename = f"{table['name']}.{format}"
    return Response(
        content=content,
        media_type=media_type,
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Cache-Control": "no-store",
        },
    )


_MAX_IMAGE_PAGE_BYTES = 15 * 1024 * 1024


@router.post("/{id_or_name}/images")
async def post_image_page(id_or_name: str, file: UploadFile = File(...), user: Any = Depends(get_current_user)):
    username = _username_from_user(user)
    if not (file.content_type or "").startswith("image/"):
        raise HTTPException(status_code=400, detail="File must be an image.")
    file_bytes = await file.read()
    if len(file_bytes) > _MAX_IMAGE_PAGE_BYTES:
        raise HTTPException(status_code=400, detail="Image must be 15MB or smaller.")
    try:
        sheet = add_image_page(username, id_or_name, file.filename or "", file_bytes)
    except SpreadsheetError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"spreadsheet": sheet}


@router.delete("/{id_or_name}/images/{image_id}")
async def delete_image_page(id_or_name: str, image_id: str, user: Any = Depends(get_current_user)):
    username = _username_from_user(user)
    try:
        sheet = remove_image_page(username, id_or_name, image_id)
    except SpreadsheetError as e:
        raise HTTPException(status_code=404, detail=str(e))
    return {"spreadsheet": sheet}


@router.put("/{id_or_name}/images/reorder")
async def put_images_reorder(id_or_name: str, payload: Dict[str, Any], user: Any = Depends(get_current_user)):
    username = _username_from_user(user)
    try:
        sheet = reorder_image_pages(username, id_or_name, payload.get("ordered_ids") or [])
    except SpreadsheetError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"spreadsheet": sheet}
