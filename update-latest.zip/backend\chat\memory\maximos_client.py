# AthenaUI v3.5 — Maximos Memory Server Client
# File: backend/chat/memory/maximos_client.py
# Created: 2026-07-30 20:53 CDT
# Updated: 2026-07-30 22:10 CDT
"""
Thin HTTP client for the Maximos Memory Server (long-term, per-character
agent memory). Mirrors the per_agent_key_client.py pattern in the
maximos-memory-server-v1-3 repo's examples/python/ folder -- the server's
[auth] key_mode in config.toml must be set to "per_agent" for this to work
as intended (matches this file).

Every request is scoped to a [user_id][agent_id] pipeline -- callers pass
the AthenaUI username as user_id and the character name as agent_id, so
each character gets its own isolated long-term memory AND its own personal
API key, minted lazily on first use via one-time /handshake calls (using the
global/startup key only for that handshake, never for anything else).

Per-agent keys are cached in-process AND persisted per-user in the Vault
(secret "maximos_agent_keys", a dict of {character: key}) so AthenaUI
doesn't need to re-handshake on every restart. IMPORTANT: the server itself
only keeps per-agent keys in memory (see src/auth/mod.rs's ApiKeyStore --
`agent_keys: RwLock<HashMap<...>>`, never written to disk), so a server
restart invalidates every previously-issued per-agent key. If a cached key
is rejected (HTTP 401), this client automatically re-handshakes once and
retries -- callers never see the staleness.

Fails soft: if the server is unreachable, unauthenticated, or misconfigured,
every method logs a warning and returns an empty/no-op result instead of
raising, so chat keeps working (just without long-term memory) rather than
breaking entirely.
"""

import base64
import logging
import os
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

import httpx

from core.runtime.runtime import get_runtime
from vault.service import VaultService

logger = logging.getLogger(__name__)

_AGENT_KEYS_SECRET_NAME = "maximos_agent_keys"

# The "Synergy" dual-model collaboration agent has its own isolated Maximos
# pipeline/history like a real character, but deliberately has NO
# VaultCharacter profile/persona -- it's an identity label for memory
# scoping only. Used by callers (HistoryManager/MemoryManager) as the
# literal `character` value for Synergy turns.
SYNERGY_AGENT_ID = "Synergy"


def _discover_global_key() -> Optional[str]:
    """
    Falls back to reading the Maximos Memory Server's own auto-generated
    global API key file when MAXIMOS_GLOBAL_KEY isn't set explicitly -- only
    works when AthenaUI and the memory server run on the same machine.
    """
    appdata = os.getenv("APPDATA")
    if not appdata:
        return None
    key_path = Path(appdata) / "MaximosMemoryServer" / "keys" / "global.key"
    try:
        key = key_path.read_text(encoding="utf-8").strip()
        return key or None
    except OSError:
        return None


class MaximosMemoryClient:
    """
    Client for the Maximos Memory Server HTTP API. One instance is reused
    process-wide (see `get_client()` below) -- it holds a keep-alive
    httpx.Client (no baked-in auth header, since every [user_id][agent_id]
    pair gets its own personal key) plus an in-process cache of minted
    per-agent keys, backed by each user's Vault for persistence across
    AthenaUI restarts.

    Persistence location: a real character's key lives on that character's
    own VaultCharacter record (`maximos_agent_key` field, via
    VaultService.set/get_character_maximos_key) -- it travels with the
    character, not in some unrelated flat blob. Synthetic, characterless
    agent ids (the "global" bucket used when `character=None`, plus
    `SYNERGY_AGENT_ID`) have no VaultCharacter record to live on, so they
    fall back to a flat per-user secret (`maximos_agent_keys`, see
    `_AGENT_KEYS_SECRET_NAME`).
    """

    _GLOBAL_BUCKET_AGENT_ID = "global"
    # Agent ids that are never expected to have a VaultCharacter record --
    # their per-agent key always lives in the flat secret, not on a
    # character profile.
    _FLAT_BUCKET_AGENT_IDS = {_GLOBAL_BUCKET_AGENT_ID, SYNERGY_AGENT_ID}

    def __init__(self, base_url: str, global_key: Optional[str], timeout: float = 10.0):
        self.enabled = bool(global_key)
        self._global_key = global_key or ""
        if not self.enabled:
            logger.warning(
                "Maximos Memory Server global API key not found (set MAXIMOS_GLOBAL_KEY, "
                "or make sure the server has run at least once on this machine to "
                "auto-generate one). Long-term memory is disabled until this is fixed."
            )
        self._client = httpx.Client(base_url=base_url.rstrip("/"), timeout=timeout)
        self._lock = threading.Lock()
        self._agent_key_cache: Dict[Tuple[str, str], str] = {}

    # ---------------------------------------------------------
    # Per-agent key handshake + caching
    # ---------------------------------------------------------
    def _handshake(self, user_id: str, agent_id: str) -> Optional[str]:
        """One-time-per-agent call using the global key to mint (or re-mint,
        after a server restart forgets it) this character's personal key."""
        try:
            resp = self._client.post(
                f"/users/{user_id}/agents/{agent_id}/handshake",
                headers={"Authorization": f"Bearer {self._global_key}"},
            )
            resp.raise_for_status()
            data = resp.json()
        except httpx.HTTPError:
            logger.warning(
                "Maximos handshake failed for user=%s agent=%s", user_id, agent_id, exc_info=True
            )
            return None
        agent_key = data.get("api_key")
        if not agent_key:
            return None
        logger.info(
            "Maximos handshake OK for user=%s agent=%s key_mode=%s pipeline_ready=%s",
            user_id, agent_id, data.get("key_mode"), data.get("pipeline_ready"),
        )
        return agent_key

    def _load_persisted_key(self, user_id: str, agent_id: str) -> Optional[str]:
        """Real characters keep their key on their own VaultCharacter record.
        Characterless agent ids (`_FLAT_BUCKET_AGENT_IDS`) have no character
        record to live on, so they fall back to a flat per-user secret
        instead."""
        if agent_id in self._FLAT_BUCKET_AGENT_IDS:
            keys = VaultService.get_secret(user_id, _AGENT_KEYS_SECRET_NAME)
            return keys.get(agent_id) if isinstance(keys, dict) else None
        return VaultService.get_character_maximos_key(user_id, agent_id)

    def _persist_key(self, user_id: str, agent_id: str, agent_key: str) -> None:
        if agent_id not in self._FLAT_BUCKET_AGENT_IDS:
            if VaultService.set_character_maximos_key(user_id, agent_id, agent_key):
                return
            # Character record didn't exist (shouldn't normally happen) --
            # fall through to the flat store so the minted key isn't lost.
            logger.warning(
                "No VaultCharacter record for user=%s agent=%s -- falling back to flat "
                "key storage; a real character record should exist by the time chat runs.",
                user_id, agent_id,
            )
        keys = VaultService.get_secret(user_id, _AGENT_KEYS_SECRET_NAME)
        keys = keys if isinstance(keys, dict) else {}
        keys[agent_id] = agent_key
        VaultService.set_secret(user_id, _AGENT_KEYS_SECRET_NAME, keys)

    def _get_agent_key(self, user_id: str, agent_id: str) -> Optional[str]:
        """Returns this character's personal API key, minting it via
        handshake (and persisting it) on first use. Cheap on repeat calls --
        checks the in-process cache before the Vault."""
        cache_key = (user_id, agent_id)
        with self._lock:
            cached = self._agent_key_cache.get(cache_key)
        if cached:
            return cached

        persisted = self._load_persisted_key(user_id, agent_id)
        if persisted:
            with self._lock:
                self._agent_key_cache[cache_key] = persisted
            return persisted

        minted = self._handshake(user_id, agent_id)
        if not minted:
            return None
        with self._lock:
            self._agent_key_cache[cache_key] = minted
        self._persist_key(user_id, agent_id, minted)
        return minted

    def _invalidate_agent_key(self, user_id: str, agent_id: str) -> None:
        with self._lock:
            self._agent_key_cache.pop((user_id, agent_id), None)

    def is_reachable(self, timeout: float = 2.0) -> bool:
        """Quick, unauthenticated connectivity check against the server's
        `/health` endpoint. Independent of per-agent keys/handshakes --
        callers use this to tell apart "no results" from "the server is
        actually down" so they can surface a clearer message instead of the
        generic empty-list fail-soft behavior."""
        try:
            resp = self._client.get("/health", timeout=timeout)
            return resp.status_code == 200
        except httpx.HTTPError:
            return False

    def _request_with_agent_key(
        self, method: str, path: str, user_id: str, agent_id: str, json_body: Dict[str, Any]
    ) -> Optional[httpx.Response]:
        """Issues one request authenticated with this character's personal
        key, transparently re-handshaking once if the key was rejected
        (401) -- which happens whenever the server has restarted since the
        key was minted, since it only keeps per-agent keys in memory."""
        agent_key = self._get_agent_key(user_id, agent_id)
        if not agent_key:
            return None

        headers = {"X-Agent-Key": agent_key, "Content-Type": "application/json"}
        resp = self._client.request(method, path, json=json_body, headers=headers)
        if resp.status_code != 401:
            return resp

        logger.info(
            "Maximos per-agent key stale for user=%s agent=%s -- re-handshaking", user_id, agent_id
        )
        self._invalidate_agent_key(user_id, agent_id)
        # NOTE: must call _handshake() directly here, not _get_agent_key().
        # _get_agent_key() checks the Vault-persisted key FIRST -- which is
        # exactly the stale key that just got a 401 -- so calling it again
        # would just re-load and re-try the same bad key forever. A real
        # fresh handshake is required to mint a genuinely new key.
        agent_key = self._handshake(user_id, agent_id)
        if not agent_key:
            return resp
        with self._lock:
            self._agent_key_cache[(user_id, agent_id)] = agent_key
        self._persist_key(user_id, agent_id, agent_key)
        headers = {"X-Agent-Key": agent_key, "Content-Type": "application/json"}
        return self._client.request(method, path, json=json_body, headers=headers)

    # ---------------------------------------------------------
    # Public API
    # ---------------------------------------------------------
    def store_memory(
        self,
        user_id: str,
        agent_id: str,
        content: str,
        *,
        tier: str = "Hot",
        channel: str = "other",
        sender: Optional[str] = None,
        receiver: Optional[str] = None,
        created_at: Optional[str] = None,
        source_entry_ids: Optional[List[str]] = None,
    ) -> Optional[str]:
        """Stores a new memory entry for this user/character. Returns the
        generated entry id, or None if the write failed/was skipped.
        `created_at` lets a caller pin the entry to a specific timestamp
        (e.g. an "agent summary" entry timestamped to the ORIGINAL
        interaction it summarizes) instead of always using "now".
        `source_entry_ids` records which raw entries (if any) this entry
        summarizes/references, for later verbatim lookup via `get_memory`."""
        if not self.enabled:
            return None
        now = created_at or datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        entry_id = str(uuid.uuid4())
        payload = {
            "id": entry_id,
            "content": content,
            "tier": tier,
            "created_at": now,
            "updated_at": now,
            "searchable": True,
            "encrypted": False,
            "channel": channel,
            "sender": sender,
            "receiver": receiver,
            "source_entry_ids": source_entry_ids or [],
            "origin_install": self._origin_install_name(user_id),
        }
        try:
            resp = self._request_with_agent_key(
                "POST", f"/users/{user_id}/agents/{agent_id}/memories", user_id, agent_id, payload
            )
            if resp is None:
                return None
            resp.raise_for_status()
            return entry_id
        except httpx.HTTPError:
            logger.warning(
                "Maximos store_memory failed for user=%s agent=%s", user_id, agent_id, exc_info=True
            )
            return None

    @staticmethod
    def _origin_install_name(user_id: str) -> Optional[str]:
        """Best-effort machine name this entry is being written from (e.g.
        "Lab Laptop"), stamped onto every stored entry so a memory synced
        across installs via Athena Link can still be traced back to where
        it was first written. Lazy import to dodge any import-order issues
        (same pattern athena_link.service.py itself uses for this module in
        reverse); never fails the write if this lookup itself fails."""
        try:
            from athena_link.service import AthenaLinkService

            return AthenaLinkService.get_install_name(user_id)
        except Exception:
            logger.warning("Could not resolve install name for %s", user_id, exc_info=True)
            return None

    def backup_agent(self, user_id: str, agent_id: str, passphrase: str) -> Optional[bytes]:
        """Asks the Maximos Memory Server to build an encrypted proprietary
        backup (".mxbak") of every memory entry it holds for this
        user/character, encrypted with a key derived from `passphrase`.
        Returns the raw (already-encrypted) backup bytes, or None if the
        server is unreachable/unauthorized/failed -- used by AthenaUI's own
        full-system backup (backup/service.py) to bundle a character's chat
        history into the same archive, without the user ever needing to
        open the Maximos Memory Server app directly."""
        if not self.enabled:
            return None
        try:
            resp = self._request_with_agent_key(
                "POST",
                f"/users/{user_id}/agents/{agent_id}/backup",
                user_id,
                agent_id,
                {"passphrase": passphrase},
            )
            if resp is None or resp.status_code >= 400:
                return None
            data = resp.json()
            b64 = data.get("backup_base64")
            if not b64:
                return None
            return base64.b64decode(b64)
        except (httpx.HTTPError, ValueError):
            logger.warning(
                "Maximos backup_agent failed for user=%s agent=%s", user_id, agent_id, exc_info=True
            )
            return None

    def restore_agent(self, user_id: str, agent_id: str, backup_bytes: bytes, passphrase: str) -> Optional[int]:
        """Restores a previously-produced ".mxbak" blob (as returned by
        `backup_agent`) into this user/character's memory on the Maximos
        Memory Server, decrypting with `passphrase`. Returns the number of
        restored entries, or None if the restore failed (wrong passphrase,
        corrupted blob, server unreachable, or privacy-mode blocked)."""
        if not self.enabled:
            return None
        try:
            payload = {
                "backup_base64": base64.b64encode(backup_bytes).decode("ascii"),
                "passphrase": passphrase,
            }
            resp = self._request_with_agent_key(
                "POST", f"/users/{user_id}/agents/{agent_id}/restore", user_id, agent_id, payload
            )
            if resp is None or resp.status_code >= 400:
                return None
            data = resp.json()
            return int(data.get("restored_count") or 0)
        except (httpx.HTTPError, ValueError):
            logger.warning(
                "Maximos restore_agent failed for user=%s agent=%s", user_id, agent_id, exc_info=True
            )
            return None

    def search(
        self, user_id: str, agent_id: str, text: str, *, limit: int = 5, channel: Union[str, Sequence[str], None] = None,
        oldest_first: bool = False,
    ) -> List[Dict[str, Any]]:
        """Returns memory entries for this user/character whose content
        matches `text`, or an empty list on failure/no matches. An empty/
        blank `text` is a deliberate "give me recent memories" request (the
        server treats an empty needle as matching everything) -- it must
        NOT short-circuit here like a missing/invalid query would, or every
        blank-query search silently returns nothing regardless of what's
        actually stored. Pass `channel` (a single canonical channel, or a
        list of them) to restrict results to those channels; omit it
        (default) to search across every channel this agent has ever
        recorded, private and group alike. Pass `oldest_first=True` to get
        the EARLIEST matching entries instead of the most recent (e.g.
        "what's your oldest memory?") -- the server sorts each channel's
        results oldest-first, and the final cross-channel merge below
        re-sorts/truncates to match.
        """
        if not self.enabled:
            return []

        if channel is None:
            channels: List[Optional[str]] = [None]
        elif isinstance(channel, str):
            channels = [channel]
        else:
            channels = list(channel)

        entries: List[Dict[str, Any]] = []
        seen_ids: set[str] = set()
        try:
            for channel_name in channels:
                payload: Dict[str, Any] = {"text": text, "limit": limit, "oldest_first": oldest_first}
                if channel_name:
                    payload["channel"] = channel_name

                resp = self._request_with_agent_key(
                    "POST",
                    f"/users/{user_id}/agents/{agent_id}/search",
                    user_id,
                    agent_id,
                    payload,
                )
                if resp is None:
                    continue
                resp.raise_for_status()

                for entry in resp.json().get("entries", []):
                    entry_id = str(entry.get("id") or "")
                    if entry_id and entry_id in seen_ids:
                        continue
                    if entry_id:
                        seen_ids.add(entry_id)
                    entries.append(entry)

            entries.sort(key=lambda e: str(e.get("created_at") or ""), reverse=not oldest_first)
            return entries[:limit]
        except httpx.HTTPError:
            logger.warning(
                "Maximos search failed for user=%s agent=%s", user_id, agent_id, exc_info=True
            )
            return []

    # ---------------------------------------------------------
    # System-wide post-it board (NOT per-agent isolated -- every agent on
    # the system can read every post; only the original author agent may
    # edit/delete its own post, enforced server-side).
    # ---------------------------------------------------------
    def list_board(self, user_id: str, agent_id: str) -> List[Dict[str, Any]]:
        """Returns every post currently on the system-wide post-it board,
        newest first, or an empty list on failure. `agent_id` is only used
        to authenticate the request -- the returned posts are not scoped
        to it."""
        if not self.enabled:
            return []
        try:
            resp = self._request_with_agent_key(
                "GET", f"/users/{user_id}/agents/{agent_id}/board/posts", user_id, agent_id, {}
            )
            if resp is None:
                return []
            resp.raise_for_status()
            return resp.json()
        except httpx.HTTPError:
            logger.warning(
                "Maximos list_board failed for user=%s agent=%s", user_id, agent_id, exc_info=True
            )
            return []

    def post_to_board(self, user_id: str, agent_id: str, content: str) -> Optional[Dict[str, Any]]:
        """Creates a new board post attributed to `agent_id`, visible to
        every agent on the system. Returns the created post, or None on
        failure."""
        if not self.enabled or not content.strip():
            return None
        try:
            resp = self._request_with_agent_key(
                "POST",
                f"/users/{user_id}/agents/{agent_id}/board/posts",
                user_id,
                agent_id,
                {"content": content},
            )
            if resp is None:
                return None
            resp.raise_for_status()
            return resp.json()
        except httpx.HTTPError:
            logger.warning(
                "Maximos post_to_board failed for user=%s agent=%s", user_id, agent_id, exc_info=True
            )
            return None

    def edit_board_post(
        self, user_id: str, agent_id: str, post_id: str, content: str
    ) -> Optional[Dict[str, Any]]:
        """Edits an existing board post's content. Only succeeds if
        `agent_id` is that post's original author (enforced server-side,
        403 otherwise). Returns the updated post, or None on failure."""
        if not self.enabled or not content.strip():
            return None
        try:
            resp = self._request_with_agent_key(
                "PUT",
                f"/users/{user_id}/agents/{agent_id}/board/posts/{post_id}",
                user_id,
                agent_id,
                {"content": content},
            )
            if resp is None:
                return None
            resp.raise_for_status()
            return resp.json()
        except httpx.HTTPError:
            logger.warning(
                "Maximos edit_board_post failed for user=%s agent=%s post=%s",
                user_id, agent_id, post_id, exc_info=True,
            )
            return None

    def delete_board_post(self, user_id: str, agent_id: str, post_id: str) -> bool:
        """Deletes an existing board post. Only succeeds if `agent_id` is
        that post's original author (enforced server-side, 403 otherwise)."""
        if not self.enabled:
            return False
        try:
            resp = self._request_with_agent_key(
                "DELETE",
                f"/users/{user_id}/agents/{agent_id}/board/posts/{post_id}",
                user_id,
                agent_id,
                {},
            )
            if resp is None:
                return False
            resp.raise_for_status()
            return True
        except httpx.HTTPError:
            logger.warning(
                "Maximos delete_board_post failed for user=%s agent=%s post=%s",
                user_id, agent_id, post_id, exc_info=True,
            )
            return False

    # ---------------------------------------------------------
    # Raw chat turns (replaces Redis short-term history + Vault chat_history)
    # ---------------------------------------------------------
    def store_chat_turn(
        self, user_id: str, agent_id: str, role: str, content: str, *, channel: str = "private_message",
        created_at: Optional[str] = None,
    ) -> Optional[str]:
        """Stores one literal 1:1 chat turn (a real message, not an extracted
        long-term "fact") in this character's own pipeline. `role` is
        "user" or "assistant" -- recorded via `sender`/`receiver` so it can
        be reconstructed later by `load_recent_chat_turns`. Only valid for
        genuinely two-party (human <-> this character) conversations -- for
        multi-party group chat turns, use `store_group_turn` instead, which
        preserves the true speaker's identity rather than collapsing every
        non-self line to the human user."""
        sender = user_id if role == "user" else agent_id
        receiver = agent_id if role == "user" else user_id
        return self.store_memory(
            user_id, agent_id, content, channel=channel, sender=sender, receiver=receiver, created_at=created_at
        )

    def store_group_turn(
        self, user_id: str, agent_id: str, speaker_name: str, content: str, *, channel: str,
        created_at: Optional[str] = None,
    ) -> Optional[str]:
        """Stores one group-chat turn in `agent_id`'s own pipeline, tagging
        `sender` with the TRUE speaker's name -- which may be the human user
        (their display name) or another character entirely, not just
        `agent_id`/`user_id`. This is what lets a later reader (e.g. private
        chat's group-activity awareness block) correctly attribute a line to
        whoever actually said it, instead of every non-self speaker being
        indistinguishable from the human user."""
        return self.store_memory(
            user_id, agent_id, content, channel=channel, sender=speaker_name, receiver=agent_id, created_at=created_at
        )

    def get_memory(self, user_id: str, agent_id: str, entry_id: str) -> Optional[Dict[str, Any]]:
        """Fetches one raw memory entry by id -- used to retrieve the exact
        original exchange an "agent summary" entry's `source_entry_ids`
        points to, for verbatim quoting. Returns None on failure/not found."""
        if not self.enabled:
            return None
        try:
            resp = self._request_with_agent_key(
                "GET", f"/users/{user_id}/agents/{agent_id}/memories/{entry_id}", user_id, agent_id, {}
            )
            if resp is None or resp.status_code == 404:
                return None
            resp.raise_for_status()
            return resp.json()
        except httpx.HTTPError:
            logger.warning(
                "Maximos get_memory failed for user=%s agent=%s id=%s", user_id, agent_id, entry_id, exc_info=True
            )
            return None

    def load_recent_chat_turns(
        self,
        user_id: str,
        agent_id: str,
        *,
        limit: int = 50,
        channel: Union[str, Sequence[str], None] = None,
        include_sender: bool = False,
    ) -> List[Dict[str, str]]:
        """Returns the most recent `limit` chat turns for this character, in
        chronological (oldest-first) order, as `{"role", "content"}` dicts
        ready to feed straight into an LLM message list. Empty on
        failure/no history -- callers should treat that the same as "no
        history yet".

        `role` collapses every non-`user_id` sender down to "assistant" --
        correct for LLM prompting (the model only needs to know "me" vs
        "not me"), but lossy for display: a group-chat line said by a
        DIFFERENT character than `agent_id` also gets `role="assistant"`,
        indistinguishable from this character's own reply. Pass
        `include_sender=True` (used by the UI-facing chat history endpoint,
        not by ChatEngine's own LLM-context builder) to also get the true
        `sender` string (the real speaker's username/display name/character
        name) on each turn dict, so a caller can attribute it correctly."""
        if not self.enabled:
            return []
        try:
            entries: List[Dict[str, Any]] = []
            seen_ids: set[str] = set()

            if channel is None:
                channels: List[Optional[str]] = [None]
            elif isinstance(channel, str):
                channels = [channel]
            else:
                channels = list(channel)

            for channel_name in channels:
                payload: Dict[str, Any] = {"text": "", "limit": limit}
                if channel_name:
                    payload["channel"] = channel_name

                resp = self._request_with_agent_key(
                    "POST",
                    f"/users/{user_id}/agents/{agent_id}/search",
                    user_id,
                    agent_id,
                    payload,
                )
                if resp is None:
                    continue
                resp.raise_for_status()

                for entry in resp.json().get("entries", []):
                    entry_id = str(entry.get("id") or "")
                    if entry_id and entry_id in seen_ids:
                        continue
                    if entry_id:
                        seen_ids.add(entry_id)
                    entries.append(entry)

            entries.sort(key=lambda e: str(e.get("created_at") or ""), reverse=True)
            entries = entries[:limit]
        except httpx.HTTPError:
            logger.warning(
                "Maximos load_recent_chat_turns failed for user=%s agent=%s", user_id, agent_id, exc_info=True
            )
            return []

        # Re-sort ascending (chronological) instead of blindly reversing the
        # descending list above -- a plain reverse() trusts that entries
        # sharing the exact same created_at (a real occurrence: the server
        # trusts whatever timestamp the client sent, and Hot-tier iteration
        # order feeding that sort is explicitly NOT chronological) end up in
        # the right relative order, which isn't guaranteed. Tiebreak equal
        # timestamps by role so the user's message always sorts before the
        # assistant's reply to it, never after.
        entries.sort(key=lambda e: (str(e.get("created_at") or ""), 0 if e.get("sender") == user_id else 1))
        turns: List[Dict[str, str]] = []
        for e in entries:
            content = e.get("content")
            if not content:
                continue
            role = "user" if e.get("sender") == user_id else "assistant"
            turn = {
                "role": role,
                "content": str(content),
                "timestamp": str(e.get("created_at") or ""),
            }
            if include_sender:
                turn["sender"] = str(e.get("sender") or "")
            turns.append(turn)
        return turns

    def clear_recent_chat_turns(
        self,
        user_id: str,
        agent_id: str,
        *,
        channel: Union[str, Sequence[str], None] = None,
        cap: int = 1000,
    ) -> int:
        """Best-effort clear: the server has no bulk/filtered delete, only
        delete-by-key, so this fetches up to `cap` matching entries and
        deletes them one at a time. Returns the number actually deleted."""
        if not self.enabled:
            return 0
        try:
            entries: List[Dict[str, Any]] = []
            seen_ids: set[str] = set()

            if channel is None:
                channels: List[Optional[str]] = [None]
            elif isinstance(channel, str):
                channels = [channel]
            else:
                channels = list(channel)

            for channel_name in channels:
                payload: Dict[str, Any] = {"text": "", "limit": cap}
                if channel_name:
                    payload["channel"] = channel_name

                resp = self._request_with_agent_key(
                    "POST",
                    f"/users/{user_id}/agents/{agent_id}/search",
                    user_id,
                    agent_id,
                    payload,
                )
                if resp is None:
                    continue
                resp.raise_for_status()

                for entry in resp.json().get("entries", []):
                    entry_id = str(entry.get("id") or "")
                    if entry_id and entry_id in seen_ids:
                        continue
                    if entry_id:
                        seen_ids.add(entry_id)
                    entries.append(entry)
        except httpx.HTTPError:
            logger.warning(
                "Maximos clear_recent_chat_turns search failed for user=%s agent=%s", user_id, agent_id, exc_info=True
            )
            return 0

        deleted = 0
        for e in entries:
            entry_id = e.get("id")
            if not entry_id:
                continue
            try:
                resp = self._request_with_agent_key(
                    "DELETE",
                    f"/users/{user_id}/agents/{agent_id}/memories/{entry_id}",
                    user_id,
                    agent_id,
                    {},
                )
                if resp is not None and resp.status_code < 400:
                    deleted += 1
            except httpx.HTTPError:
                continue
        return deleted

    def purge_user(self, user_id: str) -> bool:
        """
        Permanently deletes ALL memory (every character's chat history and
        long-term memory, across Hot/Warm/Cold) for this user from the
        Maximos Memory Server, plus every per-agent key minted for them.

        Called when an AthenaUI account is deleted so no chat history
        carries over to a future account created with the same username.
        This is an account-wide admin operation (unlike every other method
        on this client), so it authenticates with the global service key,
        never a per-agent key. Fails soft, like the rest of this client: if
        the server is unreachable, returns False and logs a warning rather
        than raising, so account deletion in AthenaUI itself never blocks on
        this.
        """
        if not self.enabled:
            return False
        try:
            resp = self._client.request(
                "DELETE",
                f"/users/{user_id}",
                headers={"Authorization": f"Bearer {self._global_key}"},
            )
            resp.raise_for_status()
        except httpx.HTTPError:
            logger.warning("Maximos purge_user failed for user=%s", user_id, exc_info=True)
            return False

        with self._lock:
            for cache_key in [k for k in self._agent_key_cache if k[0] == user_id]:
                self._agent_key_cache.pop(cache_key, None)
        return True


_client: Optional[MaximosMemoryClient] = None


def get_client() -> MaximosMemoryClient:
    """Returns the process-wide shared MaximosMemoryClient, built lazily from
    runtime env config on first use."""
    global _client
    if _client is None:
        runtime = get_runtime()
        base_url = runtime.env.MAXIMOS_URL or "http://127.0.0.1:7842"
        api_key = runtime.env.MAXIMOS_GLOBAL_KEY or _discover_global_key()
        _client = MaximosMemoryClient(base_url, api_key)
    return _client
