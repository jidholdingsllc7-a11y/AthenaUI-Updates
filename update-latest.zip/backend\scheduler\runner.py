# AthenaUI v3.5 — Scheduler Background Runner
# File: backend/scheduler/runner.py
#
# A single global asyncio loop (started once from main.py's startup event)
# that wakes up periodically, scans EVERY registered user's persisted job
# list (not just an in-memory dict -- see scheduler/service.py's docstring)
# for "approved" jobs whose run_at has arrived, and executes them by asking
# the owning character to carry out their own pre-approved task_description
# via a trusted `role:"system"` authorization message -- mirroring the exact
# framing fix already used by brokerage/task_manager.py's per-cycle
# evaluation prompt.
#
# Because this loop re-scans disk state on every tick (rather than relying
# on in-memory asyncio.Task objects created at "start time"), a job that was
# approved and then the backend got restarted (crash, manual relaunch,
# Windows update, etc.) will still run once this loop starts back up and
# notices its run_at has passed -- there is no separate "reschedule on
# startup" step to forget.
#
# WINDOWS SLEEP/LOCK CAVEAT (see api/routes/scheduler.py's /scheduler/power
# endpoint and the frontend's warning copy): locking the screen (Win+L) does
# NOT pause this loop -- background processes keep running fine through a
# lock screen. Closing a laptop lid, however, by default triggers Windows to
# SUSPEND THE WHOLE MACHINE (all processes, not just this one), which
# SetThreadExecutionState below cannot override -- only Windows' own power
# plan setting ("When I close the lid" -> "Do nothing") can. This loop calls
# SetThreadExecutionState purely to stop *idle-timeout* sleep while jobs are
# pending; it is a best-effort mitigation, not a guarantee.

from __future__ import annotations

import asyncio
import json
import logging
import sys
from datetime import datetime, timezone
from typing import Optional

from scheduler import service as scheduler_service
from users.service import UserService

logger = logging.getLogger(__name__)

POLL_SECONDS = 30

_keep_awake_active = False


def _set_keep_awake(active: bool) -> None:
    """Best-effort: prevents Windows *idle-timeout* sleep while there are
    pending/approved jobs. Does NOT reliably survive an explicit lid-close
    sleep event -- see module docstring."""
    global _keep_awake_active
    if sys.platform != "win32" or active == _keep_awake_active:
        return
    try:
        import ctypes
        ES_CONTINUOUS = 0x80000000
        ES_SYSTEM_REQUIRED = 0x00000001
        flags = (ES_CONTINUOUS | ES_SYSTEM_REQUIRED) if active else ES_CONTINUOUS
        ctypes.windll.kernel32.SetThreadExecutionState(flags)  # type: ignore[attr-defined]
        _keep_awake_active = active
    except Exception as e:
        logger.warning(f"Scheduler keep-awake call failed: {e}")


async def _execute_job(job: dict) -> None:
    from chat.engine.service import ChatEngine  # local import: avoid any import-order cycles at startup

    username = job["username"]
    character = job["character"]
    job_id = job["job_id"]

    verdict, detail = await _condition_ready(job, username)
    if verdict == "wait":
        return  # dependency job hasn't reached a terminal status yet -- retry next tick
    if verdict == "skip":
        logger.info(f"Scheduled job {job_id} for {username}/{character} skipped: {detail}")
        scheduler_service.mark_skipped(username, job_id, detail or "Condition not met.")
        scheduler_service.append_log(
            username,
            job.get("log_file"),
            f"- [{datetime.now(timezone.utc).isoformat()}] Job {job_id} SKIPPED (condition not met): {detail}",
        )
        return

    if job.get("validate_brokerage") or job.get("dry_run"):
        ok, validation_detail = await _validate_brokerage_preconditions(username, job)
        scheduler_service.append_log(
            username,
            job.get("log_file"),
            f"- [{datetime.now(timezone.utc).isoformat()}] Job {job_id} PRE-EXECUTION VALIDATION "
            f"({'passed' if ok else 'FAILED'}): {validation_detail}",
        )
        if not ok:
            scheduler_service.mark_result(username, job_id, ok=False, error=validation_detail)
            return
        if job.get("dry_run"):
            scheduler_service.mark_result(
                username, job_id, ok=True,
                result=f"DRY RUN -- validation passed, no live action was taken. {validation_detail}",
            )
            return

    prompt = (
        "You are now executing a scheduled task that YOU proposed earlier and that the user "
        "explicitly reviewed and approved in advance via the Scheduler permission popup. This is "
        "real, standing authorization for exactly what you described below -- it does not need "
        "fresh confirmation, and the user may not be actively chatting right now.\n\n"
        f"Your own task description (what you said you'd do): {job.get('task_description')}\n"
        f"Your own reasoning when you scheduled this: {job.get('reasoning')}\n"
        f"You estimated needing about {job.get('estimated_turns')} step(s) -- act efficiently and "
        "give a clear final summary of what you did (or why you decided not to act)."
    )

    trace: list = []
    try:
        engine = ChatEngine(username=username)
        result = await engine.chat_with_billing_fallback(
            messages=[{"role": "system", "content": prompt}],
            character=character,
            tool_trace=trace,
        )
        reply = result.get("reply") if isinstance(result, dict) else None
        scheduler_service.mark_result(username, job_id, ok=True, result=reply)
        scheduler_service.append_log(
            username,
            job.get("log_file"),
            f"- [{datetime.now(timezone.utc).isoformat()}] Job {job_id} EXECUTED (success):\n"
            f"{_format_trace(trace)}"
            f"  Final summary: {(reply or '').strip()[:800]}",
        )
    except Exception as e:
        logger.error(f"Scheduled job {job_id} for {username}/{character} failed: {e}")
        scheduler_service.mark_result(username, job_id, ok=False, error=str(e))
        scheduler_service.append_log(
            username,
            job.get("log_file"),
            f"- [{datetime.now(timezone.utc).isoformat()}] Job {job_id} FAILED:\n"
            f"{_format_trace(trace)}"
            f"  Error: {e}",
        )


def _format_trace(trace: list) -> str:
    """Renders each tool call made during a scheduled job's execution
    (research calls, order placement, etc.) as an indented markdown block --
    the 'granular logging' the log file is meant to capture, not just the
    final one-line summary."""
    if not trace:
        return ""
    lines = []
    for i, step in enumerate(trace, start=1):
        args_str = json.dumps(step.get("arguments"), default=str)[:400]
        result_str = json.dumps(step.get("result"), default=str)[:600]
        lines.append(f"  Step {i}: {step.get('tool')}(args={args_str})\n    -> {result_str}")
    return "\n".join(lines) + "\n"


async def _condition_ready(job: dict, username: str) -> tuple:
    """Resolves a job's optional dependency (`depends_on_job_id` +
    `condition`) into one of: ('proceed', None), ('wait', None) -- the
    dependency hasn't reached a terminal status yet, retry next tick -- or
    ('skip', reason) -- the condition was NOT met, so this job must never
    actually execute."""
    dep_id = job.get("depends_on_job_id")
    if not dep_id:
        return ("proceed", None)

    dep = scheduler_service.get_job(username, dep_id)
    if not dep:
        return ("skip", f"Dependency job {dep_id} no longer exists.")

    dep_status = dep.get("status")
    if dep_status in ("awaiting_approval", "approved"):
        return ("wait", None)
    if dep_status in ("rejected", "cancelled", "skipped"):
        return ("skip", f"Dependency job was {dep_status}, so this job's condition can never be met.")
    if dep_status == "failed":
        return ("skip", "Dependency job failed, so this job's condition was not met.")

    # dep_status == "completed" from here on
    condition = job.get("condition") or "prior_success"
    if condition == "prior_success":
        return ("proceed", None)

    if condition == "prior_success_and_position_open":
        symbol = job.get("condition_symbol")
        if not symbol:
            return ("skip", "condition_symbol was not set -- cannot verify position.")
        ok, detail = await _is_position_open(username, symbol)
        if ok is None:
            return ("skip", detail)
        return ("proceed", None) if ok else ("skip", detail)

    return ("proceed", None)


async def _is_position_open(username: str, symbol: str):
    """Returns (True/False/None, detail). None means the check itself
    couldn't be performed (e.g. no credentials) -- callers should treat that
    as 'skip', not 'proceed', since we can't confirm the condition holds."""
    try:
        from brokerage import settings as brokerage_settings
        from brokerage.alpaca_client import AlpacaClient

        mode = brokerage_settings.get_active_mode(username)
        creds = brokerage_settings.get_credentials(username, mode)
        if not creds:
            return (None, f"No Alpaca {mode} credentials configured -- cannot verify position.")

        client = AlpacaClient(creds["api_key"], creds["secret"], mode=mode)
        positions = await client.get_positions()
        is_open = any(
            str(p.get("symbol", "")).upper() == symbol.upper() and float(p.get("qty", 0)) != 0
            for p in positions
        )
        return (True, f"Position in {symbol} is open.") if is_open else (False, f"No open position in {symbol} -- sell condition not met.")
    except Exception as e:
        return (None, f"Could not verify position for {symbol}: {e}")


async def _validate_brokerage_preconditions(username: str, job: dict):
    """Lightweight pre-execution check (item 3 from Orion's feedback):
    confirms the account is still in the SAME paper/live mode it was in when
    this job was scheduled, and -- if the job supplied a rough
    `notional_estimate` -- that current buying power covers it. Returns
    (ok: bool, detail: str)."""
    try:
        from brokerage import settings as brokerage_settings
        from brokerage.alpaca_client import AlpacaClient

        current_mode = brokerage_settings.get_active_mode(username)
        expected_mode = job.get("expected_mode")
        if expected_mode and expected_mode != current_mode:
            return (False, f"Trading mode changed from '{expected_mode}' (at schedule time) to "
                           f"'{current_mode}' -- refusing to run automatically for safety. Cancel and "
                           f"reschedule if this is intentional.")

        creds = brokerage_settings.get_credentials(username, current_mode)
        if not creds:
            return (False, f"No Alpaca {current_mode} credentials configured.")

        client = AlpacaClient(creds["api_key"], creds["secret"], mode=current_mode)
        account = await client.get_account()
        if account.get("trading_blocked") or account.get("account_blocked"):
            return (False, f"Account is blocked (trading_blocked={account.get('trading_blocked')}, "
                           f"account_blocked={account.get('account_blocked')}).")

        buying_power = float(account.get("buying_power") or 0)
        notional_estimate = job.get("notional_estimate")
        if notional_estimate and buying_power < float(notional_estimate):
            return (False, f"Insufficient buying power: ${buying_power:.2f} available, "
                           f"${float(notional_estimate):.2f} estimated needed.")

        return (True, f"mode={current_mode}, buying_power=${buying_power:.2f}")
    except Exception as e:
        return (False, f"Pre-execution validation failed: {e}")


async def _tick() -> None:
    now = datetime.now(timezone.utc)
    any_open = False

    for username in UserService._load_registered_usernames():
        try:
            scheduler_service.prune_expired_awaiting_approval_jobs(username)
            jobs = scheduler_service.list_jobs(username)
        except Exception as e:
            logger.warning(f"Scheduler: could not read jobs for {username}: {e}")
            continue

        for job in jobs:
            status = job.get("status")
            if status in ("awaiting_approval", "approved"):
                any_open = True
            if status != "approved":
                continue
            try:
                run_at = scheduler_service.parse_iso(job["run_at"])
            except Exception:
                continue
            if now >= run_at:
                await _execute_job(job)

    _set_keep_awake(any_open)


async def run_scheduler_loop() -> None:
    """Runs forever (until the process exits) -- started as a fire-and-forget
    asyncio.create_task() from main.py's @app.on_event("startup") hook."""
    logger.info("Scheduler background loop starting.")
    while True:
        try:
            await _tick()
        except Exception as e:
            logger.error(f"Scheduler loop tick failed: {e}")
        await asyncio.sleep(POLL_SECONDS)
