# AthenaUI v3.5 — Interaction Summarizer
# File: backend/chat/memory/summarizer.py
"""
Generates a short, searchable summary of a single interaction (one user
message + one agent reply) for the "agent summary" long-term recall layer
(see MemoryManager.append_summary/recall_summaries). Summaries are always
timestamped by the CALLER to the user's original message -- not to when the
summary itself was generated -- so date-based recall ("did we talk about X
a few months ago?") lines up with when the exchange actually happened.

Best-effort only: any failure here (bad provider/model, network error,
malformed response) is caught and returns None so a broken summarizer call
never breaks the actual chat turn that triggered it.
"""

import logging
from typing import Optional

from llm.retry import call_with_retry
from llm.router_selector.router_selector import RouterSelector

logger = logging.getLogger(__name__)

_SUMMARY_SYSTEM_PROMPT = (
    "You summarize a single chat exchange in ONE short sentence (max ~30 "
    "words) capturing the specific topic, question, decision, or fact "
    "involved -- written so it can be found again later by keyword search "
    "(e.g. \"User asked about refinancing their car loan; agent explained "
    "the pros and cons.\"). Reply with ONLY the summary sentence, nothing else."
)

# Keeps the summarization call itself cheap/fast regardless of how long the
# actual exchange was.
_MAX_INPUT_CHARS = 4000


async def summarize_interaction(
    provider_id: str, model_id: str, user_text: str, reply_text: str
) -> Optional[str]:
    user_text = (user_text or "").strip()
    reply_text = (reply_text or "").strip()
    if not user_text or not reply_text:
        return None

    try:
        router = RouterSelector().select(provider_id=provider_id, model_id=model_id, mode="chat")
        response = await call_with_retry(
            router.chat,
            [
                {"role": "system", "content": _SUMMARY_SYSTEM_PROMPT},
                {
                    "role": "user",
                    "content": (
                        f"User said: {user_text[:_MAX_INPUT_CHARS]}\n\n"
                        f"Agent replied: {reply_text[:_MAX_INPUT_CHARS]}"
                    ),
                },
            ],
            max_tokens=80,
        )
        if not isinstance(response, dict):
            return None
        # Lazy import to avoid a circular import at module load time --
        # chat.engine.service imports chat.memory.service, which imports
        # this module, so importing ChatEngine back at the top of this
        # file would fail while chat.engine.service is still loading.
        from chat.engine.service import ChatEngine
        text = ChatEngine._normalize_assistant_text(response)
        return text.strip() or None
    except Exception:
        logger.warning(
            "Interaction summarization failed (provider=%s model=%s)", provider_id, model_id, exc_info=True
        )
        return None
