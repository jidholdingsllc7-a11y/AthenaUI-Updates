# AthenaUI — Athena Link: athena-directory Worker HTTP client
# File: backend/athena_link/directory_client.py
# Created: 2026-11-02 11:18 CST
# Updated: 2026-11-02 11:18 CST
#
# Thin HTTP client for the deployed "athena-directory" Cloudflare Worker
# (see athena-directory-worker/ project + _dev_notes/athenaui-directory-
# worker.md). This Worker is a PURE lookup/DNS directory -- it never sees
# passphrases or private keys, only public keys, public salts, and signed
# messages. Mirrors the error-handling shape of licensing/client.py
# (distinct "unreachable" vs "valid but rejected" exceptions).

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import requests

logger = logging.getLogger(__name__)

DIRECTORY_BASE_URL = "https://athena-directory.autumn-bread-543a.workers.dev"
_TIMEOUT_SECONDS = 10


class DirectoryUnreachableError(Exception):
    """The Worker could not be reached at all (network/DNS/timeout)."""


class DirectoryClientError(Exception):
    """The Worker responded, but rejected the request (4xx/5xx)."""

    def __init__(self, message: str, status_code: int):
        super().__init__(message)
        self.status_code = status_code


def _request(method: str, path: str, json_body: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    url = f"{DIRECTORY_BASE_URL}{path}"
    try:
        resp = requests.request(method, url, json=json_body, timeout=_TIMEOUT_SECONDS)
    except requests.RequestException as e:
        logger.warning("Athena Link directory request failed: %s %s -> %s", method, path, e)
        raise DirectoryUnreachableError(str(e)) from e

    try:
        data = resp.json()
    except ValueError:
        data = {}

    if resp.status_code >= 400:
        message = str(data.get("error") or f"Directory request failed ({resp.status_code})")
        raise DirectoryClientError(message, resp.status_code)

    return data


def get_salt(username: str) -> Dict[str, Any]:
    """GET /salt/{username} -- public; reserves the username with a fresh
    salt if unclaimed, or returns the existing salt if already claimed."""
    return _request("GET", f"/salt/{username}")


def register(username: str, public_key_b64: str) -> Dict[str, Any]:
    """POST /register {username, public_key} -- finalizes/claims the
    username with this install's derived public key. Idempotent if the
    same key is re-sent; raises DirectoryClientError(status=409) if a
    DIFFERENT key already claimed this username (wrong passphrase, or the
    username belongs to someone else)."""
    return _request("POST", "/register", {"username": username, "public_key": public_key_b64})


def heartbeat(username: str, install_id: str, address: str, timestamp: int, signature_b64: str) -> Dict[str, Any]:
    """POST /heartbeat -- signed. Updates this install's address/last_seen."""
    return _request(
        "POST",
        "/heartbeat",
        {
            "username": username,
            "install_id": install_id,
            "address": address,
            "timestamp": timestamp,
            "signature": signature_b64,
        },
    )


def resolve(username: str) -> Dict[str, Any]:
    """GET /resolve/{username} -- public. Returns every known install for
    this username (sorted most-recently-seen first) plus a `best_address`
    convenience field."""
    return _request("GET", f"/resolve/{username}")


def create_team(
    username: str, name: str, shared_directory_path: str, timestamp: int, signature_b64: str
) -> Dict[str, Any]:
    return _request(
        "POST",
        "/teams",
        {
            "username": username,
            "name": name,
            "shared_directory_path": shared_directory_path,
            "timestamp": timestamp,
            "signature": signature_b64,
        },
    )


def invite_member(
    team_id: str, username: str, invite_username: str, timestamp: int, signature_b64: str
) -> Dict[str, Any]:
    return _request(
        "POST",
        f"/teams/{team_id}/invite",
        {
            "username": username,
            "invite_username": invite_username,
            "timestamp": timestamp,
            "signature": signature_b64,
        },
    )


def remove_member(
    team_id: str, target_username: str, username: str, timestamp: int, signature_b64: str
) -> Dict[str, Any]:
    return _request(
        "POST",
        f"/teams/{team_id}/members/{target_username}/remove",
        {"username": username, "timestamp": timestamp, "signature": signature_b64},
    )
