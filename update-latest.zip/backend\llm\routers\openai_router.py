﻿# AthenaUI v3.5 — OpenAI Router
# File: backend/llm/routers/openai_router.py
# Created: 2026-03-28 20:31 CDT
# Updated: 2026-07-27 19:49 CDT

import requests
from typing import Any, Dict, List, Optional

from llm.routers.base import (
    BaseLLMRouter,
    raise_for_openai_compatible_image_response,
    model_rejects_custom_temperature,
    model_requires_responses_api,
)
from llm.routers.openai_responses_adapter import (
    to_responses_input,
    to_responses_tools,
    from_responses_output,
)
from llm.routers.providers import PROVIDER_OPENAI
from core.runtime.runtime import get_runtime


class OpenAIRouter(BaseLLMRouter):
    """
    Provider-specific router for OpenAI's Chat Completions API.
    Supports:
    - chat
    - tool calling (OpenAI v2)
    - images
    - streaming (stub)
    """

    API_URL = "https://api.openai.com/v1/chat/completions"
    RESPONSES_API_URL = "https://api.openai.com/v1/responses"
    IMAGE_URL = "https://api.openai.com/v1/images/generations"
    IMAGE_EDIT_URL = "https://api.openai.com/v1/images/edits"

    # ---------------------------------------------------------
    # Chat Completion
    # ---------------------------------------------------------

    def chat(
        self,
        messages: List[Dict[str, Any]],
        *,
        tools: Optional[List[Dict[str, Any]]] = None,
        tool_choice: Optional[str] = None,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> Dict[str, Any]:

        runtime = get_runtime()
        api_key = runtime.env.OPENAI_API_KEY

        if not api_key:
            raise RuntimeError("OpenAI API key not set.")

        if system_prompt:
            messages = [{"role": "system", "content": system_prompt}] + messages

        # Reasoning-family models (o1/o3/o4/gpt-5.x) reject tool calls over
        # Chat Completions outright unless reasoning is disabled -- the
        # Responses API is the only endpoint that supports real
        # reasoning_effort together with tool calls, so route there
        # whenever both are in play. No tools (or a non-reasoning model)
        # keeps using Chat Completions, unchanged.
        if tools and model_requires_responses_api(self.model_id):
            return self._chat_via_responses_api(
                messages,
                tools=tools,
                tool_choice=tool_choice,
                api_key=api_key,
                max_tokens=max_tokens,
            )

        payload: Dict[str, Any] = {
            "model": self.model_id,
            "messages": messages,
            # Stable per-provider/model key so OpenAI routes repeated calls
            # (same persona/tool-examples system prompt, nearly every turn)
            # to the same cache-holding machine instead of relying solely on
            # its own best-effort prefix hashing. See "Prompt cache keys" in
            # OpenAI's prompt caching guide.
            "prompt_cache_key": f"athenaui:{self.provider_id}:{self.model_id}",
        }
        if not model_rejects_custom_temperature(self.model_id):
            payload["temperature"] = temperature

        if max_tokens is not None:
            # Newer models (o1/o3/gpt-5 family) reject the older `max_tokens`
            # name outright ("Unsupported parameter") -- max_completion_tokens
            # is the unified replacement OpenAI accepts across all current
            # chat models, old and new, so there's no need to branch per model.
            payload["max_completion_tokens"] = max_tokens

        # Tool calling (OpenAI v2)
        if tools:
            payload["tools"] = tools
            if tool_choice:
                payload["tool_choice"] = tool_choice

        # Reasoning-family models only reach here with no tools in play (the
        # branch above already redirected tool-enabled calls to the
        # Responses API), where Chat Completions is fine with real
        # reasoning_effort -- forward the user's choice. The `elif tools`
        # fallback to "none" is defensive only and shouldn't normally fire.
        if model_rejects_custom_temperature(self.model_id):
            effort = self.reasoning_effort
            if effort and effort != "default":
                payload["reasoning_effort"] = effort
            elif tools:
                payload["reasoning_effort"] = "none"

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
        response = requests.post(self.API_URL, json=payload, headers=headers, timeout=60)
        response.raise_for_status()
        data = response.json()

        # Normalize response
        choice = data["choices"][0]

        result = {
            "id": data.get("id"),
            "model": data.get("model"),
            "content": choice["message"].get("content"),
            "tool_calls": choice["message"].get("tool_calls"),
            "finish_reason": choice.get("finish_reason"),
            "raw": data,
        }

        return result

    # ---------------------------------------------------------
    # Chat Completion via the Responses API (reasoning-family models + tools)
    # ---------------------------------------------------------
    def _chat_via_responses_api(
        self,
        messages: List[Dict[str, Any]],
        *,
        tools: List[Dict[str, Any]],
        tool_choice: Optional[str],
        api_key: str,
        max_tokens: Optional[int],
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "model": self.model_id,
            "input": to_responses_input(messages),
            "tools": to_responses_tools(tools),
            "prompt_cache_key": f"athenaui:{self.provider_id}:{self.model_id}",
        }
        if tool_choice:
            payload["tool_choice"] = tool_choice
        if max_tokens is not None:
            payload["max_output_tokens"] = max_tokens

        effort = self.reasoning_effort
        if effort and effort != "default":
            payload["reasoning"] = {"effort": effort}

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
        response = requests.post(self.RESPONSES_API_URL, json=payload, headers=headers, timeout=60)
        response.raise_for_status()
        return from_responses_output(response.json())

    # ---------------------------------------------------------
    # Image Generation
    # ---------------------------------------------------------

    def generate_image(
        self,
        prompt: str,
        *,
        size: str = "1024x1024",
        n: int = 1,
    ) -> Dict[str, Any]:

        runtime = get_runtime()
        api_key = runtime.env.OPENAI_API_KEY

        if not api_key:
            raise RuntimeError("OpenAI API key not set.")

        payload = {
            "model": self.model_id,
            "prompt": prompt,
            "size": size,
            "n": n,
        }

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
        response = requests.post(self.IMAGE_URL, json=payload, headers=headers, timeout=90)
        raise_for_openai_compatible_image_response(response)
        data = response.json()

        return {
            "images": data.get("data", []),
            "raw": data,
        }

    # ---------------------------------------------------------
    # Image Editing (reference-image-driven generation)
    # ---------------------------------------------------------
    # Uses OpenAI's images/edits endpoint, which -- unlike
    # images/generations -- accepts one or more reference images
    # alongside the prompt (multipart/form-data, `image[]` repeated per
    # image). gpt-image-family models use this to keep the same person's
    # identity/likeness in a newly generated photo, or to combine two
    # separate reference photos (e.g. two characters) into one new image.
    def generate_image_edit(
        self,
        prompt: str,
        images: List[bytes],
        *,
        size: str = "1024x1024",
        n: int = 1,
    ) -> Dict[str, Any]:

        runtime = get_runtime()
        api_key = runtime.env.OPENAI_API_KEY

        if not api_key:
            raise RuntimeError("OpenAI API key not set.")

        if not images:
            raise RuntimeError("generate_image_edit requires at least one reference image.")

        headers = {
            "Authorization": f"Bearer {api_key}",
        }

        data = {
            "model": self.model_id,
            "prompt": prompt,
            "size": size,
            "n": str(n),
        }

        files = [
            ("image[]", (f"reference_{i}.png", image_bytes, "image/png"))
            for i, image_bytes in enumerate(images)
        ]

        response = requests.post(
            self.IMAGE_EDIT_URL,
            headers=headers,
            data=data,
            files=files,
            timeout=120,
        )
        raise_for_openai_compatible_image_response(response)
        result = response.json()

        return {
            "images": result.get("data", []),
            "raw": result,
        }


# ---------------------------------------------------------
# Router registration is now handled centrally in:
#   backend/llm/router_selector/router_registry.py
# ---------------------------------------------------------

