# AthenaUI v3.5 — Spreadsheet "Document" PDF Export
# File: backend/spreadsheets/pdf_export.py
#
# Renders a spreadsheet's get_export_table() output as a polished, portrait
# document: an optional borderless letterhead, an optional stretched
# meta-fields row (e.g. Driver: ___ / Truck#: ___ / Trailer#: ___), the main
# data grid (columns may repeat labels and/or request a narrower width, e.g.
# a stacked "Extra Stops" header), and an optional small fixed-shape footer
# table (e.g. Expenses/Amounts/Description) separated by a gap. Kept separate
# from personal/export_service.py's generic rows_to_pdf_bytes(), which is
# shared by unrelated Personal-hub datasets (contacts/calendar/crm).

from __future__ import annotations

import io
from typing import Any, Dict, List

from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.lib.utils import ImageReader
from reportlab.platypus import Image, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

_CHAR_WIDTH_PT = 6.0  # rough average character width used to convert a column's "width" hint into points


def _scaled_image_flowable(path: str, max_width: float, max_height: float) -> Image:
    """Scales an image down to fit within max_width x max_height (preserving
    aspect ratio) so it renders as a single full page."""
    iw, ih = ImageReader(path).getSize()
    scale = min(max_width / iw, max_height / ih)
    return Image(path, width=iw * scale, height=ih * scale)


def _grid_col_widths(columns_full: List[Dict[str, Any]], total_width: float) -> List[float]:
    explicit = [c.get("width") for c in columns_full]
    fixed_total = sum((w or 0) * _CHAR_WIDTH_PT for w in explicit if w)
    flexible_count = sum(1 for w in explicit if not w)
    remaining = max(total_width - fixed_total, 0)
    flexible_width = (remaining / flexible_count) if flexible_count else 0
    return [(w * _CHAR_WIDTH_PT) if w else flexible_width for w in explicit]


def build_spreadsheet_pdf(table: Dict[str, Any]) -> bytes:
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        leftMargin=0.5 * inch,
        rightMargin=0.5 * inch,
        topMargin=0.5 * inch,
        bottomMargin=0.5 * inch,
    )
    styles = getSampleStyleSheet()
    elements: List[Any] = []

    header_lines = [line.strip() for line in (table.get("header_text") or "").splitlines() if line.strip()]
    if header_lines:
        elements.append(Paragraph(header_lines[0], styles["Title"]))
        for line in header_lines[1:]:
            elements.append(Paragraph(line, styles["Normal"]))
    else:
        elements.append(Paragraph(table["name"], styles["Title"]))
    elements.append(Spacer(1, 0.15 * inch))

    meta_fields = table.get("meta_fields") or []
    if meta_fields:
        meta_row = [f"{f.get('label', '')}  {f.get('value', '')}".strip() for f in meta_fields]
        meta_table = Table([meta_row], colWidths=[doc.width / len(meta_row)] * len(meta_row))
        meta_table.setStyle(
            TableStyle(
                [
                    ("BOX", (0, 0), (-1, -1), 1, colors.black),
                    ("INNERGRID", (0, 0), (-1, -1), 1, colors.black),
                    ("FONTSIZE", (0, 0), (-1, -1), 9),
                    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                    ("TOPPADDING", (0, 0), (-1, -1), 6),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
                    ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ]
            )
        )
        elements.append(meta_table)
        elements.append(Spacer(1, 0.15 * inch))

    columns_full = table.get("columns_full") or []
    rows_by_key = table.get("rows_by_key") or []
    row_labels = table.get("row_labels") or []
    has_labels = any((label or "").strip() for label in row_labels)
    if columns_full:
        grid_columns = ([{"key": "__row_label__", "label": "Row Label"}] + columns_full) if has_labels else columns_full
        header = [c["label"] for c in grid_columns]
        data = [header]
        for i, r in enumerate(rows_by_key):
            row_cells = []
            if has_labels:
                row_cells.append(row_labels[i] if i < len(row_labels) else "")
            row_cells.extend(str(r.get(c["key"], "") or "") for c in columns_full)
            data.append(row_cells)

        col_widths = _grid_col_widths(grid_columns, doc.width)
        grid_table = Table(data, colWidths=col_widths, repeatRows=1)
        grid_table.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1f2937")),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                    ("FONTSIZE", (0, 0), (-1, -1), 8),
                    ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                    ("ALIGN", (0, 0), (-1, 0), "CENTER"),
                    ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f3f4f6")]),
                ]
            )
        )
        elements.append(grid_table)
    else:
        elements.append(Paragraph("No columns yet.", styles["Normal"]))

    footer_table = table.get("footer_table") or {}
    footer_columns = footer_table.get("columns") or []
    footer_rows = footer_table.get("rows") or []
    if footer_columns:
        elements.append(Spacer(1, 0.3 * inch))
        header = [footer_table.get("label_heading") or ""] + [c["label"] for c in footer_columns]
        data = [header]
        for r in footer_rows:
            values = r.get("values") or {}
            data.append([r.get("label", "")] + [str(values.get(c["key"], "") or "") for c in footer_columns])
        n_cols = len(header)
        col_width = doc.width / n_cols
        footer_grid = Table(data, colWidths=[col_width] * n_cols, repeatRows=1)
        footer_grid.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1f2937")),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                    ("FONTSIZE", (0, 0), (-1, -1), 8),
                    ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                    ("ALIGN", (0, 0), (-1, 0), "CENTER"),
                ]
            )
        )
        elements.append(footer_grid)

    # Image pages (see spreadsheets.service.add_image_page) -- each one
    # becomes its own full page, in the user's chosen order, after the
    # table/footer content. A missing/unreadable file is skipped rather
    # than failing the whole export.
    for image_path in table.get("image_pages") or []:
        try:
            elements.append(PageBreak())
            elements.append(_scaled_image_flowable(image_path, doc.width, doc.height))
        except Exception:
            continue

    doc.build(elements)
    return buffer.getvalue()
