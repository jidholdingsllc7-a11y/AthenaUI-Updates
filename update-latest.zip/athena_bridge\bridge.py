# Athena Desktop/DOM Bridge — FULL AGENTIC VERSION Modular
# File: bridge.py
# Purpose: Real OS-level input + DOM inspection + vision + advanced UI control
# Requires: pyautogui, playwright, pillow, pytesseract, opencv-python, numpy, fastapi, uvicorn
# Created: 2026-04-09 09:04 CDT
# Updated: 2026-10-01 (DPI-awareness fix for mouse/screenshot coordinate mismatch)

# Must run BEFORE pyautogui (or anything else) touches any Win32 display API.
# Without this, on a scaled display pyautogui.screenshot() returns virtualized
# (scaled) pixel coordinates while pyautogui.moveTo()'s SetCursorPos operates
# in real physical pixels, so any screenshot/OCR-derived coordinate lands in
# the wrong place (e.g. clicking near the editor's own close button instead
# of a target further down the real screen).
import sys as _sys
if _sys.platform == "win32":
    import ctypes as _ctypes
    try:
        _ctypes.windll.shcore.SetProcessDpiAwareness(2)  # PROCESS_PER_MONITOR_DPI_AWARE
    except Exception:
        try:
            _ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass

# IMPORTANT (Windows): do NOT run this server with `uvicorn ... --reload`.
# uvicorn's reload supervisor starts the worker with use_subprocess=True,
# which makes uvicorn.loops.asyncio.asyncio_loop_factory() force a
# SelectorEventLoop instead of ProactorEventLoop on Windows. SelectorEventLoop
# cannot create subprocesses (asyncio.create_subprocess_exec raises
# NotImplementedError), which breaks Playwright's ability to launch its
# Node.js driver and takes down every DOM/Playwright-backed bridge tool
# (ui_navigate, ui_dom_tree, ui_inspect, ui_screenshot_element,
# ui_screenshot_annotated). This cannot be fixed from inside this module --
# uvicorn picks the loop class directly, overriding any policy set here.
# Correct startup command:
#   uvicorn bridge:app --host 0.0.0.0 --port 9000
# (no --reload)

from fastapi import FastAPI
from pydantic import BaseModel

from ui.dom import ensure_browser, ui_inspect_element, ui_dom_tree, ui_navigate
from ui.mouse import mouse_move_impl, mouse_click_impl, right_click_impl, double_click_impl, hover_impl, scroll_impl, drag_impl, drag_offset_impl
from ui.keyboard import keyboard_type_impl, hotkey_impl
from ui.vision import screenshot_full_impl, screenshot_element_impl, screenshot_annotated_impl, ocr_search_impl, image_match_impl, highlight_impl, cursor_marker_screenshot_impl
from ui.monitors import monitors_impl, move_to_monitor_impl, screen_info_impl
from ui.recorder import recorder_start_impl, recorder_stop_impl, recorder_log_impl, recorder_wrap_action

app = FastAPI(title="Athena Desktop/DOM Bridge")

# ---------------------------------------------------------
# MODELS
# ---------------------------------------------------------

class InspectRequest(BaseModel):
    selector: str

class MouseMoveRequest(BaseModel):
    x: float
    y: float

class MouseClickRequest(BaseModel):
    button: str = "left"

class KeyboardTypeRequest(BaseModel):
    text: str

class ScrollRequest(BaseModel):
    dx: int = 0
    dy: int = 0

class DragRequest(BaseModel):
    start_x: float
    start_y: float
    end_x: float
    end_y: float
    duration: float = 0.2

class DragOffsetRequest(BaseModel):
    x: float
    y: float
    dx: float
    dy: float
    duration: float = 0.2

class HotkeyRequest(BaseModel):
    keys: list[str]

class OCRSearchRequest(BaseModel):
    text: str

class ImageMatchRequest(BaseModel):
    template_path: str
    threshold: float = 0.8

class NavigateRequest(BaseModel):
    url: str

class HighlightRequest(BaseModel):
    x: float
    y: float
    width: float
    height: float
    duration: float = 0.5


# ---------------------------------------------------------
# ROOT
# ---------------------------------------------------------

@app.get("/")
async def root():
    return {"status": "Athena Desktop/DOM Bridge running"}


# ---------------------------------------------------------
# DOM / NAVIGATION
# ---------------------------------------------------------

@app.post("/ui/inspect")
async def ui_inspect(req: InspectRequest):
    return await recorder_wrap_action("ui_inspect", ui_inspect_element, req.selector)


@app.get("/ui/dom_tree")
async def ui_dom_tree_endpoint():
    return await recorder_wrap_action("ui_dom_tree", ui_dom_tree)


@app.post("/ui/navigate")
async def ui_navigate_endpoint(req: NavigateRequest):
    return await recorder_wrap_action("ui_navigate", ui_navigate, req.url)


# ---------------------------------------------------------
# VISION / SCREENSHOTS / OCR / IMAGE MATCH / HIGHLIGHT
# ---------------------------------------------------------

@app.get("/ui/screenshot_full")
async def screenshot_full():
    return await recorder_wrap_action("screenshot_full", screenshot_full_impl)


@app.get("/ui/cursor_screenshot")
async def cursor_screenshot():
    return await recorder_wrap_action("cursor_screenshot", cursor_marker_screenshot_impl)


@app.post("/ui/screenshot_element")
async def screenshot_element(req: InspectRequest):
    return await recorder_wrap_action("screenshot_element", screenshot_element_impl, req.selector)


@app.post("/ui/screenshot_annotated")
async def screenshot_annotated(req: InspectRequest):
    return await recorder_wrap_action("screenshot_annotated", screenshot_annotated_impl, req.selector)


@app.post("/ui/ocr_search")
async def ocr_search(req: OCRSearchRequest):
    return await recorder_wrap_action("ocr_search", ocr_search_impl, req.text)


@app.post("/ui/image_match")
async def image_match(req: ImageMatchRequest):
    return await recorder_wrap_action("image_match", image_match_impl, req.template_path, req.threshold)


@app.post("/ui/highlight")
async def highlight(req: HighlightRequest):
    return await recorder_wrap_action(
        "highlight",
        highlight_impl,
        req.x,
        req.y,
        req.width,
        req.height,
        req.duration,
    )


# ---------------------------------------------------------
# MOUSE
# ---------------------------------------------------------

@app.post("/ui/mouse_move")
async def mouse_move(req: MouseMoveRequest):
    return await recorder_wrap_action("mouse_move", mouse_move_impl, req.x, req.y)


@app.post("/ui/mouse_click")
async def mouse_click(req: MouseClickRequest):
    return await recorder_wrap_action("mouse_click", mouse_click_impl, req.button)


@app.post("/ui/right_click")
async def right_click():
    return await recorder_wrap_action("right_click", right_click_impl)


@app.post("/ui/double_click")
async def double_click():
    return await recorder_wrap_action("double_click", double_click_impl)


@app.post("/ui/hover")
async def hover(req: MouseMoveRequest):
    return await recorder_wrap_action("hover", hover_impl, req.x, req.y)


@app.post("/ui/scroll")
async def ui_scroll(req: ScrollRequest):
    return await recorder_wrap_action("scroll", scroll_impl, req.dx, req.dy)


@app.post("/ui/drag")
async def ui_drag(req: DragRequest):
    return await recorder_wrap_action(
        "drag",
        drag_impl,
        req.start_x,
        req.start_y,
        req.end_x,
        req.end_y,
        req.duration,
    )


@app.post("/ui/drag_offset")
async def ui_drag_offset(req: DragOffsetRequest):
    return await recorder_wrap_action(
        "drag_offset",
        drag_offset_impl,
        req.x,
        req.y,
        req.dx,
        req.dy,
        req.duration,
    )


# ---------------------------------------------------------
# KEYBOARD
# ---------------------------------------------------------

@app.post("/ui/keyboard_type")
async def keyboard_type(req: KeyboardTypeRequest):
    return await recorder_wrap_action("keyboard_type", keyboard_type_impl, req.text)


@app.post("/ui/hotkey")
async def hotkey(req: HotkeyRequest):
    return await recorder_wrap_action("hotkey", hotkey_impl, req.keys)


# ---------------------------------------------------------
# MONITORS
# ---------------------------------------------------------

@app.get("/ui/monitors")
async def monitors():
    return await recorder_wrap_action("monitors", monitors_impl)


@app.get("/ui/screen_info")
async def screen_info():
    return await recorder_wrap_action("screen_info", screen_info_impl)


@app.post("/ui/move_to_monitor")
async def move_to_monitor(index: int):
    return await recorder_wrap_action("move_to_monitor", move_to_monitor_impl, index)


# ---------------------------------------------------------
# RECORDER
# ---------------------------------------------------------

@app.post("/ui/record/start")
async def record_start():
    return recorder_start_impl()


@app.post("/ui/record/stop")
async def record_stop():
    return recorder_stop_impl()


@app.get("/ui/record/log")
async def record_log():
    return recorder_log_impl()
