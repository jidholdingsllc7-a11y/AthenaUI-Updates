# AthenaUI v3.7 — Shared Build/Lint/Test Helpers
# File: backend/tools/system/build_check/_common.py
# Created: 2026-10-25
#
# Auto-detects the right build/lint/test command for a project directory
# from marker files (package.json, tsconfig.json, Cargo.toml, go.mod, a
# Python project) so project_build_check/project_lint_test don't need the
# model to already know the right toolchain invocation, with an explicit
# `command` override for anything the auto-detection misses. Runs via the
# shell (not create_subprocess_exec) so Windows .cmd shims like npm/npx
# resolve correctly through PATHEXT.

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any, Dict, Optional

from workspace.service import WorkspaceService

_MAX_OUTPUT_CHARS = 60_000
_DEFAULT_TIMEOUT_SECONDS = 300


class BuildCheckError(Exception):
    """Raised for input problems reported as a clean error, not a traceback."""


def resolve_target_dir(username: str, path: Optional[str], scope_dir: Optional[str]) -> Path:
    ws = WorkspaceService.get_workspace(username)
    if ws is None:
        raise BuildCheckError(f"Workspace not available for user '{username}'.")

    root = ws.root.resolve()
    rel = path or scope_dir or "."
    target = (root / rel).resolve()

    try:
        target.relative_to(root)
    except ValueError:
        raise BuildCheckError("'path' must stay inside the workspace.")

    if not target.is_dir():
        raise BuildCheckError(f"Not a directory: {rel}")

    return target


def _npm_script(target: Path, script: str) -> Optional[str]:
    package_json = target / "package.json"
    if not package_json.is_file():
        return None
    try:
        data = json.loads(package_json.read_text(encoding="utf-8"))
    except Exception:
        return None
    if script in (data.get("scripts") or {}):
        return f"npm run {script}"
    return None


def _is_python_project(target: Path) -> bool:
    return (
        (target / "pyproject.toml").is_file()
        or (target / "requirements.txt").is_file()
        or any(target.glob("*.py"))
    )


def detect_build_command(target: Path) -> Optional[str]:
    cmd = _npm_script(target, "build")
    if cmd:
        return cmd
    if (target / "tsconfig.json").is_file():
        return "npx tsc --noEmit"
    if (target / "Cargo.toml").is_file():
        return "cargo check"
    if (target / "go.mod").is_file():
        return "go build ./..."
    if _is_python_project(target):
        return "python -m compileall -q ."
    return None


def detect_lint_command(target: Path) -> Optional[str]:
    cmd = _npm_script(target, "lint")
    if cmd:
        return cmd
    if (target / "Cargo.toml").is_file():
        return "cargo clippy"
    if (target / "ruff.toml").is_file() or (target / ".ruff.toml").is_file():
        return "ruff check ."
    if _is_python_project(target):
        return "python -m pyflakes ."
    return None


def detect_test_command(target: Path) -> Optional[str]:
    cmd = _npm_script(target, "test")
    if cmd:
        return cmd
    if (target / "Cargo.toml").is_file():
        return "cargo test"
    if (target / "go.mod").is_file():
        return "go test ./..."
    if _is_python_project(target):
        return "python -m pytest -q"
    return None


async def run_command(cwd: Path, command: str, *, timeout: int = _DEFAULT_TIMEOUT_SECONDS) -> Dict[str, Any]:
    """Runs `command` via the shell with the given cwd, bounded by `timeout`
    seconds. Never raises for a missing binary or a non-zero exit -- both
    are reportable states, not bugs."""
    try:
        proc = await asyncio.create_subprocess_shell(
            command,
            cwd=str(cwd),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
    except Exception as e:
        return {"status": "error", "error": f"Could not start command '{command}': {e}"}

    try:
        stdout_bytes, stderr_bytes = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        proc.kill()
        await proc.wait()
        return {"status": "error", "error": f"Command timed out after {timeout}s: {command}"}

    stdout = stdout_bytes.decode("utf-8", errors="replace")
    stderr = stderr_bytes.decode("utf-8", errors="replace")
    combined = (stdout + ("\n" + stderr if stderr.strip() else "")).strip()

    truncated = False
    if len(combined) > _MAX_OUTPUT_CHARS:
        combined = combined[:_MAX_OUTPUT_CHARS] + "\n…(truncated)"
        truncated = True

    return {
        "status": "ok" if proc.returncode == 0 else "failed",
        "returncode": proc.returncode,
        "command": command,
        "output": combined or "(no output)",
        "truncated": truncated,
    }
