# AthenaUI -- Ledger signing
# File: backend/ledger/signing.py
#
# Cryptographic signing for ledger records (marketing-activity audit trail).
# Uses a local Ed25519 keypair (self-provisioned on first use, stored under
# vault/certs/) to sign a canonical hash of each record -- proof that THIS
# AthenaUI installation attested to a record's content at a specific time,
# independent of whatever external ledger (e.g. SCDO) it may also be pushed to.

from __future__ import annotations

import hashlib
import json
import os
import threading
from pathlib import Path
from typing import Any, Dict

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization

BACKEND_DIR = Path(__file__).resolve().parent.parent
CERTS_DIR = BACKEND_DIR / "vault" / "certs"
PRIVATE_KEY_PATH = CERTS_DIR / "ledger_signing_private.pem"
PUBLIC_KEY_PATH = CERTS_DIR / "ledger_signing_public.pem"

_lock = threading.Lock()
_cached_key: Ed25519PrivateKey | None = None


def _load_or_create_keypair() -> Ed25519PrivateKey:
    global _cached_key
    if _cached_key is not None:
        return _cached_key

    with _lock:
        if _cached_key is not None:
            return _cached_key

        CERTS_DIR.mkdir(parents=True, exist_ok=True)
        if PRIVATE_KEY_PATH.is_file():
            with open(PRIVATE_KEY_PATH, "rb") as f:
                _cached_key = serialization.load_pem_private_key(f.read(), password=None)
            return _cached_key

        private_key = Ed25519PrivateKey.generate()
        private_bytes = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        )
        public_bytes = private_key.public_key().public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        with open(PRIVATE_KEY_PATH, "wb") as f:
            f.write(private_bytes)
        with open(PUBLIC_KEY_PATH, "wb") as f:
            f.write(public_bytes)
        try:
            os.chmod(PRIVATE_KEY_PATH, 0o600)
        except OSError:
            pass  # best-effort -- not all filesystems support POSIX perms (e.g. Windows)

        _cached_key = private_key
        return _cached_key


def canonical_hash(payload: Dict[str, Any]) -> str:
    """Deterministic SHA-256 hash of a record's content, independent of key order."""
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def sign_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Signs the canonical hash of `payload`. Returns a signature block to store
    alongside the record -- never mutates `payload` itself."""
    private_key = _load_or_create_keypair()
    content_hash = canonical_hash(payload)
    signature = private_key.sign(content_hash.encode("utf-8"))
    public_fingerprint = hashlib.sha256(
        private_key.public_key().public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )
    ).hexdigest()[:16]
    return {
        "algorithm": "ed25519",
        "content_hash_sha256": content_hash,
        "signature_hex": signature.hex(),
        "signer_fingerprint": public_fingerprint,
    }


def verify_payload(payload: Dict[str, Any], signature_block: Dict[str, Any]) -> bool:
    """Self-check: re-derive the hash from `payload` and verify it against the
    stored signature using this installation's own public key."""
    private_key = _load_or_create_keypair()
    expected_hash = canonical_hash(payload)
    if expected_hash != signature_block.get("content_hash_sha256"):
        return False
    try:
        private_key.public_key().verify(bytes.fromhex(signature_block["signature_hex"]), expected_hash.encode("utf-8"))
        return True
    except Exception:
        return False
