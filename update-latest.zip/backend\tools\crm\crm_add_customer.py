# AthenaUI v3.5 — crm_add_customer Tool
# File: backend/tools/crm/crm_add_customer.py

from typing import Any, Dict

from crm.service import CrmError, create_customer

capabilities = {
    "needs_filesystem": True,
    "needs_bridge": False,
    "needs_network": False,
    "needs_user": True,
}


async def run(args: Dict[str, Any]) -> str:
    try:
        username = args.get("username")
        character = args.get("character")
        name = args.get("name")
        if not username:
            return "[ERROR] Missing 'username' argument."
        if not name:
            return "[ERROR] Missing 'name' argument."

        customer = create_customer(
            username,
            name=name,
            company=args.get("company"),
            email=args.get("email"),
            phone=args.get("phone"),
            stage=args.get("stage", "lead"),
            value=args.get("value", 0.0),
            source=args.get("source"),
            owner_character=character,
            notes=args.get("notes"),
            preferred_contact_method=args.get("preferred_contact_method"),
            platform_first_contact=args.get("platform_first_contact"),
        )
        return f"Customer added: {customer['name']} (id={customer['id']}, stage={customer['stage']})."
    except CrmError as e:
        return f"[ERROR] {e}"
    except Exception as e:
        return f"[ERROR] Failed to add customer: {str(e)}"
