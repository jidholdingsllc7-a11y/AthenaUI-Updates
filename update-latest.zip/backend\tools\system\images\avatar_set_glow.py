# AthenaUI — Avatar Glow Control Tool
# File: backend/tools/system/images/avatar_set_glow.py
# Purpose: Lets a character adjust its own avatar's live CSS glow pulse
# (intensity/speed), as a subtle expressive signal -- distinct from a
# pre-baked animated GIF, this just updates two numbers on the character
# record, so it adds no image-generation latency even when called every turn.

from typing import Any, Dict

capabilities = {
    "needs_bridge": False,
    "needs_filesystem": False,
    "needs_network": False,
    "needs_user": True,
}


def _clamp01(value: Any, default: float) -> float:
    try:
        value = float(value)
    except (TypeError, ValueError):
        return default
    return max(0.0, min(1.0, value))


async def run(args: Dict[str, Any]):
    username = args.get("username", "system")
    character = args.get("character") or args.get("character_id")

    if not character:
        return {"error": "Missing character for avatar glow"}

    from characters.system.load import load_character
    from characters.system.save import save_character

    char = load_character(username, character)
    if not char:
        return {"error": f"Character '{character}' not found"}

    avatar = char.get("avatar") or {}
    glow = avatar.get("glow") or {}

    new_glow = {
        "enabled": bool(args.get("enabled", glow.get("enabled", True))),
        "intensity": _clamp01(args.get("intensity"), glow.get("intensity", 0.5)),
        "speed": _clamp01(args.get("speed"), glow.get("speed", 0.5)),
    }
    avatar["glow"] = new_glow
    char["avatar"] = avatar
    save_character(username, char, key=character)

    return {"status": "ok", "glow": new_glow}
