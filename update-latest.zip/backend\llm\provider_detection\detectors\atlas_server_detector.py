# AthenaUI v3.5 — Atlas Server Provider Auto-Detection
# File: backend/llm/provider_detection/detectors/atlas_server_detector.py

import requests
from typing import List, Optional

from llm.provider_detection.detector_base import ProviderDetectorBase, ProviderDetectionResult
from llm.routers.providers import PROVIDER_ATLAS_SERVER


class AtlasServerDetector(ProviderDetectorBase):
    provider_id = PROVIDER_ATLAS_SERVER

    def __init__(self, base_url: Optional[str] = "http://127.0.0.1:8090", api_key: Optional[str] = None):
        self.base_url = base_url
        self.api_key = api_key

    def detect(self) -> ProviderDetectionResult:
        try:
            models = self.list_models()
        except Exception as e:
            return ProviderDetectionResult(False, error=str(e))

        warnings = [
            "Atlas Server orchestrates multiple fine-tuned models internally "
            "and presents them as a single model."
        ]
        return ProviderDetectionResult(True, models, warnings)

    def list_models(self) -> List[str]:
        url = f"{self.base_url}/v1/models"
        headers = {"Authorization": f"Bearer {self.api_key}"} if self.api_key else {}

        r = requests.get(url, headers=headers, timeout=5)
        if r.status_code == 401:
            raise RuntimeError("Atlas Server rejected the API key.")
        if r.status_code >= 400:
            raise RuntimeError("Atlas Server not reachable.")

        data = r.json()
        return sorted([m["id"] for m in data.get("data", [])])
