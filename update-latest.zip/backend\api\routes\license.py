# AthenaUI — Licensing routes (Stripe subscription + Cloudflare Worker)
# File: backend/api/routes/license.py
#
# Wires the frontend Subscription page to the licensing Worker: activation,
# restore-on-new-machine, and startup/login (re-)validation. See
# licensing/service.py for storage + offline-grace behavior and
# billing/gate.py for the developer-mode enforcement bypass.

import logging
from typing import Any, Dict

from fastapi import APIRouter, Depends

from auth.service import get_current_user
from billing.gate import subscription_enforced
from licensing.service import license_service

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
if not logger.handlers:
    _handler = logging.StreamHandler()
    _handler.setFormatter(logging.Formatter("%(asctime)s [%(name)s] %(message)s"))
    logger.addHandler(_handler)

router = APIRouter(prefix="/license", tags=["license"])


@router.get("/status")
async def license_status(user: Dict[str, Any] = Depends(get_current_user)):
    # The frontend calls this on every login/app load. If a license was
    # already activated on this machine, re-validate it with the Worker
    # right here instead of only ever reading stale local state -- this is
    # the "startup/login should automatically refresh" behavior: it keeps
    # entitlements (premium_access/founder_tier/etc.) and the offline-grace
    # timestamp current without requiring the user to visit the
    # Subscription page. A license that has never been activated has no
    # key to refresh, so this is a no-op until the user actually enters one.
    status = license_service.get_status()
    if status.get("license_key"):
        logger.info("license_status(): stored key found, auto-refreshing with the Worker.")
        status = license_service.refresh()
    status["enforced"] = subscription_enforced()
    return status


@router.post("/validate")
async def license_validate(user: Dict[str, Any] = Depends(get_current_user)):
    logger.info("POST /license/validate called by user=%s", user.get("username"))
    status = license_service.refresh()
    status["enforced"] = subscription_enforced()
    return status


@router.post("/activate")
async def license_activate(payload: dict, user: Dict[str, Any] = Depends(get_current_user)):
    logger.info("POST /license/activate called by user=%s", user.get("username"))
    status = license_service.activate(payload.get("license_key", ""))
    status["enforced"] = subscription_enforced()
    return status


@router.post("/restore")
async def license_restore(payload: dict, user: Dict[str, Any] = Depends(get_current_user)):
    # Restoring on a new/reset machine is the same server-side operation as
    # first-time activation -- the Worker decides whether to allow the
    # rebind, or reports a machine-mismatch reason if it can't.
    logger.info("POST /license/restore called by user=%s", user.get("username"))
    status = license_service.activate(payload.get("license_key", ""))
    status["enforced"] = subscription_enforced()
    return status


@router.post("/restore-public")
async def license_restore_public(payload: dict):
    # Unauthenticated on purpose: this backs the login screen's "Restore by
    # Key" button, which must work before any local user account exists
    # (e.g. a freshly wiped machine with nothing set up yet). The license
    # itself lives in the SystemVault (machine-wide, not per-user -- see
    # licensing/service.py), so there's no user context required here; the
    # license_key the customer supplies is itself the credential, and the
    # Worker still enforces machine-binding rules on its end.
    logger.info("POST /license/restore-public called (pre-login)")
    status = license_service.activate(payload.get("license_key", ""))
    status["enforced"] = subscription_enforced()
    return status


@router.post("/portal")
async def license_portal(user: Dict[str, Any] = Depends(get_current_user)):
    logger.info("POST /license/portal called by user=%s", user.get("username"))
    return license_service.get_portal_url()
