# AthenaUI — Chat reply feedback (thumbs up/down) storage
# File: backend/chat/feedback_store.py
#
# Records user thumbs up/down ratings on individual assistant replies.
# Only meaningful (and only ever shown in the frontend) for replies
# produced by our own Atlas Server TLM, since that's the only provider
# whose weights we can actually retrain from this signal -- for every
# third-party provider there is nowhere for the feedback to go, so it's
# never collected for those. Stored as one append-only JSONL file per
# user so Atlas Server can later ingest it directly as training data.

import json
import time
import uuid
from pathlib import Path
from typing import Any, Dict, Optional


def _feedback_path(username: str) -> Path:
    from core.runtime.runtime import get_runtime

    path: Path = get_runtime().env.DATA_DIR / "users" / username / "feedback"
    path.mkdir(parents=True, exist_ok=True)
    return path / "reply_ratings.jsonl"


def record_reply_feedback(
    username: str,
    *,
    rating: str,
    provider_id: str,
    model_id: Optional[str],
    character: Optional[str],
    channel: Optional[str],
    message_excerpt: Optional[str],
) -> Dict[str, Any]:
    if rating not in ("up", "down"):
        raise ValueError("'rating' must be 'up' or 'down'.")

    entry = {
        "id": str(uuid.uuid4()),
        "created_at": time.time(),
        "rating": rating,
        "provider_id": provider_id,
        "model_id": model_id,
        "character": character,
        "channel": channel,
        # Capped, plain-text excerpt only -- this is a lightweight training
        # signal, not a full transcript store (that already exists via
        # ChatHistoryService).
        "message_excerpt": (message_excerpt or "")[:4000],
    }

    path = _feedback_path(username)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry) + "\n")

    return entry
