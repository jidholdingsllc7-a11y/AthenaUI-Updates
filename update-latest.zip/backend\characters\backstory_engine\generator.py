﻿# AthenaUI v3.5 — Backstory Engine
# File: backend/characters/backstory_engine/generator.py
# Created: 2026-04-10 20:48 CDT
# Updated: 2026-07-30 22:12 CDT

import json

from .prompt_builder import build_prompt, build_full_character_prompt
from .validator import validate_backstory
from .formatter import format_backstory


def generate_backstory(
    character: dict,
    username: str,
    user_prompt: str | None = None,
    related_characters: list[dict] | None = None,
) -> str:
    """
    Generate a new backstory for a character using the user's (or system
    default's) configured chat provider. Does NOT write to disk; just
    returns the text. `related_characters` (optional): existing relatives'
    {name, relation, backstory} so the LLM can weave in consistent shared
    family history (see prompt_builder._build_family_section).
    """
    prompt = build_prompt(character, user_prompt=user_prompt, related_characters=related_characters)
    raw_text = call_llm(prompt, username)
    validated = validate_backstory(raw_text, character)
    formatted = format_backstory(validated)
    return formatted


def generate_character_details(
    character: dict,
    username: str,
    user_prompt: str | None = None,
    related_characters: list[dict] | None = None,
) -> dict:
    """
    Generates a FULL set of character fields in one LLM call -- gender, age,
    occupation, traits, a physical appearance description (written so it
    can be used directly as an avatar image-generation prompt), and the
    backstory -- instead of just the backstory alone. Used by auto
    ("Surprise Me") and partial ("Starting Point") creation so every field
    the user left blank actually gets invented, not just the backstory.

    Returns a dict containing only the keys the LLM actually provided a
    usable value for, from: gender, age, occupation, traits, appearance,
    backstory. Callers should fall back gracefully (e.g. generate_backstory)
    if a field they need is missing -- a malformed/non-JSON LLM response
    simply yields an empty dict rather than raising.
    """
    prompt = build_full_character_prompt(character, user_prompt=user_prompt, related_characters=related_characters)
    raw_text = call_llm(prompt, username)
    data = _parse_character_details_json(raw_text)

    result: dict = {}

    gender = data.get("gender")
    if isinstance(gender, str) and gender.strip():
        result["gender"] = gender.strip()

    age = data.get("age")
    if isinstance(age, (int, float)) and not isinstance(age, bool):
        age_int = int(age)
        if age_int >= 18:
            result["age"] = age_int

    occupation = data.get("occupation")
    if isinstance(occupation, str) and occupation.strip():
        result["occupation"] = occupation.strip()

    traits = data.get("traits")
    if isinstance(traits, list):
        cleaned_traits = [str(t).strip() for t in traits if str(t).strip()]
        if cleaned_traits:
            result["traits"] = cleaned_traits

    appearance = data.get("appearance")
    if isinstance(appearance, str) and appearance.strip():
        result["appearance"] = appearance.strip()

    backstory = data.get("backstory")
    if isinstance(backstory, str) and backstory.strip():
        validated = validate_backstory(backstory.strip(), character)
        result["backstory"] = format_backstory(validated)

    return result


def _parse_character_details_json(raw_text: str) -> dict:
    """
    Extracts the first {...} JSON object from the LLM's raw text response
    (models sometimes wrap JSON in markdown fences or add stray commentary
    before/after it) and parses it. Returns {} if nothing parseable is found
    so callers can fall back gracefully instead of crashing on a malformed
    response.
    """
    text = raw_text.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
        text = text.strip()

    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end == -1 or end <= start:
        return {}

    try:
        parsed = json.loads(text[start:end + 1])
    except (json.JSONDecodeError, ValueError):
        return {}

    return parsed if isinstance(parsed, dict) else {}


def refresh_backstory(
    character: dict,
    username: str,
    user_prompt: str | None = None,
    related_characters: list[dict] | None = None,
) -> str:
    """
    Explicitly request a brand-new backstory.
    Same pipeline as generate, but semantically 'replace existing'.
    """
    return generate_backstory(character, username, user_prompt=user_prompt, related_characters=related_characters)


def _resolve_chat_provider_and_model(username: str) -> tuple[str, str]:
    from vault.service import VaultService
    from config.loader import Config
    from llm.registry.registry import LLMRegistry

    provider_id = str(VaultService.get_preference(username, "llm.provider_id", "") or "").strip().lower()
    if not provider_id:
        raise RuntimeError("No chat provider configured. Choose one in Settings before generating a backstory.")

    model_id = str(VaultService.get_preference(username, "llm.chat_model", "") or "").strip()

    # The static provider/model registry (backend/config/providers + models)
    # is optional and frequently unavailable in this environment. Track
    # whether it actually loaded so we never discard a real, user-configured
    # model_id just because that registry failed to load.
    registry_loaded = False
    try:
        Config.load()
        LLMRegistry.load()
        registry_loaded = True
    except Exception:
        registry_loaded = False

    if model_id:
        if registry_loaded:
            try:
                LLMRegistry.validate_provider_and_model(provider_id, model_id)
            except Exception:
                pass  # registry may just be stale/incomplete -- still trust the user's saved selection
        return provider_id, model_id

    if registry_loaded:
        default_model = LLMRegistry.get_default_chat_model(provider_id)
        if default_model:
            return provider_id, default_model

    raise RuntimeError(f"No chat model available for provider '{provider_id}'. Choose one in Settings.")


def call_llm(prompt: str, username: str) -> str:
    """
    Real LLM call, using the same provider/model/key resolution pattern as
    ChatEngine (chat/engine/service.py): resolve the user's configured chat
    provider (falling back to the system default provider), resolve its API
    key via the shared llm.api_key_resolver (user vault, then system vault,
    kept as the single source of truth for provider -> env-var mapping so
    newer providers like atlas_server don't silently fall out of sync here),
    inject it into the runtime env, and run a single non-streaming,
    tool-free chat completion.
    """
    from llm.router_selector.router_selector import RouterSelector
    from llm.api_key_resolver import resolve_and_inject_api_key, ApiKeyResolutionError

    provider_id, model_id = _resolve_chat_provider_and_model(username)
    try:
        resolve_and_inject_api_key(username, provider_id)
    except ApiKeyResolutionError as e:
        raise RuntimeError(str(e)) from e

    router = RouterSelector.select(provider_id=provider_id, model_id=model_id, mode="chat")
    response = router.chat([{"role": "user", "content": prompt}])

    content = response.get("content") if isinstance(response, dict) else None
    if isinstance(content, str) and content.strip():
        return content.strip()

    if isinstance(content, list):
        parts = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict) and isinstance(item.get("text"), str):
                parts.append(item["text"])
        joined = "\n".join(p for p in parts if p).strip()
        if joined:
            return joined

    text = response.get("text") if isinstance(response, dict) else None
    if isinstance(text, str) and text.strip():
        return text.strip()

    reply = response.get("reply") if isinstance(response, dict) else None
    if isinstance(reply, str) and reply.strip():
        return reply.strip()

    raise RuntimeError("The LLM provider returned no usable text for the backstory.")
