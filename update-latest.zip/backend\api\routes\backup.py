# AthenaUI v3.5 — Full System Backup / Restore API Routes
# File: backend/api/routes/backup.py
#
# Routes for the granular, encrypted full-system backup feature:
#   - GET  /backup/items               -- checklist data (categories +
#                                          user/system characters) for the
#                                          frontend's selection UI.
#   - POST /backup/export              -- builds + downloads an encrypted
#                                          ".athenabak" per a chosen
#                                          passphrase + selection.
#   - POST /backup/restore             -- restores into the CURRENTLY
#                                          logged-in account (passphrase +
#                                          file upload).
#   - POST /backup/restore/new-account -- PUBLIC (pre-login), for restoring
#                                          onto a freshly reinstalled machine.
#   - GET/POST/DELETE /backup/schedule -- view/configure/disable a
#                                          recurring automatic backup.

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import Response

from api.deps.auth_middleware import get_current_user
from backup.service import BackupError, create_full_backup, list_backup_items, restore_full_backup
from backup import schedule_service

router = APIRouter(prefix="/backup", tags=["backup"])


def _username_from_user(user: Any) -> str:
    if isinstance(user, dict):
        username = user.get("username")
    else:
        username = getattr(user, "username", None)
    if not username:
        raise HTTPException(status_code=401, detail="Authentication required.")
    return str(username)


def _parse_selection(selection: Optional[str]) -> Optional[dict]:
    if not selection:
        return None
    try:
        parsed = json.loads(selection)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid selection payload.")
    if not isinstance(parsed, dict):
        raise HTTPException(status_code=400, detail="Invalid selection payload.")
    return parsed


@router.get("/items")
async def backup_items(user: Any = Depends(get_current_user)):
    username = _username_from_user(user)
    return list_backup_items(username)


@router.post("/export")
async def export_backup(
    passphrase: str = Form(...),
    selection: Optional[str] = Form(None),
    user: Any = Depends(get_current_user),
):
    username = _username_from_user(user)
    try:
        data = create_full_backup(username, passphrase=passphrase, selection=_parse_selection(selection))
    except BackupError as e:
        raise HTTPException(status_code=400, detail=str(e))

    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    filename = f"{username}_athenaui_backup_{stamp}.athenabak"
    return Response(
        content=data,
        media_type="application/octet-stream",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.post("/restore")
async def restore_into_own_account(
    file: UploadFile = File(...),
    passphrase: str = Form(...),
    user: Any = Depends(get_current_user),
):
    """Restore a backup into the CURRENTLY LOGGED IN account. The archive's
    username must match the caller's -- restoring someone else's backup
    into your account is refused for safety."""
    username = _username_from_user(user)
    file_bytes = await file.read()
    try:
        result = restore_full_backup(file_bytes, passphrase=passphrase, expected_username=username, allow_create=False)
    except BackupError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return result


@router.post("/restore/new-account")
async def restore_into_new_account(
    file: UploadFile = File(...),
    passphrase: str = Form(...),
):
    """Public, pre-login restore flow for a freshly reinstalled AthenaUI on
    a new machine -- creates a brand-new local account from the backup's
    own embedded credentials. Refuses if that username already exists
    locally."""
    file_bytes = await file.read()
    try:
        result = restore_full_backup(file_bytes, passphrase=passphrase, expected_username=None, allow_create=True)
    except BackupError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return result


# ---------------------------------------------------------
# Scheduled (automatic) backups
# ---------------------------------------------------------

@router.get("/schedule")
async def get_schedule(user: Any = Depends(get_current_user)):
    username = _username_from_user(user)
    return schedule_service.get_schedule(username)


@router.post("/schedule")
async def set_schedule(payload: dict, user: Any = Depends(get_current_user)):
    username = _username_from_user(user)
    try:
        result = schedule_service.set_schedule(
            username,
            enabled=bool(payload.get("enabled")),
            frequency=str(payload.get("frequency") or "weekly"),
            time_of_day=str(payload.get("time_of_day") or "03:00"),
            destination_folder=str(payload.get("destination_folder") or ""),
            selection=payload.get("selection") or {"full_system": True},
            passphrase=payload.get("passphrase") or None,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return result


@router.delete("/schedule")
async def delete_schedule(user: Any = Depends(get_current_user)):
    username = _username_from_user(user)
    schedule_service.clear_schedule(username)
    return {"ok": True}


@router.post("/restore/new-account")
async def restore_as_new_account(file: UploadFile = File(...)):
    """Public, no-auth restore used from the Login page's Restore Backup
    flow (e.g. after reinstalling AthenaUI on a new machine). Only creates
    a brand-new local account -- refuses if that username already exists
    locally, to prevent a stray backup file being used to hijack/overwrite
    a different live account."""
    zip_bytes = await file.read()
    try:
        result = restore_full_backup(zip_bytes, expected_username=None, allow_create=True)
    except BackupError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return result
