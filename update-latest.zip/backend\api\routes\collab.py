# AthenaUI v3.5 — Collab Group Chat API Routes
# File: backend/api/routes/collab.py
#
# Authenticated REST endpoints for the Collab Group Chat feature: agents
# autonomously start these discussions themselves (see
# chat/collab/orchestrator.py, triggered today from auto_reply/monitor.py),
# and the user can browse the list of threads that exist, read the full
# transcript of one, and optionally join in and chat with that same agent
# or group of agents at any time -- reusing the same persistent thread.

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from auth.service import get_current_user
from chat.collab import service as collab_service

router = APIRouter(prefix="/collab", tags=["collab"])


class CollabMessageRequest(BaseModel):
    message: str


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _load_router(username: str, session_id: str):
    """Hydrates a saved Collab session into a live GroupChatRouter. Raises
    404 if it doesn't exist -- Collab sessions are only ever created by
    chat/collab/orchestrator.py (agents initiate them), never directly via
    this route file."""
    from chat.group.router import GroupChatRouter
    from characters.system.load import load_character

    data = collab_service.get_session(username, session_id)
    if not data:
        raise HTTPException(404, "Collab session not found")

    def get_safety_role(name: str) -> int:
        char = load_character(username, name)
        return char.get("safety_role", 0) if char else 0

    def get_delay_seconds() -> float:
        return 0.0

    session = GroupChatRouter.from_saved_state(
        data, get_safety_role=get_safety_role, get_delay_seconds=get_delay_seconds,
    )
    return session, data


def _save_router(username: str, session_id: str, session, original: Dict[str, Any]) -> None:
    data = session.to_dict()
    data.update({
        "id": session_id,
        "title": original.get("title"),
        "origin": original.get("origin"),
        "turn_cap": original.get("turn_cap"),
        "status": "concluded" if session.state.concluded else "active",
        "concluded_reason": session.state.concluded_reason,
        "created_at": original.get("created_at"),
        "last_activity_at": _now_iso(),
    })
    collab_service.save_session(username, session_id, data)


def _turn_dict(session, entry) -> Dict[str, Any]:
    return {
        "sender": entry["sender"],
        "message": entry["message"],
        "addressed_target": entry.get("addressed_target"),
        "timestamp": entry["timestamp"],
    }


@router.get("/sessions")
async def collab_list_sessions(user: Dict[str, Any] = Depends(get_current_user)):
    return {"sessions": collab_service.list_sessions(user["username"])}


@router.get("/sessions/{session_id}")
async def collab_get_session(session_id: str, user: Dict[str, Any] = Depends(get_current_user)):
    data = collab_service.get_session(user["username"], session_id)
    if not data:
        raise HTTPException(404, "Collab session not found")
    return {
        "id": data.get("id", session_id),
        "title": data.get("title") or session_id,
        "participants": data.get("character_names", []),
        "origin": data.get("origin", "manual"),
        "status": data.get("status", "active"),
        "concluded_reason": data.get("concluded_reason"),
        "created_at": data.get("created_at"),
        "last_activity_at": data.get("last_activity_at"),
        "history": [
            {"timestamp": m["timestamp"], "sender": m["sender"], "message": m["message"]}
            for m in data.get("history", [])
        ],
    }


@router.post("/sessions/{session_id}/message")
async def collab_send_message(
    session_id: str,
    payload: CollabMessageRequest,
    user: Dict[str, Any] = Depends(get_current_user),
):
    """The user joins an existing Collab thread and speaks -- appends their
    message, then immediately runs one agent turn so they get a reply."""
    username = user["username"]
    session, original = _load_router(username, session_id)

    await session.user_message(payload.message)
    result = await session.next_turn()

    _save_router(username, session_id, session, original)

    return {"status": "ok", "reply": _turn_dict(session, result) if result else None}


@router.post("/sessions/{session_id}/next_turn")
async def collab_next_turn(session_id: str, user: Dict[str, Any] = Depends(get_current_user)):
    """Lets the user request one more agent turn without saying anything
    themselves -- e.g. "keep going" after reading the transcript."""
    username = user["username"]
    session, original = _load_router(username, session_id)

    result = await session.next_turn()
    _save_router(username, session_id, session, original)

    return {"status": "ok", "reply": _turn_dict(session, result) if result else None}
