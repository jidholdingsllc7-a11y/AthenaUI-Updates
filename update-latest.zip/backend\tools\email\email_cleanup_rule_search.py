# AthenaUI v3.5 — email_cleanup_rule_search Tool
# File: backend/tools/email/email_cleanup_rule_search.py
#
# Lists the saved inbox cleanup rules for an account (or all accounts) --
# call this BEFORE cleaning up an inbox so you follow the user's taught
# keep/delete preferences instead of guessing.

from typing import Any, Dict

from email_rules.service import list_rules

capabilities = {
    "needs_filesystem": True,
    "needs_bridge": False,
    "needs_network": False,
    "needs_user": True,
}


async def run(args: Dict[str, Any]) -> str:
    try:
        username = args.get("username")
        if not username:
            return "[ERROR] Missing 'username' argument."

        rules = list_rules(username, account_label=args.get("account_label"))
        if not rules:
            return "No saved cleanup rules yet for this account."

        lines = [
            f"- id={r['id']} | {r['action']} when {r['match_type']} matches '{r['match_value']}'"
            + (f" (note: {r['note']})" if r.get("note") else "")
            for r in rules
        ]
        return "\n".join(lines)
    except Exception as e:
        return f"[ERROR] Failed to search cleanup rules: {str(e)}"
