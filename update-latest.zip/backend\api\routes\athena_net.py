# AthenaUI — Athena Net API Routes
# File: backend/api/routes/athena_net.py
# Created: 2026-11-02

from __future__ import annotations

import base64

from fastapi import APIRouter, Body, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse, Response

from api.deps.auth_middleware import get_current_user
from athena_net.dropbox_service import DropboxService, DropboxServiceError
from athena_net.dropbox_storage import DropboxStorageBackend
from athena_net.storage_backend import StorageBackendError

router = APIRouter(prefix="/athena_net", tags=["athena_net"])


def _username_from_user(user) -> str:
    username = user.get("username") if isinstance(user, dict) else getattr(user, "username", None)
    if not username:
        raise HTTPException(status_code=401, detail="Authentication required.")
    return str(username)


def _get_storage_backend(username: str, root_path: str | None = None) -> DropboxStorageBackend:
    try:
        return DropboxStorageBackend.for_user(username, root_path=root_path)
    except StorageBackendError as e:
        raise HTTPException(status_code=400, detail=str(e))


def _callback_redirect_uri(request: Request) -> str:
    return str(request.base_url).rstrip("/") + "/athena_net/dropbox/oauth/callback"


def _result_page(message: str, ok: bool) -> HTMLResponse:
    color = "#15803d" if ok else "#b91c1c"
    html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Athena Net — Dropbox</title></head>
<body style="font-family: sans-serif; text-align: center; padding: 60px 20px;">
<h2 style="color: {color};">{message}</h2>
<p>You can close this tab and return to Athena UI.</p>
<script>setTimeout(function() {{ window.close(); }}, 2000);</script>
</body></html>"""
    return HTMLResponse(content=html, status_code=200 if ok else 400)


@router.get("/dropbox/status")
async def dropbox_status(user=Depends(get_current_user)):
    username = _username_from_user(user)
    return DropboxService.get_status(username)


@router.post("/dropbox/oauth/start")
async def dropbox_oauth_start(request: Request, user=Depends(get_current_user)):
    username = _username_from_user(user)
    try:
        authorize_url = DropboxService.create_authorize_url(username, _callback_redirect_uri(request))
    except DropboxServiceError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"authorize_url": authorize_url}


@router.get("/dropbox/oauth/callback")
async def dropbox_oauth_callback(request: Request, code: str = "", state: str = "", error: str = ""):
    # Public route -- hit directly by the browser redirect from Dropbox, so
    # no Authorization header is present. The opaque `state` token (created
    # in dropbox_oauth_start and bound to the requesting username) is the
    # only thing that ties this request back to a specific account.
    if error:
        return _result_page(f"Dropbox authorization was not completed ({error}).", ok=False)
    if not code or not state:
        return _result_page("Missing authorization code from Dropbox.", ok=False)

    try:
        DropboxService.handle_callback(code, state, _callback_redirect_uri(request))
    except DropboxServiceError as e:
        return _result_page(f"Failed to connect Dropbox: {e}", ok=False)

    return _result_page("Dropbox connected successfully!", ok=True)


@router.post("/dropbox/disconnect")
async def dropbox_disconnect(user=Depends(get_current_user)):
    username = _username_from_user(user)
    DropboxService.disconnect(username)
    return {"ok": True}


@router.post("/dropbox/shared-folder")
async def dropbox_set_shared_folder(payload: dict = Body(...), user=Depends(get_current_user)):
    username = _username_from_user(user)
    path = str(payload.get("path", "")).strip()
    if not path:
        raise HTTPException(status_code=400, detail="path is required")
    normalized = DropboxService.set_shared_folder_path(username, path)
    return {"ok": True, "shared_folder_path": normalized}


@router.get("/dropbox/browse")
async def dropbox_browse(path: str = "", user=Depends(get_current_user)):
    # Browses from the TRUE Dropbox namespace root (not the configured
    # shared-folder root), so the user can find the real name of their
    # team's shared Team Folder (e.g. "jidholdingsllc") to select it.
    username = _username_from_user(user)
    backend = _get_storage_backend(username, root_path="/")
    try:
        return {"entries": backend.list(path)}
    except StorageBackendError as e:
        raise HTTPException(status_code=502, detail=str(e))


@router.get("/storage/list")
async def storage_list(path: str = "", user=Depends(get_current_user)):
    username = _username_from_user(user)
    backend = _get_storage_backend(username)
    try:
        return {"entries": backend.list(path)}
    except StorageBackendError as e:
        raise HTTPException(status_code=502, detail=str(e))


@router.get("/storage/file")
async def storage_read_file(path: str, user=Depends(get_current_user)):
    username = _username_from_user(user)
    backend = _get_storage_backend(username)
    try:
        data = backend.read(path)
    except StorageBackendError as e:
        raise HTTPException(status_code=502, detail=str(e))
    return Response(content=data, media_type="application/octet-stream")


@router.post("/storage/file")
async def storage_write_file(payload: dict = Body(...), user=Depends(get_current_user)):
    username = _username_from_user(user)
    path = str(payload.get("path", "")).strip()
    content = payload.get("content", "")
    encoding = str(payload.get("encoding", "utf8")).lower()
    if not path:
        raise HTTPException(status_code=400, detail="path is required")

    if encoding == "base64":
        try:
            data = base64.b64decode(content)
        except Exception:
            raise HTTPException(status_code=400, detail="content is not valid base64")
    else:
        data = str(content).encode("utf-8")

    backend = _get_storage_backend(username)
    try:
        backend.write(path, data)
    except StorageBackendError as e:
        raise HTTPException(status_code=502, detail=str(e))
    return {"ok": True}


@router.delete("/storage/file")
async def storage_delete_file(path: str, user=Depends(get_current_user)):
    username = _username_from_user(user)
    backend = _get_storage_backend(username)
    try:
        backend.delete(path)
    except StorageBackendError as e:
        raise HTTPException(status_code=502, detail=str(e))
    return {"ok": True}
