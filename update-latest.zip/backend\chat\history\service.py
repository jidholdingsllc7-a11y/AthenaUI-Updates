﻿# AthenaUI v3.5 — Chat History Manager
# File: backend/chat/history/service.py
# Created: 2026-04-06 21:15 CDT
# Updated: 2026-07-30 22:10 CDT
"""
Raw chat transcript storage. Backed entirely by the Maximos Memory Server
(same [user_id][agent_id]-isolated pipeline used by chat/memory/service.py's
MemoryManager for long-term facts) -- no Redis, no Vault. Maximos was built
to replace both for agent memory, so this is the single source of truth for
"what did we actually say to each other" history.

IMPORTANT: scoped per (username, character), matching MemoryManager's
convention -- `character=None` targets the same shared "global" bucket used
when no character is selected.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union
from uuid import uuid4

from core.runtime.runtime import get_runtime
from chat.memory.maximos_client import get_client as get_maximos_client

logger = logging.getLogger(__name__)


CHANNEL_PRIVATE_CHAT = "private_message"
CHANNEL_GROUP_CHAT = "group_chat_message"
CHANNEL_VOICE_CALL = "phone_call"
CHANNEL_BUILDMAP_CHAT = "private_message"
CHANNEL_TASKS_CHAT = "private_message"
CHANNEL_BROKERAGE_CHAT = "private_message"
CHANNEL_MARKETING_CHAT = "other"
CHANNEL_MOBILE_CHAT = "private_message"
CHANNEL_JOB_NOTE = "other"
# Not a real conversation channel -- a separate "agent summary" recall index
# (see chat/memory/service.py's MemoryManager.append_summary). Kept in
# _VALID_WIRE_CHANNELS below for consistency even though summary writes
# bypass normalize_channel() (MemoryManager talks to MaximosMemoryClient
# directly, same as this module does).
CHANNEL_AGENT_SUMMARY = "agent_summary"

# The Maximos Memory Server's `channel` field is a strict Rust enum with
# EXACTLY these six wire values -- anything else fails server-side
# validation with HTTP 422 and the write is silently dropped (the client
# fails soft and only logs a warning). AthenaUI's richer channel concepts
# above (build map / tasks / brokerage / mobile chat) therefore collapse
# onto "private_message" on the wire -- they're all still genuinely a 1:1
# conversation with the user -- while GROUP chat keeps its own distinct
# wire value so it never mixes into private chat history.
_VALID_WIRE_CHANNELS = {
    "private_message", "group_chat_message", "phone_call", "email", "other", "agent_summary",
}


def normalize_channel(channel: Optional[str], *, default: str = CHANNEL_PRIVATE_CHAT) -> str:
    raw = str(channel or "").strip().lower()
    if not raw:
        return default
    # Backward compatibility with a short-lived "event:xxx" naming scheme --
    # nothing tagged that way was ever actually persisted (every such write
    # was rejected by the server), but map it sensibly just in case.
    if raw.startswith("event:"):
        raw = raw.split("event:", 1)[1]
    if raw in _VALID_WIRE_CHANNELS:
        return raw
    return default


def channel_variants(channel: Optional[str]) -> List[str]:
    return [normalize_channel(channel)]


def expand_channels(channel: Union[str, Sequence[str], None]) -> Optional[List[str]]:
    """Like `channel_variants`, but accepts either a single canonical
    channel or a list of distinct canonical channels (e.g. every
    1:1-conversation channel: private chat, mobile chat, voice call) and
    returns the union of all their variants. Returns None when `channel` is
    None, meaning "no channel filter"."""
    if channel is None:
        return None
    if isinstance(channel, str):
        return channel_variants(channel)
    merged: List[str] = []
    for c in channel:
        merged.extend(channel_variants(c))
    return merged


class ChatHistoryItem:
    def __init__(self, id: str, role: str, content: str, timestamp: str = "", sender: str = ""):
        self.id = id
        self.role = role
        self.content = content
        self.timestamp = timestamp
        self.sender = sender


class ChatHistoryService:
    """
    Compatibility service expected by api/routes/chat.py.
    """

    def __init__(self, username: str, character: Optional[str] = None):
        self.username = username
        self.character = character
        self._mgr = HistoryManager(username)

    def get_history(self, limit: int = 50) -> List[ChatHistoryItem]:
        raw = self._mgr.load_short_history(self.character, limit=limit, include_sender=True)
        return [
            ChatHistoryItem(
                id=uuid4().hex,
                role=str(m.get("role") or "assistant"),
                content=str(m.get("content") or ""),
                timestamp=str(m.get("timestamp") or ""),
                sender=str(m.get("sender") or ""),
            )
            for m in raw
        ]

    def get_channel_history(self, limit: int = 20, channel: Optional[str] = None) -> List[Dict[str, str]]:
        """Recent turns for a specific channel as plain {"role", "content"}
        dicts, oldest-first -- ready to feed straight into an LLM message
        list (unlike get_history(), which is display-oriented)."""
        return self._mgr.load_short_history(self.character, limit=limit, channel=channel)

    def append(self, role: str, content: str, *, channel: Optional[str] = None) -> None:
        self._mgr.append_short_history(
            self.character,
            {"role": role, "content": content},
            channel=channel,
        )

    def clear(self) -> None:
        self._mgr.clear_short_history(self.character)


class HistoryManager:
    """
    Stores/retrieves the raw chat transcript for a (username, character) pair
    via the Maximos Memory Server.
    """

    def __init__(self, username: str):
        self.username = username
        self.maximos = get_maximos_client()

    @staticmethod
    def _agent_id(character: Optional[str]) -> str:
        return character or "global"

    # ---------------------------------------------------------
    # Raw transcript (Maximos-backed)
    # ---------------------------------------------------------
    def load_short_history(
        self,
        character: Optional[str] = None,
        limit: int = 50,
        channel: Union[str, Sequence[str], None] = None,
        include_sender: bool = False,
    ) -> List[Dict[str, Any]]:
        return self.maximos.load_recent_chat_turns(
            self.username,
            self._agent_id(character),
            limit=limit,
            channel=expand_channels(channel),
            include_sender=include_sender,
        )

    def load_recent_channel_entries(
        self,
        character: Optional[str],
        channel: Union[str, Sequence[str]],
        limit: int = 15,
    ) -> List[Dict[str, Any]]:
        """Returns raw recent entries (with the TRUE `sender` preserved --
        see `MaximosMemoryClient.store_group_turn`) for the given channel(s),
        oldest-first. Unlike `load_short_history`, this does NOT collapse
        the speaker down to a "user"/"assistant" role -- it's meant for
        cross-context awareness (e.g. showing a private-chat character what
        recently happened in group chat, correctly attributed), not for
        feeding directly into an LLM message list as literal turns."""
        entries = self.maximos.search(
            self.username,
            self._agent_id(character),
            "",
            channel=expand_channels(channel),
            limit=limit,
        )
        entries = list(reversed(entries))  # server returns newest-first
        return entries

    def append_short_history(
        self,
        character: Optional[str],
        message: Dict[str, Any],
        *,
        channel: Optional[str] = None,
    ) -> Tuple[Optional[str], str]:
        """Returns (entry_id, created_at) for the just-stored turn (entry_id
        is None if the write failed/was skipped, created_at is always the
        real timestamp used even on failure). Callers that don't need this
        can simply ignore the return value, same as before."""
        role = str(message.get("role") or "")
        content = str(message.get("content") or "")
        created_at = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        if not role or not content:
            return None, created_at
        entry_id = self.maximos.store_chat_turn(
            self.username,
            self._agent_id(character),
            role,
            content,
            channel=normalize_channel(channel),
            created_at=created_at,
        )
        return entry_id, created_at

    def clear_short_history(self, character: Optional[str] = None, channel: Union[str, Sequence[str], None] = None):
        self.maximos.clear_recent_chat_turns(
            self.username,
            self._agent_id(character),
            channel=expand_channels(channel),
        )


# ---------------------------------------------------------
# v3.0 PUBLIC API (module-level functions)
# ---------------------------------------------------------

def load_chat_history(username: str, character: Optional[str] = None, limit: int = 50):
    """
    Public API used by:
    - export engine
    - chat engine
    - tasks
    - character research
    """
    mgr = HistoryManager(username)
    return mgr.load_short_history(character, limit)


def append_chat_message(
    username: str,
    character: Optional[str],
    message: Dict[str, Any],
    *,
    channel: Optional[str] = None,
):
    mgr = HistoryManager(username)
    mgr.append_short_history(character, message, channel=channel)


def clear_chat_history(username: str, character: Optional[str] = None):
    mgr = HistoryManager(username)
    mgr.clear_short_history(character)


def export_chat_history(username: str, character: Optional[str] = None) -> Path:
    """
    Export chat history for a character to a JSON file and return its path.
    Compatibility API used by character export routes.
    """
    runtime = get_runtime()
    session_label = character or "default"
    out_dir = runtime.env.DATA_DIR / "users" / username / "exports" / "chat"
    out_dir.mkdir(parents=True, exist_ok=True)

    messages = load_chat_history(username, character=character, limit=9999)
    out_path = out_dir / f"{session_label}_history.json"
    out_path.write_text(json.dumps(messages, indent=2), encoding="utf-8")
    return out_path


def restore_chat_history(username: str, character: Optional[str] = None) -> None:
    """
    Restore chat history from exported JSON back into Maximos.
    Compatibility API used by character restore routes.
    """
    runtime = get_runtime()
    session_label = character or "default"
    in_path = runtime.env.DATA_DIR / "users" / username / "exports" / "chat" / f"{session_label}_history.json"
    if not in_path.exists():
        return

    try:
        messages = json.loads(in_path.read_text(encoding="utf-8"))
    except Exception:
        return

    clear_chat_history(username, character=character)
    for msg in messages if isinstance(messages, list) else []:
        if isinstance(msg, dict):
            append_chat_message(username, character, msg)
