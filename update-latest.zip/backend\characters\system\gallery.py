﻿# AthenaUI v3.5 — Character Gallery Helper
# File: backend/characters/system/gallery.py
# Created: 2026-04-11 11:45 CDT
# Updated: 2026-09-27 21:00 CDT

import json
from pathlib import Path

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".gif"}

def list_character_gallery(username: str, character: str) -> dict:
    base = Path(f"data/users/{username}/characters/{character}/gallery")

    categories = ["modern", "pair", "pets", "images"]
    result = {}

    for cat in categories:
        folder = base / cat
        if folder.exists():
            result[cat] = [
                f"/data/users/{username}/characters/{character}/gallery/{cat}/{img.name}"
                for img in sorted(folder.iterdir(), key=lambda p: p.name.lower())
                if img.is_file() and img.suffix.lower() in IMAGE_EXTENSIONS
            ]
        else:
            result[cat] = []

    return result


def _read_image_metadata(image_path: Path) -> dict:
    """Reads the JSON sidecar written by ImageGenerationService._write_image_metadata
    (same filename, .json extension) if one exists. Older images generated
    before metadata sidecars existed simply have none -- returns {}."""
    sidecar = image_path.with_suffix(".json")
    if not sidecar.exists() or not sidecar.is_file():
        return {}
    try:
        return json.loads(sidecar.read_text(encoding="utf-8"))
    except Exception:
        return {}


def list_character_gallery_detailed(username: str, character: str) -> dict:
    """
    Like list_character_gallery, but each image entry is an object carrying
    whatever metadata is available (prompt used to generate it, when, who's
    in it, etc.) instead of a bare URL string -- lets an agent actually
    "see" what each existing photo depicts (via its prompt/description)
    well enough to pick a specific one as a reference for a new pair/group
    photo, instead of always defaulting to the same avatar/first-in-folder
    image. Used by the image_gallery_list tool; the plain URL-list shape of
    list_character_gallery() is left untouched for existing REST consumers.
    """
    base = Path(f"data/users/{username}/characters/{character}/gallery")

    categories = ["modern", "pair", "pets", "images"]
    result: dict = {}

    for cat in categories:
        folder = base / cat
        entries = []
        if folder.exists():
            for img in sorted(folder.iterdir(), key=lambda p: p.name.lower()):
                if not (img.is_file() and img.suffix.lower() in IMAGE_EXTENSIONS):
                    continue
                meta = _read_image_metadata(img)
                entries.append({
                    "url": f"/data/users/{username}/characters/{character}/gallery/{cat}/{img.name}",
                    "filename": img.name,
                    "prompt": meta.get("prompt"),
                    "characters": meta.get("characters"),
                    "created_at": meta.get("created_at"),
                })
        result[cat] = entries

    return result
