﻿# AthenaUI v3.5 — Base LLM Router
# File: backend/llm/routers/base.py
# Created: 2026-03-28 20:28 CDT
# Updated: 2026-07-27 19:49 CDT

import json
import re
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional


class ImageModerationBlocked(RuntimeError):
    """Raised when an image provider rejects a generation/edit request (or
    its own output) for violating its content safety system -- distinct
    from other failures (bad key, network error, unsupported model) so
    callers can retry once (these are often non-deterministic per attempt)
    instead of treating it like every other error."""


def raise_for_openai_compatible_image_response(response) -> None:
    """requests' own `raise_for_status()` discards the response body, which
    for OpenAI-shaped image error responses is where the actually useful
    detail lives (e.g. which safety category got tripped) -- surface it, and
    raise `ImageModerationBlocked` specifically for a moderation rejection so
    callers can tell it apart from a real/persistent failure. Shared by any
    router whose provider's image API returns OpenAI-shaped error bodies
    (OpenAI itself, xAI's OpenAI-compatible endpoints)."""
    if response.status_code < 400:
        return
    try:
        body = response.json()
        detail = (body.get("error") or {}).get("message") or response.text
        code = (body.get("error") or {}).get("code") or ""
    except ValueError:
        detail = response.text
        code = ""
    if code == "moderation_blocked" or "safety system" in detail.lower():
        raise ImageModerationBlocked(detail)
    raise RuntimeError(f"Image request failed ({response.status_code}): {detail}")


def model_rejects_custom_temperature(model_id: str) -> bool:
    """OpenAI's reasoning-family models (o1/o3/o4/gpt-5+) only accept the
    API's own default temperature and reject any other explicit value
    ("Unsupported value: 'temperature' does not support 0.7 with this
    model. Only the default (1) value is supported.") -- detected by model
    ID prefix since there's no registry flag for this yet. Matches any
    "gpt-<N>" where N >= 5 (not a fixed "gpt-5"/"gpt-6" list) so a future
    gpt-7/gpt-8/etc. reasoning model is caught automatically instead of
    needing a code change every time OpenAI ships a new generation (this
    bit us live with "gpt-6.1-sol", which the old fixed-prefix check missed)."""
    normalized = (model_id or "").strip().lower()
    if normalized.startswith(("o1", "o3", "o4")):
        return True
    match = re.match(r"gpt-(\d+)", normalized)
    return bool(match) and int(match.group(1)) >= 5


def anthropic_model_rejects_custom_temperature(model_id: str) -> bool:
    """Anthropic's newer Claude generations (confirmed live for
    claude-sonnet-5, via "`temperature` is deprecated for this model.")
    reject any explicit `temperature` value outright -- detected by model ID
    since there's no registry flag for this yet. Matches any
    "claude-<family>-<N>" where N >= 5 so a future claude-opus-6/haiku-6/etc.
    is caught automatically instead of needing a code change per release."""
    normalized = (model_id or "").strip().lower()
    match = re.search(r"claude-[a-z]+-(\d+)", normalized)
    return bool(match) and int(match.group(1)) >= 5


def model_requires_responses_api(model_id: str) -> bool:
    """OpenAI's reasoning-family models (o1/o3/o4/gpt-5.x, confirmed live
    for gpt-5.5 too) reject tool calls over Chat Completions unless
    reasoning_effort is "none" ("To use function tools, use /v1/responses
    or set reasoning_effort to none") -- the Responses API is the only
    endpoint that supports real reasoning_effort together with tool calls.
    Alias of the same reasoning-family prefix check as
    model_rejects_custom_temperature, kept as a separate function since the
    two facts (temperature rejection vs. needing the Responses API) happen
    to overlap today but are conceptually distinct and may diverge later."""
    return model_rejects_custom_temperature(model_id)


class BaseLLMRouter(ABC):
    """
    Base class for all provider-specific routers.
    Each router must implement the core chat interface.
    """

    def __init__(self, provider_id: str, model_id: str, capabilities: Dict[str, Any]):
        self.provider_id = provider_id
        self.model_id = model_id
        self.capabilities = capabilities
        # Optional per-request reasoning/thinking effort (e.g. "low",
        # "medium", "high", "xhigh", "max"), set by ChatEngine/route
        # handlers right after selecting a router, based on the user's
        # dropdown choice in ChatPage/SidebarChat. Not every provider
        # supports this -- routers that don't understand it simply never
        # read it, so it's a safe universal no-op by default here in the
        # base class rather than a per-router constructor kwarg.
        self.reasoning_effort: Optional[str] = None

    # ---------------- System Prompt Extraction ----------------

    @staticmethod
    def _extract_system_prompt(messages: List[Dict[str, Any]]):
        """
        Pulls any existing role="system" messages (e.g. character persona
        and memory prompts injected upstream by ChatEngine/PersonaManager)
        out of a messages list.

        Returns a tuple of (merged_system_content_or_None, remaining_messages)
        so provider routers can treat upstream-injected system content as the
        authoritative base prompt instead of silently overriding/duplicating
        it with their own hardcoded identity prompt.
        """
        system_parts = []
        remaining = []
        # Only forward keys every provider payload builder downstream
        # actually understands -- callers often source `messages` from chat
        # history records that carry extra bookkeeping fields (e.g.
        # "timestamp", "sender"); passing those through verbatim makes
        # schema-strict providers like Anthropic reject the whole request
        # with a 400 "Extra inputs are not permitted".
        _ALLOWED_MESSAGE_KEYS = {"role", "content", "tool_calls", "tool_call_id", "name"}
        for msg in messages:
            if msg.get("role") == "system" and msg.get("content"):
                system_parts.append(msg["content"])
            else:
                remaining.append({k: v for k, v in msg.items() if k in _ALLOWED_MESSAGE_KEYS})
        merged = "\n\n".join(system_parts) if system_parts else None
        return merged, remaining

    # ---------------- tool_choice normalization ----------------

    # ---------------- Prompt caching (Anthropic cache_control) ----------------

    @staticmethod
    def _anthropic_system_with_cache(system_prompt: Optional[str]) -> Any:
        """Wraps a system prompt string in Anthropic's content-block array
        format with an explicit `cache_control` breakpoint, so the system
        prompt (persona + tool-usage examples -- identical on nearly every
        call) is read from Anthropic's prompt cache instead of being
        reprocessed at full price every turn. Shared by AnthropicRouter and
        BedrockRouter (Bedrock's Anthropic-model InvokeModel body accepts
        the same Messages API system/cache_control shape). Caching a prompt
        under the model's minimum cacheable length (varies by model) is a
        harmless no-op per Anthropic's docs, so no size check is needed
        here."""
        if not system_prompt:
            return system_prompt
        return [{"type": "text", "text": system_prompt, "cache_control": {"type": "ephemeral"}}]

    @staticmethod
    def _anthropic_tools_with_cache(tools: Optional[List[Dict[str, Any]]]) -> Optional[List[Dict[str, Any]]]:
        """Marks the last tool definition with a `cache_control` breakpoint
        so the (static, often large) tools array is cached as a unit across
        calls instead of being reprocessed every request -- Anthropic caches
        `tools` -> `system` -> `messages` as a single chained prefix, so one
        breakpoint on the last tool covers the whole array."""
        if not tools:
            return tools
        tools = list(tools)
        last = dict(tools[-1])
        last["cache_control"] = {"type": "ephemeral"}
        tools[-1] = last
        return tools

    @staticmethod
    def _to_anthropic_tool_choice(tool_choice: Optional[Any]) -> Optional[Dict[str, Any]]:
        """Converts a generic OpenAI-style tool_choice (a bare string such as
        "auto"/"required"/"none", or an OpenAI {"type": "function",
        "function": {"name": ...}} object) into Anthropic's object-shaped
        tool_choice. Anthropic's Messages API rejects a bare string outright
        with "tool_choice: Input should be an object" -- shared by
        AnthropicRouter and BedrockRouter (Bedrock's Anthropic-model
        InvokeModel body uses this same shape)."""
        if tool_choice is None:
            return None
        if isinstance(tool_choice, dict):
            if tool_choice.get("type") == "function":
                name = (tool_choice.get("function") or {}).get("name")
                if name:
                    return {"type": "tool", "name": name}
            return tool_choice
        normalized = str(tool_choice).strip().lower()
        if normalized in ("required", "any"):
            return {"type": "any"}
        if normalized == "none":
            return {"type": "none"}
        return {"type": "auto"}

    @staticmethod
    def _to_gemini_tool_choice(tool_choice: Optional[Any]) -> Optional[Dict[str, Any]]:
        """Converts a generic OpenAI-style tool_choice into Gemini's
        functionCallingConfig object ({"mode": "AUTO"|"ANY"|"NONE"}) --
        Gemini rejects a bare string the same way Anthropic does."""
        if tool_choice is None:
            return None
        if isinstance(tool_choice, dict):
            return tool_choice
        normalized = str(tool_choice).strip().lower()
        if normalized in ("required", "any"):
            return {"mode": "ANY"}
        if normalized == "none":
            return {"mode": "NONE"}
        return {"mode": "AUTO"}

    @staticmethod
    def _to_anthropic_tools(tools: Optional[List[Dict[str, Any]]]) -> Optional[List[Dict[str, Any]]]:
        """Converts OpenAI-style function tool schemas ({"type": "function",
        "function": {"name", "description", "parameters"}}) into Anthropic's
        discriminated tool schema ({"type": "custom", "name", "description",
        "input_schema"}) -- newer Anthropic API versions reject the OpenAI
        "function" tag outright ("Input tag 'function' ... does not match
        any of the expected tags"). Shared by AnthropicRouter and
        BedrockRouter (Bedrock's Anthropic-model InvokeModel body uses this
        same tool shape)."""
        if not tools:
            return tools
        converted = []
        for tool in tools:
            if isinstance(tool, dict) and tool.get("type") == "function":
                fn = tool.get("function") or {}
                converted.append({
                    "type": "custom",
                    "name": fn.get("name"),
                    "description": fn.get("description", ""),
                    "input_schema": fn.get("parameters") or {"type": "object", "properties": {}},
                })
            else:
                converted.append(tool)
        return converted

    @staticmethod
    def _to_anthropic_messages(messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Translates OpenAI-shaped chat messages into Anthropic's message
        format: Anthropic has no "tool" role (tool results must be a "user"
        message with a tool_result content block) and no top-level
        "tool_calls" field on assistant messages (tool calls must be
        "tool_use" content blocks instead). Without this, a multi-round
        tool-calling conversation either gets rejected outright (unknown
        role "tool") or silently loses every prior tool call. Shared by
        AnthropicRouter and BedrockRouter."""
        converted: List[Dict[str, Any]] = []
        for msg in messages:
            role = msg.get("role")
            if role == "tool":
                converted.append({
                    "role": "user",
                    "content": [{
                        "type": "tool_result",
                        "tool_use_id": msg.get("tool_call_id"),
                        "content": str(msg.get("content") or ""),
                    }],
                })
                continue
            if role == "assistant" and msg.get("tool_calls"):
                blocks: List[Dict[str, Any]] = []
                text = msg.get("content")
                if text:
                    blocks.append({"type": "text", "text": text})
                for call in msg["tool_calls"]:
                    fn = call.get("function") or {}
                    args = fn.get("arguments")
                    if isinstance(args, str):
                        try:
                            args = json.loads(args) if args else {}
                        except ValueError:
                            args = {}
                    blocks.append({
                        "type": "tool_use",
                        "id": call.get("id"),
                        "name": fn.get("name"),
                        "input": args if isinstance(args, dict) else {},
                    })
                converted.append({"role": "assistant", "content": blocks})
                continue
            content = msg.get("content")
            if isinstance(content, list):
                converted.append({"role": role, "content": BaseLLMRouter._to_anthropic_content_blocks(content)})
                continue
            # Only {"role", "content"} are valid here -- Anthropic's schema
            # rejects unknown keys outright (e.g. a "timestamp" key carried
            # over from chat-history dicts causes a 400 "Extra inputs are
            # not permitted"), so never pass the original msg dict through
            # as-is.
            converted.append({"role": role, "content": content})
        return converted

    @staticmethod
    def _to_anthropic_content_blocks(blocks: List[Any]) -> List[Dict[str, Any]]:
        """Converts OpenAI-shaped multimodal content blocks (the
        `{"type": "image_url", "image_url": {"url": "data:<mime>;base64,..."}}`
        shape every caller in this codebase builds, e.g. chat.py's image
        upload/analysis flow) into Anthropic's own block shape (`{"type":
        "image", "source": {"type": "base64", "media_type": ..., "data":
        ...}}`) -- Anthropic's API otherwise rejects the request outright
        since it has no concept of an "image_url" block type. Only inline
        base64 data URIs are supported (not remote http(s) image URLs,
        which none of our callers currently send)."""
        converted: List[Dict[str, Any]] = []
        for block in blocks:
            if not isinstance(block, dict):
                converted.append(block)
                continue
            if block.get("type") == "image_url":
                url = (block.get("image_url") or {}).get("url", "")
                match = re.match(r"^data:([^;]+);base64,(.+)$", url, re.DOTALL)
                if match:
                    converted.append({
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": match.group(1),
                            "data": match.group(2),
                        },
                    })
                    continue
            converted.append(block)
        return converted

    # ---------------- Core Chat Interface ----------------

    @abstractmethod
    def chat(
        self,
        messages: List[Dict[str, Any]],
        *,
        tools: Optional[List[Dict[str, Any]]] = None,
        tool_choice: Optional[str] = None,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Synchronous chat completion.
        Returns a normalized response dict.
        """
        raise NotImplementedError

    # ---------------- Streaming (optional) ----------------

    def stream_chat(
        self,
        messages: List[Dict[str, Any]],
        *,
        tools: Optional[List[Dict[str, Any]]] = None,
        tool_choice: Optional[str] = None,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ):
        """
        Streaming chat completion.
        Default implementation raises if not supported.
        """
        if not self.capabilities.get("streaming", False):
            raise RuntimeError(f"Streaming not supported for model '{self.model_id}'.")
        raise NotImplementedError

    # ---------------- Images (optional) ----------------

    def generate_image(
        self,
        prompt: str,
        *,
        size: str = "1024x1024",
        n: int = 1,
    ) -> Dict[str, Any]:
        """
        Image generation.
        Default implementation raises if not supported.
        """
        if not self.capabilities.get("images", False):
            raise RuntimeError(f"Image generation not supported for model '{self.model_id}'.")
        raise NotImplementedError

    def generate_image_edit(
        self,
        prompt: str,
        images: List[bytes],
        *,
        size: str = "1024x1024",
        n: int = 1,
    ) -> Dict[str, Any]:
        """
        Image editing/composition using one or more reference images (e.g.
        turning a character's existing avatar into a new selfie, or
        combining two characters' reference photos into one image).
        Default implementation raises if not supported -- only providers/
        models that actually support an image-edit-with-references endpoint
        (e.g. OpenAI's gpt-image family) should override this.
        """
        raise NotImplementedError

    # ---------------- Embeddings (optional) ----------------

    def embed(
        self,
        inputs: List[str],
    ) -> Dict[str, Any]:
        """
        Text embeddings.
        Default implementation raises; provider routers can override.
        """
        raise NotImplementedError
