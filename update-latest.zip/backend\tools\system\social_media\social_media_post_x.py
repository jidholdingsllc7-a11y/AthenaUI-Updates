# AthenaUI -- Social Media X (Twitter) Post Tool
# File: backend/tools/system/social_media/social_media_post_x.py
#
# Posts a tweet to the user's configured X account. Publicly visible and
# irreversible once posted, so this is flagged dangerous/requires_approval --
# the executor's approval gate (tools/executor/executor.py:_enforce_capabilities)
# will surface an Allow/Deny prompt in the sidebar before this ever actually runs.

from typing import Any, Dict

capabilities = {
    "needs_bridge": False,
    "needs_filesystem": False,
    "needs_network": True,
    "needs_user": True,
    "is_dangerous": True,
    "requires_approval": True,
}


async def run(args: Dict[str, Any]):
    username = args.get("username")
    content = (args.get("content") or "").strip()
    if not content:
        return {"error": "Missing 'content' argument."}

    from social_media import settings as social_media_settings
    from social_media.x_client import XClient, XError

    creds = social_media_settings.get_x_credentials(username)
    if not creds:
        return {"error": "No X credentials configured. Ask the user to add them in Social Media settings."}

    client = XClient(**creds)
    try:
        result = await client.post_tweet(content)
    except XError as e:
        return {"error": str(e)}

    data = result.get("data") or {}
    response = {"ok": True, "result": result}
    if "verified_text" in data:
        response["verified_text"] = data["verified_text"]
        response["verified_length"] = data["verified_length"]
        response["verification_note"] = (
            "verified_text is X's own authoritative read-back of the published post -- compare it to the "
            "submitted content to confirm nothing was cut off. A shortened https://t.co/... link in place of "
            "a longer URL is expected (X auto-shortens all links) and does not indicate truncation."
        )
    return response
