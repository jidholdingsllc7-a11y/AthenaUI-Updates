# AthenaUI v3.5 — Image Gallery List Tool
# File: backend/tools/system/images/image_gallery_list.py
# Purpose: Lets an agent see what photos already exist in their own gallery
# (grouped by category, with URLs) instead of only being able to generate
# brand-new ones -- fixes characters who could generate selfies but had no
# way to actually "see" what was already saved.
# Created: 2026-08-06

from typing import Any, Dict
from characters.system.gallery import list_character_gallery_detailed

capabilities = {
    "needs_bridge": False,
    "needs_filesystem": True,
    "needs_network": False,
    "needs_user": True,
}


async def run(args: Dict[str, Any]):
    username = args.get("username", "system")
    # `character` is server-injected (always the calling agent). An
    # explicit `other_character` lets an agent look at a DIFFERENT named
    # character's gallery too -- e.g. to see what photos a partner already
    # has before picking one as a reference for a pair photo together.
    character = args.get("other_character") or args.get("character") or args.get("character_id")

    if not character:
        return {"error": "Missing character for gallery listing"}

    gallery = list_character_gallery_detailed(username, character)
    total = sum(len(v) for v in gallery.values())

    return {
        "character": character,
        "gallery": gallery,
        "total_images": total,
        "chat_message": (
            f"{character} has {total} photo(s) saved in their gallery. Each entry's \"prompt\" "
            "describes what it depicts -- pass its \"url\" as a reference_image when generating "
            "a new selfie/pair/group photo to use that specific photo instead of the default one."
            if total else
            f"{character}'s gallery is currently empty -- no photos saved yet."
        ),
    }
