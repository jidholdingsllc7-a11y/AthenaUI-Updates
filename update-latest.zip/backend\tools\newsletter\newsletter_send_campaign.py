# AthenaUI v3.5 — newsletter_send_campaign Tool
# File: backend/tools/newsletter/newsletter_send_campaign.py
#
# Sends one email (a newsletter issue) to every currently-subscribed
# address, using the user's configured email account (see tools/email/
# email_send.py for the underlying account/sharing rules). This sends real
# email to real people right away -- dangerous/requires_approval, mirroring
# social_media_post_x.py's pattern, so the executor's approval gate shows
# an Allow/Deny prompt before this actually runs. For a FUTURE send date,
# don't call this directly -- use the schedule_job tool instead and
# describe this exact action as the task, so the user approves it once,
# at send time.

from typing import Any, Dict

from newsletter.service import NewsletterError, list_subscribers
from emailing.service import EmailServiceError, EmailAccountsService

capabilities = {
    "needs_filesystem": True,
    "needs_bridge": False,
    "needs_network": True,
    "needs_user": True,
    "is_dangerous": True,
    "requires_approval": True,
}


async def run(args: Dict[str, Any]) -> str:
    try:
        username = args.get("username")
        character = args.get("character")
        subject = args.get("subject")
        body = args.get("body")

        if not username:
            return "[ERROR] Missing 'username' argument."
        if not character:
            return "[ERROR] No active agent identity -- sending a campaign requires one."
        if not subject:
            return "[ERROR] Missing 'subject' argument."
        if not body:
            return "[ERROR] Missing 'body' argument."

        subscribers = list_subscribers(username, status="subscribed")
        if not subscribers:
            return "No subscribed newsletter recipients -- nothing sent."

        sent, failed = 0, []
        for sub in subscribers:
            try:
                EmailAccountsService.send_email(
                    username=username,
                    character=character,
                    to=sub["email"],
                    subject=subject,
                    body=body,
                    account_label=args.get("account_label"),
                )
                sent += 1
            except EmailServiceError as e:
                failed.append(f"{sub['email']} ({e})")

        summary = f"Newsletter sent to {sent}/{len(subscribers)} subscriber(s)."
        if failed:
            summary += " Failed: " + "; ".join(failed)
        return summary
    except NewsletterError as e:
        return f"[ERROR] {e}"
    except Exception as e:
        return f"[ERROR] Failed to send newsletter campaign: {str(e)}"
