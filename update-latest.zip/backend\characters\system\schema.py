﻿# AthenaUI v3.5 — Character Schema
# File: backend/characters/system/schema.py
# Created: 2026-04-10 22:34 CDT
# Updated: 2026-07-27 19:49 CDT

from typing import TypedDict, Literal, Optional

# ---------------------------------------------------------
#  PROFILE
# ---------------------------------------------------------

class FamilyTie(TypedDict, total=False):
    character: str  # name/key of the existing related character
    relation: str    # e.g. "sister", "brother", "mother", "father", "daughter", "son"


class CharacterProfile(TypedDict, total=False):
    full_name: str
    age: int
    gender: str
    occupation: str
    traits: list[str]
    appearance: str  # physical description, written to double as an avatar image-generation prompt
    backstory: str
    avatar: dict  # { "type": "uploaded" | "generated", "path": str }
    family_ties: list[FamilyTie]


# ---------------------------------------------------------
#  SKILLS
# ---------------------------------------------------------

class CharacterSkills(TypedDict, total=False):
    domains: list[str]
    preferences: dict
    training_notes: str


# ---------------------------------------------------------
#  RELATIONSHIPS
# ---------------------------------------------------------

class CharacterRelationship(TypedDict, total=False):
    status: str
    partner: str


class RelationshipToUser(TypedDict, total=False):
    mode: Literal["professional", "friendly", "dating", "romantic", "family", "other"]
    notes: str


# ---------------------------------------------------------
#  MEMORY
# ---------------------------------------------------------

class CharacterMemory(TypedDict, total=False):
    chat_history: list
    notes: str


# ---------------------------------------------------------
#  META
# ---------------------------------------------------------

class CharacterMeta(TypedDict, total=False):
    version: str
    source: str  # "auto" | "partial" | "full" | "research" | "imported"
    created_at: str
    updated_at: str


# ---------------------------------------------------------
#  FULL CHARACTER
# ---------------------------------------------------------

class Character(TypedDict, total=False):
    id: str
    name: str
    voice_id: Optional[str]
    is_agent: bool  # user-created characters only -- grants Agent/tool-use capability (see is_agent_character())
    profile: CharacterProfile
    skills: CharacterSkills
    relationship: CharacterRelationship
    relationship_to_user: RelationshipToUser
    memory: CharacterMemory
    meta: CharacterMeta


# ---------------------------------------------------------
#  DEFAULT SCHEMA BUILDER
# ---------------------------------------------------------

def new_character_base() -> Character:
    return {
        "id": "",
        "name": "",
        "voice_id": None,
        "is_agent": False,
        "profile": {
            "full_name": "",
            "age": 25,
            "gender": "",
            "occupation": "",
            "traits": [],
            "appearance": "",
            "backstory": "",
            "avatar": {"type": None, "path": None},
            "family_ties": [],
        },
        "skills": {
            "domains": [],
            "preferences": {},
            "training_notes": "",
        },
        "relationship": {
            "status": "",
            "partner": "",
        },
        "relationship_to_user": {
            "mode": "professional",
            "notes": "",
        },
        "memory": {
            "chat_history": [],
            "notes": "",
        },
        "meta": {
            "version": "3.0",
            "source": "auto",
            "created_at": "",
            "updated_at": "",
        },
    }


# ---------------------------------------------------------
#  VALIDATION
# ---------------------------------------------------------

def validate_character_schema(char: dict):
    """
    Light validation to ensure required fields exist.
    """
    if "name" not in char or not char["name"]:
        raise ValueError("Character must have a name.")

    if "profile" not in char:
        raise ValueError("Character missing profile section.")

    if "meta" not in char:
        raise ValueError("Character missing meta section.")

    return True


# ---------------------------------------------------------
#  AGENT CAPABILITY
# ---------------------------------------------------------

def is_agent_character(char: dict | None) -> bool:
    """
    Whether this character is allowed to use Agent/tool-use capabilities
    (scheduler, brokerage, filesystem, terminal, browser/UI automation, etc.)
    rather than being confined to plain chat/companion features.

    True for:
      - Built-in system agents (`system_owned: true`, e.g. Orion Lumos) --
        always trusted, regardless of the newer `is_agent` flag.
      - User-created characters that have been explicitly promoted via the
        `is_agent` flag (set at creation time or toggled later in the
        character editor).

    Defaults to False for any user-created character that hasn't opted in,
    so newly created characters are chat-only until deliberately granted
    Agent capability.
    """
    if not isinstance(char, dict):
        return False
    return bool(char.get("system_owned")) or bool(char.get("is_agent"))

