﻿# AthenaUI v3.5 — Provider-specific router for DeepSeek models
# File: backend/llm/routers/deepseek_router.py
# Created: 2026-03-28 21:14 CDT
# Updated: 2026-07-27 19:49 CDT

import json
import requests
from typing import Any, Dict, List, Optional

from llm.routers.base import BaseLLMRouter
from llm.router_selector.router_selector import RouterSelector
from llm.routers.providers import PROVIDER_DEEPSEEK
from core.runtime.runtime import get_runtime

from tools.registry.tool_examples import TOOL_EXAMPLES



class DeepSeekRouter(BaseLLMRouter):
    """
    Provider-specific router for DeepSeek models.
    Supports:
    - chat
    - tool calling (OpenAI v2â€“style)
    - streaming (stub)
    """

    API_URL = "https://api.deepseek.com/v1/chat/completions"

    # ---------------------------------------------------------
    # Build system prompt with tool examples
    # ---------------------------------------------------------

    def _build_system_prompt(self, base_prompt: Optional[str], *, include_tool_examples: bool = True) -> str:
        if not include_tool_examples:
            return base_prompt if base_prompt else "You are AthenaUI v3.1."

        examples_json = json.dumps(TOOL_EXAMPLES, indent=2)

        tool_usage_block = f"""
You have access to a set of tools. Use them whenever needed.

Here are examples of correct tool usage:
{examples_json}

DeepSeek tool calling rules (OpenAI v2 compatible):
- Use "tools": [...] to declare tools
- Use "tool_choice": ... to force a tool
- Return tool calls in "message.tool_calls"

If you need to call a tool, do NOT explain â€” just call it.
"""

        if base_prompt:
            return base_prompt + "\n\n" + tool_usage_block

        return "You are AthenaUI v3.1.\n\n" + tool_usage_block

    # ---------------------------------------------------------
    # Chat Completion
    # ---------------------------------------------------------

    def chat(
        self,
        messages: List[Dict[str, Any]],
        *,
        tools: Optional[List[Dict[str, Any]]] = None,
        tool_choice: Optional[str] = None,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> Dict[str, Any]:

        runtime = get_runtime()
        api_key = runtime.env.DEEPSEEK_API_KEY

        if not api_key:
            raise RuntimeError("DeepSeek API key not set.")

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }

        # Extract any upstream persona/memory system prompt already present
        extracted_prompt, remaining_messages = self._extract_system_prompt(messages)
        final_system_prompt = self._build_system_prompt(system_prompt or extracted_prompt, include_tool_examples=bool(tools))

        # Inject system message
        full_messages = [{"role": "system", "content": final_system_prompt}] + remaining_messages

        payload: Dict[str, Any] = {
            "model": self.model_id,
            "messages": full_messages,
            "temperature": temperature,
        }

        if max_tokens is not None:
            payload["max_tokens"] = max_tokens

        # Tool calling (OpenAI v2â€“style)
        if tools:
            payload["tools"] = tools
            if tool_choice:
                payload["tool_choice"] = tool_choice

        # Send request
        response = requests.post(self.API_URL, json=payload, headers=headers)
        response.raise_for_status()
        data = response.json()

        # Normalize DeepSeek response
        choice = data["choices"][0]
        message = choice.get("message", {})

        result = {
            "id": data.get("id"),
            "model": data.get("model"),
            "content": message.get("content"),
            "tool_calls": message.get("tool_calls"),
            "finish_reason": choice.get("finish_reason"),
            "raw": data,
        }

        return result

    # ---------------------------------------------------------
    # Streaming (stub)
    # ---------------------------------------------------------

    def stream_chat(
        self,
        messages: List[Dict[str, Any]],
        *,
        tools: Optional[List[Dict[str, Any]]] = None,
        tool_choice: Optional[str] = None,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ):
        raise NotImplementedError("DeepSeek streaming not implemented yet.")


# ---------------------------------------------------------
# Register Router
# ---------------------------------------------------------

RouterSelector.register_router(PROVIDER_DEEPSEEK, DeepSeekRouter)

