# AthenaUI v3.7 — Project Build-Completeness Check Tool
# File: backend/tools/system/build_check/project_build_check.py
# Created: 2026-10-25

from __future__ import annotations

from typing import Any, Dict

from ._common import BuildCheckError, detect_build_command, resolve_target_dir, run_command

capabilities = {
    "needs_filesystem": True,
    "needs_bridge": False,
    "needs_network": False,
    "needs_user": True,
    "is_dangerous": True,
}


async def run(args: Dict[str, Any]) -> Dict[str, Any]:
    """
    Verifies a project actually builds/compiles cleanly -- auto-detects the
    right command (npm run build / tsc --noEmit / cargo check / go build /
    python -m compileall) from project marker files, or runs an explicit
    `command` override if given.
    """
    username = args.get("username")
    if not username:
        return {"status": "error", "error": "Missing required argument: username."}

    try:
        target = resolve_target_dir(username, args.get("path"), args.get("_scope_dir"))
    except BuildCheckError as e:
        return {"status": "error", "error": str(e)}

    command = args.get("command") or detect_build_command(target)
    if not command:
        return {
            "status": "error",
            "error": (
                "Could not auto-detect a build command for this directory "
                "(no package.json build script, tsconfig.json, Cargo.toml, go.mod, "
                "or Python project found). Pass an explicit 'command' to run instead."
            ),
        }

    return await run_command(target, command)
