# AthenaUI — Subscription gating plumbing
#
# Exposes the on/off switch gating logic should check, wired to the
# developer/release build mode: gating is always OFF in developer mode so
# testing never requires a real subscription, and ON in release mode.
#
# Real gating (via the Stripe/Cloudflare Worker licensing server, see
# licensing/service.py) looks like:
#   if not has_active_license():
#       raise HTTPException(402, "An active subscription is required.")

from core.build_mode import is_developer_mode


def subscription_enforced() -> bool:
    return not is_developer_mode()


def has_active_license() -> bool:
    """True if access should be allowed right now: developer mode always
    bypasses enforcement; otherwise defers to the stored/validated license
    status (machine-bound Stripe subscription via the Cloudflare Worker,
    see licensing/service.py)."""
    if not subscription_enforced():
        return True
    from licensing.service import license_service
    return license_service.has_access()


def has_premium_access() -> bool:
    """Gate for Premium-tier-only features (e.g. Synergy). Developer mode
    always bypasses, same as has_active_license(); otherwise requires both
    an active license AND the premium_access entitlement flag (set by the
    Worker for the AthenaUI Premium/Premium Yearly price tiers, or via the
    founder/friends-and-family promo codes -- see cloudflare worker.txt)."""
    if not subscription_enforced():
        return True
    from licensing.service import license_service
    status = license_service.get_status()
    return bool(status.get("valid")) and bool(status.get("premium_access"))
    if not subscription_enforced():
        return True
    from licensing.service import license_service
    return license_service.has_access()
