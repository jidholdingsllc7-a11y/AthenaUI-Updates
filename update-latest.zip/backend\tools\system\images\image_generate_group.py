# AthenaUI v3.5 — Group Photo Generate Tool
# File: backend/tools/system/images/image_generate_group.py
# Purpose: Lets an agent generate a single combined photo of themselves and
# up to 2 other people together (other characters, and/or the actual human
# user via include_user), using each person's own reference photo so
# identities stay consistent. The resulting image is saved to every
# included character's gallery/pair/ (and the user's own gallery if
# include_user is set).
# Created: 2026-08-02

from typing import Any, Dict
from llm.image_generation.service import ImageGenerationService

capabilities = {
    "needs_bridge": False,
    "needs_filesystem": False,
    "needs_network": True,
    "needs_user": True,
}

async def run(args: Dict[str, Any]):
    username = args.get("username", "system")
    character = args.get("character") or args.get("character_id")
    other_characters = args.get("other_characters")
    prompt = args.get("prompt")
    include_user = bool(args.get("include_user"))
    reference_images = args.get("reference_images")
    if not isinstance(reference_images, dict):
        reference_images = None

    if not character:
        return {"error": "Missing character for group photo generation"}
    if not isinstance(other_characters, list) or not (1 <= len(other_characters) <= 2):
        return {"error": "other_characters must be a list of 1 or 2 other characters"}
    if not prompt:
        return {"error": "Missing prompt describing the scene"}

    try:
        service = ImageGenerationService()
        return await service.generate_group_image(
            username=username,
            characters=[character] + list(other_characters),
            prompt=prompt,
            include_user=include_user,
            reference_images=reference_images,
        )
    except Exception as e:
        return {"error": str(e)}
