# AthenaUI v3.6 — OpenAI Responses API Adapter
# File: backend/llm/routers/openai_responses_adapter.py
#
# Converts between AthenaUI's provider-agnostic common wire format (the
# OpenAI Chat-Completions-shaped `messages`/`tools`/response dict every
# router must produce -- see chat/engine/service.py, normalizer.py,
# executor.py) and OpenAI's Responses API (/v1/responses) shape, so
# reasoning-family models (o1/o3/o4/gpt-5.x) can use real reasoning_effort
# together with tool calls -- a combination Chat Completions rejects
# outright for these models. Used only by openai_router.py; no other
# router or engine code needs to know this format exists (see
# Athena_UI_Tool_Migration_Plan.txt for the full migration plan).

from typing import Any, Dict, List, Optional


def to_responses_input(messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Converts our common `messages` list into a Responses API `input` list."""
    input_items: List[Dict[str, Any]] = []

    for message in messages:
        role = message.get("role")

        if role == "tool":
            input_items.append({
                "type": "function_call_output",
                "call_id": message.get("tool_call_id"),
                "output": message.get("content") or "",
            })
            continue

        if role == "assistant" and message.get("tool_calls"):
            content = message.get("content")
            if content:
                input_items.append({"role": "assistant", "content": content})
            for call in message["tool_calls"]:
                fn = call.get("function") if isinstance(call.get("function"), dict) else {}
                input_items.append({
                    "type": "function_call",
                    "call_id": call.get("id"),
                    "name": fn.get("name"),
                    "arguments": fn.get("arguments") or "{}",
                })
            continue

        # system/user/plain-assistant messages pass through as-is.
        input_items.append({"role": role, "content": message.get("content")})

    return input_items


def to_responses_tools(tools: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Converts our nested {"type":"function","function":{...}} tool schemas
    into the Responses API's flat {"type":"function","name",...} shape."""
    flat_tools: List[Dict[str, Any]] = []
    for tool in tools:
        fn = tool.get("function") if isinstance(tool.get("function"), dict) else {}
        flat_tools.append({
            "type": "function",
            "name": fn.get("name"),
            "description": fn.get("description", ""),
            "parameters": fn.get("parameters", {"type": "object", "properties": {}}),
        })
    return flat_tools


def from_responses_output(data: Dict[str, Any]) -> Dict[str, Any]:
    """Converts a Responses API response body back into the SAME common
    shape every other router returns ({"content","tool_calls","finish_reason",
    "raw"}), so normalizer.py/_run_tool_loop/_run_streaming_tool_loop/
    start_agentic need zero changes to understand it."""
    content_parts: List[str] = []
    tool_calls: List[Dict[str, Any]] = []

    for item in data.get("output", []) or []:
        item_type = item.get("type")
        if item_type == "message":
            for part in item.get("content", []) or []:
                text = part.get("text")
                if text:
                    content_parts.append(text)
        elif item_type == "function_call":
            tool_calls.append({
                "id": item.get("call_id"),
                "type": "function",
                "function": {
                    "name": item.get("name"),
                    "arguments": item.get("arguments") or "{}",
                },
            })

    status = data.get("status")
    finish_reason = "tool_calls" if tool_calls else ("stop" if status == "completed" else status)

    return {
        "id": data.get("id"),
        "model": data.get("model"),
        "content": "".join(content_parts) if content_parts else None,
        "tool_calls": tool_calls or None,
        "finish_reason": finish_reason,
        "raw": data,
    }
