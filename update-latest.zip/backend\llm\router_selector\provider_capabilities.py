﻿# AthenaUI v3.5 — Provider Capabilities Matrix
# File: backend/llm/router_selector/provider_capabilities.py
# Created: 2026-03-28 22:53 CDT
# Updated: 2026-07-27 19:49 CDT

from llm.routers.providers import *

# Each provider entry describes:
# - chat: supports chat completions
# - tools: supports native tool calling (True), emulated ( "emulated" ), or not supported (False)
# - images: supports image generation
# - embeddings: supports embeddings API
# - streaming: supports streaming responses
# - local: is the provider local (True) or cloud (False)
# - notes: any quirks or special behavior


PROVIDER_CAPABILITIES = {
    # ---------------------------------------------------------
    # Cloud Providers
    # ---------------------------------------------------------

    PROVIDER_OPENAI: {
        "chat": True,
        "tools": True,
        "images": True,
        "embeddings": True,
        "streaming": True,
        "local": False,
        "notes": "Full OpenAI v2 support.",
    },

    PROVIDER_ANTHROPIC: {
        "chat": True,
        "tools": True,
        "images": False,
        "embeddings": False,
        "streaming": True,
        "local": False,
        "notes": "Claude-style messages and tool use.",
    },

    PROVIDER_XAI: {
        "chat": True,
        "tools": True,
        "images": True,
        "embeddings": False,
        "streaming": True,
        "local": False,
        "notes": "Grok-compatible API. Supports both plain generation and reference-image edits (up to 3 images).",
    },

    PROVIDER_GROQ: {
        "chat": True,
        "tools": True,
        "images": False,
        "embeddings": False,
        "streaming": True,
        "local": False,
        "notes": "Extremely fast inference.",
    },

    PROVIDER_MISTRAL: {
        "chat": True,
        "tools": True,
        "images": False,
        "embeddings": True,
        "streaming": True,
        "local": False,
        "notes": "Mistral API v2.",
    },

    PROVIDER_FIREWORKS: {
        "chat": True,
        "tools": True,
        "images": False,
        "embeddings": True,
        "streaming": True,
        "local": False,
        "notes": "OpenAI-compatible.",
    },

    PROVIDER_TOGETHER: {
        "chat": True,
        "tools": True,
        "images": False,
        "embeddings": True,
        "streaming": True,
        "local": False,
        "notes": "OpenAI-compatible.",
    },

    PROVIDER_GEMINI: {
        "chat": True,
        "tools": True,
        "images": True,
        "embeddings": True,
        "streaming": True,
        "local": False,
        "notes": "Gemini 2.0 API.",
    },

    PROVIDER_DEEPSEEK: {
        "chat": True,
        "tools": True,
        "images": False,
        "embeddings": False,
        "streaming": True,
        "local": False,
        "notes": "DeepSeek API.",
    },

    PROVIDER_PERPLEXITY: {
        "chat": True,
        "tools": False,
        "images": False,
        "embeddings": False,
        "streaming": True,
        "local": False,
        "notes": "Search-augmented LLM.",
    },

    PROVIDER_COHERE: {
        "chat": True,
        "tools": True,
        "images": False,
        "embeddings": True,
        "streaming": False,
        "local": False,
        "notes": "Cohere Chat API.",
    },

    PROVIDER_AI21: {
        "chat": True,
        "tools": True,
        "images": False,
        "embeddings": False,
        "streaming": False,
        "local": False,
        "notes": "AI21 Studio Chat API.",
    },

    PROVIDER_AZURE_OPENAI: {
        "chat": True,
        "tools": True,
        "images": True,
        "embeddings": True,
        "streaming": True,
        "local": False,
        "notes": "Deployment-based OpenAI API.",
    },

    PROVIDER_BEDROCK: {
        "chat": True,
        "tools": True,
        "images": False,
        "embeddings": True,
        "streaming": False,
        "local": False,
        "notes": "AWS Bedrock with SigV4 signing.",
    },

    PROVIDER_OPENROUTER: {
        "chat": True,
        "tools": True,
        "images": False,
        "embeddings": False,
        "streaming": True,
        "local": False,
        "notes": "OpenAI-compatible meta-provider.",
    },

    # ---------------------------------------------------------
    # HuggingFace Providers
    # ---------------------------------------------------------

    PROVIDER_HUGGINGFACE: {
        "chat": True,
        "tools": "emulated",
        "images": False,
        "embeddings": False,
        "streaming": False,
        "local": False,
        "notes": "HF Inference API.",
    },

    PROVIDER_HF_TGI: {
        "chat": True,
        "tools": "emulated",
        "images": False,
        "embeddings": False,
        "streaming": False,
        "local": False,
        "notes": "Text Generation Inference server.",
    },

    # ---------------------------------------------------------
    # Local Providers
    # ---------------------------------------------------------

    PROVIDER_OLLAMA: {
        "chat": True,
        "tools": "emulated",
        "images": False,
        "embeddings": False,
        "streaming": True,
        "local": True,
        "notes": "Local Ollama runtime.",
    },

    PROVIDER_LMSTUDIO: {
        "chat": True,
        "tools": True,
        "images": False,
        "embeddings": False,
        "streaming": True,
        "local": True,
        "notes": "OpenAI-compatible local server.",
    },

    PROVIDER_TRANSFORMERS_LOCAL: {
        "chat": True,
        "tools": "emulated",
        "images": False,
        "embeddings": False,
        "streaming": False,
        "local": True,
        "notes": "Direct Transformers execution.",
    },

    PROVIDER_ATLAS_SERVER: {
        "chat": True,
        "tools": True,
        "images": False,
        "embeddings": False,
        "streaming": False,
        "local": True,
        "notes": "Local multi-model orchestrator (Dolphin/Qwen behind one "
                 "OpenAI-compatible endpoint); appears as a single model.",
    },

    # ---------------------------------------------------------
    # Custom Provider
    # ---------------------------------------------------------

    PROVIDER_CUSTOM_HTTP: {
        "chat": False,
        "tools": False,
        "images": False,
        "embeddings": False,
        "streaming": False,
        "local": False,
        "notes": "Custom enterprise LLM integration required.",
    },
}
