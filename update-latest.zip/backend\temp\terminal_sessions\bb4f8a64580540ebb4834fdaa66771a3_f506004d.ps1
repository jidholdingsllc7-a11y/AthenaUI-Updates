$ErrorActionPreference = 'Continue'
Set-Location -LiteralPath 'C:\AthenaWorkspace\droidcraft'
$host.UI.RawUI.WindowTitle = 'AthenaUI Agent Terminal'
Remove-Module PSReadLine -Force -ErrorAction SilentlyContinue
foreach ($__athena_scope in 'Machine','User') {
  [System.Environment]::GetEnvironmentVariables($__athena_scope).GetEnumerator() | ForEach-Object {
    if ($_.Key -ieq 'Path') { return }
    Set-Item -Path ("Env:" + $_.Key) -Value $_.Value -ErrorAction SilentlyContinue
  }
}
$__athena_machine_path = [System.Environment]::GetEnvironmentVariable('Path','Machine')
$__athena_user_path = [System.Environment]::GetEnvironmentVariable('Path','User')
$env:Path = @($__athena_machine_path, $__athena_user_path, $env:Path) -join ';'
Start-Transcript -Path 'C:\AthenaUi\backend\temp\terminal_sessions\bb4f8a64580540ebb4834fdaa66771a3.log' -Append | Out-Null
$__athena_ok = $true
Write-Host '> @'
import ast
from pathlib import Path
root=Path('droidcraft/droidcraft/backend/app')
for p in root.rglob('*.py'):
 try: ast.parse(p.read_text(encoding='utf-8-sig'), filename=str(p))
 except SyntaxError as e: print(f'{p}:{e.lineno}: {e.msg}')
print('AST scan complete')
'@ | python -'
try {
    Invoke-Expression '@''
import ast
from pathlib import Path
root=Path(''droidcraft/droidcraft/backend/app'')
for p in root.rglob(''*.py''):
 try: ast.parse(p.read_text(encoding=''utf-8-sig''), filename=str(p))
 except SyntaxError as e: print(f''{p}:{e.lineno}: {e.msg}'')
print(''AST scan complete'')
''@ | python -'
    $__athena_ok = $? -and ($LASTEXITCODE -eq $null -or $LASTEXITCODE -eq 0)
} catch {
    $__athena_ok = $false
    Write-Host $_.Exception.Message
}
$__athena_code = if ($LASTEXITCODE -ne $null) { $LASTEXITCODE } elseif ($__athena_ok) { 0 } else { 1 }
Write-Host "##ATHENA_TERMINAL_DONE## exit=$__athena_code"
