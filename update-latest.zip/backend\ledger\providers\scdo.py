# AthenaUI -- SCDO ledger provider
# File: backend/ledger/providers/scdo.py
#
# SCDO (Australia) is the user's intended external compliance ledger, but no
# API contract exists yet. This provider is designed to be the ONLY place
# that needs real changes once SCDO's integration details are available:
# configure `ledger.scdo_base_url` (GET/POST /ledger/scdo-config) and the API
# key (stored encrypted via VaultService.set_secret), then adjust `push()`'s
# request shape to match SCDO's real schema. Until configured, pushes are
# queued locally only (never raises) so nothing blocks on the missing
# integration -- records are still signed and stored locally either way.

from __future__ import annotations

from typing import Any, Dict

import requests

from ledger.providers.base import LedgerProvider
from safety.ssrf_guard import assert_url_is_safe
from vault.service import VaultService


class SCDOProvider(LedgerProvider):
    def __init__(self, username: str) -> None:
        self._username = username

    def _config(self) -> Dict[str, str]:
        return {
            "base_url": str(VaultService.get_preference(self._username, "ledger.scdo_base_url", "") or ""),
            "api_key": str(VaultService.get_secret(self._username, "ledger.scdo_api_key") or ""),
        }

    def push(self, record: Dict[str, Any]) -> Dict[str, Any]:
        config = self._config()
        base_url = config["base_url"].strip().rstrip("/")
        if not base_url:
            return {"status": "queued_local_only", "reason": "SCDO not configured yet."}

        url = f"{base_url}/ledger-entries"
        assert_url_is_safe(url, self._username)  # base_url is user-supplied -- SSRF guard applies here too

        headers = {"Content-Type": "application/json"}
        if config["api_key"]:
            headers["Authorization"] = f"Bearer {config['api_key']}"

        resp = requests.post(url, json=record, headers=headers, timeout=20)
        if resp.status_code >= 400:
            return {"status": "push_failed", "http_status": resp.status_code, "detail": resp.text[:500]}
        try:
            body = resp.json()
        except ValueError:
            body = {"raw": resp.text[:500]}
        return {"status": "pushed", "http_status": resp.status_code, "response": body}
