﻿# AthenaUI v3.5 — System Logging Service
# File: backend/logs_system/system/service.py
# Created: 2026-04-09 20:06 CDT
# Updated: 2026-10-25

import logging
import traceback
from datetime import datetime
from typing import Any, Dict, Optional

from logs_system.tail.service import tail_logger
from logs_system.vault.service import vault_logger
from logs_system.db.service import tail_log_db

_error_console_logger = logging.getLogger("athenaui.errors")

# Any dict key containing one of these (case-insensitive) has its value
# redacted before being persisted -- verbose error details are meant to be
# exported and shared (e.g. a customer sending us their Tail Log PDF), so
# secrets must never end up in there even though the surrounding context is
# deliberately as detailed as possible.
_SECRET_KEY_MARKERS = ("key", "token", "secret", "password", "authorization", "cookie")

# Long strings (file contents, huge tool results, etc.) are truncated rather
# than dropped -- still useful for diagnosis without bloating the log store.
_MAX_STRING_LEN = 4000


def _redact(value: Any, _depth: int = 0) -> Any:
    if _depth > 6:
        return "...[max depth reached]"
    if isinstance(value, dict):
        redacted: Dict[str, Any] = {}
        for k, v in value.items():
            if isinstance(k, str) and any(marker in k.lower() for marker in _SECRET_KEY_MARKERS):
                redacted[k] = "***redacted***"
            else:
                redacted[k] = _redact(v, _depth + 1)
        return redacted
    if isinstance(value, (list, tuple)):
        return [_redact(v, _depth + 1) for v in list(value)[:50]]
    if isinstance(value, str) and len(value) > _MAX_STRING_LEN:
        return value[:_MAX_STRING_LEN] + f"...[truncated {len(value) - _MAX_STRING_LEN} chars]"
    return value


class SystemLogger:
    """
    Central logging facade.
    - Normalizes payloads (timestamp, level, agent_state, event, details, task_id).
    - Forwards entries to Live Tail, Vault, and the persistent SQL log store.
    """

    def log(
        self,
        *,
        event: str,
        level: str = "info",
        agent_state: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        task_id: Optional[str] = None,
    ) -> None:
        payload: Dict[str, Any] = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "level": level,
            "agent_state": agent_state,
            "event": event,
            "details": details or {},
            "task_id": task_id,
        }

        # Live Tail (in-memory + streaming)
        tail_logger.emit(payload)

        # Vault (persistent, per-user -- no-op if no user context)
        vault_logger.emit(payload)

        # Persistent SQL log store (best-effort; logging must never fail on this)
        try:
            tail_log_db.append(payload)
        except Exception:
            pass

    def log_exception(
        self,
        *,
        event: str,
        exc: BaseException,
        details: Optional[Dict[str, Any]] = None,
        task_id: Optional[str] = None,
        agent_state: Optional[str] = None,
    ) -> None:
        """
        Verbose error logging for troubleshooting. Records the exception type,
        message, and full traceback alongside whatever caller-supplied context
        is available (tool name, arguments, provider/model, username, etc.),
        with obvious secret-shaped values redacted. MUST be called from inside
        the `except` block that caught `exc` (relies on `traceback.format_exc()`
        picking up the currently-handled exception).

        This is the entry a customer can export from the Tail Log page to a
        signed PDF and send back to us -- letting us diagnose a failure (e.g.
        why a tool didn't work, or a bad API key/setup on their end) without
        needing to reproduce it ourselves.
        """
        payload = _redact(dict(details or {}))
        payload["exception_type"] = type(exc).__name__
        payload["exception_message"] = str(exc)
        payload["traceback"] = traceback.format_exc()

        # Also mirror into the standard Python logging stream, so it shows up
        # in the server console / Health Check capture (logs_system.console)
        # even if the Tail Log page itself is never opened.
        _error_console_logger.error(event, exc_info=exc)

        self.log(event=event, level="error", agent_state=agent_state, details=payload, task_id=task_id)


# Singleton instance
system_logger = SystemLogger()
