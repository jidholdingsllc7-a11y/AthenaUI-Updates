# AthenaUI v3.7 — List Allowed Directories Tool
# File: backend/tools/fs/list_allowed_directories.py
# Created: 2026-10-25

from workspace.service import WorkspaceService
from typing import Any, Dict

capabilities = {
    "needs_filesystem": True,
    "needs_bridge": False,
    "needs_network": False,
    "needs_user": True,
}

async def run(args: Dict[str, Any]) -> str:
    """
    Sandbox self-check: report the directory boundary this agent's
    filesystem/terminal tools are restricted to right now -- the full
    workspace root, plus any narrower working directory currently scoped
    for this conversation (see ToolExecutor.set_scope_dir).
    """
    try:
        username = args.get("username")
        if not username:
            return "[ERROR] Missing 'username' in tool arguments."

        ws = WorkspaceService.get_workspace(username)
        if ws is None:
            return f"[ERROR] Workspace not available for user '{username}'."

        lines = [f"Workspace root (all file/terminal tools are sandboxed inside this): {ws.root}"]

        scope_dir = args.get("_scope_dir")
        if scope_dir:
            lines.append(
                "Active working directory for this conversation (write-capable file "
                f"tools are additionally restricted to here): {scope_dir}"
            )
        else:
            lines.append("No narrower working directory is currently scoped -- the full workspace root above applies.")

        return "\n".join(lines)

    except Exception as e:
        return f"[ERROR] Failed to list allowed directories: {str(e)}"
