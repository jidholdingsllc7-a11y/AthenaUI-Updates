# AthenaUI v3.5 — Troubleshooting Tips Library Service
# File: backend/troubleshooting_tips/service.py
#
# A shared, appendable library of program-troubleshooting tips/tricks that
# ANY character/agent (regardless of which LLM provider is behind it) can
# search before troubleshooting a program, and append to when it discovers
# a new trick -- so hard-won knowledge accumulates across sessions instead
# of being re-discovered (or re-explained via a bloated system prompt)
# every single time.
#
# This is intentionally separate from any per-program troubleshooting log
# (a record of what happened while debugging one specific program run) --
# this is general, reusable "here's a trick that helped" wisdom, taggable
# by program/language/symptom so it stays searchable instead of becoming
# one giant dump of text.
#
# Storage: ONE global SQLite file, NOT per human user account -- every
# character/agent on every account on this install shares the same
# library (and it ships pre-created, unencrypted, with every install, so
# it's available from the very first run instead of starting siloed per
# account):
#   {DATA_DIR}/global/troubleshooting_tips/tips.sqlite

from __future__ import annotations

import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from core.runtime.runtime import get_runtime


class TroubleshootingTipsError(Exception):
    pass


def _root_dir(username: str) -> Path:
    # Global, not per-user -- `username` is accepted only for call-site
    # compatibility and is no longer used to partition storage.
    runtime = get_runtime()
    root = runtime.env.DATA_DIR / "global" / "troubleshooting_tips"
    root.mkdir(parents=True, exist_ok=True)
    return root


def _db_path(username: str) -> Path:
    return _root_dir(username) / "tips.sqlite"


def _connect(username: str) -> sqlite3.Connection:
    conn = sqlite3.connect(_db_path(username))
    conn.row_factory = sqlite3.Row
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS tips (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            tip TEXT NOT NULL,
            tags TEXT,
            program TEXT,
            source_character TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
        """
    )
    return conn


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _normalize_tags(tags: Optional[Any]) -> str:
    if not tags:
        return ""
    if isinstance(tags, (list, tuple, set)):
        parts = [str(t).strip().lower() for t in tags if str(t).strip()]
    else:
        parts = [p.strip().lower() for p in str(tags).split(",") if p.strip()]
    return ",".join(dict.fromkeys(parts))  # de-dupe, keep order


def _row_to_tip(row: sqlite3.Row) -> Dict[str, Any]:
    return dict(row)


def add_tip(
    username: str,
    title: str,
    tip: str,
    tags: Optional[Any] = None,
    program: Optional[str] = None,
    character: Optional[str] = None,
) -> Dict[str, Any]:
    title = (title or "").strip()
    tip = (tip or "").strip()
    if not title:
        raise TroubleshootingTipsError("'title' is required.")
    if not tip:
        raise TroubleshootingTipsError("'tip' is required.")

    tip_id = uuid.uuid4().hex[:12]
    now = _now()
    with _connect(username) as conn:
        conn.execute(
            """
            INSERT INTO tips
                (id, title, tip, tags, program, source_character, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (tip_id, title, tip, _normalize_tags(tags), (program or "").strip() or None,
             character, now, now),
        )
        row = conn.execute("SELECT * FROM tips WHERE id = ?", (tip_id,)).fetchone()
    return _row_to_tip(row)


def search_tips(
    username: str,
    query: Optional[str] = None,
    tags: Optional[Any] = None,
    program: Optional[str] = None,
    limit: int = 10,
) -> List[Dict[str, Any]]:
    limit = max(1, min(int(limit or 10), 50))

    clauses: List[str] = []
    params: List[Any] = []

    query = (query or "").strip()
    if query:
        clauses.append("(title LIKE ? OR tip LIKE ? OR tags LIKE ? OR program LIKE ?)")
        like = f"%{query}%"
        params.extend([like, like, like, like])

    for tag in _normalize_tags(tags).split(",") if tags else []:
        if tag:
            clauses.append("tags LIKE ?")
            params.append(f"%{tag}%")

    program = (program or "").strip()
    if program:
        clauses.append("program LIKE ?")
        params.append(f"%{program}%")

    where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
    sql = f"SELECT * FROM tips {where} ORDER BY created_at DESC LIMIT ?"
    params.append(limit)

    with _connect(username) as conn:
        rows = conn.execute(sql, params).fetchall()
    return [_row_to_tip(r) for r in rows]
