﻿# AthenaUI v3.5 — Chat Tool Executor Compatibility Adapter
# File: backend/chat/tools/executor.py
# Updated: 2026-07-27 19:49 CDT

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

from tools.registry.loader import load_tools
from tools.executor.executor import ToolExecutor as GlobalToolExecutor


class _SchemaRegistryView:
    def __init__(self, registry, name_map: Dict[str, str]):
        self._registry = registry
        self._name_map = name_map

    @staticmethod
    def _to_wire_name(tool_name: str) -> str:
        # OpenAI tool names must match ^[a-zA-Z0-9_-]+$
        sanitized = re.sub(r"[^a-zA-Z0-9_-]", "_", tool_name)
        return sanitized or "tool"

    def resolve_tool_name(self, wire_name: str) -> str:
        return self._name_map.get(wire_name, wire_name)

    # Identity values that are always force-injected server-side (see
    # ToolExecutor.execute()'s `args["username"] = ...` and the engine's
    # `arguments = {**arguments, "character": character}`). These must never
    # be shown to the model as fillable parameters: the model can't know the
    # real values, so it guesses/hallucinates one, and a hallucinated value
    # can look plausible enough to slip through -- e.g. it previously caused
    # a real vault "onboarding not finalized" error because the model
    # invented its own `username` for memory_search. Stripping them here
    # also avoids leaving `required` fields the model has no way to satisfy
    # correctly.
    _SERVER_INJECTED_PARAMS = ("username", "character")

    @classmethod
    def _strip_server_injected_params(cls, parameters: Any) -> Any:
        if not isinstance(parameters, dict):
            return parameters
        params = dict(parameters)
        properties = params.get("properties")
        if isinstance(properties, dict):
            properties = {
                key: value for key, value in properties.items()
                if key not in cls._SERVER_INJECTED_PARAMS
            }
            params["properties"] = properties
        required = params.get("required")
        if isinstance(required, list):
            params["required"] = [r for r in required if r not in cls._SERVER_INJECTED_PARAMS]
        return params

    def get_all_schemas(self, allowed_names: Any = None):
        """`allowed_names`, when given, restricts the returned schemas to
        only those original tool names (e.g. group chat exposing just
        `memory_search` instead of the full 1:1 toolset)."""
        normalized = []
        self._name_map.clear()

        for tool in self._registry.list():
            schema = tool.get("schema") if isinstance(tool, dict) else None
            if not isinstance(schema, dict):
                continue

            original_name = tool.get("name") if isinstance(tool, dict) else None
            if not original_name:
                continue
            if allowed_names is not None and original_name not in allowed_names:
                continue

            wire_name = self._to_wire_name(original_name)
            suffix = 1
            while wire_name in self._name_map and self._name_map[wire_name] != original_name:
                suffix += 1
                wire_name = f"{self._to_wire_name(original_name)}_{suffix}"
            self._name_map[wire_name] = original_name

            if schema.get("type") == "function" and isinstance(schema.get("function"), dict):
                fn = dict(schema.get("function", {}))
                fn["name"] = wire_name
                if "parameters" in fn:
                    fn["parameters"] = self._strip_server_injected_params(fn["parameters"])
                normalized.append(
                    {
                        "type": "function",
                        "function": fn,
                    }
                )
                continue

            normalized.append(
                {
                    "type": "function",
                    "function": {
                        "name": wire_name,
                        "description": schema.get("description", ""),
                        "parameters": self._strip_server_injected_params(
                            schema.get("parameters", {"type": "object", "properties": {}})
                        ),
                    },
                }
            )

        return normalized


class ToolExecutor:
    """
    Compatibility wrapper exposing the old chat ToolExecutor shape:
    - .registry.get_all_schemas()
    - async .execute(tool_name, arguments)
    """

    # Write-capable fs tools (and which of their args are workspace-relative
    # paths) that a directory-scoped turn (see ChatEngine._build_messages'
    # editor_context.is_directory handling / set_scope_dir below) must not be
    # allowed to escape. Read-only tools (file_read/file_list_dir/file_search/
    # etc.) are deliberately NOT restricted -- reading something elsewhere in
    # the workspace for context is reasonable, writing to it isn't, and this
    # is the actual enforcement backing the "Agent working directory" the
    # user is shown/told, rather than relying on the model to just comply.
    _SCOPED_WRITE_TOOL_PATH_ARGS: Dict[str, tuple] = {
        "file_write": ("path",),
        "file_edit_lines": ("path",),
        "file_delete": ("path",),
        "file_mkdir": ("path",),
        "file_move": ("source", "destination"),
        "file_copy": ("source", "destination"),
    }

    # terminal_run gets arbitrary shell commands, which can't be reliably
    # parsed/sandboxed to a sub-directory the way a single `path` arg can --
    # so this is a best-effort narrowing (default cwd for a brand-new
    # session), NOT a hard guarantee like the write-tool block above. A
    # command can still `cd`/use an absolute path to escape it deliberately.
    # project_build_check/project_lint_test default their own `path` arg to
    # this same scope when omitted; list_allowed_directories just reports it
    # back to the model as part of its self-check.
    _SCOPE_AWARE_TOOLS = ("terminal_run", "project_build_check", "project_lint_test", "list_allowed_directories")

    def __init__(self, username: str = "system"):
        self._username = username
        self._registry = load_tools()
        self._executor = GlobalToolExecutor(self._registry)
        self._tool_name_map: Dict[str, str] = {}
        self.registry = _SchemaRegistryView(self._registry, self._tool_name_map)
        self._scope_dir_parts: Optional[List[str]] = None

    @staticmethod
    def _normalize_rel_parts(path: str) -> List[str]:
        parts: List[str] = []
        for part in str(path or "").replace("\\", "/").split("/"):
            if part in ("", "."):
                continue
            if part == "..":
                if parts:
                    parts.pop()
                continue
            parts.append(part)
        return parts

    def set_scope_dir(self, path: Optional[str]) -> None:
        """Restricts write-capable fs tools to this directory for the rest
        of this (per-request) engine's lifetime -- called by ChatEngine
        whenever the user has a specific directory open in Code Suite, so an
        agent told to analyze/fix things in there can't wander off and edit
        unrelated files elsewhere in the workspace. Pass None to clear it
        (single-file or no editor context at all)."""
        self._scope_dir_parts = self._normalize_rel_parts(path) if path else None

    async def execute(self, tool_name: str, arguments: Dict[str, Any]) -> Any:
        tool_name = self.registry.resolve_tool_name(tool_name)
        args = dict(arguments or {})
        # SECURITY: `username` is a trusted server-side identity value, never
        # something the model should control. Some tool schemas expose it as
        # an LLM-fillable parameter (so providers that require all listed
        # params to be filled don't choke), but the model's own guess must
        # never be trusted -- always force it to the real logged-in user,
        # overwriting anything the model supplied (previously this only used
        # setdefault(), so a model-hallucinated username silently won and
        # could route tool calls -- including vault/memory lookups -- at a
        # different user's data).
        args["username"] = self._username

        if self._scope_dir_parts is not None:
            path_args = self._SCOPED_WRITE_TOOL_PATH_ARGS.get(tool_name)
            if path_args:
                scope_label = "/".join(self._scope_dir_parts)
                for arg_name in path_args:
                    value = args.get(arg_name)
                    if not value:
                        continue
                    value_parts = self._normalize_rel_parts(value)
                    if value_parts[:len(self._scope_dir_parts)] != self._scope_dir_parts:
                        return (
                            f"[ERROR] '{value}' is outside the active working directory "
                            f"('{scope_label}'). This conversation is scoped to that "
                            f"directory only -- ask the user explicitly before touching "
                            f"anything outside it."
                        )
            if tool_name in self._SCOPE_AWARE_TOOLS:
                args["_scope_dir"] = "/".join(self._scope_dir_parts)

        return await self._executor.execute(tool_name, args)

