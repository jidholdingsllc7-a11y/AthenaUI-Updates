# AthenaUI — HTTP client for the Cloudflare Worker licensing server
# File: backend/licensing/client.py
#
# Thin wrapper around the two endpoints the Worker exposes for AthenaUI:
# POST /activate and POST /validate-license. See licensing/service.py for
# how responses are turned into stored state + enforcement decisions.

import logging

import requests

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
if not logger.handlers:
    _handler = logging.StreamHandler()
    _handler.setFormatter(logging.Formatter("%(asctime)s [%(name)s] %(message)s"))
    logger.addHandler(_handler)

WORKER_BASE_URL = "https://shrill-mountain-4e30athenaui-licensing.autumn-bread-543a.workers.dev"
_TIMEOUT_SECONDS = 15


class LicensingUnreachableError(Exception):
    """The Worker could not be reached at all (no internet, DNS failure,
    timeout, etc.) -- distinct from the Worker responding with
    valid/ok: false, which is a real license decision, not an outage."""


def _post(path: str, license_key: str, machine_id: str) -> dict:
    url = f"{WORKER_BASE_URL}{path}"
    logger.info(
        "Licensing request -> %s license_key=%s machine_id=%s", path, license_key, machine_id
    )
    try:
        resp = requests.post(
            url,
            json={"license_key": license_key, "machine_id": machine_id},
            timeout=_TIMEOUT_SECONDS,
        )
    except requests.RequestException as e:
        logger.error("Licensing request -> %s UNREACHABLE: %s", path, e)
        raise LicensingUnreachableError(str(e)) from e

    try:
        data = resp.json()
    except ValueError:
        data = {}

    logger.info(
        "Licensing response <- %s status=%s body=%s", path, resp.status_code, data
    )

    if not resp.ok and "ok" not in data and "valid" not in data:
        # Non-2xx with no usable body -- surface a generic reason so the
        # caller always has something sensible to show the user.
        data.setdefault("ok", False)
        data.setdefault("valid", False)
        data.setdefault("reason", f"Licensing server error ({resp.status_code}).")
        logger.warning("Licensing response <- %s non-2xx with no usable body: %s", path, resp.status_code)
    return data


def activate(license_key: str, machine_id: str) -> dict:
    """POST /activate -- binds `license_key` to `machine_id`. Returns
    {"ok": true} on success, or {"ok": false, "reason": ...}."""
    result = _post("/activate", license_key, machine_id)
    if not result.get("ok"):
        logger.warning(
            "Activation FAILED for license_key=%s machine_id=%s reason=%s",
            license_key, machine_id, result.get("reason"),
        )
    else:
        logger.info("Activation OK for license_key=%s machine_id=%s", license_key, machine_id)
    return result


def validate_license(license_key: str, machine_id: str) -> dict:
    """POST /validate-license -- returns the full entitlement payload
    (valid, founder_tier, premium_access, friends_family, free_month,
    marketing_consent[, reason])."""
    result = _post("/validate-license", license_key, machine_id)
    if not result.get("valid"):
        logger.warning(
            "Validation returned NOT VALID for license_key=%s machine_id=%s reason=%s",
            license_key, machine_id, result.get("reason"),
        )
    else:
        logger.info("Validation OK for license_key=%s machine_id=%s", license_key, machine_id)
    return result


def create_portal_session(license_key: str) -> dict:
    """POST /create-portal-session -- returns {"ok": true, "url": ...} with
    a Stripe Billing Portal link the customer can use to update their
    payment method or cancel their own subscription, or {"ok": false,
    "reason": ...}."""
    url = f"{WORKER_BASE_URL}/create-portal-session"
    logger.info("Licensing request -> /create-portal-session license_key=%s", license_key)
    try:
        resp = requests.post(url, json={"license_key": license_key}, timeout=_TIMEOUT_SECONDS)
    except requests.RequestException as e:
        logger.error("Licensing request -> /create-portal-session UNREACHABLE: %s", e)
        raise LicensingUnreachableError(str(e)) from e

    try:
        data = resp.json()
    except ValueError:
        data = {}

    logger.info(
        "Licensing response <- /create-portal-session status=%s body=%s", resp.status_code, data
    )

    if not resp.ok and "ok" not in data:
        data.setdefault("ok", False)
        data.setdefault("reason", f"Licensing server error ({resp.status_code}).")
    return data
