# AthenaUI v3.5 — Schedule Job Tool
# File: backend/tools/system/scheduler/schedule_job.py
#
# Lets a character PROPOSE a future task for themselves (a buy/sell task, a
# research follow-up, a marketing task, etc.) -- this NEVER executes
# anything by itself. It only creates a job in "awaiting_approval" status;
# the user must explicitly review and check it off in the Scheduler
# permission popup before scheduler/runner.py's background loop will ever
# run it.

from datetime import datetime, timedelta, timezone
from typing import Any, Dict

from scheduler import service as scheduler_service

capabilities = {
    "needs_bridge": False,
    "needs_filesystem": False,
    "needs_network": False,
    "needs_user": True,
}


async def run(args: Dict[str, Any]):
    username = args.get("username")
    character = args.get("character")
    task_description = (args.get("task_description") or "").strip()
    reasoning = (args.get("reasoning") or "").strip()
    run_at = (args.get("run_at") or "").strip()
    delay_minutes = args.get("delay_minutes")
    estimated_turns = args.get("estimated_turns") or 3
    log_file = (args.get("log_file") or "").strip() or None
    depends_on_job_id = (args.get("depends_on_job_id") or "").strip() or None
    condition = (args.get("condition") or "").strip() or None
    condition_symbol = (args.get("condition_symbol") or "").strip() or None
    dry_run = bool(args.get("dry_run") or False)
    validate_brokerage = bool(args.get("validate_brokerage") or False)
    notional_estimate = args.get("notional_estimate")
    repeat_every_minutes = args.get("repeat_every_minutes")
    active_repeat_every_minutes = args.get("active_repeat_every_minutes")

    if not task_description:
        return {"error": "Missing 'task_description' -- describe exactly what you will do when this runs."}
    if not reasoning:
        return {"error": "Missing 'reasoning' -- explain why this should be scheduled."}

    if not run_at:
        if delay_minutes is None:
            return {"error": "Provide either 'run_at' (ISO 8601 datetime) or 'delay_minutes'."}
        try:
            run_at = (datetime.now(timezone.utc) + timedelta(minutes=float(delay_minutes))).isoformat()
        except (TypeError, ValueError):
            return {"error": "Invalid 'delay_minutes'."}

    try:
        job = scheduler_service.create_job(
            username=username,
            character=character,
            task_description=task_description,
            run_at=run_at,
            reasoning=reasoning,
            estimated_turns=estimated_turns,
            log_file=log_file,
            depends_on_job_id=depends_on_job_id,
            condition=condition,
            condition_symbol=condition_symbol,
            dry_run=dry_run,
            validate_brokerage=validate_brokerage,
            notional_estimate=notional_estimate,
            repeat_every_minutes=repeat_every_minutes,
            active_repeat_every_minutes=active_repeat_every_minutes,
        )
    except ValueError as e:
        return {"error": str(e)}
    except Exception as e:
        return {"error": f"Could not parse 'run_at': {e}. Use ISO 8601, e.g. 2026-08-04T14:30:00Z."}

    if log_file:
        scheduler_service.append_log(
            username,
            log_file,
            f"- [{job['created_at']}] Scheduled job {job['job_id']}: {task_description} "
            f"(run_at={job['run_at']})"
            + (f" [depends_on={depends_on_job_id}, condition={condition or 'prior_success'}]" if depends_on_job_id else "")
            + (" [DRY RUN]" if dry_run else ""),
        )

    return {
        "ok": True,
        "job_id": job["job_id"],
        "status": job["status"],
        "run_at": job["run_at"],
        "log_file": log_file,
        "depends_on_job_id": depends_on_job_id,
        "condition": condition,
        "dry_run": dry_run,
        "repeat_every_minutes": job.get("repeat_every_minutes"),
        "active_repeat_every_minutes": job.get("active_repeat_every_minutes"),
        "message": (
            "Scheduled -- this will NOT run until the user reviews it and checks it off in the "
            "Scheduler permission popup. Tell the user what you scheduled and why so they know "
            "to expect the approval prompt."
            + (
                " This is a RECURRING task -- once approved, it will keep re-running on its own "
                "every repeat_every_minutes until the user cancels its currently-pending occurrence; "
                "only the first occurrence needs approval."
                if repeat_every_minutes else ""
            )
        ),
    }
