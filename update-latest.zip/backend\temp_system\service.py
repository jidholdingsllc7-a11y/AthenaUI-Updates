﻿# AthenaUI v3.5 — Temp System
# File: backend/temp_system/service.py
# Created: 2026-04-11 12:30 CDT
# Updated: 2026-07-27 19:49 CDT

import uuid
import json
import shutil
from pathlib import Path

from core.env.env_loader import Env

# ---------------------------------------------------------
#  ROOT TEMP DIRECTORY
# ---------------------------------------------------------

# Anchored to Env.WRITABLE_ROOT (not a bare relative "temp") so this always
# resolves to the same directory regardless of the backend process's CWD --
# a relative path here previously created a stray second temp/ tree whenever
# the process was launched from a different working directory.
temp_root = Env.WRITABLE_ROOT / "temp"
temp_root.mkdir(parents=True, exist_ok=True)

# Subsystem directories
SUBSYSTEMS = [
    "characters",
    "onboarding",
    "code_suite",
    "research",
    "images",
    "tasks",
    "generic",
]

for sub in SUBSYSTEMS:
    (temp_root / sub).mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------
#  CREATE TEMP DIRECTORY
# ---------------------------------------------------------

def create_temp_dir(subsystem: str = "generic") -> Path:
    """
    Creates a unique temp directory inside the subsystem folder.
    Returns the Path.
    """
    if subsystem not in SUBSYSTEMS:
        subsystem = "generic"

    temp_id = uuid.uuid4().hex
    path = temp_root / subsystem / temp_id
    path.mkdir(parents=True, exist_ok=True)
    return path


# ---------------------------------------------------------
#  CREATE TEMP FILE
# ---------------------------------------------------------

def create_temp_file(subsystem: str = "generic", suffix: str = "") -> Path:
    """
    Creates a unique temp file inside the subsystem folder.
    Returns the Path.
    """
    temp_dir = create_temp_dir(subsystem)
    file_path = temp_dir / f"temp_{uuid.uuid4().hex}{suffix}"
    file_path.touch()
    return file_path


# ---------------------------------------------------------
#  JSON HELPERS
# ---------------------------------------------------------

def write_temp_json(path: Path, data: dict):
    path.write_text(json.dumps(data, indent=2))


def read_temp_json(path: Path) -> dict:
    return json.loads(path.read_text())


# ---------------------------------------------------------
#  BINARY HELPERS
# ---------------------------------------------------------

def write_temp_bytes(path: Path, data: bytes):
    path.write_bytes(data)


def read_temp_bytes(path: Path) -> bytes:
    return path.read_bytes()


# ---------------------------------------------------------
#  DELETE TEMP PATH (FILE OR DIRECTORY)
# ---------------------------------------------------------

def delete_temp_path(path: Path):
    if path.is_dir():
        shutil.rmtree(path, ignore_errors=True)
    elif path.exists():
        path.unlink()


# ---------------------------------------------------------
#  PURGE ALL TEMP (CALL ON LOGOUT)
# ---------------------------------------------------------

def purge_all_temp():
    """
    Deletes everything inside backend/temp.
    Called automatically on logout.
    """
    for sub in SUBSYSTEMS:
        folder = temp_root / sub
        if folder.exists():
            shutil.rmtree(folder, ignore_errors=True)
            folder.mkdir(parents=True, exist_ok=True)
