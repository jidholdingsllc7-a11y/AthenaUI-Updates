﻿# AthenaUI v3.5 — Group Chat Router
# File: backend/chat/group/router.py
# Created: 2026-04-11 18:40 CDT
# Updated: 2026-07-30 22:10 CDT

from __future__ import annotations

import asyncio
import json
import logging
import re
from datetime import datetime
from typing import List, Dict, Any, Optional, Callable

from chat.group.state import GroupChatState, GroupParticipant, GroupMessage
from chat.group.address_parser import resolve_addressed_target
from chat.group.prompt_builder import build_group_chat_messages
from chat.group.birthday import BirthdayService  # NEW
from chat.memory.maximos_client import get_client as get_maximos_client
from chat.memory.service import MemoryManager
from chat.memory.summarizer import summarize_interaction
from chat.history.service import CHANNEL_GROUP_CHAT, normalize_channel
from chat.tools.executor import ToolExecutor
from chat.tools.normalizer import ToolCallNormalizer
from chat.engine.service import ChatEngine, _detect_emotion
from llm.image_generation.service import ImageGenerationService, image_result_to_markdown
from images.avatar_engine.triggers import should_generate_avatar_for_message
from llm.router_selector.router_selector import RouterSelector
from llm.api_key_resolver import resolve_and_inject_api_key
from llm.retry import call_with_retry
from llm.context_trim import compact_tool_history

logger = logging.getLogger(__name__)

# Collab Group Chat -- agents may end an autonomous discussion early (before
# hitting the turn cap) by emitting this exact marker; it's stripped out of
# the displayed/stored text and turned into state.concluded/concluded_reason.
_CONCLUDE_RE = re.compile(r"\[\[CONCLUDE:?\s*(.*?)\]\]", re.IGNORECASE | re.DOTALL)


class GroupChatRouter:
    # Tools available in group chat -- deliberately a narrow whitelist (not
    # the full 1:1 toolset) to avoid multiple agents concurrently touching
    # the filesystem/terminal/UI automation/brokerage in the same session.
    # memory_search/board_list are read-only recall; the image_* tools let
    # an agent generate or actually look at a photo on request without any
    # of that collision risk.
    GROUP_CHAT_TOOL_NAMES = frozenset({
        "memory_search", "memory_recall_summary", "memory_recall_details", "board_list",
        "image_check_capability", "image_generate_selfie",
        "image_generate_pair", "image_generate_group",
        "image_gallery_list", "image_analyze",
    })

    # See ChatEngine.TOOL_LOOP_MAX_TOKENS -- same reasoning applies here:
    # group chat replies are short, so cap the completion instead of letting
    # a provider default to the model's full output ceiling for its 402
    # pre-flight cost estimate.
    TOOL_LOOP_MAX_TOKENS = 4096

    def __init__(
        self,
        username: str,
        user_display_name: str,
        character_names: List[str],
        provider: str,
        model: str,
        get_safety_role: Callable[[str], int],
        get_delay_seconds: Callable[[], float],
        voice_wait_hook: Optional[Callable[[str], None]] = None,
        is_introduction: bool = False,  # NEW
        name: str = "",
        scene_description: Optional[str] = None,
        is_collab: bool = False,  # NEW -- Collab Group Chat (see chat/collab/)
    ) -> None:

        self.username = username
        self.user_display_name = user_display_name
        self.provider = provider
        self.model = model
        self.get_delay_seconds = get_delay_seconds
        self.voice_wait_hook = voice_wait_hook
        self._get_safety_role = get_safety_role
        self._maximos = get_maximos_client()
        self._tools = ToolExecutor(username=username)
        self._normalizer = ToolCallNormalizer()

        participants = [
            GroupParticipant(name=c, safety_role=get_safety_role(c))
            for c in character_names
        ]

        # Create state
        self.state = GroupChatState(
            user_name=user_display_name,
            participants=participants,
            name=name,
            username=username,
            scene_description=scene_description,
            is_collab=is_collab,
        )

        # NEW — Introduction Chat Mode
        if is_introduction:
            self.state.is_introduction = True

        # NEW — Birthday Detection
        birthday_target = BirthdayService.check_today(
            username=username,
            character_names=character_names,
        )

        if birthday_target:
            self.state.is_birthday = True
            self.state.birthday_target = birthday_target

        # Resolve the user's own (or system-default) provider API key and
        # inject it into runtime.env before constructing the router --
        # without this, group chat silently relied on whatever key
        # happened to already be sitting in runtime.env from a previous
        # 1:1 chat request in this same process (or nothing at all right
        # after a fresh server restart), even though the user's own key
        # was correctly saved in the vault.
        resolve_and_inject_api_key(username, provider)

        # v3.0 unified router
        self.router = RouterSelector.select(provider_id=provider, model_id=model, mode="chat")

    # ---------------- Core helpers ----------------

    def _now_iso(self) -> str:
        return datetime.utcnow().isoformat() + "Z"

    async def _delay_after_message(self, speaker: str) -> None:
        if self.voice_wait_hook:
            await asyncio.to_thread(self.voice_wait_hook, speaker)
        delay = self.get_delay_seconds()
        if delay > 0:
            await asyncio.sleep(delay)

    async def _llm_reply_for_character(self, character_name: str) -> str:
        messages = build_group_chat_messages(self.state, character_name)

        max_rounds = 4
        rounds = 0
        image_markdown: List[str] = []

        while True:
            rounds += 1
            if rounds > max_rounds:
                return "I could not complete this response because tool calls exceeded the safe limit."

            # The broader toolset (filesystem, terminal, UI automation,
            # brokerage, etc.) is intentionally NOT passed in group chat:
            # with several agents taking turns in the same session, letting
            # them all call those tools created a real risk of
            # concurrent/overlapping access and system crashes. Group chat
            # replies stay text-only for everything except memory_search --
            # read-only recall of a character's own long-term memory carries
            # none of that collision risk, and without it characters had no
            # way to pull their private-chat memory into a group session
            # other than whatever was proactively injected at intro time.
            #
            # router.chat() is a synchronous, blocking (network I/O) call --
            # run it in a thread instead of awaiting it directly (it is not
            # a coroutine).
            response = await call_with_retry(
                self.router.chat,
                compact_tool_history(messages),
                tools=self._tools.registry.get_all_schemas(allowed_names=self.GROUP_CHAT_TOOL_NAMES),
                tool_choice="auto",
                max_tokens=self.TOOL_LOOP_MAX_TOKENS,
            )

            tool_call = self._normalizer.normalize(response)
            if not tool_call:
                # router.chat() returns a plain dict, not an object with a
                # `.content` attribute -- reuse ChatEngine's robust
                # dict/list/text extraction instead.
                text = ChatEngine._normalize_assistant_text(response) if isinstance(response, dict) else str(response)
                if not text:
                    text = "..."

                # Occasional emotional/scene-triggered auto-photo -- best
                # effort only, must never break the actual reply.
                try:
                    emotion = _detect_emotion(text)
                    if should_generate_avatar_for_message({
                        "is_group_chat": True,
                        "emotion": emotion,
                        "scene_change": bool(self.state.scene_description),
                    }):
                        selfie_result = await ImageGenerationService().generate_selfie(
                            self.username, character_name, emotion=emotion,
                            location=self.state.scene_description,
                        )
                        selfie_md = image_result_to_markdown(selfie_result)
                        if selfie_md:
                            image_markdown.append(selfie_md)
                except Exception:
                    logger.debug("Group chat auto-photo skipped for character=%s", character_name, exc_info=True)

                if image_markdown:
                    text = (text + "\n\n" + "\n\n".join(image_markdown)).strip()
                return text

            tool_name = tool_call["tool_name"]
            arguments = tool_call["arguments"]
            tool_call_id = tool_call.get("tool_call_id")
            if isinstance(arguments, dict) and not arguments.get("character"):
                arguments = {**arguments, "character": character_name}

            tool_result = await self._tools.execute(tool_name, arguments)

            md = image_result_to_markdown(tool_result if isinstance(tool_result, dict) else None)
            if md:
                image_markdown.append(md)

            tool_message = {"role": "tool", "content": tool_result if isinstance(tool_result, str) else json.dumps(tool_result)}
            if tool_call_id:
                tool_message["tool_call_id"] = tool_call_id
            messages.append(tool_message)

    def _append_history(
        self,
        sender: str,
        message: str,
    ) -> Dict[str, Optional[str]]:
        timestamp = self._now_iso()
        entry = GroupMessage(
            timestamp=timestamp,
            sender=sender,
            type="group",
            message=message,
        )
        self.state.history.append(entry)

        # Persist to each participant's character memory (Maximos Memory
        # Server) so each character has one consistent conversational mind
        # across interaction modes -- a group-chat line is recalled later
        # in 1:1 chat the same way a 1:1 line would be. `sender` is stored
        # as the TRUE speaker's name (the human's display name, or another
        # character entirely) rather than collapsed into a generic "user"
        # role -- otherwise, from any other participant's own pipeline, a
        # different character's line was previously indistinguishable from
        # something the actual human said. Every participant's copy of this
        # SAME broadcast line shares the exact same `timestamp`, even though
        # each gets its own distinct entry_id (one per pipeline) -- the
        # returned dict lets a caller (e.g. next_turn's summarizer hookup)
        # look up the entry_id for a specific participant's own pipeline.
        participant_names = {p.name for p in self.state.participants}
        entry_ids: Dict[str, Optional[str]] = {}

        for participant in participant_names:
            try:
                entry_ids[participant] = self._maximos.store_group_turn(
                    self.username,
                    participant,
                    sender,
                    message,
                    channel=normalize_channel(CHANNEL_GROUP_CHAT),
                    created_at=timestamp,
                )
            except Exception:
                # Group chat should continue even if one history write fails.
                entry_ids[participant] = None

        return entry_ids

    # ---------------- Public API ----------------

    async def user_message(self, text: str) -> None:
        self.state.interrupt_flag = False
        self._append_history(self.user_display_name, text)

    async def next_turn(self) -> Optional[Dict[str, Any]]:
        if not self.state.participants:
            return None

        last_msg = self.state.history[-1] if self.state.history else None
        addressed_target: Optional[str] = None

        if last_msg:
            participant_names = [p.name for p in self.state.participants]
            addressed_target = resolve_addressed_target(
                last_msg.message,
                participant_names=participant_names,
                user_name=self.user_display_name,
            )

        if addressed_target == "__USER__":
            return None

        if addressed_target:
            speaker_name = addressed_target
            # An @mention grants an out-of-turn reply, but the round-robin
            # pointer still needs to advance past this speaker -- otherwise
            # the very next normal turn calls get_next_participant() with a
            # stale index and picks this same speaker again (a duplicate
            # turn), and the queue order after that never recovers to the
            # correct safety-role sequence.
            self.state.set_next_participant(speaker_name)
        else:
            speaker = self.state.get_next_participant()
            speaker_name = speaker.name

        reply_text = await self._llm_reply_for_character(speaker_name)

        # Collab Group Chat only -- let a participant explicitly end the
        # discussion (before the caller's turn cap is reached) instead of
        # always running the full cap. The marker never reaches the user
        # (stripped before it's stored/returned).
        if self.state.is_collab:
            match = _CONCLUDE_RE.search(reply_text)
            if match:
                reply_text = _CONCLUDE_RE.sub("", reply_text).strip()
                self.state.concluded = True
                self.state.concluded_reason = match.group(1).strip() or "Discussion concluded."

        reply_entry_ids = self._append_history(speaker_name, reply_text)

        # Best-effort "agent summary" recall layer, mirroring 1:1 chat's
        # ChatEngine._finalize_reply: one short, searchable summary of this
        # exchange (the triggering message + this reply), timestamped to
        # when the triggering message actually happened. Scope note: a
        # summary can only reliably link back to the REPLY's own entry_id
        # in speaker_name's pipeline -- the triggering message got a
        # DIFFERENT entry_id per participant (see _append_history), so
        # there's no single "the" entry_id for it within this same
        # pipeline to also link. The raw triggering text remains separately
        # searchable via ordinary channel search either way.
        if last_msg:
            try:
                summary_text = await summarize_interaction(self.provider, self.model, last_msg.message, reply_text)
                if summary_text:
                    own_reply_id = reply_entry_ids.get(speaker_name)
                    MemoryManager(self.username).append_summary(
                        speaker_name,
                        summary_text,
                        created_at=last_msg.timestamp,
                        source_entry_ids=[own_reply_id] if own_reply_id else [],
                    )
            except Exception:
                logger.debug("Group chat interaction summarization skipped for character=%s", speaker_name, exc_info=True)

        # Does THIS reply itself hand off to someone else (so the caller can
        # decide whether to keep the automatic turn chain going beyond the
        # normal one-turn-per-participant budget)? Exclude self-mentions.
        participant_names = [p.name for p in self.state.participants]
        reply_addressed_target = resolve_addressed_target(
            reply_text,
            participant_names=participant_names,
            user_name=self.user_display_name,
        )
        if reply_addressed_target == speaker_name:
            reply_addressed_target = None

        # Once every participant has introduced themselves once, in
        # safety-role order, fall back to normal group-chat behavior for
        # every subsequent turn.
        if self.state.is_introduction:
            ordered = self.state.sorted_participants()
            if ordered and ordered[-1].name == speaker_name:
                self.state.is_introduction = False

        await self._delay_after_message(speaker_name)

        return {
            "sender": speaker_name,
            "message": reply_text,
            "addressed_target": reply_addressed_target,
            "timestamp": self.state.history[-1].timestamp,
            "provider_id": self.provider,
            "model_id": self.model,
        }

    async def run_auto_mode(self, max_iterations: int = 25) -> None:
        self.state.auto_mode = True
        self.state.interrupt_flag = False

        iterations = 0
        while self.state.auto_mode and not self.state.interrupt_flag:
            iterations += 1
            if iterations > max_iterations:
                break

            result = await self.next_turn()
            if result is None:
                break

            last_msg = self.state.history[-1]
            participant_names = [p.name for p in self.state.participants]
            addressed_target = resolve_addressed_target(
                last_msg.message,
                participant_names=participant_names,
                user_name=self.user_display_name,
            )

            if addressed_target == "__USER__":
                break

        self.state.auto_mode = False

    def interrupt(self) -> None:
        self.state.interrupt_flag = True
        self.state.auto_mode = False

    def add_participant(self, character_name: str, scene_setup: Optional[str] = None) -> None:
        """Adds a new character to this already-running group chat session
        in place -- no need to end the session and start a fresh one just
        to bring someone else in. `scene_setup` (optional) is recorded as a
        message from the user announcing/framing the new arrival (e.g. "Sol
        just walked in and sat down"), visible to every participant --
        old and new alike -- and persisted to each of their own long-term
        memory pipelines the same as any other group message.
        """
        if self.state.find_participant(character_name):
            return  # already in this session -- nothing to do

        safety_role = self._get_safety_role(character_name)
        self.state.participants.append(GroupParticipant(name=character_name, safety_role=safety_role))

        if scene_setup and scene_setup.strip():
            self._append_history(self.user_display_name, scene_setup.strip())

    # ---------------- Save / resume across restarts ----------------
    # GROUP_CHAT_SESSIONS in api/routes/chat.py is in-memory only, so a
    # server restart (or the process just cycling for any reason) silently
    # drops every live group chat. to_dict()/from_saved_state() let the
    # frontend persist a session to disk on request and load it back later
    # into a brand new GroupChatRouter, indistinguishable from one that was
    # never interrupted.

    def to_dict(self) -> Dict[str, Any]:
        return {
            "username": self.username,
            "user_display_name": self.user_display_name,
            "character_names": [p.name for p in self.state.participants],
            "provider": self.provider,
            "model": self.model,
            "name": self.state.name,
            "scene_description": self.state.scene_description,
            "turn_index": self.state.turn_index,
            "is_collab": self.state.is_collab,
            "concluded": self.state.concluded,
            "concluded_reason": self.state.concluded_reason,
            "history": [
                {
                    "timestamp": m.timestamp,
                    "sender": m.sender,
                    "type": m.type,
                    "message": m.message,
                }
                for m in self.state.history
            ],
        }

    @classmethod
    def from_saved_state(
        cls,
        data: Dict[str, Any],
        get_safety_role: Callable[[str], int],
        get_delay_seconds: Callable[[], float],
        voice_wait_hook: Optional[Callable[[str], None]] = None,
    ) -> "GroupChatRouter":
        router = cls(
            username=data["username"],
            user_display_name=data["user_display_name"],
            character_names=data["character_names"],
            provider=data["provider"],
            model=data["model"],
            get_safety_role=get_safety_role,
            get_delay_seconds=get_delay_seconds,
            voice_wait_hook=voice_wait_hook,
            # History already exists -- introductions (and whatever
            # birthday state applied at save time) shouldn't replay; a
            # fresh __init__ already recomputes today's birthday check on
            # its own, which is correct even if the resume happens on a
            # different day than the save.
            is_introduction=False,
            name=data.get("name", ""),
            scene_description=data.get("scene_description"),
            is_collab=bool(data.get("is_collab")),
        )
        router.state.concluded = bool(data.get("concluded"))
        router.state.concluded_reason = data.get("concluded_reason")
        router.state.history = [
            GroupMessage(
                timestamp=m["timestamp"],
                sender=m["sender"],
                type=m.get("type", "group"),
                message=m["message"],
            )
            for m in data.get("history", [])
        ]
        router.state.turn_index = data.get("turn_index", 0)
        return router


