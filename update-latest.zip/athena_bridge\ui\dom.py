# DOM and navigation utilities
# File: ui/dom.py
# Created: 2026-04-09 11:21 CDT
# Updated: 2026-04-09 11:21 CDT

from playwright.async_api import async_playwright

browser = None
page = None

async def ensure_browser():
    global browser, page
    needs_launch = (
        browser is None
        or not browser.is_connected()
        or page is None
        or page.is_closed()
    )
    if needs_launch:
        pw = await async_playwright().start()
        browser = await pw.chromium.launch(headless=False)
        page = await browser.new_page()
    return page

async def ui_inspect_element(selector: str):
    page = await ensure_browser()
    try:
        element = await page.query_selector(selector)
        if not element:
            return {"status": "not_found", "selector": selector}

        box = await element.bounding_box()
        html = await element.inner_html()

        center = None
        if box:
            center = {
                "x": box["x"] + box["width"] / 2,
                "y": box["y"] + box["height"] / 2,
            }

        return {
            "status": "ok",
            "selector": selector,
            "bounding_box": box,
            "center": center,
            "inner_html": html,
        }
    except Exception as e:
        return {"status": "error", "error": str(e)}

async def ui_dom_tree():
    page = await ensure_browser()
    try:
        tree = await page.evaluate(
            """
            () => {
              function serialize(node) {
                if (!node) return null;

                const children = [];
                node.childNodes.forEach((child) => {
                  const serialized = serialize(child);
                  if (serialized) children.push(serialized);
                });

                const isElement = node.nodeType === Node.ELEMENT_NODE;
                const isText = node.nodeType === Node.TEXT_NODE;

                if (isText) {
                  const text = node.textContent.trim();
                  if (!text) return null;
                  return {
                    type: "text",
                    text,
                  };
                }

                if (isElement) {
                  const el = node;
                  return {
                    type: "element",
                    tag: el.tagName.toLowerCase(),
                    id: el.id || null,
                    classes: el.className ? el.className.split(" ").filter(Boolean) : [],
                    role: el.getAttribute("role"),
                    aria_label: el.getAttribute("aria-label"),
                    text: el.innerText && el.innerText.trim() ? el.innerText.trim() : null,
                    children,
                  };
                }

                return null;
              }

              return serialize(document.documentElement);
            }
            """
        )
        return {"status": "ok", "tree": tree}
    except Exception as e:
        return {"status": "error", "error": str(e)}

async def ui_navigate(url: str):
    page = await ensure_browser()
    try:
        await page.goto(url)
        title = await page.title()
        try:
            text = await page.inner_text("body")
        except Exception:
            text = ""
        text = text.strip()
        truncated = len(text) > 4000
        return {
            "status": "ok",
            "url": url,
            "title": title,
            "text": text[:4000],
            "text_truncated": truncated,
        }
    except Exception as e:
        return {"status": "error", "error": str(e)}
