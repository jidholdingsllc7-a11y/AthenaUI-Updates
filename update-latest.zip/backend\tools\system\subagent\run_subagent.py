# AthenaUI v3.5 -- Sub-Agent Delegation Tool
# File: backend/tools/system/subagent/run_subagent.py
# Created: 2026 (sub-agent delegation feature)
#
# Lets an agent spin up a small, bounded, stateless helper "sub-agent" to
# handle a MULTI-STEP research/exploration task -- the same pattern this
# assistant itself uses when it delegates exploration work (e.g.
# `explore_subagent`) instead of burning the main conversation's own
# context/tool-calling budget on routine investigation. NOT intended for a
# single one-shot lookup (one web search, one file read, etc.) -- the
# calling agent should just call that tool directly for those; see the
# tool's JSON schema description (tools/schemas/subagent/run_subagent.json)
# for the exact guidance given to the model.
#
# Deliberately scoped to read-only / side-effect-free tools: the sub-agent
# can search/read files, grep, list directories, inspect git history, recall
# memory, and web-search -- but can NEVER write/delete files, run terminal
# commands, hit arbitrary HTTP endpoints, or call `run_subagent` itself (no
# recursive sub-agents; this tool is deliberately never included in its own
# allowed pool). It has no persona, no chat history, and no memory of its
# own -- every call is a clean slate, and only its final text reply is
# returned to the calling agent (its intermediate tool calls are invisible,
# so it's told to make that reply self-contained).

from __future__ import annotations

from typing import Any, Dict, List

from logs_system.system.service import system_logger

capabilities = {
    "needs_filesystem": True,
    "needs_bridge": False,
    "needs_network": True,
    "needs_user": True,
}

DEFAULT_MAX_ROUNDS = 8
MAX_ROUNDS_CAP = 15

# The ONLY tools a sub-agent may ever use, regardless of what the calling
# agent requests via `tool_names` -- read-only/inspection tools, no writes,
# no terminal, no outbound side effects beyond a read-only web search, and
# never itself. A whitelist (not a blocklist) on purpose: a newly registered
# tool is excluded by default until deliberately added here.
SUBAGENT_ALLOWED_TOOL_POOL = frozenset({
    "file_search", "grep_search", "file_read", "file_list_dir",
    "file_list_dir_recursive", "workspace_overview", "file_metadata", "file_diff",
    "git_diff", "git_log", "git_blame",
    "web_search",
    "memory_search", "memory_recall_summary", "memory_recall_details",
})

SUBAGENT_SYSTEM_PROMPT = (
    "You are a focused, stateless sub-agent spun up to handle ONE narrow research "
    "or search task delegated by another agent. You have no persona, no memory of "
    "past conversations, and no access to this conversation's history -- this is a "
    "clean slate. Use the tools available to you to investigate the task, then "
    "reply with a concise, factual, self-contained summary of what you found "
    "(file paths, line numbers, relevant snippets/quotes, etc.) -- the calling "
    "agent only ever sees your final text reply, never your intermediate tool "
    "calls. If you can't find something after reasonable effort, say so plainly "
    "instead of guessing or inventing an answer."
)


def _resolve_allowed_tools(requested: Any) -> frozenset:
    if not isinstance(requested, list) or not requested:
        return SUBAGENT_ALLOWED_TOOL_POOL
    requested_set = {t for t in requested if isinstance(t, str)}
    narrowed = SUBAGENT_ALLOWED_TOOL_POOL & requested_set
    # An empty/unrecognized intersection falls back to the full safe pool
    # rather than leaving the sub-agent with zero tools to work with.
    return narrowed or SUBAGENT_ALLOWED_TOOL_POOL


async def run(args: Dict[str, Any], username: str) -> str:
    task = str(args.get("task") or "").strip()
    if not task:
        return "[ERROR] 'task' is required -- describe the specific thing the sub-agent should find or figure out."

    allowed = _resolve_allowed_tools(args.get("tool_names"))

    try:
        max_rounds = int(args.get("max_rounds") or DEFAULT_MAX_ROUNDS)
    except (TypeError, ValueError):
        max_rounds = DEFAULT_MAX_ROUNDS
    max_rounds = max(1, min(max_rounds, MAX_ROUNDS_CAP))

    from chat.engine.service import ChatEngine

    engine = ChatEngine(username=username)
    try:
        provider_id, model_id = engine._get_active_chat_model()
        api_key = engine._get_api_key(provider_id)
    except Exception as e:
        system_logger.log_exception(
            event="Sub-agent could not start",
            exc=e,
            details={"task": task, "username": username, "allowed_tools": sorted(allowed)},
        )
        return f"[ERROR] Sub-agent could not start: {e}"

    engine._inject_provider_api_key(provider_id, api_key)
    router = engine.router_selector.select(provider_id=provider_id, model_id=model_id, mode="chat")

    messages: List[Dict[str, Any]] = [
        {"role": "system", "content": SUBAGENT_SYSTEM_PROMPT},
        {"role": "user", "content": task},
    ]

    try:
        result = await engine._run_tool_loop(
            router,
            messages,
            character=None,
            tool_allowlist=allowed,
            provider_id=provider_id,
            max_rounds=max_rounds,
            # Distinguish "the sub-agent's own small delegated round budget ran
            # out" from a system-wide failure -- the generic fallback message
            # (shared with the main chat loop's much larger MAX_TOOL_ROUNDS)
            # reads like a scary global error when surfaced verbatim to the
            # user, when it's really just a signal to the CALLING agent that
            # this task needed a narrower scope or a higher max_rounds.
            exhausted_message=(
                f"[Sub-agent ran out of its {max_rounds}-round budget before finishing -- this is NOT a "
                "system error, just this sub-task needing more rounds than it was given. Don't report this "
                "as a failure to the user; either call the tool(s) yourself directly for a narrower piece of "
                "this task, or retry run_subagent with a higher max_rounds (up to 15) and/or a more specific task.]"
            ),
        )
    except Exception as e:
        system_logger.log_exception(
            event="Sub-agent failed",
            exc=e,
            details={
                "task": task,
                "username": username,
                "provider_id": provider_id,
                "model_id": model_id,
                "allowed_tools": sorted(allowed),
                "max_rounds": max_rounds,
            },
        )
        return f"[ERROR] Sub-agent failed: {e}"

    text = ChatEngine._normalize_assistant_text(result)
    return text or "[Sub-agent finished without returning any findings.]"
