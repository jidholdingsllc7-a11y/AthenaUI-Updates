# AthenaUI -- Synergy Worker process (Synergy_Reborn.md Section 1)
# File: backend/synergy_worker/app.py
#
# A thin, duplicable FastAPI service -- run twice (once as "Synergy-A", once
# as "Synergy-B"; see scripts/start_synergy_workers.ps1) so Synergy's two
# models get real process-level isolation instead of sharing the main
# backend's single event loop. Holds NO provider credentials of its own --
# every outbound LLM call is proxied through the main Athena UI backend (see
# api/routes/synergy_worker.py::proxy_chat). Local filesystem/search/memory
# tool execution (Section 4) runs directly in THIS process by reusing the
# exact same chat.tools.executor.ToolExecutor the main backend uses -- same
# approval gating, same MAP safety checks, same directory sandboxing, zero
# duplicated logic.
#
# Phase 1 scope: proves the separate-process + credential-proxy + local
# tool-execution architecture end-to-end with a real bounded tool-calling
# loop. Does NOT yet implement the full diagnostic/apply/verdict discussion
# protocol, inter-worker messaging, or MMS contributor tagging -- those are
# later phases that build on this foundation.
#
# Run from the `backend/` directory so `chat.*`/`tools.*`/`core.*` imports
# resolve, e.g.:
#   $env:SYNERGY_LABEL = "Synergy-A"; $env:SYNERGY_PORT = "8101"
#   python -m uvicorn synergy_worker.app:app --host 127.0.0.1 --port 8101

from __future__ import annotations

import asyncio
import json
import os
from typing import Any, Dict, List, Optional

import requests
from fastapi import FastAPI, HTTPException

from core.runtime.runtime import init_runtime
init_runtime()

from chat.tools.executor import ToolExecutor
from chat.tools.normalizer import ToolCallNormalizer
from llm.context_trim import compact_tool_history
from safety.approvals import ApprovalRequiredError

LABEL = os.environ.get("SYNERGY_LABEL", "Synergy-A")
PORT = int(os.environ.get("SYNERGY_PORT", "8101"))
HOST = os.environ.get("SYNERGY_HOST", "127.0.0.1")
BACKEND_URL = os.environ.get("ATHENA_BACKEND_URL", "http://127.0.0.1:8000")

_VALID_LABELS = ("Synergy-A", "Synergy-B")
if LABEL not in _VALID_LABELS:
    raise RuntimeError(f"SYNERGY_LABEL must be one of {_VALID_LABELS}, got {LABEL!r}")

_OTHER_LABEL = "Synergy-B" if LABEL == "Synergy-A" else "Synergy-A"

app = FastAPI(title=f"AthenaUI {LABEL} Worker", version="1.0.0")

normalizer = ToolCallNormalizer()

DEFAULT_MAX_ROUNDS = 12

_SYSTEM_PROMPT = (
    "You are {label}, one of two collaborating coding agents in AthenaUI's "
    "Synergy system, working on a bounded task. Use the available tools to "
    "actually inspect/change real files under the given directory. When you "
    "are done, reply with plain text only summarizing what you found or "
    "changed."
)

# Inter-agent messaging (Synergy_Reborn.md Section 8, points 34-37).
# Deliberately a single tool, not a pair: SENDING is an explicit model
# action (point 35 -- "messages sent as complete units"), while RECEIVING
# happens passively/automatically every round (see _run_one_round draining
# the inbox below) -- "as little structure as possible" per the build
# directive, no separate check-inbox tool a model has to remember to call.
_SEND_MESSAGE_TOOL_NAME = "send_message_to_other_synergy"
_SEND_MESSAGE_SCHEMA = {
    "type": "function",
    "function": {
        "name": _SEND_MESSAGE_TOOL_NAME,
        "description": (
            f"Send a short status update, question, or finding directly to {_OTHER_LABEL}, "
            "your collaborating Synergy worker on this task. They will see it automatically "
            "at the start of their next turn -- no need for them to ask."
        ),
        "parameters": {
            "type": "object",
            "properties": {"text": {"type": "string", "description": "The message to send."}},
            "required": ["text"],
        },
    },
}

# "Menu on the table": rather than injecting every allowed tool's full
# definition into the prompt on every single turn, this worker's schemas
# only ever carry ONE real tool (tool_list) until the model actually calls
# it -- only then does the real catalog (whatever `tool_names` this round
# was given) become genuine, callable schemas. See _menu_unlocked/
# _run_one_round below -- mirrors chat/synergy/service.py's in-process
# equivalent exactly (duplicated here, not imported, to keep this worker
# process independent of the main backend's orchestrator module).
_TOOL_LIST_TOOL_NAME = "tool_list"
_TOOL_LIST_SCHEMA = {
    "type": "function",
    "function": {
        "name": _TOOL_LIST_TOOL_NAME,
        "description": (
            "Pull up the full menu of real tools available to you right now, grouped into "
            "sections with a one-line description each. This is the ONLY tool in your prompt "
            "until you call it -- keeps your context lean instead of carrying every tool's full "
            "definition on every turn. Call it whenever you think you might need a tool; once "
            "called, everything on the menu becomes directly callable for the rest of this "
            "conversation (no need to call this again unless you want a refresher)."
        ),
        "parameters": {"type": "object", "properties": {}},
    },
}


def _menu_unlocked(messages: List[Dict[str, Any]]) -> bool:
    """True once this conversation has actually called tool_list."""
    for msg in messages:
        if msg.get("role") != "assistant":
            continue
        for call in (msg.get("tool_calls") or []):
            fn = call.get("function") if isinstance(call, dict) else None
            if isinstance(fn, dict) and fn.get("name") == _TOOL_LIST_TOOL_NAME:
                return True
    return False


def _build_tool_menu_text(registry: Any, allowed_names: Optional[set]) -> str:
    """Formats the real tool catalog as a categorized menu (section headers
    from tools/registry/categories.py, one line per tool) -- what tool_list
    actually returns once called."""
    from tools.registry.categories import TOOL_CATEGORIES
    schemas_by_name = {
        s["function"]["name"]: s["function"]
        for s in registry.get_all_schemas(allowed_names=allowed_names)
    }
    sections: List[str] = []
    covered: set = set()
    for category in TOOL_CATEGORIES:
        names_here = sorted(n for n in category["tool_names"] if n in schemas_by_name)
        if not names_here:
            continue
        covered.update(names_here)
        lines = [f"## {category['label']}"]
        for name in names_here:
            desc = str(schemas_by_name[name].get("description") or "").split(". ")[0].strip().rstrip(".")
            lines.append(f"- {name}: {desc}.")
        sections.append("\n".join(lines))
    leftover = sorted(set(schemas_by_name) - covered)
    if leftover:
        lines = ["## Other"]
        for name in leftover:
            desc = str(schemas_by_name[name].get("description") or "").split(". ")[0].strip().rstrip(".")
            lines.append(f"- {name}: {desc}.")
        sections.append("\n".join(lines))
    return "\n\n".join(sections) if sections else "(No tools available.)"


def _worker_token() -> str:
    """Reads the same shared secret file the main backend generates (see
    api/routes/synergy_worker.py::get_or_create_worker_token) -- both
    processes run on the same machine against the same data directory, so
    either side can create it first."""
    from api.routes.synergy_worker import get_or_create_worker_token
    return get_or_create_worker_token()


def _auth_headers() -> Dict[str, str]:
    return {"Authorization": f"Bearer {_worker_token()}"}


def _drain_inbox_sync() -> List[Dict[str, Any]]:
    """Pulls (and clears) this worker's queued messages from the main
    backend's shared mailbox (api/routes/synergy_worker.py). Best-effort --
    returns [] on any failure rather than raising, since a transient mailbox
    hiccup shouldn't stall an otherwise-working round."""
    try:
        resp = requests.get(f"{BACKEND_URL}/synergy/{LABEL}/inbox", headers=_auth_headers(), timeout=10)
        resp.raise_for_status()
        return resp.json().get("messages") or []
    except Exception as e:
        print(f"[{LABEL}] WARNING: inbox check failed: {e}")
        return []


def _send_message_sync(text: str) -> None:
    resp = requests.post(
        f"{BACKEND_URL}/synergy/message",
        json={"from": LABEL, "to": _OTHER_LABEL, "text": text},
        headers=_auth_headers(),
        timeout=10,
    )
    resp.raise_for_status()


@app.on_event("startup")
async def register_with_backend() -> None:
    try:
        resp = requests.post(
            f"{BACKEND_URL}/synergy/register",
            json={"label": LABEL, "host": HOST, "port": PORT},
            headers=_auth_headers(),
            timeout=5,
        )
        resp.raise_for_status()
    except Exception as e:
        # Non-fatal -- a transient failure to ping the main backend at boot
        # shouldn't crash this process; /task calls still work as long as
        # the backend is reachable by the time they actually come in.
        print(f"[{LABEL}] WARNING: registration with main backend failed: {e}")


@app.get("/health")
async def health() -> Dict[str, Any]:
    return {"status": "ok", "label": LABEL}


def _proxy_chat(
    username: str,
    provider_id: str,
    model_id: str,
    messages: List[Dict[str, Any]],
    tools: Optional[List[Dict[str, Any]]],
    *,
    temperature: float = 0.2,
    max_tokens: int = 8192,
) -> Dict[str, Any]:
    resp = requests.post(
        f"{BACKEND_URL}/synergy/proxy/chat",
        json={
            "username": username,
            "provider_id": provider_id,
            "model_id": model_id,
            "messages": messages,
            "tools": tools,
            "tool_choice": "auto",
            "temperature": temperature,
            "max_tokens": max_tokens,
        },
        headers=_auth_headers(),
        timeout=180,
    )
    resp.raise_for_status()
    return resp.json()


async def _run_one_round(
    username: str,
    provider_id: str,
    model_id: str,
    messages: List[Dict[str, Any]],
    tool_names: Optional[List[str]],
    directory_path: Optional[str],
    *,
    temperature: float = 0.2,
    max_tokens: int = 8192,
) -> Dict[str, Any]:
    """Executes exactly ONE model turn: one proxied LLM call, plus local
    execution (via THIS process's own ToolExecutor -- no duplicated logic,
    same approval/MAP-check/directory-scoping enforcement as the main
    backend) of any tool call(s) that response contained. Does not mutate
    the caller's `messages` list -- returns a new one reflecting this
    round's additions, the same per-round contract
    SynergyOrchestrator/SynergyChatOrchestrator already use in-process.
    `tool_names`: None = no restriction (every registered tool allowed,
    e.g. /task's standalone loop below); [] = zero task tools (plain text
    only, aside from the always-available messaging tool below); a
    non-empty list = restrict to exactly those tool names.
    Shape returned:
      {"status": "done", "content": str, "messages": [...]}
      {"status": "in_progress", "messages": [...], "tool_call_labels": [...]}
      {"status": "approval_pending", "messages": [...]}
    """
    executor = ToolExecutor(username=username)
    if directory_path:
        executor.set_scope_dir(str(directory_path))

    # "Menu on the table" gating (see _TOOL_LIST_SCHEMA above): tool_names
    # == [] is a deliberate "stop calling tools, period" signal (e.g. a
    # forced-conclusion nudge) -- in that case don't offer tool_list either,
    # matching the existing zero-tools contract. Otherwise, the real
    # catalog only becomes real schemas once tool_list has actually been
    # called in this conversation; tool_list itself stays offered so the
    # model can re-check the menu anytime once unlocked.
    if tool_names == []:
        base_schemas: List[Dict[str, Any]] = []
        show_tool_list = False
    elif not _menu_unlocked(messages):
        base_schemas = []
        show_tool_list = True
    elif tool_names is None:
        base_schemas = executor.registry.get_all_schemas()
        show_tool_list = True
    else:
        base_schemas = executor.registry.get_all_schemas(allowed_names=set(tool_names))
        show_tool_list = True
    schemas = base_schemas + [_SEND_MESSAGE_SCHEMA] + ([_TOOL_LIST_SCHEMA] if show_tool_list else [])

    # Passive inbox check (Section 8 point 37: "workers check their inbox
    # between tool calls and before starting a new task step") -- no tool
    # call needed to receive, only to send (see _SEND_MESSAGE_SCHEMA above).
    inbox_messages = await asyncio.to_thread(_drain_inbox_sync)
    messages = list(messages)
    if inbox_messages:
        combined = "\n".join(f"- [{m.get('from')}] {m.get('text')}" for m in inbox_messages)
        messages.append({"role": "user", "content": f"New message(s) from your collaborating Synergy worker:\n{combined}"})

    try:
        # compact_tool_history: this worker's OWN /turn + /task entry
        # points both funnel every round through here -- without this
        # guard every stale tool result (file reads, web search, etc.)
        # gets resent to the provider on every subsequent round, which is
        # exactly how a long Synergy run balloons into a multi-million-
        # token prompt (same fix applied to the main backend's own
        # in-process tool loops, see chat/synergy/service.py).
        response = await asyncio.to_thread(
            _proxy_chat, username, provider_id, model_id, compact_tool_history(messages), schemas,
            temperature=temperature, max_tokens=max_tokens,
        )
    except requests.HTTPError as e:
        detail = e.response.text if e.response is not None else str(e)
        raise HTTPException(status_code=502, detail=f"LLM proxy call failed: {detail}")
    except requests.RequestException as e:
        raise HTTPException(status_code=502, detail=f"Could not reach main backend proxy: {e}")

    if not isinstance(response, dict):
        return {"status": "done", "content": str(response or ""), "messages": messages}

    parsed = normalizer.normalize(response)
    content = response.get("content") or response.get("reply") or response.get("text")
    if not parsed:
        return {"status": "done", "content": str(content or ""), "messages": messages}

    raw_tool_calls = response.get("tool_calls")
    if not isinstance(raw_tool_calls, list) or not raw_tool_calls:
        raw_tool_calls = [{
            "id": parsed.get("tool_call_id"),
            "type": "function",
            "function": {"name": parsed["tool_name"], "arguments": json.dumps(parsed["arguments"])},
        }]
    messages.append({"role": "assistant", "content": content, "tool_calls": raw_tool_calls})

    tool_call_labels: List[str] = []
    for index, raw_call in enumerate(raw_tool_calls):
        call = parsed if index == 0 else normalizer.normalize({"tool_calls": [raw_call]})
        call_id = raw_call.get("id") if isinstance(raw_call, dict) else None
        if not call:
            messages.append({"role": "tool", "tool_call_id": call_id, "content": json.dumps({"status": "error", "error": "Malformed tool call."})})
            continue

        call_name = call["tool_name"]

        if call_name == _SEND_MESSAGE_TOOL_NAME:
            text = str(call["arguments"].get("text") or "").strip()
            if text:
                await asyncio.to_thread(_send_message_sync, text)
                tool_call_labels.append(f"messaged {_OTHER_LABEL}: {text[:60]}")
                messages.append({"role": "tool", "tool_call_id": call_id, "content": json.dumps({"status": "sent", "to": _OTHER_LABEL})})
            else:
                messages.append({"role": "tool", "tool_call_id": call_id, "content": json.dumps({"status": "error", "error": "text is required"})})
            continue

        if call_name == _TOOL_LIST_TOOL_NAME:
            if not show_tool_list:
                messages.append({"role": "tool", "tool_call_id": call_id, "content": json.dumps({"status": "error", "error": f"Tool '{call_name}' is not permitted."})})
                continue
            menu_text = _build_tool_menu_text(executor.registry, set(tool_names) if tool_names else None)
            messages.append({"role": "tool", "tool_call_id": call_id, "content": menu_text})
            tool_call_labels.append("pulled up the tool menu")
            continue

        if tool_names and call_name not in tool_names:
            messages.append({"role": "tool", "tool_call_id": call_id, "content": json.dumps({"status": "error", "error": f"Tool '{call_name}' is not permitted."})})
            continue

        tool_call_labels.append(call_name)
        try:
            tool_result = await executor.execute(call_name, {**call["arguments"], "character": "Synergy"})
        except ApprovalRequiredError:
            messages.append({"role": "tool", "tool_call_id": call_id, "content": json.dumps({"status": "pending_approval"})})
            return {"status": "approval_pending", "messages": messages}
        except Exception as e:
            tool_result = {"status": "error", "error": str(e)}

        messages.append({
            "role": "tool",
            "tool_call_id": call_id,
            "content": tool_result if isinstance(tool_result, str) else json.dumps(tool_result),
        })

    return {"status": "in_progress", "messages": messages, "tool_call_labels": tool_call_labels}


@app.post("/task")
async def run_task(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Runs a bounded tool-calling loop for one Synergy task. Body:
    {"username", "provider_id", "model_id", "task", "directory_path"?,
    "max_rounds"?}. Kept for standalone manual testing of this worker
    process -- the main backend's SynergyOrchestrator/SynergyChatOrchestrator
    (Phase 1b) call the lower-level /turn endpoint below instead, since they
    own the real diagnostic/discussion/apply round-budget state machine
    themselves and only need ONE round executed per call."""
    username = str(payload.get("username") or "").strip()
    provider_id = str(payload.get("provider_id") or "").strip()
    model_id = str(payload.get("model_id") or "").strip()
    task = str(payload.get("task") or "").strip()
    directory_path = payload.get("directory_path")
    max_rounds = int(payload.get("max_rounds") or DEFAULT_MAX_ROUNDS)

    if not username or not provider_id or not model_id or not task:
        raise HTTPException(status_code=400, detail="username, provider_id, model_id, task are required.")

    messages: List[Dict[str, Any]] = [
        {"role": "system", "content": _SYSTEM_PROMPT.format(label=LABEL)},
        {"role": "user", "content": (f"Directory: {directory_path}\n\n" if directory_path else "") + task},
    ]

    tool_call_labels: List[str] = []
    for round_num in range(max_rounds):
        result = await _run_one_round(username, provider_id, model_id, messages, None, directory_path)
        messages = result["messages"]
        tool_call_labels.extend(result.get("tool_call_labels", []))
        if result["status"] == "done":
            return {
                "status": "done",
                "label": LABEL,
                "result": result.get("content") or "(No reply produced.)",
                "tool_call_labels": tool_call_labels,
                "rounds_used": round_num + 1,
            }
        if result["status"] == "approval_pending":
            return {"status": "approval_pending", "label": LABEL, "tool_call_labels": tool_call_labels, "rounds_used": round_num + 1}

    return {
        "status": "needs_more_rounds",
        "label": LABEL,
        "tool_call_labels": tool_call_labels,
        "rounds_used": max_rounds,
    }


@app.post("/turn")
async def run_turn(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Phase 1b primitive: runs exactly ONE round (one proxied LLM call plus
    any resulting local tool execution, via this process's OWN ToolExecutor
    -- Section 1's "tool execution happens locally in the worker" design)
    against a caller-supplied conversation, and returns immediately. The
    main backend's SynergyOrchestrator/SynergyChatOrchestrator call this
    repeatedly to drive their own diagnostic/discussion/apply round-budget
    and resume state machine while delegating actual inference + tool
    execution to this separate process. Body: {"username", "provider_id",
    "model_id", "messages", "tool_names"?, "directory_path"?,
    "temperature"?, "max_tokens"?}."""
    username = str(payload.get("username") or "").strip()
    provider_id = str(payload.get("provider_id") or "").strip()
    model_id = str(payload.get("model_id") or "").strip()
    messages = payload.get("messages")
    if not username or not provider_id or not model_id or not isinstance(messages, list):
        raise HTTPException(status_code=400, detail="username, provider_id, model_id, messages are required.")

    tool_names = payload.get("tool_names")
    result = await _run_one_round(
        username, provider_id, model_id, messages,
        list(tool_names) if isinstance(tool_names, list) else None,
        payload.get("directory_path"),
        temperature=payload.get("temperature") if payload.get("temperature") is not None else 0.2,
        max_tokens=payload.get("max_tokens") if payload.get("max_tokens") is not None else 8192,
    )
    result["label"] = LABEL
    return result


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host=HOST, port=PORT)
