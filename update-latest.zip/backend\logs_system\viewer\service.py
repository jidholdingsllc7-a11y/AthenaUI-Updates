﻿# AthenaUI v3.5 — Log Viewer Service
# File: backend/logs_system/viewer/service.py
# Created: 2026-04-09 20:36 CDT
# Updated: 2026-07-27 19:49 CDT

import json
import os
from typing import Any, Dict, List, Optional

from logs_system.vault.service import vault_logger  # noqa: F401  # kept for symmetry
from logs_system.db.service import tail_log_db


class LogViewerService:
    """
    Unified view over:
    - Live Tail (in-memory, recent logs)
    - Vault logs (JSONL files on disk)
    """

    def __init__(self, vault_base_dir: Optional[str] = None) -> None:
        # Must match VaultLogger base_dir
        self.vault_base_dir = vault_base_dir or os.path.join("vault", "logs")

    # -----------------------------
    # Tail (in-memory) access
    # -----------------------------

    def get_recent_tail(
        self,
        limit: int = 200,
        level: Optional[str] = None,
        task_id: Optional[str] = None,
        event: Optional[str] = None,
        agent_state: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        # Reads from the persistent SQL store (not the in-memory ring buffer)
        # so the Tail Log view shows real history across server restarts,
        # not just whatever has accumulated since the process last started.
        entries = tail_log_db.get_recent(limit=limit, agent_state=agent_state)
        return self._filter_entries(entries, level=level, task_id=task_id, event=event)

    def get_tail_range(
        self,
        start: Optional[str] = None,
        end: Optional[str] = None,
        agent_state: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Returns Tail Log entries with an ISO timestamp within [start, end]
        (either bound omitted means "no limit" on that side), oldest-to-
        newest in the exact order they were logged. Backed by the
        persistent SQL log store, so this covers full history across
        server restarts -- not just what's still in the in-memory ring
        buffer (see get_recent_tail for that).
        """
        return tail_log_db.get_range(start=start, end=end, agent_state=agent_state)

    # -----------------------------
    # Vault (on-disk) access
    # -----------------------------

    def list_log_files(self) -> List[str]:
        """
        Return a list of log filenames in the vault log directory.
        """
        if not os.path.isdir(self.vault_base_dir):
            return []
        return sorted(
            f for f in os.listdir(self.vault_base_dir)
            if f.endswith(".log.jsonl")
        )

    def list_dates(self) -> List[str]:
        """
        Return a list of date-based log files (YYYY-MM-DD.log.jsonl).
        """
        files = self.list_log_files()
        dates = []
        for f in files:
            if f[:4].isdigit() and f.endswith(".log.jsonl"):
                dates.append(f.replace(".log.jsonl", ""))
        return sorted(dates)

    def read_log_file(
        self,
        filename: str,
        *,
        level: Optional[str] = None,
        task_id: Optional[str] = None,
        event: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """
        Read a specific log file from the vault and optionally filter.
        """
        path = os.path.join(self.vault_base_dir, filename)
        if not os.path.isfile(path):
            return []

        entries: List[Dict[str, Any]] = []
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                except json.JSONDecodeError:
                    continue
                entries.append(entry)

        filtered = self._filter_entries(entries, level=level, task_id=task_id, event=event)
        if limit is not None and limit < len(filtered):
            return filtered[-limit:]
        return filtered

    def read_by_task_id(
        self,
        task_id: str,
        *,
        level: Optional[str] = None,
        event: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """
        Read logs for a specific task_id.
        - Prefer per-task file if present.
        - Fallback to scanning all files (still fine for early versions).
        """
        task_filename = f"{task_id}.log.jsonl"
        task_path = os.path.join(self.vault_base_dir, task_filename)

        if os.path.isfile(task_path):
            return self.read_log_file(
                task_filename,
                level=level,
                task_id=task_id,
                event=event,
                limit=limit,
            )

        # Fallback: scan all files
        files = self.list_log_files()
        entries: List[Dict[str, Any]] = []
        for f in files:
            path = os.path.join(self.vault_base_dir, f)
            with open(path, "r", encoding="utf-8") as fh:
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        entry = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if entry.get("task_id") == task_id:
                        entries.append(entry)

        filtered = self._filter_entries(entries, level=level, task_id=task_id, event=event)
        if limit is not None and limit < len(filtered):
            return filtered[-limit:]
        return filtered

    # -----------------------------
    # Filtering helpers
    # -----------------------------

    def _filter_entries(
        self,
        entries: List[Dict[str, Any]],
        *,
        level: Optional[str] = None,
        task_id: Optional[str] = None,
        event: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        result: List[Dict[str, Any]] = []
        for e in entries:
            if level and e.get("level") != level:
                continue
            if task_id and e.get("task_id") != task_id:
                continue
            if event and e.get("event") != event:
                continue
            result.append(e)
        return result


log_viewer = LogViewerService()
