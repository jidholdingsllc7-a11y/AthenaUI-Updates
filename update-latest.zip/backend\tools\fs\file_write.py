﻿# AthenaUI v3.5 — File Write Tool
# File: backend/tools/fs/file_write.py
# Created: 2026-04-12 10:13 CDT
# Updated: 2026-07-27 19:49 CDT

from workspace.service import WorkspaceService
from typing import Any, Dict

capabilities = {
    "needs_filesystem": True,
    "needs_bridge": False,
    "needs_network": False,
    "needs_user": True,
}

async def run(args: Dict[str, Any]) -> str:
    try:
        username = args.get("username")
        path = args.get("path")
        content = args.get("content")

        if not username or not path:
            return "[ERROR] Missing required arguments (username, path)."

        ws = WorkspaceService.get_workspace(username)
        if ws is None:
            return f"[ERROR] Workspace not available for user '{username}'."

        return ws.write_file_tracked(path, content, character=args.get("character"))

    except Exception as e:
        return f"[ERROR] Failed to write file: {str(e)}"
