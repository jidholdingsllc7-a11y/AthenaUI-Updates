# AthenaUI v3.5 â€” FastAPI Entry Point
# File: backend/main.py
# Created: 2026-04-11 19:50 CDT
# Updated: 2026-07-27 19:49 CDT

from __future__ import annotations

import asyncio
import uvicorn
import logging
import requests
import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

# ---------------------------------------------------------
# Initialize runtime BEFORE importing any services
# ---------------------------------------------------------
from core.runtime.runtime import init_runtime, get_runtime
init_runtime()

# Eagerly create/seed the encrypted SystemVault on first backend launch
# (e.g. right after install) instead of waiting for whichever feature
# happens to touch it first (license check, admin page, etc. -- all of
# which require a logged-in user and so would otherwise defer this until
# well after the first user account is created).
from system_vault.system_vault import SystemVault
SystemVault.load()

from logs_system.console.service import console_capture
console_capture.install()

from logs_system.system.service import system_logger
from auth.service import AuthService

# ---------------------------------------------------------
# Tool System (Registry + Loader + Executor)
# ---------------------------------------------------------
from tools.registry.loader import load_tools
from tools.executor.executor import ToolExecutor

# Load all tools into registry
tool_registry = load_tools()

# Create executor instance
executor = ToolExecutor(tool_registry)

# ---------------------------------------------------------
# Pre-onboarding routers (safe before vault exists)
# ---------------------------------------------------------
from api.routes.auth import router as auth_router
from api.routes.admin import router as admin_router
from api.routes.license import router as license_router
from api.routes.onboarding import router as onboarding_router
from api.routes.system import router as system_router
from api.routes.logs import router as logs_router
from api.routes.map import router as map_router
from api.routes.system_version import router as system_version_router
from api.routes.backup import router as backup_router
from api.deps.auth_middleware import AuthMiddleware


class _UvicornNotificationsFilter(logging.Filter):
    """
    Suppress noisy polling access logs for notifications and health-check
    endpoints so the Health Check console log tail stays useful for actual
    errors instead of filling up with routine polling.
    """

    _NOISY_PATHS = ("/logs/notifications", "/system/health", "/system/console_log")

    def filter(self, record: logging.LogRecord) -> bool:
        message = record.getMessage()
        return not any(p in message for p in self._NOISY_PATHS)

# ---------------------------------------------------------
# Helper: Determine if ANY user has completed onboarding
# ---------------------------------------------------------

def onboarding_completed() -> bool:
    """
    Returns True if at least one user has completed onboarding.
    Allows multi-user onboarding later.
    """
    service = AuthService()
    users = service._load_users()

    for username, data in users.items():
        if data.get("onboarding_complete"):
            return True

    return False

# ---------------------------------------------------------
# Lazy-load post-onboarding routers
# ---------------------------------------------------------

def load_post_onboarding_routers(app: FastAPI):
    """
    Import and include routers that require:
    - vault to exist
    - at least one onboarded user
    - provider/model settings
    """
    from api.routes.characters import router as characters_router
    from api.routes.chat import router as chat_router
    from api.routes.build_map import router as build_map_router
    from api.routes.code_suite import router as code_suite_router
    from api.routes.image_settings import router as image_settings_router
    from api.routes.images import router as images_router
    from api.routes.videos import router as videos_router
    from api.routes.llm_settings import router as llm_settings_router
    from api.routes.log_exports import router as log_exports_router
    from api.routes.skills import router as skills_router
    from api.routes.tasks import router as tasks_router
    from api.routes.job_library import router as job_library_router
    from api.routes.users import router as users_router
    from api.routes.vault import router as vault_router
    from api.routes.settings import router as settings_router
    from api.routes.brokerage import router as brokerage_router
    from api.routes.scheduler import router as scheduler_router
    from api.routes.calendar import router as calendar_router
    from api.routes.crm import router as crm_router
    from api.routes.competitors import router as competitors_router
    from api.routes.social_media import router as social_media_router
    from api.routes.ledger import router as ledger_router
    from api.routes.mobile_chat import router as mobile_chat_router
    from api.routes.personal import router as personal_router
    from api.routes.mobile_personal import router as mobile_personal_router
    from api.routes.spreadsheets import router as spreadsheets_router
    from api.routes.mobile_spreadsheets import router as mobile_spreadsheets_router
    from api.routes.documents import router as documents_router
    from api.routes.twilio import router as twilio_router
    from api.routes.newsletter import router as newsletter_router
    from api.routes.email_management import router as email_management_router
    from api.routes.marketing_email import router as marketing_email_router
    from api.routes.collab import router as collab_router
    from api.routes.feedback import router as feedback_router
    from api.routes.artifacts import router as artifacts_router
    from api.routes.synergy_worker import router as synergy_worker_router
    from api.routes.maximos import router as maximos_router

    app.include_router(characters_router)
    app.include_router(chat_router)
    app.include_router(mobile_chat_router)
    app.include_router(mobile_personal_router)
    app.include_router(mobile_spreadsheets_router)
    app.include_router(build_map_router)
    app.include_router(code_suite_router)
    app.include_router(image_settings_router)
    app.include_router(images_router)
    app.include_router(videos_router)
    app.include_router(llm_settings_router)
    app.include_router(log_exports_router)
    app.include_router(skills_router)
    app.include_router(tasks_router)
    app.include_router(job_library_router)
    app.include_router(users_router)
    app.include_router(vault_router)
    app.include_router(settings_router)
    app.include_router(brokerage_router)
    app.include_router(scheduler_router)
    app.include_router(calendar_router)
    app.include_router(crm_router)
    app.include_router(competitors_router)
    app.include_router(social_media_router)
    app.include_router(ledger_router)
    app.include_router(personal_router)
    app.include_router(spreadsheets_router)
    app.include_router(documents_router)
    app.include_router(twilio_router)
    app.include_router(newsletter_router)
    app.include_router(email_management_router)
    app.include_router(marketing_email_router)
    app.include_router(collab_router)
    app.include_router(feedback_router)
    app.include_router(artifacts_router)
    app.include_router(synergy_worker_router)
    app.include_router(maximos_router)


# ---------------------------------------------------------
# Create App
# ---------------------------------------------------------

def create_app() -> FastAPI:
    app = FastAPI(
        title="AthenaUI v3.5 Backend",
        version="3.5.3",
        docs_url="/docs",
        redoc_url="/redoc",
    )

    # ---------------------------------------------------------
    # Provider Error Safety Net
    # ---------------------------------------------------------
    # Any raw HTTP error from an upstream AI provider (OpenAI, xAI,
    # ElevenLabs, Anthropic, etc.) that a route didn't already handle
    # itself lands here instead of surfacing as a bare 500 traceback.
    # Auth/billing-shaped statuses (401/402/403/429) get a friendly
    # "check your subscription/billing" message naming the actual
    # provider, inferred from the failing request's hostname.
    _PROVIDER_HOSTS = {
        "api.openai.com": "OpenAI",
        "api.x.ai": "xAI",
        "api.elevenlabs.io": "ElevenLabs",
        "api.anthropic.com": "Anthropic",
        "generativelanguage.googleapis.com": "Google Gemini",
        "api.mistral.ai": "Mistral",
        "api.cohere.ai": "Cohere",
        "api.groq.com": "Groq",
        "api.together.xyz": "Together AI",
        "api.fireworks.ai": "Fireworks AI",
        "openrouter.ai": "OpenRouter",
        "api.perplexity.ai": "Perplexity",
    }

    def _provider_name_from_url(url: str) -> str:
        for host, label in _PROVIDER_HOSTS.items():
            if host in url:
                return label
        return "the AI provider"

    def _provider_error_response(url: str, status_code: int) -> JSONResponse:
        provider = _provider_name_from_url(url)
        if status_code in (401, 402, 403, 429):
            return JSONResponse(
                status_code=402,
                content={
                    "error": "subscription_required",
                    "provider": provider,
                    "detail": (
                        f"{provider} rejected this request (HTTP {status_code}). "
                        f"Please check that your {provider} subscription/billing is "
                        "active and your API key is valid, then try again."
                    ),
                },
            )
        return JSONResponse(
            status_code=502,
            content={
                "error": "provider_error",
                "provider": provider,
                "detail": f"{provider} returned an unexpected error (HTTP {status_code}).",
            },
        )

    @app.exception_handler(requests.exceptions.HTTPError)
    async def _requests_http_error_handler(request: Request, exc: requests.exceptions.HTTPError):
        resp = exc.response
        status_code = resp.status_code if resp is not None else 502
        url = str(resp.url) if resp is not None else ""
        system_logger.log(event=f"Upstream provider HTTP error: {exc}", level="error")
        return _provider_error_response(url, status_code)

    @app.exception_handler(httpx.HTTPStatusError)
    async def _httpx_http_error_handler(request: Request, exc: httpx.HTTPStatusError):
        status_code = exc.response.status_code
        url = str(exc.response.url)
        system_logger.log(event=f"Upstream provider HTTP error: {exc}", level="error")
        return _provider_error_response(url, status_code)

    @app.exception_handler(requests.exceptions.RequestException)
    async def _requests_connection_error_handler(request: Request, exc: requests.exceptions.RequestException):
        system_logger.log(event=f"Upstream provider connection error: {exc}", level="error")
        return JSONResponse(
            status_code=502,
            content={
                "error": "provider_unreachable",
                "detail": "Could not reach an upstream AI provider. Please check your internet connection and try again.",
            },
        )

    # ---------------------------------------------------------
    # CORS
    # ---------------------------------------------------------
    access_logger = logging.getLogger("uvicorn.access")
    if not any(isinstance(f, _UvicornNotificationsFilter) for f in access_logger.filters):
        access_logger.addFilter(_UvicornNotificationsFilter())

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ---------------------------------------------------------
    # Router Loading Logic
    # ---------------------------------------------------------

    # Always load pre-onboarding routers
    app.include_router(auth_router)
    app.include_router(admin_router)
    app.include_router(license_router)
    app.include_router(onboarding_router)
    app.include_router(system_router)
    app.include_router(logs_router)
    app.include_router(map_router)
    app.include_router(system_version_router)
    app.include_router(backup_router)

    # Always load full router set. Route-level auth and vault checks should
    # determine access instead of startup-time router omission.
    load_post_onboarding_routers(app)

    # Serve generated/uploaded images (avatars, gallery art, generated_images)
    # directly from disk so the frontend can render them via plain <img src>
    # URLs. NOTE: this directory is served without auth -- acceptable for
    # this local, single-machine desktop app (CORS is already wide open
    # above), but do not point this at anything containing secrets.
    runtime = get_runtime()
    runtime.env.DATA_DIR.mkdir(parents=True, exist_ok=True)
    app.mount("/data", StaticFiles(directory=str(runtime.env.DATA_DIR)), name="data")

    # Populate request.state.user from Authorization Bearer token for routes
    # that rely on request-scoped auth state.
    app.add_middleware(AuthMiddleware)

    # Catches anything that slips past every route/tool-level try/except (a
    # genuine bug, not a handled error) -- logs it verbosely (full traceback +
    # request path/method) via the same Tail Log pipeline used everywhere else
    # in the app, instead of either crashing the worker or silently returning
    # FastAPI's bare default 500. The client still only ever sees a generic
    # message; the real detail lives server-side for troubleshooting/export.
    @app.exception_handler(Exception)
    async def _unhandled_exception_handler(request: Request, exc: Exception):
        system_logger.log_exception(
            event=f"Unhandled error on {request.method} {request.url.path}",
            exc=exc,
            details={"method": request.method, "path": request.url.path, "query": str(request.url.query)},
        )
        return JSONResponse(status_code=500, content={"detail": "Internal server error."})

    # ---------------------------------------------------------
    # Tool Execution Endpoint
    # ---------------------------------------------------------

    @app.post("/agent/tool_call")
    async def tool_call(payload: dict):
        """
        Unified tool execution endpoint for all agent tools.
        Expected payload:
        {
            "tool": "tool_name",
            "arguments": { ... }
        }
        """
        tool_name = payload.get("tool")
        args = payload.get("arguments", {})

        if not tool_name:
            raise HTTPException(status_code=400, detail="Missing 'tool' field.")

        try:
            result = await executor.execute(tool_name, args)
            return {"ok": True, "result": result}
        except Exception as e:
            system_logger.log_exception(
                event=f"Tool '{tool_name}' failed (/agent/tool_call)",
                exc=e,
                details={"tool": tool_name, "arguments": args},
            )
            raise HTTPException(status_code=500, detail=str(e))

    # ---------------------------------------------------------
    # Startup / Shutdown
    # ---------------------------------------------------------

    @app.on_event("startup")
    async def on_startup() -> None:
        system_logger.log(event="AthenaUI v3.5 starting up")

        # Start the global scheduler background loop (scans every user's
        # persisted job list for due, user-approved jobs). Fire-and-forget --
        # it runs for the lifetime of the process.
        try:
            from scheduler.runner import run_scheduler_loop
            asyncio.create_task(run_scheduler_loop())
            system_logger.log(event="Scheduler background loop started.")
        except Exception as e:
            system_logger.log(event=f"Scheduler loop failed to start: {e}", level="error")

        # Start the global inbox-monitoring/auto-reply background loop (scans
        # every user's configured "monitor this email account" assignments
        # for new mail, raising notifications and optionally auto-replying).
        try:
            from auto_reply.monitor import run_monitor_loop
            asyncio.create_task(run_monitor_loop())
            system_logger.log(event="Inbox monitor background loop started.")
        except Exception as e:
            system_logger.log(event=f"Inbox monitor loop failed to start: {e}", level="error")

        # Start the global X (Twitter) mentions/DMs monitoring background loop
        # (mirrors the inbox monitor above: new-mention/DM notifications, plus
        # optional auto-reply or an approve/deny drafted-reply queue).
        try:
            from social_media.monitor import run_monitor_loop as run_x_monitor_loop
            asyncio.create_task(run_x_monitor_loop())
            system_logger.log(event="X mentions/DMs monitor background loop started.")
        except Exception as e:
            system_logger.log(event=f"X mentions/DMs monitor loop failed to start: {e}", level="error")

        # Start the global scheduled-backup background loop (scans every
        # user's configured recurring backup schedule and runs any that are
        # due, writing an encrypted .athenabak to their chosen folder).
        try:
            from backup.scheduler_runner import run_backup_schedule_loop
            asyncio.create_task(run_backup_schedule_loop())
            system_logger.log(event="Backup scheduler background loop started.")
        except Exception as e:
            system_logger.log(event=f"Backup scheduler loop failed to start: {e}", level="error")

    @app.on_event("shutdown")
    async def on_shutdown() -> None:
        system_logger.log(event="AthenaUI v3.5 shutting down")

    return app


# ---------------------------------------------------------
# App Instance
# ---------------------------------------------------------

app = create_app()


# ---------------------------------------------------------
# Run Server
# ---------------------------------------------------------

if __name__ == "__main__":
    uvicorn.run(
        "backend.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
    )
