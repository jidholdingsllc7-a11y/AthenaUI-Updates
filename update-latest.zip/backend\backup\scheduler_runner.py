# AthenaUI v3.5 — Scheduled Backup Background Runner
# File: backend/backup/scheduler_runner.py
#
# A single global asyncio loop (started once from main.py's startup event,
# mirroring scheduler/runner.py and auto_reply/monitor.py's established
# pattern) that wakes up periodically, finds every user whose scheduled
# backup is due (backup/schedule_service.py), builds an encrypted
# ".athenabak" backup per their saved selection + stored passphrase, and
# writes it to their configured destination folder.

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from pathlib import Path

from backup import schedule_service
from backup.service import BackupError, create_full_backup
from notifications.service.service import NotificationService

logger = logging.getLogger(__name__)

POLL_SECONDS = 300


async def _run_one(username: str, schedule: dict) -> None:
    passphrase = schedule.get("passphrase")
    destination = schedule.get("destination_folder")
    selection = schedule.get("selection") or {"full_system": True}

    if not passphrase or not destination:
        schedule_service.record_run(username, ok=False, message="missing passphrase or destination folder")
        return

    try:
        data = await asyncio.to_thread(create_full_backup, username, passphrase=passphrase, selection=selection)
        stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        dest_dir = Path(destination).expanduser()
        dest_dir.mkdir(parents=True, exist_ok=True)
        dest_path = dest_dir / f"{username}_scheduled_backup_{stamp}.athenabak"
        dest_path.write_bytes(data)
        schedule_service.record_run(username, ok=True, message=f"wrote {dest_path.name}")
        NotificationService.send(
            username,
            type="info",
            message=f"Scheduled backup completed: {dest_path.name}",
            metadata={"path": str(dest_path)},
        )
    except BackupError as e:
        schedule_service.record_run(username, ok=False, message=str(e))
        logger.warning("Scheduled backup failed for %s: %s", username, e)
    except Exception as e:
        schedule_service.record_run(username, ok=False, message=str(e))
        logger.error("Scheduled backup crashed for %s", username, exc_info=True)


async def _tick() -> None:
    for username, schedule in schedule_service.due_schedules().items():
        await _run_one(username, schedule)


async def run_backup_schedule_loop() -> None:
    """Runs forever (until backend exits)."""
    logger.info("Backup scheduler background loop starting.")
    while True:
        try:
            await _tick()
        except Exception as e:
            logger.error(f"Backup scheduler loop tick failed: {e}")
        await asyncio.sleep(POLL_SECONDS)
