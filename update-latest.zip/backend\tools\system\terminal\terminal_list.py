# AthenaUI -- Terminal List Tool
# File: backend/tools/system/terminal/terminal_list.py
#
# Lists every terminal session this backend process currently tracks --
# including ones not currently visible in the user's own UI (opened by an
# earlier turn, a different agent, or a Synergy worker process) -- so an
# agent can discover and manage a session it didn't itself open, instead of
# only ever being able to act on a session_id it already happens to know.

from __future__ import annotations

from typing import Any, Dict

from . import _session

capabilities = {
    "needs_filesystem": False,
    "needs_bridge": False,
    "needs_network": False,
    "needs_user": True,
    "is_dangerous": False,
}


async def run(args: Dict[str, Any]) -> Dict[str, Any]:
    return {"sessions": _session.list_sessions()}
