# AthenaUI — Shared "menu on the table" tool-gating helpers.
#
# A single meta-tool (`tool_list`) is the only schema offered to a model
# until it actually calls it -- once called (anywhere earlier in this
# conversation's message history), the real allowed tool catalog becomes
# genuine, callable schemas for the rest of the conversation. This keeps the
# per-turn prompt lean (one tiny schema instead of the full ~138-tool
# registry) until the model itself decides it might need a tool.
#
# Originally built for chat.synergy.service (Synergy's dual-model
# discussion/build loop); chat.engine.service (the main chat engine, used
# by every character including non-Agent ones) now uses the same pattern.
# Kept here, in a module neither of those two imports from each other, to
# avoid a circular import (chat.synergy.service already imports from
# chat.engine.service).

from typing import Any, Dict, List, Optional

TOOL_LIST_TOOL_NAME = "tool_list"
TOOL_LIST_SCHEMA = {
    "type": "function",
    "function": {
        "name": TOOL_LIST_TOOL_NAME,
        "description": (
            "Pull up the full menu of real tools available to you right now, grouped into "
            "sections with a one-line description each. This is the ONLY tool in your prompt "
            "until you call it -- keeps your context lean instead of carrying every tool's full "
            "definition on every turn. Call it whenever you think you might need a tool; once "
            "called, everything on the menu becomes directly callable for the rest of this "
            "conversation (no need to call this again unless you want a refresher)."
        ),
        "parameters": {"type": "object", "properties": {}},
    },
}


def menu_unlocked(messages: List[Dict[str, Any]]) -> bool:
    """True once this conversation has actually called tool_list -- only
    then do the real tools become genuine, callable schemas (see
    menu_gated_schemas)."""
    for msg in messages:
        if msg.get("role") != "assistant":
            continue
        for call in (msg.get("tool_calls") or []):
            fn = call.get("function") if isinstance(call, dict) else None
            if isinstance(fn, dict) and fn.get("name") == TOOL_LIST_TOOL_NAME:
                return True
    return False


def build_tool_menu_text(registry: Any, allowed_names: Optional[frozenset]) -> str:
    """Formats the real tool catalog as a categorized menu (section headers
    from tools/registry/categories.py, one line per tool) -- what tool_list
    actually returns once called."""
    from tools.registry.categories import TOOL_CATEGORIES
    schemas_by_name = {
        s["function"]["name"]: s["function"]
        for s in registry.get_all_schemas(allowed_names=allowed_names)
    }
    sections: List[str] = []
    covered: set = set()
    for category in TOOL_CATEGORIES:
        names_here = sorted(n for n in category["tool_names"] if n in schemas_by_name)
        if not names_here:
            continue
        covered.update(names_here)
        lines = [f"## {category['label']}"]
        for name in names_here:
            desc = str(schemas_by_name[name].get("description") or "").split(". ")[0].strip().rstrip(".")
            lines.append(f"- {name}: {desc}.")
        sections.append("\n".join(lines))
    leftover = sorted(set(schemas_by_name) - covered)
    if leftover:
        lines = ["## Other"]
        for name in leftover:
            desc = str(schemas_by_name[name].get("description") or "").split(". ")[0].strip().rstrip(".")
            lines.append(f"- {name}: {desc}.")
        sections.append("\n".join(lines))
    return "\n\n".join(sections) if sections else "(No tools available.)"


def menu_gated_schemas(registry: Any, allowed_names: Optional[frozenset], messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """"Menu on the table" lean-loading: until tool_list has actually been
    called in this conversation, it's the ONLY schema offered -- once
    called, the real `allowed_names` catalog becomes genuine, callable
    schemas too (tool_list stays available alongside them as a refresher)."""
    if not menu_unlocked(messages):
        return [TOOL_LIST_SCHEMA]
    return registry.get_all_schemas(allowed_names=allowed_names) + [TOOL_LIST_SCHEMA]
