# AthenaUI — Shared "menu on the table" tool-gating helpers.
#
# A single meta-tool (`list_tool_categories`) is the only schema offered to
# a model until it picks a category -- calling it with no arguments returns
# the list of categories available to this character (one line each, with a
# short description and tool count); calling it again WITH a `category`
# argument permanently unlocks that one category's real tools as genuine,
# callable schemas for the rest of the conversation (plus the shared
# database/sqldb tools, bundled in automatically so an agent never has to
# separately unlock "database" just to log notes about what it's doing).
# Picking additional categories later in the same conversation adds to what's
# unlocked -- it never replaces an earlier pick. This keeps the per-turn
# prompt lean (a tiny meta-tool schema, plus only the categories actually
# picked so far) instead of handing a character its entire allowed catalog
# (which for a full-access Agent character can be ~150 tools) the moment it
# so much as peeks at the menu.
#
# Used by chat.engine.service (the main chat engine, used by every character
# including non-Agent ones). Synergy has its own separate, unrelated
# tool_list/menu-gating implementation in chat.synergy.service -- Synergy's
# tool set is already hand-curated to just what it needs (see
# _compute_synergy_tool_names), so it isn't part of this category-picker
# redesign.

from typing import Any, Dict, List, Optional

TOOL_LIST_TOOL_NAME = "list_tool_categories"

# category_ids not already covered by one of these named, business-sensible
# bundles become their own single-category entry further down (see
# _all_menu_definitions) -- so nothing in tools/registry/categories.py
# becomes unreachable just because it wasn't explicitly grouped here.
_NAMED_MENUS: List[Dict[str, Any]] = [
    {
        "id": "marketing",
        "label": "Marketing",
        "description": "CRM contacts, competitor tracking, calendar events, newsletter campaigns, and marketing tips.",
        "category_ids": ["crm", "competitors", "calendar", "newsletter", "marketing_tips"],
    },
    {
        "id": "social_media",
        "label": "Social Media",
        "description": "Post, reply, and check mentions/DMs on X, Facebook, and Moltbook.",
        "category_ids": ["social_media"],
    },
    {
        "id": "personal_tools",
        "label": "Personal Tools",
        "description": "Manage the user's schedule, contacts, and spreadsheets.",
        "category_ids": ["calendar", "crm", "spreadsheets"],
    },
    {
        "id": "finance_tools",
        "label": "Finance Tools",
        "description": "Brokerage account/positions/orders and market data.",
        "category_ids": ["brokerage", "market_data"],
    },
]

# Categories that are either always-on already (never gated, so meaningless
# as a menu choice), purely internal (database -- bundled into every pick
# instead, see menu_gated_schemas), or carry no public tools (atlas_reference
# -- its one tool is excluded from the public catalog entirely).
_EXCLUDED_FROM_MENU = frozenset({
    "memory", "images", "relationships", "collab", "database", "atlas_reference",
})


def _all_menu_definitions() -> List[Dict[str, Any]]:
    """_NAMED_MENUS plus a pass-through, single-category entry for every
    remaining tools/registry/categories.py category not already grouped
    into one of those bundles -- so every category stays reachable."""
    from tools.registry.categories import TOOL_CATEGORIES
    consumed = {cid for menu in _NAMED_MENUS for cid in menu["category_ids"]}
    menus = list(_NAMED_MENUS)
    for category in TOOL_CATEGORIES:
        cid = category["id"]
        if cid in consumed or cid in _EXCLUDED_FROM_MENU or category.get("always_on"):
            continue
        menus.append({
            "id": cid,
            "label": category["label"],
            "description": f"{category['label']} tools.",
            "category_ids": [cid],
        })
    return menus


_MENU_DEFINITIONS_BY_ID: Dict[str, Dict[str, Any]] = {m["id"]: m for m in _all_menu_definitions()}


def _category_tool_names(category_id: str) -> List[str]:
    from tools.registry.categories import TOOL_CATEGORIES
    for category in TOOL_CATEGORIES:
        if category["id"] == category_id:
            return category["tool_names"]
    return []


TOOL_LIST_SCHEMA = {
    "type": "function",
    "function": {
        "name": TOOL_LIST_TOOL_NAME,
        "description": (
            "Call with no arguments to see the categories of tools available to you right now "
            "(e.g. 'marketing', 'social_media', 'finance_tools'), one line each with a short "
            "description. This is the ONLY tool in your prompt until you pick a category -- keeps "
            "your context lean instead of carrying every tool's full definition on every turn. "
            "Call again WITH a `category` argument (one of the ids from the list) to unlock that "
            "category's real tools as directly callable for the rest of this conversation -- picking "
            "a category always also unlocks the shared database tools (db_create/db_list/db_query/"
            "db_share/db_unshare), so you don't need to separately pick a category just to log notes "
            "about what you're doing. Pick as many categories as you actually need, one at a time."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "category": {
                    "type": "string",
                    "description": "Optional. The id of the category to unlock (from a prior call's listing). Omit to just see the category list.",
                },
            },
        },
    },
}


def _selected_category_ids(messages: List[Dict[str, Any]]) -> frozenset:
    """Every distinct `category` value this conversation has actually passed
    to list_tool_categories so far (regardless of whether it was a valid
    id -- unknown ones simply unlock nothing, see menu_gated_schemas)."""
    import json as _json
    selected: set = set()
    for msg in messages:
        if msg.get("role") != "assistant":
            continue
        for call in (msg.get("tool_calls") or []):
            fn = call.get("function") if isinstance(call, dict) else None
            if not isinstance(fn, dict) or fn.get("name") != TOOL_LIST_TOOL_NAME:
                continue
            raw_args = fn.get("arguments")
            args = raw_args if isinstance(raw_args, dict) else None
            if args is None and isinstance(raw_args, str):
                try:
                    args = _json.loads(raw_args)
                except (ValueError, TypeError):
                    args = None
            category = (args or {}).get("category") if isinstance(args, dict) else None
            if isinstance(category, str) and category.strip():
                selected.add(category.strip())
    return frozenset(selected)


def menu_unlocked(messages: List[Dict[str, Any]]) -> bool:
    """True once at least one (valid) category has been picked."""
    return bool(_selected_category_ids(messages) & _MENU_DEFINITIONS_BY_ID.keys())


def _schemas_by_original_name(registry: Any, allowed_names: Optional[frozenset]) -> Dict[str, Any]:
    """registry.get_all_schemas() keys its results by "wire name" (dots/
    other OpenAI-illegal characters sanitized to underscores, e.g.
    build_map.create -> build_map_create) -- re-key by the original,
    dotted-allowed tool name (the same names tools/registry/categories.py
    uses) via the wire->original map get_all_schemas populates as a side
    effect, so category membership checks below actually match."""
    schemas = registry.get_all_schemas(allowed_names=allowed_names)
    name_map = getattr(registry, "_name_map", {})
    by_wire = {s["function"]["name"]: s["function"] for s in schemas}
    return {name_map.get(wire, wire): fn for wire, fn in by_wire.items()}


def _available_menus(registry: Any, allowed_names: Optional[frozenset]) -> List[Dict[str, Any]]:
    """_all_menu_definitions(), filtered to ones with at least one tool this
    character is actually allowed to use, each annotated with its real
    `tool_names` (already intersected with allowed_names/the live registry)."""
    schemas_by_name = _schemas_by_original_name(registry, allowed_names)
    available = []
    for menu in _all_menu_definitions():
        names = sorted({
            name
            for cid in menu["category_ids"]
            for name in _category_tool_names(cid)
            if name in schemas_by_name
        })
        if names:
            available.append({**menu, "tool_names": names})
    return available


def build_tool_menu_text(registry: Any, allowed_names: Optional[frozenset], category: Optional[str] = None) -> str:
    """What list_tool_categories actually returns. With no `category`: the
    list of available categories. With a `category`: either that category's
    unlocked tools (plus the bundled database tools) if it's a valid,
    available id, or an error plus the category list again if not."""
    menus = _available_menus(registry, allowed_names)
    menus_by_id = {m["id"]: m for m in menus}

    if not category:
        if not menus:
            return "(No tool categories available.)"
        lines = ["Available tool categories:"]
        for menu in menus:
            lines.append(f"- {menu['id']}: {menu['description']} ({len(menu['tool_names'])} tools)")
        lines.append("\nCall list_tool_categories again with a `category` argument to unlock one.")
        return "\n".join(lines)

    menu = menus_by_id.get(category)
    if menu is None:
        lines = [f"'{category}' isn't a valid/available category. Available categories:"]
        for m in menus:
            lines.append(f"- {m['id']}: {m['description']} ({len(m['tool_names'])} tools)")
        return "\n".join(lines)

    schemas_by_name = _schemas_by_original_name(registry, allowed_names)
    db_names = sorted(n for n in _category_tool_names("database") if n in schemas_by_name)
    lines = [f"Unlocked '{category}' -- now directly callable:"]
    for name in menu["tool_names"]:
        desc = str(schemas_by_name[name].get("description") or "").split(". ")[0].strip().rstrip(".")
        lines.append(f"- {name}: {desc}.")
    if db_names:
        lines.append("\nAlso unlocked (bundled with every category pick): shared database tools --")
        for name in db_names:
            desc = str(schemas_by_name[name].get("description") or "").split(". ")[0].strip().rstrip(".")
            lines.append(f"- {name}: {desc}.")
    return "\n".join(lines)


def menu_gated_schemas(registry: Any, allowed_names: Optional[frozenset], messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """"Menu on the table" lean-loading: until at least one category has
    actually been picked in this conversation, list_tool_categories is the
    ONLY schema offered -- once one (or more) picked, each picked category's
    real tools become genuine, callable schemas too (plus the shared
    database tools, bundled in automatically), alongside
    list_tool_categories itself (kept available to unlock further
    categories or get a refresher listing)."""
    selected = _selected_category_ids(messages) & _MENU_DEFINITIONS_BY_ID.keys()
    if not selected:
        return [TOOL_LIST_SCHEMA]
    unlocked_category_ids: set = {"database"}
    for menu_id in selected:
        unlocked_category_ids.update(_MENU_DEFINITIONS_BY_ID[menu_id]["category_ids"])
    unlocked_names = {name for cid in unlocked_category_ids for name in _category_tool_names(cid)}
    scoped_names = unlocked_names if allowed_names is None else (unlocked_names & allowed_names)
    return registry.get_all_schemas(allowed_names=frozenset(scoped_names)) + [TOOL_LIST_SCHEMA]
