# AthenaUI -- Social Media Manual-Post Draft Tool
# File: backend/tools/system/social_media/social_media_draft_manual_post.py
#
# For platforms AthenaUI has no API access to: presents a draft for the user
# to copy/paste manually. Flagged requires_approval so a human reviews the
# exact text before being asked to post it anywhere. The ledger
# (backend/ledger/) logs this as a pending draft the moment this tool
# executes; it isn't marked "published" until the user confirms it with a
# live URL via POST /ledger/manual-posts/{record_id}/confirm.

from typing import Any, Dict

capabilities = {
    "needs_bridge": False,
    "needs_filesystem": False,
    "needs_network": False,
    "needs_user": True,
    "is_dangerous": True,
    "requires_approval": True,
}


async def run(args: Dict[str, Any]):
    platform = (args.get("platform") or "").strip()
    content = (args.get("content") or "").strip()
    if not platform:
        return {"error": "Missing 'platform' argument."}
    if not content:
        return {"error": "Missing 'content' argument."}

    return {
        "ok": True,
        "platform": platform,
        "content": content,
        "reminder": (
            f"This draft for {platform} has been logged to the Marketing Ledger as pending. "
            "Once posted live, confirm it in the Marketing Ledger with the post's URL so it's "
            "recorded as published."
        ),
    }
