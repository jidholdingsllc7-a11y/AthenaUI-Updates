﻿# AthenaUI v3.5 — Terminal Run Tool
# File: backend/tools/system/terminal/terminal_run.py
# Created: 2026-04-12 10:25 CDT
# Updated: 2026-08-24

from __future__ import annotations

import asyncio
import shlex
import subprocess
import sys
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from workspace.service import WorkspaceService

from . import _session

capabilities = {
    "needs_filesystem": True,
    "needs_bridge": False,
    "needs_network": False,
    "needs_user": True,
    "is_dangerous": True,
}

# Safety ceiling on how long we'll watch a single command before giving up
# and returning whatever was captured so far -- the visible window itself is
# left open (-NoExit) regardless, so the user can keep watching/using it.
_MAX_WAIT_SECONDS = 600
_POLL_INTERVAL_SECONDS = 0.3

# If a command produces no NEW output for this long and hasn't written the
# done marker, treat it as long-running/still-serving (e.g. a dev server
# like uvicorn/vite that never exits) and hand control back to the agent
# immediately with whatever was captured, instead of blocking the whole
# chat turn until _MAX_WAIT_SECONDS. The agent can keep watching it (and
# its console output as it happens) via terminal_check.
_IDLE_RETURN_SECONDS = 3.0


def _ps_quote(value: str) -> str:
    """Wraps `value` in single quotes for safe embedding in a PowerShell
    single-quoted string literal (doubling any embedded single quotes)."""
    return "'" + value.replace("'", "''") + "'"


def _split_command_chain(command: str) -> List[Tuple[Optional[str], str]]:
    """Splits a bash-style chain like "cd foo && dir" into
    [(None, "cd foo"), ("&&", "dir")], respecting single/double-quoted
    substrings -- Windows PowerShell 5.1 has no '&&'/'||' operators at all,
    so agent-issued commands (which default to bash-isms) need this
    translated instead of just failing."""
    parts: List[Tuple[Optional[str], str]] = []
    current: List[str] = []
    op: Optional[str] = None
    in_squote = in_dquote = False
    i, n = 0, len(command)
    while i < n:
        ch = command[i]
        if ch == "'" and not in_dquote:
            in_squote = not in_squote
        elif ch == '"' and not in_squote:
            in_dquote = not in_dquote
        elif not in_squote and not in_dquote and command[i : i + 2] in ("&&", "||"):
            parts.append((op, "".join(current).strip()))
            op = command[i : i + 2]
            current = []
            i += 2
            continue
        current.append(ch)
        i += 1
    parts.append((op, "".join(current).strip()))
    return [p for p in parts if p[1]]


def _build_env_refresh() -> str:
    """Refreshes PATH (and other vars) from the registry before running a
    command. subprocess.Popen inherits this backend process's environment
    block, which was captured once at backend startup and never changes
    afterward -- so without this, something like a winget/MSI JDK or Go
    install that only updates the registry's Machine/User Environment keys
    would never become visible to any agent-run command, no matter how many
    new terminal windows get opened, until the whole backend process is
    restarted. This is the same trick tools like Chocolatey's `refreshenv` use."""
    return (
        "foreach ($__athena_scope in 'Machine','User') {\n"
        "  [System.Environment]::GetEnvironmentVariables($__athena_scope).GetEnumerator() | ForEach-Object {\n"
        "    if ($_.Key -ieq 'Path') { return }\n"
        "    Set-Item -Path (\"Env:\" + $_.Key) -Value $_.Value -ErrorAction SilentlyContinue\n"
        "  }\n"
        "}\n"
        "$__athena_machine_path = [System.Environment]::GetEnvironmentVariable('Path','Machine')\n"
        "$__athena_user_path = [System.Environment]::GetEnvironmentVariable('Path','User')\n"
        "$env:Path = @($__athena_machine_path, $__athena_user_path, $env:Path) -join ';'\n"
    )


def _build_command_block(command: str) -> str:
    """Builds the chained-segment + done-marker body shared by both a brand
    new session's script and a continuation command fed into an already-open
    session's shell."""
    segments = []
    for op, cmd in _split_command_chain(command):
        guard_open, guard_close = "", ""
        if op == "&&":
            guard_open, guard_close = "if ($__athena_ok) {\n", "\n}"
        elif op == "||":
            guard_open, guard_close = "if (-not $__athena_ok) {\n", "\n}"
        segments.append(
            f"{guard_open}"
            f"Write-Host '> {cmd}'\n"
            "try {\n"
            f"    Invoke-Expression {_ps_quote(cmd)}\n"
            "    $__athena_ok = $? -and ($LASTEXITCODE -eq $null -or $LASTEXITCODE -eq 0)\n"
            "} catch {\n"
            "    $__athena_ok = $false\n"
            "    Write-Host $_.Exception.Message\n"
            "}"
            f"{guard_close}"
        )

    return (
        "$__athena_ok = $true\n"
        + "\n".join(segments)
        + "\n$__athena_code = if ($LASTEXITCODE -ne $null) { $LASTEXITCODE } elseif ($__athena_ok) { 0 } else { 1 }\n"
        f"Write-Host \"{_session._DONE_MARKER} exit=$__athena_code\"\n"
    )


def _build_script(workspace_root: Path, log_path: Path, command: str) -> str:
    """Builds the PowerShell script for the FIRST call of a new session:
    chained segments run with bash-like &&/|| short-circuiting, everything
    captured via Start-Transcript. Start-Transcript (rather than tee-ing each
    command by hand) keeps recording for the entire lifetime of this -NoExit
    window -- including anything fed to it later, whether by a follow-up
    terminal_run call reusing this session or (if stdin weren't redirected)
    a user typing -- so a later terminal_check call can see it too."""
    return (
        "$ErrorActionPreference = 'Continue'\n"
        f"Set-Location -LiteralPath {_ps_quote(str(workspace_root))}\n"
        "$host.UI.RawUI.WindowTitle = 'AthenaUI Agent Terminal'\n"
        # PSReadLine (Windows PowerShell 5.1's default interactive line
        # editor) does not support a redirected/piped stdin at all -- it
        # throws repeated "ReadLine ... not supported" errors the moment the
        # shell reaches its idle prompt with stdin piped. Since stdin is
        # piped here specifically so a later terminal_run call can feed this
        # same session more commands, the legacy (non-PSReadLine) console
        # input reader -- which does support piped input -- must be used
        # instead.
        "Remove-Module PSReadLine -Force -ErrorAction SilentlyContinue\n"
        + _build_env_refresh()
        + f"Start-Transcript -Path {_ps_quote(str(log_path))} -Append | Out-Null\n"
        + _build_command_block(command)
    )


def _build_continuation_script(command: str) -> str:
    """Builds just the next command's script for a session whose shell is
    already open and idle -- no Set-Location/Start-Transcript re-init needed,
    since that process is still alive and already transcribing. PATH is still
    refreshed every time in case something was installed since the last command."""
    return _build_env_refresh() + _build_command_block(command)



async def run(args: Dict[str, Any]) -> Dict[str, Any]:
    """
    Runs a terminal command in a REAL, visible OS console window -- not
    embedded in the app UI and not hidden in the background -- so the user
    watches it execute exactly like their own terminal. Output is captured
    via Start-Transcript into a per-session log file this function tails, so
    the agent sees everything that happened even if the user moves the
    window behind the app. The window is left open afterward (until the
    user closes it themselves).
    Reusing the same session_id on a later call feeds the command into that
    SAME still-open shell (via its stdin) instead of opening another window
    -- real continuation, so cwd/env vars/activated venvs etc. carry over
    exactly like a real terminal. The trade-off: stdin is redirected for
    this, so the user can no longer usefully type into that window directly
    -- they can still watch it, just not drive it by hand. If that session's
    shell is still busy with a previous long-running command (e.g. a dev
    server), a new command is NOT queued into it (it would just sit unread
    behind the running process) -- use a different/omitted session_id to
    open a separate window for something else alongside it.
    """
    command = args["command"]
    username = args["username"]
    session_id = args.get("session_id") or uuid.uuid4().hex

    ws = WorkspaceService.get_workspace(username)
    if ws is None:
        return {
            "returncode": -1,
            "stdout": "",
            "stderr": f"[ERROR] Workspace not available for user '{username}'. Cannot run command.",
            "session_id": session_id,
        }
    workspace_root = ws.root

    # When a Code Suite directory is actively scoped (see ToolExecutor
    # .set_scope_dir), start brand-new terminal sessions inside it rather
    # than the full workspace root -- best-effort only (a command can still
    # `cd`/use an absolute path out), but keeps ordinary relative-path
    # commands from landing on the wrong file elsewhere in the workspace.
    scope_dir = args.get("_scope_dir")
    run_cwd = workspace_root
    if scope_dir:
        candidate = (workspace_root / scope_dir).resolve()
        try:
            is_inside = candidate == workspace_root.resolve() or candidate.is_relative_to(workspace_root.resolve())
        except AttributeError:
            is_inside = str(candidate).startswith(str(workspace_root.resolve()))
        if is_inside and candidate.is_dir():
            run_cwd = candidate

    if sys.platform != "win32":
        # Non-Windows dev environments: fall back to the previous
        # hidden/blocking behavior rather than guessing at a terminal emulator.
        try:
            proc = subprocess.run(
                shlex.split(command), cwd=str(run_cwd), capture_output=True, text=True, shell=False,
            )
            return {
                "returncode": proc.returncode, "stdout": proc.stdout, "stderr": proc.stderr,
                "session_id": session_id,
            }
        except Exception as e:
            return {"returncode": -1, "stdout": "", "stderr": str(e), "session_id": session_id}

    session = _session.get_session(session_id)
    log_path = session["log_path"]

    proc = session.get("proc")
    proc_alive = proc is not None and proc.poll() is None

    if proc_alive and session.get("busy"):
        return {
            "returncode": -1,
            "stdout": "",
            "stderr": (
                "[This session's terminal is still busy running a previous long-running command (e.g. a "
                "dev server) -- sending it another command now would just sit unread behind whatever is "
                "already running in the foreground, not run 'alongside' it. Use terminal_check with this "
                "session_id to keep watching it, or call terminal_run with a different/omitted session_id "
                "to open a separate window for something else.]"
            ),
            "session_id": session_id,
        }

    reused_session = False
    if proc_alive:
        # The shell from a previous call in this session is still open and
        # idle at its prompt -- feed it the next command instead of opening
        # another window. Writing the continuation as its own script file and
        # invoking it with a single "& 'path'" line (rather than writing the
        # whole multi-line script straight to stdin) keeps the transcript
        # clean -- the legacy console input reader echoes back whatever it
        # reads from a piped stdin line-by-line, so a multi-line write would
        # otherwise dump this tool's own generated PowerShell boilerplate
        # into the agent's result alongside the command's real output.
        continuation_path = _session.SESSION_DIR / f"{session_id}_{uuid.uuid4().hex[:8]}.ps1"
        continuation_path.write_text(_build_continuation_script(command), encoding="utf-8")
        try:
            proc.stdin.write(f"& {_ps_quote(str(continuation_path))}\r\n".encode("utf-8"))
            proc.stdin.flush()
            reused_session = True
        except (BrokenPipeError, OSError, ValueError):
            proc_alive = False

    if not reused_session:
        # First call for this session, or the previous window died/was
        # closed -- start a brand-new (visible) process and remember it so
        # the NEXT call in this session can reuse it.
        script_path = _session.SESSION_DIR / f"{session_id}_{uuid.uuid4().hex[:8]}.ps1"
        script_path.write_text(_build_script(run_cwd, log_path, command), encoding="utf-8")

        proc = subprocess.Popen(
            ["powershell.exe", "-NoExit", "-ExecutionPolicy", "Bypass", "-File", str(script_path)],
            creationflags=subprocess.CREATE_NEW_CONSOLE,
            stdin=subprocess.PIPE,
        )
        session["proc"] = proc

    session["busy"] = True

    start = time.monotonic()
    last_len = 0
    last_change = start
    while True:
        await asyncio.sleep(_POLL_INTERVAL_SECONDS)
        content = _session.read_log(log_path)

        match = _session._DONE_RE.search(content, session["offset"])
        if match:
            output = content[session["offset"] : match.start()].rstrip("\n")
            session["offset"] = match.end()
            session["busy"] = False
            return {
                "returncode": int(match.group(1)), "stdout": output, "stderr": "",
                "session_id": session_id,
            }

        if len(content) != last_len:
            last_len = len(content)
            last_change = time.monotonic()

        if proc.poll() is not None:
            # The window/process ended before writing the done marker (e.g.
            # the user closed it manually) -- report what was captured.
            output = content[session["offset"] :].rstrip("\n")
            session["offset"] = len(content)
            session["busy"] = False
            session["proc"] = None
            return {
                "returncode": proc.returncode if proc.returncode is not None else -1,
                "stdout": output,
                "stderr": "[Terminal window was closed before the command finished.]",
                "session_id": session_id,
            }

        now = time.monotonic()
        elapsed = now - start
        if elapsed > _IDLE_RETURN_SECONDS and now - last_change > _IDLE_RETURN_SECONDS:
            output = content[session["offset"] :].rstrip("\n")
            session["offset"] = len(content)
            return {
                "returncode": None,
                "still_running": True,
                "stdout": output,
                "stderr": (
                    f"[No new output for {_IDLE_RETURN_SECONDS:.0f}s -- this looks like a long-running "
                    "process (e.g. a dev server) rather than a finished command. It's still running in "
                    "the open terminal window; call terminal_check with this session_id to see new "
                    "output as it happens (e.g. incoming requests, reload events). This session's shell "
                    "is now busy with it -- to run something else alongside it, use a different/omitted "
                    "session_id to open a separate window.]"
                ),
                "session_id": session_id,
            }

        if elapsed > _MAX_WAIT_SECONDS:
            output = content[session["offset"] :].rstrip("\n")
            session["offset"] = len(content)
            return {
                "returncode": None,
                "still_running": True,
                "stdout": output,
                "stderr": (
                    f"[Command is still running after {_MAX_WAIT_SECONDS}s -- the terminal window is "
                    "still open; use terminal_check with this session_id to look again later.]"
                ),
                "session_id": session_id,
            }
