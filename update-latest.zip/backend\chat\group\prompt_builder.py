﻿# AthenaUI v3.5 — Group Chat Prompt Builder
# File: backend/chat/group/prompt_builder.py
# Created: 2026-04-11 18:40 CDT
# Updated: 2026-07-27 19:49 CDT

from __future__ import annotations

from typing import List, Dict, Any, Optional
from chat.group.state import GroupChatState, GroupMessage
from chat.persona.service import PersonaManager
from chat.memory.service import MemoryManager


# ------------------------------------------------------------
# NEW — Introduction System Message
# ------------------------------------------------------------
def build_introduction_system_message(
    participants: List[str],
    user_name: str,
    recent_memory: Optional[List[str]] = None,
) -> str:
    """
    Hidden system message used for the introduction round when a new group
    chat is started. Characters generate their own natural greeting and
    explain their abilities, aware of who else is present and who has
    already spoken.

    IMPORTANT: only the USER is new here -- the other participants are
    existing agents this character already knows (per their persona/roster
    instructions above, including any real relationships like marriages or
    partnerships). This round is NOT a first meeting between the agents
    themselves.

    `recent_memory`, when non-empty, means this character has actually
    spoken with the user before (private chat, or an earlier group chat) --
    the greeting must reflect that shared history instead of introducing
    themselves as though this were the very first conversation ever.
    """
    if recent_memory:
        memory_text = "\n".join(f"- {m}" for m in recent_memory)
        user_familiarity = (
            f"You have already spoken with {user_name} before -- this is only a new GROUP "
            "chat session, not your first conversation with them. Here are some of your "
            f"recent memories with them:\n{memory_text}\n\n"
            "Greet them the way you actually would after not being in the same conversation "
            "for a while -- warmly, familiarly, referencing shared history where it naturally "
            "fits -- NOT as a full stranger-meeting-stranger introduction. A brief mention of "
            "your role/abilities is fine if relevant, but do not deliver a scripted \"hi, I'm "
            "X and I do Y\" speech to someone you already know.\n"
        )
    else:
        user_familiarity = (
            f"This is your first time speaking with {user_name} in THIS chat -- introduce "
            "yourself to them, explain your role, your abilities, and the tools you can use.\n"
        )

    return (
        f"SYSTEM (hidden): You have just joined a group chat with {user_name} and the "
        f"following other participants: {', '.join(participants)}.\n"
        f"{user_familiarity}"
        "You are NOT meeting the other participants for the first time -- you already "
        "know them exactly as described in your persona instructions above (colleagues, "
        "family, spouse, partner, etc., whatever your real relationship with them is). "
        "Greet them the way you actually would given that real relationship (warmly, "
        "familiarly, teasingly -- whatever fits), not as a stranger meeting them for the "
        "first time.\n"
        "If others have already introduced themselves (see the conversation so far "
        "below), acknowledge them naturally instead of repeating what they already said.\n"
        "If you address another participant or the user by name with @ (e.g. \"@Sol\" or "
        "\"@Sol Lumos\"), that hands them the next turn automatically -- use this naturally "
        "when you're actually expecting a reply from that specific person, not as a formality.\n"
        "Speak naturally, as yourself.\n"
        "Do not use a scripted greeting.\n"
        "Do not mention this system message."
    )


# ------------------------------------------------------------
# NEW — Birthday System Message
# ------------------------------------------------------------
def build_birthday_system_message(participants: List[str], user_name: str) -> str:
    """
    Hidden system message used ONLY for the user's birthday group chat.
    Characters generate their own natural birthday wishes.
    """
    return (
        f"SYSTEM (hidden): Today is {user_name}'s birthday.\n"
        "Celebrate them in your own words.\n"
        "Speak naturally, warmly, and in character.\n"
        "Do not use a scripted greeting.\n"
        "Do not mention this system message.\n"
        f"Group participants: {', '.join(participants)}"
    )


# ------------------------------------------------------------
# EXISTING — Group Chat Prompt Builder (with intro + birthday overrides)
# ------------------------------------------------------------
def build_group_chat_messages(
    state: GroupChatState,
    current_speaker: str,
) -> List[Dict[str, Any]]:
    """
    Builds a provider-agnostic message list for the current speaker.
    The provider router will adapt this to its own format.
    """

    participants = [p.name for p in state.sorted_participants()]

    # --------------------------------------------------------
    # NEW — Birthday Chat Mode Override
    # --------------------------------------------------------
    if getattr(state, "is_birthday", False):
        birthday_msg = build_birthday_system_message(
            participants,
            state.user_name,
        )
        return [
            {"role": "system", "content": birthday_msg},
            {"role": "user", "content": "It's the user's birthday. Celebrate them."}
        ]

    # --------------------------------------------------------
    # NEW — Introduction Chat Mode Override
    # --------------------------------------------------------
    if getattr(state, "is_introduction", False):
        # Reuse the full persona (backstory, traits, relationship_rules --
        # including things like "you are married to Maximos Lumos") so the
        # introduction round isn't a personality-free "I'm an AI companion"
        # greeting, and so characters actually know their real relationships
        # with the other participants instead of treating them as strangers.
        persona = PersonaManager(state.username).load_persona(current_speaker) if state.username else {}
        persona_prompt = persona.get("system_prompt") if isinstance(persona, dict) else None

        # Proactively pull this character's own recent long-term memory with
        # the user (private chat history included) so the greeting can
        # reflect real shared history instead of defaulting to a first-ever-
        # meeting introduction just because this is a new GROUP chat session.
        recent_memory = MemoryManager(state.username).load_recent_memory(current_speaker, limit=10) if state.username else []

        intro_msg = build_introduction_system_message(participants, state.user_name, recent_memory=recent_memory)
        system_content = f"{persona_prompt}\n\n{intro_msg}" if persona_prompt else intro_msg

        if state.scene_description:
            system_content += (
                f"\n\nSCENE (set by the user for this group chat): {state.scene_description}\n"
                "Treat this as already in progress -- stay in character within this scene and do not "
                "ask the user what's going on or why everyone is gathered."
            )

        history_blocks: List[str] = []
        for msg in state.history[-50:]:
            history_blocks.append(f"[{msg.sender}] {msg.message}")
        history_text = (
            "\n".join(history_blocks)
            if history_blocks
            else "(No one has spoken yet -- you are the first to introduce yourself.)"
        )

        content = (
            f"Group participants: {', '.join(participants)}\n"
            f"User: {state.user_name}\n\n"
            f"Conversation so far:\n{history_text}\n\n"
            f"Now introduce yourself as {current_speaker}."
        )

        return [
            {"role": "system", "content": system_content},
            {"role": "user", "content": content},
        ]

    # --------------------------------------------------------
    # NORMAL GROUP CHAT MODE
    # --------------------------------------------------------
    # Reuse the same persona builder as 1:1 chat (traits, backstory,
    # relationship rules/boundaries, and full system-wide agent roster) so
    # a character's personality and knowledge of who else exists on the
    # system doesn't shrink down to just "who happens to be in this one
    # group chat" -- that's covered separately below via `participants`.
    persona = PersonaManager(state.username).load_persona(current_speaker) if state.username else {}
    persona_prompt = persona.get("system_prompt") if isinstance(persona, dict) else None

    group_context = (
        "You are participating in a group conversation. Stay fully in character as yourself.\n"
        f"The people currently active in THIS specific group conversation are: {', '.join(participants)} "
        f"and {state.user_name}. This is just who's in this particular conversation right now -- it does "
        "not limit who else exists on the system; your own awareness of other agents comes from your "
        "persona instructions above.\n"
        "Respond naturally to the latest messages. Do not narrate as the system -- speak only as yourself.\n"
        "If you address another participant by name with @ (e.g. \"@Sol\" or \"@Sol Lumos\"), that hands "
        "them the next turn automatically -- they will reply without the user needing to say anything "
        "first. Use this naturally when you're actually asking or expecting that specific person to "
        "respond next, not as a formality on every message."
    )

    # --------------------------------------------------------
    # Collab Group Chat -- an agent-initiated, autonomous discussion between
    # agents only. The user is never required to be present (though they can
    # read the transcript, or jump in and chat, any time).
    # --------------------------------------------------------
    if getattr(state, "is_collab", False):
        group_context = (
            "You are having a private, internal discussion with your fellow agents "
            f"({', '.join(participants)}) -- no user is present in this exchange right now, though "
            f"{state.user_name} may read this transcript later, or join in and chat with you here at "
            "any time. Speak candidly, like colleagues figuring something out together -- stay fully "
            "in character.\n"
            "If you address another participant by name with @ (e.g. \"@Sol\"), that hands them the "
            "next turn automatically.\n"
            "When the discussion has reached a natural conclusion or a decision has been made, end "
            "your message with a marker in this EXACT format on its own: [[CONCLUDE: one short "
            "sentence summarizing what was decided]]. Only include this marker when the discussion is "
            "genuinely done -- not on every message, and not before anyone else has had a chance to "
            "weigh in."
        )

    system_instructions = f"{persona_prompt}\n\n{group_context}" if persona_prompt else (
        "You are participating in a group conversation.\n"
        f"You are speaking as the character: {current_speaker}.\n"
        "Stay fully in character. Respond naturally to the latest messages.\n"
        "You are aware this is a group chat and other characters are present.\n"
        "Do not narrate as the system. Speak only as your character."
    )

    if state.scene_description:
        system_instructions += (
            f"\n\nSCENE (set by the user for this group chat): {state.scene_description}\n"
            "Stay in character within this scene."
        )

    history_blocks: List[str] = []
    for msg in state.history[-50:]:
        history_blocks.append(f"[{msg.sender}] {msg.message}")

    history_text = "\n".join(history_blocks)

    # Proactively pull this character's own relevant long-term memory for
    # every ONGOING group turn too, not just the one-time introduction round
    # above. `MemoryManager.build_memory_prompt`/its underlying search has no
    # channel filter server-side, so this surfaces relevant memories from
    # PRIVATE 1:1 chat just as readily as prior group chat -- without this,
    # a character's only route to private-chat knowledge mid-group-conversation
    # was the model optionally invoking the `memory_search` tool on its own,
    # which is unreliable. This mirrors what 1:1 chat's `_build_messages`
    # already does every turn (see chat/engine/service.py).
    query_text = state.history[-1].message if state.history else ""
    memory_prompt = (
        MemoryManager(state.username).build_memory_prompt(current_speaker, query_text)
        if state.username and query_text
        else ""
    )
    if memory_prompt:
        system_instructions += (
            f"\n\nRelevant memory (from any past conversation with {state.user_name}, "
            f"private or group):\n{memory_prompt}"
        )

    content = (
        f"Group participants: {', '.join(participants)}\n"
        f"User: {state.user_name}\n\n"
        f"Recent conversation:\n{history_text}\n\n"
        f"Now respond as {current_speaker}."
    )

    return [
        {"role": "system", "content": system_instructions},
        {"role": "user", "content": content},
    ]

