﻿# AthenaUI v3.5 — Provider-specific router for Cohere models
# File: backend/llm/routers/cohere_router.py
# Created: 2026-03-28 21:24 CDT
# Updated: 2026-07-27 19:49 CDT

import json
import requests
from typing import Any, Dict, List, Optional

from llm.routers.base import BaseLLMRouter
from llm.router_selector.router_selector import RouterSelector
from llm.routers.providers import PROVIDER_COHERE
from core.runtime.runtime import get_runtime

from tools.registry.tool_examples import TOOL_EXAMPLES



class CohereRouter(BaseLLMRouter):
    """
    Provider-specific router for Cohere models.
    Supports:
    - chat
    - tool calling (Cohere format)
    - streaming (stub)
    """

    API_URL = "https://api.cohere.com/v1/chat"

    # ---------------------------------------------------------
    # Build system prompt with tool examples
    # ---------------------------------------------------------

    def _build_system_prompt(self, base_prompt: Optional[str], *, include_tool_examples: bool = True) -> str:
        if not include_tool_examples:
            return base_prompt if base_prompt else "You are AthenaUI v3.1."

        examples_json = json.dumps(TOOL_EXAMPLES, indent=2)

        tool_usage_block = f"""
You have access to a set of tools. Use them whenever needed.

Here are examples of correct tool usage:
{examples_json}

Cohere tool calling rules:
- Tools are declared in "tools"
- Tool calls appear in "tool_calls"
- Arguments appear in "arguments"

If you need to call a tool, do NOT explain â€” just call it.
"""

        if base_prompt:
            return base_prompt + "\n\n" + tool_usage_block

        return "You are AthenaUI v3.1.\n\n" + tool_usage_block

    # ---------------------------------------------------------
    # Chat Completion
    # ---------------------------------------------------------

    def chat(
        self,
        messages: List[Dict[str, Any]],
        *,
        tools: Optional[List[Dict[str, Any]]] = None,
        tool_choice: Optional[str] = None,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> Dict[str, Any]:

        runtime = get_runtime()
        api_key = runtime.env.COHERE_API_KEY

        if not api_key:
            raise RuntimeError("Cohere API key not set.")

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }

        # Extract any upstream persona/memory system prompt already present
        extracted_prompt, remaining_messages = self._extract_system_prompt(messages)
        final_system_prompt = self._build_system_prompt(system_prompt or extracted_prompt, include_tool_examples=bool(tools))

        # Cohere message format
        cohere_messages = [{"role": "SYSTEM", "message": final_system_prompt}]

        # Convert OpenAI-style messages to Cohere format
        for msg in remaining_messages:
            role = msg["role"].upper()
            if role == "ASSISTANT":
                role = "CHATBOT"
            elif role == "USER":
                role = "USER"
            elif role == "SYSTEM":
                role = "SYSTEM"

            cohere_messages.append({
                "role": role,
                "message": msg["content"],
            })

        payload: Dict[str, Any] = {
            "model": self.model_id,
            "messages": cohere_messages,
            "temperature": temperature,
        }

        if max_tokens is not None:
            payload["max_tokens"] = max_tokens

        # Tool calling (Cohere format)
        if tools:
            payload["tools"] = tools
            if tool_choice:
                payload["tool_choice"] = tool_choice

        # Send request
        response = requests.post(self.API_URL, json=payload, headers=headers)
        response.raise_for_status()
        data = response.json()

        # Normalize Cohere response
        text_content = data.get("text")
        tool_calls = data.get("tool_calls")

        result = {
            "id": data.get("id"),
            "model": self.model_id,
            "content": text_content,
            "tool_calls": tool_calls,
            "finish_reason": data.get("finish_reason"),
            "raw": data,
        }

        return result

    # ---------------------------------------------------------
    # Streaming (stub)
    # ---------------------------------------------------------

    def stream_chat(
        self,
        messages: List[Dict[str, Any]],
        *,
        tools: Optional[List[Dict[str, Any]]] = None,
        tool_choice: Optional[str] = None,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ):
        raise NotImplementedError("Cohere streaming not implemented yet.")


# ---------------------------------------------------------
# Register Router
# ---------------------------------------------------------

RouterSelector.register_router(PROVIDER_COHERE, CohereRouter)

