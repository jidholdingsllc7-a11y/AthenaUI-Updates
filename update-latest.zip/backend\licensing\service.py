# AthenaUI — License storage + enforcement logic
# File: backend/licensing/service.py
#
# Bridges the Cloudflare Worker licensing server (licensing/client.py) with
# local storage. Stored in the SystemVault -- global/installer-scoped, not
# per-user, since one license binds this whole machine install, not a
# single AthenaUI user account -- and consulted by billing/gate.py for
# enforcement (with a developer-mode bypass applied by the caller).

import logging
import time
from typing import Any, Dict

from system_vault.system_vault import SystemVault
from licensing import client
from licensing.fingerprint import get_machine_id

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
if not logger.handlers:
    _handler = logging.StreamHandler()
    _handler.setFormatter(logging.Formatter("%(asctime)s [%(name)s] %(message)s"))
    logger.addHandler(_handler)

_KEYS = {
    "license_key": "license_key",
    "valid": "license_valid",
    "reason": "license_reason",
    "premium_access": "license_premium_access",
    "founder_tier": "license_founder_tier",
    "friends_family": "license_friends_family",
    "free_month": "license_free_month",
    "trial_active": "license_trial_active",
    "trial_end": "license_trial_end",
    "marketing_consent": "license_marketing_consent",
    "last_validated_at": "license_last_validated_at",
}

# How long a previously-valid license stays usable if the Worker can't be
# reached -- a brief outage or dropped wifi shouldn't lock a paying user
# out immediately. A real invalid/canceled/mismatch response from the
# Worker is NEVER granted this grace, only a genuine "unreachable" outage.
_OFFLINE_GRACE_SECONDS = 3 * 24 * 60 * 60  # 3 days


class LicenseService:
    def get_status(self) -> Dict[str, Any]:
        """Currently stored license status -- no network call."""
        stored = {name: SystemVault.get(key) for name, key in _KEYS.items()}
        return {
            "license_key": stored["license_key"] or None,
            "machine_id": get_machine_id(),
            "valid": bool(stored["valid"]),
            "reason": stored["reason"] or None,
            "premium_access": bool(stored["premium_access"]),
            "founder_tier": bool(stored["founder_tier"]),
            "friends_family": bool(stored["friends_family"]),
            "free_month": bool(stored["free_month"]),
            "trial_active": bool(stored["trial_active"]),
            "trial_end": stored["trial_end"] or None,
            "marketing_consent": bool(stored["marketing_consent"]),
            "last_validated_at": stored["last_validated_at"] or None,
            "activated": bool(stored["license_key"]),
        }

    def activate(self, license_key: str) -> Dict[str, Any]:
        """Binds `license_key` to this machine. Used for both first-time
        activation and "Restore License" on a new/reset machine -- the
        Worker itself decides whether to allow the rebind (or reports a
        machine-mismatch reason if the old machine wasn't freed)."""
        license_key = (license_key or "").strip()
        if not license_key:
            logger.warning("activate() called with no license key.")
            return {"valid": False, "reason": "License key is required."}

        machine_id = get_machine_id()
        logger.info("activate() starting for license_key=%s machine_id=%s", license_key, machine_id)
        try:
            activate_result = client.activate(license_key, machine_id)
        except client.LicensingUnreachableError as e:
            logger.error("activate() could not reach the Worker for license_key=%s: %s", license_key, e)
            return {
                "valid": False,
                "reason": "Could not reach the licensing server. Check your internet connection and try again.",
            }

        if not activate_result.get("ok"):
            reason = activate_result.get("reason") or "Could not activate this license key."
            logger.warning("activate() rejected by Worker for license_key=%s: %s", license_key, reason)
            return {"valid": False, "reason": reason}

        logger.info("activate() bound license_key=%s to machine_id=%s, validating...", license_key, machine_id)
        return self._validate_and_store(license_key, machine_id)

    def refresh(self) -> Dict[str, Any]:
        """Re-validates the already-stored license (startup/login check)."""
        license_key = SystemVault.get(_KEYS["license_key"])
        if not license_key:
            logger.info("refresh() called with no license_key stored yet -- nothing to refresh.")
            return {"valid": False, "reason": "No license activated yet."}
        logger.info("refresh() re-validating stored license_key=%s", license_key)
        return self._validate_and_store(str(license_key), get_machine_id())

    def _validate_and_store(self, license_key: str, machine_id: str) -> Dict[str, Any]:
        try:
            result = client.validate_license(license_key, machine_id)
        except client.LicensingUnreachableError as e:
            logger.error("_validate_and_store() could not reach the Worker for license_key=%s: %s", license_key, e)
            return self._offline_fallback()

        valid = bool(result.get("valid"))
        logger.info(
            "_validate_and_store() license_key=%s valid=%s reason=%s premium_access=%s",
            license_key, valid, result.get("reason"), result.get("premium_access"),
        )

        SystemVault.set(_KEYS["license_key"], license_key)
        SystemVault.set(_KEYS["valid"], valid)
        SystemVault.set(_KEYS["reason"], result.get("reason"))
        SystemVault.set(_KEYS["premium_access"], bool(result.get("premium_access")))
        SystemVault.set(_KEYS["founder_tier"], bool(result.get("founder_tier")))
        SystemVault.set(_KEYS["friends_family"], bool(result.get("friends_family")))
        SystemVault.set(_KEYS["free_month"], bool(result.get("free_month")))
        SystemVault.set(_KEYS["trial_active"], bool(result.get("trial_active")))
        SystemVault.set(_KEYS["trial_end"], result.get("trial_end"))
        SystemVault.set(_KEYS["marketing_consent"], bool(result.get("marketing_consent")))
        if valid:
            SystemVault.set(_KEYS["last_validated_at"], time.time())

        return self.get_status()

    def _offline_fallback(self) -> Dict[str, Any]:
        """Worker unreachable -- honor a short grace period off the last
        known-good validation instead of locking the user out over a blip."""
        last_valid = SystemVault.get(_KEYS["valid"])
        last_validated_at = SystemVault.get(_KEYS["last_validated_at"]) or 0
        within_grace = bool(last_valid) and (time.time() - float(last_validated_at)) < _OFFLINE_GRACE_SECONDS

        status = self.get_status()
        status["valid"] = within_grace
        status["offline"] = True
        status["reason"] = (
            "Licensing server unreachable -- using your last known-good license (offline grace period)."
            if within_grace else
            "Licensing server unreachable and the offline grace period has expired. Please reconnect to the internet."
        )
        return status

    def has_access(self) -> bool:
        """Used by billing/gate.py. True if this install currently has a
        valid, enforceable license (caller applies the developer-mode
        bypass separately)."""
        return bool(self.get_status().get("valid"))

    def get_portal_url(self) -> Dict[str, Any]:
        """Returns a Stripe Billing Portal link for the license activated
        on this machine, so the customer can manage/cancel their own
        subscription without emailing support."""
        license_key = SystemVault.get(_KEYS["license_key"])
        if not license_key:
            return {"ok": False, "reason": "No license activated on this machine yet."}
        try:
            result = client.create_portal_session(str(license_key))
        except client.LicensingUnreachableError as e:
            logger.error("get_portal_url() could not reach the Worker: %s", e)
            return {
                "ok": False,
                "reason": "Could not reach the licensing server. Check your internet connection and try again.",
            }
        if not result.get("ok"):
            logger.warning("get_portal_url() rejected by Worker: %s", result.get("reason"))
        return result


license_service = LicenseService()
