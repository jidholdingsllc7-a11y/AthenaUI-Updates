# AthenaUI v3.5 — Email Management API Routes
# File: backend/api/routes/email_management.py
#
# Direct, authenticated REST endpoints backing the Personal Email
# ("Outlook Express"-style) page and the Marketing Email dashboard's inbox
# view: paginated inbox browsing, single-message read, delete (single/bulk),
# compose/send, and the cleanup-rules library. These call the SAME
# EmailAccountsService/email_rules functions the agent tools use, but are
# invoked directly by the user clicking around the UI (implicit approval,
# same pattern as the Social Media "Approve & Post" buttons) rather than
# through the chat tool-executor's approval gate.

from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Body, Depends, HTTPException, Query

from api.deps.auth_middleware import get_current_user
from emailing.service import EmailAccountsService, EmailServiceError
from email_rules.service import EmailRulesError, add_rule, delete_rule, list_rules

router = APIRouter(prefix="/email", tags=["email"])


def _username_from_user(user: Any) -> str:
    username = user.get("username") if isinstance(user, dict) else getattr(user, "username", None)
    if not username:
        raise HTTPException(status_code=401, detail="Authentication required.")
    return str(username)


def _label_for_account(username: str, account_id: str) -> str:
    account = EmailAccountsService.get_account_by_id(username, account_id)
    if not account:
        raise HTTPException(status_code=404, detail=f"Email account '{account_id}' not found.")
    return account["label"]


@router.get("/inbox")
async def get_inbox_page(
    account_id: str = Query(...),
    character: str = Query(...),
    limit: int = Query(50),
    offset: int = Query(0),
    newest_first: bool = Query(True),
    mailbox: str = Query("INBOX"),
    user: Dict[str, Any] = Depends(get_current_user),
):
    username = _username_from_user(user)
    label = _label_for_account(username, account_id)
    try:
        page = EmailAccountsService.list_inbox_page(
            username, character, account_label=label, mailbox=mailbox,
            limit=limit, offset=offset, newest_first=newest_first,
        )
    except EmailServiceError as e:
        raise HTTPException(status_code=400, detail=str(e))
    page["account_id"] = account_id
    return page


@router.get("/inbox/{uid}")
async def get_inbox_message(
    uid: str,
    account_id: str = Query(...),
    character: str = Query(...),
    mailbox: str = Query("INBOX"),
    user: Dict[str, Any] = Depends(get_current_user),
):
    username = _username_from_user(user)
    label = _label_for_account(username, account_id)
    try:
        message = EmailAccountsService.get_message(username, character, uid=uid, account_label=label, mailbox=mailbox)
    except EmailServiceError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return message


@router.post("/inbox/{uid}/delete")
async def delete_inbox_message(
    uid: str,
    payload: Dict[str, Any] = Body(...),
    user: Dict[str, Any] = Depends(get_current_user),
):
    username = _username_from_user(user)
    account_id = str(payload.get("account_id", ""))
    character = str(payload.get("character", ""))
    if not account_id or not character:
        raise HTTPException(status_code=400, detail="'account_id' and 'character' are required.")
    label = _label_for_account(username, account_id)
    try:
        result = EmailAccountsService.delete_message(
            username, character, uid=uid, account_label=label, mailbox=payload.get("mailbox", "INBOX"),
        )
    except EmailServiceError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"ok": True, **result}


@router.post("/inbox/delete-bulk")
async def delete_inbox_messages(
    payload: Dict[str, Any] = Body(...),
    user: Dict[str, Any] = Depends(get_current_user),
):
    username = _username_from_user(user)
    account_id = str(payload.get("account_id", ""))
    character = str(payload.get("character", ""))
    uids: List[str] = payload.get("uids") or []
    if not account_id or not character:
        raise HTTPException(status_code=400, detail="'account_id' and 'character' are required.")
    if not uids:
        raise HTTPException(status_code=400, detail="'uids' must be a non-empty list.")
    label = _label_for_account(username, account_id)
    try:
        result = EmailAccountsService.delete_messages(
            username, character, uids=[str(u) for u in uids],
            account_label=label, mailbox=payload.get("mailbox", "INBOX"),
        )
    except EmailServiceError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"ok": True, **result}


@router.post("/send")
async def send_inbox_message(
    payload: Dict[str, Any] = Body(...),
    user: Dict[str, Any] = Depends(get_current_user),
):
    username = _username_from_user(user)
    account_id = str(payload.get("account_id", ""))
    character = str(payload.get("character", ""))
    to = str(payload.get("to", ""))
    subject = str(payload.get("subject", ""))
    body = str(payload.get("body", ""))
    if not account_id or not character or not to:
        raise HTTPException(status_code=400, detail="'account_id', 'character', and 'to' are required.")
    label = _label_for_account(username, account_id)
    try:
        result = EmailAccountsService.send_email(
            username=username, character=character, to=to, subject=subject, body=body, account_label=label,
        )
    except EmailServiceError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"ok": True, **result}


# ---------------------------------------------------------
# Cleanup rules -- "teach the agent how to auto clean this inbox"
# ---------------------------------------------------------

@router.get("/rules")
async def get_rules(
    account_id: Optional[str] = Query(None),
    user: Dict[str, Any] = Depends(get_current_user),
):
    username = _username_from_user(user)
    return {"rules": list_rules(username, account_id=account_id)}


@router.post("/rules")
async def create_rule(
    payload: Dict[str, Any] = Body(...),
    user: Dict[str, Any] = Depends(get_current_user),
):
    username = _username_from_user(user)
    account_id = payload.get("account_id")
    account_label = None
    if account_id:
        account_label = _label_for_account(username, account_id)
    try:
        rule = add_rule(
            username,
            action=str(payload.get("action", "")),
            match_type=str(payload.get("match_type", "")),
            match_value=str(payload.get("match_value", "")),
            account_id=account_id,
            account_label=account_label,
            note=payload.get("note"),
            character=payload.get("character"),
        )
    except EmailRulesError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"ok": True, "rule": rule}


@router.delete("/rules/{rule_id}")
async def remove_rule(rule_id: str, user: Dict[str, Any] = Depends(get_current_user)):
    username = _username_from_user(user)
    try:
        delete_rule(username, rule_id)
    except EmailRulesError as e:
        raise HTTPException(status_code=404, detail=str(e))
    return {"ok": True}
