﻿# AthenaUI v3.5 — Group Chat State
# File: backend/chat/group/state.py
# Created: 2026-04-11 18:40 CDT
# Updated: 2026-07-27 19:49 CDT

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional


@dataclass
class GroupParticipant:
    name: str
    safety_role: int


@dataclass
class GroupMessage:
    timestamp: str
    sender: str
    type: str  # "group"
    message: str


@dataclass
class GroupChatState:
    user_name: str
    participants: List[GroupParticipant]
    name: str = ""
    history: List[GroupMessage] = field(default_factory=list)
    username: str = ""  # the logged-in account's username, for persona/roster lookups

    # NEW — Special chat modes
    is_introduction: bool = False
    is_birthday: bool = False
    birthday_target: Optional[str] = None  # "user" or character name

    # Optional user-set scene/roleplay context for this session (e.g. "family
    # dinner, everyone just sat down") so agents don't need to ask what's
    # going on before engaging.
    scene_description: Optional[str] = None

    # Existing fields
    auto_mode: bool = False
    interrupt_flag: bool = False
    turn_index: int = 0

    # Collab Group Chat -- an agent-initiated, autonomous discussion between
    # agents only (no user required to be present). is_collab flips on the
    # narrated "this is a private internal discussion" framing + the
    # CONCLUDE marker convention in prompt_builder/router; concluded/
    # concluded_reason record whether a participant explicitly ended the
    # discussion (vs. it just running out of turns).
    is_collab: bool = False
    concluded: bool = False
    concluded_reason: Optional[str] = None

    def sorted_participants(self) -> List[GroupParticipant]:
        return sorted(self.participants, key=lambda p: p.safety_role)

    def get_next_participant(self) -> GroupParticipant:
        ordered = self.sorted_participants()
        if not ordered:
            raise ValueError("No participants in group chat")
        participant = ordered[self.turn_index % len(ordered)]
        self.turn_index = (self.turn_index + 1) % len(ordered)
        return participant

    def find_participant(self, name: str) -> Optional[GroupParticipant]:
        for p in self.participants:
            if p.name.lower() == name.lower():
                return p
        return None

    def set_next_participant(self, name: str) -> None:
        ordered = self.sorted_participants()
        for idx, p in enumerate(ordered):
            if p.name.lower() == name.lower():
                self.turn_index = (idx + 1) % len(ordered)
                return

