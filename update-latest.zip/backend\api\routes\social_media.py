# AthenaUI -- Social Media API Routes
# File: backend/api/routes/social_media.py
#
# REST surface for: storing/verifying credentials for X, Facebook, and
# Moltbook (each verified against the real API before being saved, mirroring
# api/routes/brokerage.py's set_credentials pattern), the X "upgraded
# account" character-limit toggle, Moltbook agent self-registration,
# on-demand post-copy generation for all 6 Marketing-page platforms, and
# direct "Approve & Post" publishing for the 3 platforms with API access.
#
# The publish endpoint is a direct, human-initiated REST call (the user
# clicking "Approve & Post" in the Marketing UI) -- a separate, already-
# authenticated action, distinct from the agent-facing tools in
# tools/system/social_media/*.py, which go through the tool executor's
# approval gate instead since those calls can originate autonomously from
# an agent/task.

from __future__ import annotations

from typing import Any, Dict

from fastapi import APIRouter, Body, Depends, HTTPException

from api.deps.auth_middleware import get_current_user
from social_media import drafts as social_media_drafts
from social_media import settings as social_media_settings
from social_media.content_generator import CHARACTER_LIMITS, generate_post
from social_media.facebook_client import FacebookClient, FacebookError
from social_media.moltbook_client import MoltbookClient, MoltbookError
from social_media.x_client import XClient, XError

router = APIRouter(prefix="/social_media", tags=["social-media"])


def _username(user: Any) -> str:
    username = user.get("username") if isinstance(user, dict) else getattr(user, "username", None)
    if not username:
        raise HTTPException(status_code=401, detail="Authentication required.")
    return str(username)


# ---------------------------------------------------------
# Status / capability
# ---------------------------------------------------------

@router.get("/status")
async def get_status(user: Dict[str, Any] = Depends(get_current_user)):
    username = _username(user)
    return {
        "platforms": social_media_settings.capability_status(username),
        "character_limits": CHARACTER_LIMITS,
    }


# ---------------------------------------------------------
# Credentials
# ---------------------------------------------------------

@router.post("/credentials/x")
async def set_x_credentials(payload: Dict[str, Any] = Body(...), user: Dict[str, Any] = Depends(get_current_user)):
    username = _username(user)
    api_key = str(payload.get("api_key", "")).strip()
    api_secret = str(payload.get("api_secret", "")).strip()
    access_token = str(payload.get("access_token", "")).strip()
    access_token_secret = str(payload.get("access_token_secret", "")).strip()
    bearer_token = str(payload.get("bearer_token", "")).strip()
    if not all([api_key, api_secret, access_token, access_token_secret, bearer_token]):
        raise HTTPException(status_code=400, detail="api_key, api_secret, access_token, access_token_secret, and bearer_token are all required")

    client = XClient(api_key, api_secret, access_token, access_token_secret, bearer_token)
    try:
        await client.verify_credentials()
    except XError as e:
        raise HTTPException(status_code=400, detail=f"X rejected these credentials: {e}")

    social_media_settings.set_credentials(username, "x", {
        "api_key": api_key,
        "api_secret": api_secret,
        "access_token": access_token,
        "access_token_secret": access_token_secret,
        "bearer_token": bearer_token,
    })
    return {"ok": True}


@router.post("/credentials/x/clear")
async def clear_x_credentials(user: Dict[str, Any] = Depends(get_current_user)):
    username = _username(user)
    social_media_settings.clear_credentials(username, "x")
    return {"ok": True}


@router.post("/credentials/x/upgraded-account")
async def set_x_upgraded_account(payload: Dict[str, Any] = Body(...), user: Dict[str, Any] = Depends(get_current_user)):
    username = _username(user)
    social_media_settings.set_x_upgraded_account(username, bool(payload.get("enabled")))
    return {"ok": True, "enabled": social_media_settings.get_x_upgraded_account(username)}


@router.post("/credentials/facebook")
async def set_facebook_credentials(payload: Dict[str, Any] = Body(...), user: Dict[str, Any] = Depends(get_current_user)):
    username = _username(user)
    page_access_token = str(payload.get("page_access_token", "")).strip()
    page_id = str(payload.get("page_id", "")).strip()
    if not page_access_token or not page_id:
        raise HTTPException(status_code=400, detail="page_access_token and page_id are required")

    client = FacebookClient(page_access_token, page_id)
    try:
        await client.verify_credentials()
    except FacebookError as e:
        raise HTTPException(status_code=400, detail=f"Facebook rejected these credentials: {e}")

    social_media_settings.set_credentials(username, "facebook", {
        "page_access_token": page_access_token,
        "page_id": page_id,
    })
    return {"ok": True}


@router.post("/credentials/facebook/clear")
async def clear_facebook_credentials(user: Dict[str, Any] = Depends(get_current_user)):
    username = _username(user)
    social_media_settings.clear_credentials(username, "facebook")
    return {"ok": True}


@router.post("/credentials/moltbook")
async def set_moltbook_credentials(payload: Dict[str, Any] = Body(...), user: Dict[str, Any] = Depends(get_current_user)):
    """Manual entry path -- for a Moltbook agent API key the user already has (e.g. from a prior registration)."""
    username = _username(user)
    character = str(payload.get("character", "")).strip()
    api_key = str(payload.get("api_key", "")).strip()
    if not character:
        raise HTTPException(status_code=400, detail="character is required")
    if not api_key:
        raise HTTPException(status_code=400, detail="api_key is required")

    client = MoltbookClient(api_key)
    try:
        status = await client.get_status()
    except MoltbookError as e:
        raise HTTPException(status_code=400, detail=f"Moltbook rejected this API key: {e}")

    social_media_settings.set_moltbook_credentials(
        username, character, api_key, moltbook_username=payload.get("moltbook_username") or character
    )
    return {"ok": True, "status": status.get("status")}


@router.post("/credentials/moltbook/clear")
async def clear_moltbook_credentials(payload: Dict[str, Any] = Body(...), user: Dict[str, Any] = Depends(get_current_user)):
    username = _username(user)
    character = str(payload.get("character", "")).strip()
    if not character:
        raise HTTPException(status_code=400, detail="character is required")
    social_media_settings.clear_moltbook_credentials(username, character)
    return {"ok": True}


@router.get("/moltbook/agents")
async def get_moltbook_agents(user: Dict[str, Any] = Depends(get_current_user)):
    """Which of the user's characters/agents already have a linked Moltbook account."""
    username = _username(user)
    return {"linked": social_media_settings.moltbook_status(username)}


@router.post("/moltbook/register")
async def register_moltbook_agent(payload: Dict[str, Any] = Body(...), user: Dict[str, Any] = Depends(get_current_user)):
    """
    Registers a brand-new Moltbook agent account and links it to the chosen
    character/agent immediately. Returns the `claim_url` the human user must
    visit (and then tweet a verification message from their X account) to
    activate the agent -- Moltbook's human-agent-bond anti-spam mechanism.
    """
    username = _username(user)
    character = str(payload.get("character", "")).strip()
    name = str(payload.get("name", "")).strip()
    description = str(payload.get("description", "")).strip()
    if not character:
        raise HTTPException(status_code=400, detail="character is required")
    if not name or not description:
        raise HTTPException(status_code=400, detail="name and description are required")

    client = MoltbookClient()
    try:
        result = await client.register(name, description)
    except MoltbookError as e:
        raise HTTPException(status_code=400, detail=f"Moltbook registration failed: {e}")

    agent = result.get("agent") or {}
    api_key = agent.get("api_key")
    if not api_key:
        raise HTTPException(status_code=502, detail="Moltbook did not return an api_key.")

    social_media_settings.set_moltbook_credentials(username, character, api_key, moltbook_username=name)
    return {
        "ok": True,
        "claim_url": agent.get("claim_url"),
        "verification_code": agent.get("verification_code"),
    }


# ---------------------------------------------------------
# Post generation (all 6 platforms) + direct publish (X/Facebook/Moltbook)
# ---------------------------------------------------------

@router.post("/generate")
async def generate(payload: Dict[str, Any] = Body(...), user: Dict[str, Any] = Depends(get_current_user)):
    username = _username(user)
    platform = str(payload.get("platform", "")).strip().lower()
    topic = str(payload.get("topic", "")).strip()
    character = str(payload.get("character", "")).strip() or None
    if platform not in CHARACTER_LIMITS:
        raise HTTPException(status_code=400, detail=f"Unknown platform '{platform}'")
    if not topic:
        raise HTTPException(status_code=400, detail="topic is required")

    upgraded = social_media_settings.get_x_upgraded_account(username) if platform == "x" else False
    try:
        text = generate_post(username, platform, topic, upgraded_account=upgraded, character=character)
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Post generation failed: {e}")
    return {"platform": platform, "content": text}


@router.post("/post/x")
async def post_x(payload: Dict[str, Any] = Body(...), user: Dict[str, Any] = Depends(get_current_user)):
    username = _username(user)
    content = str(payload.get("content", "")).strip()
    if not content:
        raise HTTPException(status_code=400, detail="content is required")
    creds = social_media_settings.get_x_credentials(username)
    if not creds:
        raise HTTPException(status_code=400, detail="No X credentials configured.")
    client = XClient(**creds)
    try:
        result = await client.post_tweet(content)
    except XError as e:
        raise HTTPException(status_code=502, detail=str(e))
    return {"ok": True, "result": result}


@router.post("/post/facebook")
async def post_facebook(payload: Dict[str, Any] = Body(...), user: Dict[str, Any] = Depends(get_current_user)):
    username = _username(user)
    content = str(payload.get("content", "")).strip()
    if not content:
        raise HTTPException(status_code=400, detail="content is required")
    creds = social_media_settings.get_facebook_credentials(username)
    if not creds:
        raise HTTPException(status_code=400, detail="No Facebook credentials configured.")
    client = FacebookClient(creds["page_access_token"], creds["page_id"])
    try:
        result = await client.post_to_feed(content)
    except FacebookError as e:
        raise HTTPException(status_code=502, detail=str(e))
    return {"ok": True, "result": result}


@router.post("/post/moltbook")
async def post_moltbook(payload: Dict[str, Any] = Body(...), user: Dict[str, Any] = Depends(get_current_user)):
    """
    Direct human-initiated publish. Either pass `draft_id` (to post/clear an
    agent-drafted post from the Moltbook pending-drafts queue) or pass
    `character`, `content`, `title`, and `submolt_name` directly for a
    manually-generated post -- either way, the given character's own linked
    Moltbook credentials are used.
    """
    username = _username(user)
    draft_id = str(payload.get("draft_id", "")).strip()

    if draft_id:
        draft = social_media_drafts.get_draft(username, draft_id)
        if not draft:
            raise HTTPException(status_code=404, detail="Draft not found.")
        character = draft["character"]
        content = draft["content"]
        submolt_name = draft["submolt_name"]
        title = draft["title"]
    else:
        character = str(payload.get("character", "")).strip()
        content = str(payload.get("content", "")).strip()
        submolt_name = str(payload.get("submolt_name", "")).strip()
        title = str(payload.get("title", "")).strip() or content[:100]

    if not character:
        raise HTTPException(status_code=400, detail="character is required")
    if not content:
        raise HTTPException(status_code=400, detail="content is required")
    if not submolt_name:
        raise HTTPException(status_code=400, detail="submolt_name is required")

    creds = social_media_settings.get_moltbook_credentials(username, character)
    if not creds:
        raise HTTPException(status_code=400, detail=f"No Moltbook credentials linked to '{character}'.")
    client = MoltbookClient(creds["api_key"])
    try:
        result = await client.create_post(submolt_name=submolt_name, title=title, content=content)
    except MoltbookError as e:
        raise HTTPException(status_code=502, detail=str(e))

    if draft_id:
        social_media_drafts.delete_draft(username, draft_id)
    return {"ok": True, "result": result}


@router.post("/post/moltbook/comment")
async def post_moltbook_comment(payload: Dict[str, Any] = Body(...), user: Dict[str, Any] = Depends(get_current_user)):
    """
    Direct human-initiated comment publish. Either pass `draft_id` (to post
    an agent-drafted comment from the pending-drafts queue) or pass
    `character`, `post_id`, `content`, and optional `parent_id` directly --
    either way, the given character's own linked Moltbook credentials are
    used.
    """
    username = _username(user)
    draft_id = str(payload.get("draft_id", "")).strip()

    if draft_id:
        draft = social_media_drafts.get_draft(username, draft_id)
        if not draft:
            raise HTTPException(status_code=404, detail="Draft not found.")
        character = draft["character"]
        content = draft["content"]
        post_id = draft["post_id"]
        parent_id = draft.get("parent_id") or None
    else:
        character = str(payload.get("character", "")).strip()
        content = str(payload.get("content", "")).strip()
        post_id = str(payload.get("post_id", "")).strip()
        parent_id = str(payload.get("parent_id", "")).strip() or None

    if not character:
        raise HTTPException(status_code=400, detail="character is required")
    if not content:
        raise HTTPException(status_code=400, detail="content is required")
    if not post_id:
        raise HTTPException(status_code=400, detail="post_id is required")

    creds = social_media_settings.get_moltbook_credentials(username, character)
    if not creds:
        raise HTTPException(status_code=400, detail=f"No Moltbook credentials linked to '{character}'.")
    client = MoltbookClient(creds["api_key"])
    try:
        result = await client.comment_on_post(post_id, content, parent_id=parent_id)
    except MoltbookError as e:
        raise HTTPException(status_code=502, detail=str(e))

    if draft_id:
        social_media_drafts.delete_draft(username, draft_id)
    return {"ok": True, "result": result}


# ---------------------------------------------------------
# Agent-drafted Moltbook posts (pending human review/approval)
# ---------------------------------------------------------

@router.get("/drafts")
async def list_drafts(platform: str | None = None, user: Dict[str, Any] = Depends(get_current_user)):
    username = _username(user)
    return {"drafts": social_media_drafts.list_drafts(username, platform=platform)}


@router.post("/drafts/{draft_id}/dismiss")
async def dismiss_draft(draft_id: str, user: Dict[str, Any] = Depends(get_current_user)):
    username = _username(user)
    social_media_drafts.delete_draft(username, draft_id)
    return {"ok": True}

