# AthenaUI — Athena Net: Dropbox OAuth2 + connection service
# File: backend/athena_net/dropbox_service.py
# Created: 2026-11-02
#
# Handles the OAuth2 "Authorization Code" flow (with offline/refresh-token
# access) against a user's own registered Dropbox app (App key/secret saved
# via the generic app-key vault storage under app_name="dropbox", see
# api/routes/settings.py's /settings/app-key). This is the user's own app,
# not a shared AthenaUI-wide Dropbox app -- each team sets up their own.

from __future__ import annotations

import secrets
import time
from typing import Any, Dict, Optional, Tuple

import requests

from vault.service import VaultService

AUTHORIZE_URL = "https://www.dropbox.com/oauth2/authorize"
TOKEN_URL = "https://api.dropboxapi.com/oauth2/token"
REVOKE_URL = "https://api.dropboxapi.com/2/auth/token/revoke"
ACCOUNT_URL = "https://api.dropboxapi.com/2/users/get_current_account"

STATE_TTL_SECONDS = 600


class DropboxServiceError(Exception):
    pass


class DropboxService:
    # In-memory, single-process store: state token -> (username, expires_at).
    # Only needs to survive the few minutes between "Connect Dropbox" and the
    # browser redirect landing back on the callback route, so no persistence
    # is needed -- a restart simply means an in-flight connect attempt has to
    # be started over.
    _pending_states: Dict[str, Tuple[str, float]] = {}

    # ---------------------------------------------------------
    # App credentials (App key/secret, entered in Settings)
    # ---------------------------------------------------------

    @staticmethod
    def _get_app_credentials(username: str) -> Tuple[str, str]:
        key_data = VaultService.get_app_api_key(username, "dropbox") or {}
        app_key = str(key_data.get("value_1", "")).strip()
        app_secret = str(key_data.get("secret", "")).strip()
        if not app_key or not app_secret:
            raise DropboxServiceError(
                "Dropbox app key/secret are not saved yet. Enter them in "
                "Settings > Athena Net Settings first."
            )
        return app_key, app_secret

    # ---------------------------------------------------------
    # Step 1: build the authorize URL, remembering which user asked
    # ---------------------------------------------------------

    @classmethod
    def create_authorize_url(cls, username: str, redirect_uri: str) -> str:
        app_key, _app_secret = cls._get_app_credentials(username)

        cls._prune_expired_states()
        state = secrets.token_urlsafe(32)
        cls._pending_states[state] = (username, time.time() + STATE_TTL_SECONDS)

        params = {
            "client_id": app_key,
            "response_type": "code",
            "redirect_uri": redirect_uri,
            "token_access_type": "offline",  # request a refresh token
            "state": state,
        }
        query = "&".join(f"{k}={requests.utils.quote(str(v), safe='')}" for k, v in params.items())
        return f"{AUTHORIZE_URL}?{query}"

    @classmethod
    def _prune_expired_states(cls) -> None:
        now = time.time()
        expired = [s for s, (_, exp) in cls._pending_states.items() if exp < now]
        for s in expired:
            cls._pending_states.pop(s, None)

    # ---------------------------------------------------------
    # Step 2: handle the redirect back from Dropbox
    # ---------------------------------------------------------

    @classmethod
    def handle_callback(cls, code: str, state: str, redirect_uri: str) -> str:
        """
        Exchanges the authorization code for tokens, fetches basic account
        info, and saves everything in the vault under app_name="dropbox".
        Returns the username this connection belongs to.
        """
        entry = cls._pending_states.pop(state, None)
        if not entry:
            raise DropboxServiceError("This Dropbox authorization link expired or was already used.")

        username, expires_at = entry
        if time.time() > expires_at:
            raise DropboxServiceError("This Dropbox authorization link expired. Please try connecting again.")

        app_key, app_secret = cls._get_app_credentials(username)

        token_resp = requests.post(
            TOKEN_URL,
            data={
                "code": code,
                "grant_type": "authorization_code",
                "client_id": app_key,
                "client_secret": app_secret,
                "redirect_uri": redirect_uri,
            },
            timeout=20,
        )
        if token_resp.status_code != 200:
            raise DropboxServiceError(f"Dropbox token exchange failed: {token_resp.text[:500]}")

        token_data = token_resp.json()
        access_token = token_data.get("access_token")
        refresh_token = token_data.get("refresh_token")
        if not access_token or not refresh_token:
            raise DropboxServiceError("Dropbox did not return an offline refresh token. Try reconnecting.")

        account_email = None
        account_name = None
        root_namespace_id = None
        is_team_space = False
        try:
            account_resp = requests.post(
                ACCOUNT_URL,
                headers={"Authorization": f"Bearer {access_token}"},
                timeout=20,
            )
            if account_resp.status_code == 200:
                account_data = account_resp.json()
                account_email = account_data.get("email")
                account_name = (account_data.get("name") or {}).get("display_name")
                # Dropbox Business accounts expose a separate "team space"
                # namespace (containing both the member's own home folder AND
                # any Team Folders they have access to) distinct from the
                # default "home" namespace, which only shows personal files.
                # Without targeting the team space explicitly, file ops land
                # in the personal home namespace instead of the shared Team
                # Folder. See DropboxStorageBackend._headers().
                root_info = account_data.get("root_info") or {}
                if root_info.get(".tag") == "team":
                    root_namespace_id = root_info.get("root_namespace_id")
                    is_team_space = bool(root_namespace_id)
        except requests.RequestException:
            pass  # non-fatal -- the connection itself still succeeded

        existing = VaultService.get_app_api_key(username, "dropbox") or {}
        key_data: Dict[str, Any] = dict(existing)
        key_data["refresh_token"] = refresh_token
        key_data["connected"] = True
        key_data["account_email"] = account_email
        key_data["account_name"] = account_name
        key_data["root_namespace_id"] = root_namespace_id
        key_data["is_team_space"] = is_team_space
        key_data["root_checked"] = True
        VaultService.set_app_api_key(username, "dropbox", key_data)

        return username

    # ---------------------------------------------------------
    # Status / disconnect
    # ---------------------------------------------------------

    @classmethod
    def get_status(cls, username: str) -> Dict[str, Any]:
        key_data = VaultService.get_app_api_key(username, "dropbox") or {}
        app_configured = bool(key_data.get("value_1")) and bool(key_data.get("secret"))
        connected = bool(key_data.get("connected")) and bool(key_data.get("refresh_token"))

        # Self-heal: accounts connected before team-space detection existed
        # never fetched root_namespace_id -- fetch it once, lazily.
        if connected and not key_data.get("root_checked"):
            key_data = cls._refresh_root_info(username, key_data) or key_data

        return {
            "app_configured": app_configured,
            "connected": connected,
            "account_email": key_data.get("account_email") if connected else None,
            "account_name": key_data.get("account_name") if connected else None,
            "shared_folder_path": key_data.get("shared_folder_path") or "/AthenaNet",
            "is_team_space": bool(key_data.get("is_team_space")),
        }

    @classmethod
    def _refresh_root_info(cls, username: str, key_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        try:
            access_token = cls.get_access_token(username)
            resp = requests.post(ACCOUNT_URL, headers={"Authorization": f"Bearer {access_token}"}, timeout=20)
            if resp.status_code != 200:
                return None
            account_data = resp.json()
            root_info = account_data.get("root_info") or {}
            updated = dict(key_data)
            if root_info.get(".tag") == "team":
                updated["root_namespace_id"] = root_info.get("root_namespace_id")
                updated["is_team_space"] = bool(updated["root_namespace_id"])
            else:
                updated["root_namespace_id"] = None
                updated["is_team_space"] = False
            updated["root_checked"] = True
            VaultService.set_app_api_key(username, "dropbox", updated)
            return updated
        except (DropboxServiceError, requests.RequestException):
            return None

    @staticmethod
    def get_root_namespace_id(username: str) -> Optional[str]:
        key_data = VaultService.get_app_api_key(username, "dropbox") or {}
        return key_data.get("root_namespace_id") or None

    @staticmethod
    def set_shared_folder_path(username: str, path: str) -> str:
        normalized = "/" + path.strip("/")
        existing = VaultService.get_app_api_key(username, "dropbox") or {}
        key_data: Dict[str, Any] = dict(existing)
        key_data["shared_folder_path"] = normalized
        VaultService.set_app_api_key(username, "dropbox", key_data)
        return normalized

    @classmethod
    def get_access_token(cls, username: str) -> str:
        """
        Exchanges the saved refresh token for a fresh short-lived access
        token. Used by future Dropbox file operations (storage backend) --
        not cached here since callers so far are infrequent/one-shot; add
        caching if/when a hot path needs it.
        """
        app_key, app_secret = cls._get_app_credentials(username)
        key_data = VaultService.get_app_api_key(username, "dropbox") or {}
        refresh_token = key_data.get("refresh_token")
        if not refresh_token:
            raise DropboxServiceError("Dropbox is not connected yet.")

        resp = requests.post(
            TOKEN_URL,
            data={
                "grant_type": "refresh_token",
                "refresh_token": refresh_token,
                "client_id": app_key,
                "client_secret": app_secret,
            },
            timeout=20,
        )
        if resp.status_code != 200:
            raise DropboxServiceError(f"Failed to refresh Dropbox access token: {resp.text[:500]}")

        access_token = resp.json().get("access_token")
        if not access_token:
            raise DropboxServiceError("Dropbox did not return an access token.")
        return access_token

    @classmethod
    def disconnect(cls, username: str) -> None:
        key_data = VaultService.get_app_api_key(username, "dropbox") or {}

        # Best-effort revoke -- failing to revoke shouldn't block disconnect.
        try:
            access_token = cls.get_access_token(username)
            requests.post(REVOKE_URL, headers={"Authorization": f"Bearer {access_token}"}, timeout=20)
        except Exception:
            pass

        key_data.pop("refresh_token", None)
        key_data.pop("account_email", None)
        key_data.pop("account_name", None)
        key_data["connected"] = False
        VaultService.set_app_api_key(username, "dropbox", key_data)
