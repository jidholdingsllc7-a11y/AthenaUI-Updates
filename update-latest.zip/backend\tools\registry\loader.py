﻿# AthenaUI v3.5 — Tool Loader
# File: backend/tools/registry/loader.py
# Created: 2026-04-12 13:30 CDT
# Updated: 2026-07-27 19:49 CDT

import json
from pathlib import Path
from typing import Any, Dict
from tools.registry.registry import ToolRegistry

# ---------------------------------------------------------
# Base paths
# ---------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent.parent
SCHEMAS_DIR = BASE_DIR / "schemas"
registry = ToolRegistry()

def _load_schema(relative_path: str) -> Dict[str, Any]:
    schema_path = SCHEMAS_DIR / relative_path
    with schema_path.open("r", encoding="utf-8") as f:
        return json.load(f)

# ---------------------------------------------------------
# Import tool implementations
# ---------------------------------------------------------
# FS Tools
from tools.fs import (
    file_read,
    file_write,
    file_edit_lines,
    file_delete,
    file_delete_proposal,
    file_diff,
    file_search,
    grep_search,        # new
    file_list_dir,      # new
    file_list_dir_recursive,
    workspace_overview,
    file_mkdir,         # new
    file_copy,          # new
    file_move,          # new
    file_metadata,      # new
    select_language,    # new
    file_read_multiple,        # new
    list_allowed_directories,  # new
)

# HTTP
from tools.system.http import http_request, webhook_trigger

# TERMINAL
from tools.system.terminal import terminal_run, terminal_check, terminal_list, terminal_kill

# BUILD / LINT / TEST (project-completeness checks)
from tools.system.build_check import project_build_check, project_lint_test

# PROCESS / PORT INTROSPECTION
from tools.system.process import process_list, port_check, process_kill

# GIT
from tools.system.git import git_diff, git_log, git_blame

# SEARCH
from tools.system.search import web_search

# SUB-AGENT (bounded, stateless read-only helper agent delegation)
from tools.system.subagent import run_subagent, run_subagent_capabilities

# BUILD MAP
from tools.system.build_map import create as build_map_create
from tools.system.build_map import update as build_map_update
from tools.system.build_map import get as build_map_get
from tools.system.build_map import execute as build_map_execute
from tools.system.build_map import verify as build_map_verify

# IMAGES
from tools.system.images import (
    image_generate,
    image_generate_avatar,
    image_generate_character,
    image_generate_campaign,
    image_check_capability,
    image_save_to_workspace,
    image_generate_selfie,
    image_generate_pair,
    image_generate_group,
    image_gallery_list,
    image_analyze,
    avatar_set_glow,
)

# UI / BRIDGE
from tools.system.ui import (
    ui_inspect,
    ui_dom_tree,
    ui_navigate,
    ui_screenshot_full,
    ui_screenshot_element,
    ui_screenshot_annotated,
    ui_ocr_search,
    ui_image_match,
    ui_highlight,
    ui_locate_element,
    mouse_move,
    mouse_click,
    right_click,
    double_click,
    hover,
    scroll,
    drag,
    drag_offset,
    keyboard_type,
    hotkey,
    monitors,
    move_to_monitor,
    screen_info,
    record_start,
    record_stop,
    record_log,
)

# NOTE (2026-07-31): The gmail_optimize_*/photos_optimize_*/calendar_sync tools
# were removed -- they were non-functional stubs (no OAuth credentials
# configured, no real Gmail/Photos/Calendar API calls implemented anywhere;
# calendar_sync's underlying CalendarGoogleSync.push_event_to_google() was a
# bare `pass` that faked success). They confused agents into believing real
# actions had been taken. Removed rather than fixed since making them real
# requires the user to register an OAuth app in Google Cloud Console first.

# MEMORY (Maximos Memory Server)
from tools.memory import memory_search, memory_recall_summary, memory_recall_details

# POST-IT BOARD (Maximos Memory Server, system-wide)
from tools.board import board_list, board_post, board_edit, board_delete

# COLLAB (agent-initiated cross-character discussions, rate-limited "slow mode")
from tools.collab import collab_start_discussion, collab_rate_limit_grant

# BROKERAGE (Alpaca)
from tools.system.brokerage import (
    alpaca_get_account,
    alpaca_research_stock,
    alpaca_get_positions,
    alpaca_list_orders,
    alpaca_place_order,
)

# MARKET DATA (Massive -- hour/minute ticker bars)
from tools.system.brokerage import massive_get_bars

# SCHEDULER (self-scheduled agent tasks, user-approved)
from tools.system.scheduler import (
    schedule_job,
    schedule_list,
    schedule_cancel,
    schedule_log_create,
    set_recurring_pace,
)

# ATLAS PRIVATE REFERENCE (gated to Atlas Lumos inside the tool itself)
from tools.system.atlas import atlas_system_specs_lookup

# BUILD AN EXPERT (per-caller private reference library, gated inside the tool itself)
from tools.system.characters import expert_library_lookup

# RELATIONSHIPS (organic in-character propose/accept, no user/timer trigger)
from tools.relationships import propose_upgrade, respond_to_proposal

# SHARED AGENT SQL DATABASES (per-agent named SQLite dbs, shareable)
from tools.database import db_create, db_list, db_query, db_share, db_unshare

# ATHENA NET (shared team Dropbox folder)
from tools.athena_net import upload_file as athena_net_upload_file, list_files as athena_net_list_files

# EMAIL (system email accounts configured in Settings, shareable per agent)
from tools.email import email_send, email_list_accounts, email_list_inbox, email_read_message, email_delete_message, email_delete_messages, email_cleanup_rule_add, email_cleanup_rule_search

# CRM (shared marketing customer/lead pipeline)
from tools.crm import crm_add_customer, crm_list_customers, crm_log_activity, crm_update_stage, crm_update_contact_info

# TROUBLESHOOTING TIPS (shared, appendable library of program-debugging tricks)
from tools.troubleshooting import troubleshooting_tip_search, troubleshooting_tip_add

# MARKETING TIPS (shared, appendable library of marketing tricks)
from tools.marketing import marketing_tip_search, marketing_tip_add

# NEWSLETTER (opt-in subscriber list + campaign sending)
from tools.newsletter import newsletter_subscribe_customer, newsletter_list_subscribers, newsletter_send_campaign, newsletter_save_draft
from tools.artifacts import render_artifact, coin_toss

# TWILIO (SMS + voice calling)
from tools.twilio import sms_check_capability, sms_send, call_place

# COMPETITOR TRACKING (scrape + snapshot competitor websites)
from tools.competitors import competitor_add, competitor_scrape, competitor_list

# CALENDAR (shared marketing/event calendar)
from tools.athena_calendar import calendar_add_event, calendar_list_events

# SPREADSHEETS (user-defined named spreadsheets, templates, agent-editable rows)
from tools.spreadsheets import (
    spreadsheet_list,
    spreadsheet_create,
    spreadsheet_save_as_template,
    spreadsheet_create_from_template,
    spreadsheet_add_row,
    spreadsheet_update_row,
    spreadsheet_export,
)

# SOCIAL MEDIA (X/Twitter, Facebook, Moltbook)
from tools.system.social_media import (
    social_media_check_capability,
    social_media_post_x,
    social_media_draft_manual_post,
    social_media_post_facebook,
    social_media_post_moltbook,
    social_media_register_moltbook_agent,
    social_media_moltbook_check_feed,
    social_media_moltbook_explore,
    social_media_moltbook_comment,
    social_media_x_check_mentions,
    social_media_x_reply,
    social_media_x_like,
    social_media_x_retweet,
    social_media_x_get_tweet,
    social_media_x_check_dms,
    social_media_x_send_dm,
)

# ---------------------------------------------------------
# Registration
# ---------------------------------------------------------
def load_tools() -> ToolRegistry:
    # ---------------- FS Tools ----------------
    registry.register(
        "file_read",
        schema=_load_schema("fs/file_read.json"),
        implementation=file_read.run,
        capabilities=file_read.capabilities,
    )
    registry.register(
        "file_write",
        schema=_load_schema("fs/file_write.json"),
        implementation=file_write.run,
        capabilities=file_write.capabilities,
    )
    registry.register(
        "file_edit_lines",
        schema=_load_schema("fs/file_edit_lines.json"),
        implementation=file_edit_lines.run,
        capabilities=file_edit_lines.capabilities,
    )
    registry.register(
        "file_delete",
        schema=_load_schema("fs/file_delete.json"),
        implementation=file_delete.run,
        capabilities=file_delete.capabilities,
    )
    registry.register(
        "file_delete_proposal",
        schema=_load_schema("fs/file_delete_proposal.json"),
        implementation=file_delete_proposal.run,
        capabilities=file_delete_proposal.capabilities,
    )
    registry.register(
        "file_diff",
        schema=_load_schema("fs/file_diff.json"),
        implementation=file_diff.run,
        capabilities=file_diff.capabilities,
    )
    registry.register(
        "file_search",
        schema=_load_schema("fs/file_search.json"),
        implementation=file_search.run,
        capabilities=file_search.capabilities,
    )
    registry.register(
        "grep_search",
        schema=_load_schema("fs/grep_search.json"),
        implementation=grep_search.run,
        capabilities=grep_search.capabilities,
    )
    # NEW FS Tools
    registry.register(
        "file_list_dir",
        schema=_load_schema("fs/file_list_dir.json"),
        implementation=file_list_dir.run,
        capabilities=file_list_dir.capabilities,
    )
    registry.register(
        "file_list_dir_recursive",
        schema=_load_schema("fs/file_list_dir_recursive.json"),
        implementation=file_list_dir_recursive.run,
        capabilities=file_list_dir_recursive.capabilities,
    )
    registry.register(
        "workspace_overview",
        schema=_load_schema("fs/workspace_overview.json"),
        implementation=workspace_overview.run,
        capabilities=workspace_overview.capabilities,
    )
    registry.register(
        "file_mkdir",
        schema=_load_schema("fs/file_mkdir.json"),
        implementation=file_mkdir.run,
        capabilities=file_mkdir.capabilities,
    )
    registry.register(
        "file_copy",
        schema=_load_schema("fs/file_copy.json"),
        implementation=file_copy.run,
        capabilities=file_copy.capabilities,
    )
    registry.register(
        "file_move",
        schema=_load_schema("fs/file_move.json"),
        implementation=file_move.run,
        capabilities=file_move.capabilities,
    )
    registry.register(
        "file_metadata",
        schema=_load_schema("fs/file_metadata.json"),
        implementation=file_metadata.run,
        capabilities=file_metadata.capabilities,
    )
    registry.register(
        "select_language",
        schema=_load_schema("fs/select_language.json"),
        implementation=select_language.run,
        capabilities=select_language.capabilities,
    )
    registry.register(
        "file_read_multiple",
        schema=_load_schema("fs/file_read_multiple.json"),
        implementation=file_read_multiple.run,
        capabilities=file_read_multiple.capabilities,
    )
    registry.register(
        "list_allowed_directories",
        schema=_load_schema("fs/list_allowed_directories.json"),
        implementation=list_allowed_directories.run,
        capabilities=list_allowed_directories.capabilities,
    )

    # ---------------- HTTP ----------------
    registry.register(
        "http_request",
        schema=_load_schema("http/http_request.json"),
        implementation=http_request.run,
        capabilities=http_request.capabilities,
    )
    registry.register(
        "webhook_trigger",
        schema=_load_schema("http/webhook_trigger.json"),
        implementation=webhook_trigger.run,
        capabilities=webhook_trigger.capabilities,
    )

    # ---------------- TERMINAL ----------------
    registry.register(
        "terminal_run",
        schema=_load_schema("terminal/terminal_run.json"),
        implementation=terminal_run.run,
        capabilities=terminal_run.capabilities,
    )
    registry.register(
        "terminal_check",
        schema=_load_schema("terminal/terminal_check.json"),
        implementation=terminal_check.run,
        capabilities=terminal_check.capabilities,
    )
    registry.register(
        "terminal_list",
        schema=_load_schema("terminal/terminal_list.json"),
        implementation=terminal_list.run,
        capabilities=terminal_list.capabilities,
    )
    registry.register(
        "terminal_kill",
        schema=_load_schema("terminal/terminal_kill.json"),
        implementation=terminal_kill.run,
        capabilities=terminal_kill.capabilities,
    )

    # ---------------- BUILD / LINT / TEST ----------------
    registry.register(
        "project_build_check",
        schema=_load_schema("build_check/project_build_check.json"),
        implementation=project_build_check.run,
        capabilities=project_build_check.capabilities,
    )
    registry.register(
        "project_lint_test",
        schema=_load_schema("build_check/project_lint_test.json"),
        implementation=project_lint_test.run,
        capabilities=project_lint_test.capabilities,
    )

    # ---------------- PROCESS / PORT ----------------
    registry.register(
        "process_list",
        schema=_load_schema("process/process_list.json"),
        implementation=process_list.run,
        capabilities=process_list.capabilities,
    )
    registry.register(
        "port_check",
        schema=_load_schema("process/port_check.json"),
        implementation=port_check.run,
        capabilities=port_check.capabilities,
    )
    registry.register(
        "process_kill",
        schema=_load_schema("process/process_kill.json"),
        implementation=process_kill.run,
        capabilities=process_kill.capabilities,
    )

    # ---------------- GIT ----------------
    registry.register(
        "git_diff",
        schema=_load_schema("git/git_diff.json"),
        implementation=git_diff.run,
        capabilities=git_diff.capabilities,
    )
    registry.register(
        "git_log",
        schema=_load_schema("git/git_log.json"),
        implementation=git_log.run,
        capabilities=git_log.capabilities,
    )
    registry.register(
        "git_blame",
        schema=_load_schema("git/git_blame.json"),
        implementation=git_blame.run,
        capabilities=git_blame.capabilities,
    )

    # ---------------- SEARCH ----------------
    registry.register(
        "web_search",
        schema=_load_schema("search/web_search.json"),
        implementation=web_search.run,
        capabilities=web_search.capabilities,
    )

    # ---------------- BUILD MAP ----------------
    registry.register(
        "build_map.create",
        schema=_load_schema("build_map/create.json"),
        implementation=build_map_create.run,
        capabilities=build_map_create.capabilities,
    )
    registry.register(
        "build_map.update",
        schema=_load_schema("build_map/update.json"),
        implementation=build_map_update.run,
        capabilities=build_map_update.capabilities,
    )
    registry.register(
        "build_map.get",
        schema=_load_schema("build_map/get.json"),
        implementation=build_map_get.run,
        capabilities=build_map_get.capabilities,
    )
    registry.register(
        "build_map.execute",
        schema=_load_schema("build_map/execute.json"),
        implementation=build_map_execute.run,
        capabilities=build_map_execute.capabilities,
    )
    registry.register(
        "build_map.verify",
        schema=_load_schema("build_map/verify.json"),
        implementation=build_map_verify.run,
        capabilities=build_map_verify.capabilities,
    )

    # ---------------- IMAGES ----------------
    registry.register(
        "image_generate",
        schema=_load_schema("images/image_generate.json"),
        implementation=image_generate.run,
        capabilities=image_generate.capabilities,
    )
    registry.register(
        "image_generate_avatar",
        schema=_load_schema("images/image_generate_avatar.json"),
        implementation=image_generate_avatar.run,
        capabilities=image_generate_avatar.capabilities,
    )
    registry.register(
        "image_generate_character",
        schema=_load_schema("images/image_generate_character.json"),
        implementation=image_generate_character.run,
        capabilities=image_generate_character.capabilities,
    )
    registry.register(
        "image_generate_campaign",
        schema=_load_schema("images/image_generate_campaign.json"),
        implementation=image_generate_campaign.run,
        capabilities=image_generate_campaign.capabilities,
    )
    registry.register(
        "image_check_capability",
        schema=_load_schema("images/image_check_capability.json"),
        implementation=image_check_capability.run,
        capabilities=image_check_capability.capabilities,
    )
    registry.register(
        "image_save_to_workspace",
        schema=_load_schema("images/image_save_to_workspace.json"),
        implementation=image_save_to_workspace.run,
        capabilities=image_save_to_workspace.capabilities,
    )
    registry.register(
        "image_generate_selfie",
        schema=_load_schema("images/image_generate_selfie.json"),
        implementation=image_generate_selfie.run,
        capabilities=image_generate_selfie.capabilities,
    )
    registry.register(
        "avatar_set_glow",
        schema=_load_schema("images/avatar_set_glow.json"),
        implementation=avatar_set_glow.run,
        capabilities=avatar_set_glow.capabilities,
    )
    registry.register(
        "image_generate_pair",
        schema=_load_schema("images/image_generate_pair.json"),
        implementation=image_generate_pair.run,
        capabilities=image_generate_pair.capabilities,
    )
    registry.register(
        "image_generate_group",
        schema=_load_schema("images/image_generate_group.json"),
        implementation=image_generate_group.run,
        capabilities=image_generate_group.capabilities,
    )
    registry.register(
        "image_gallery_list",
        schema=_load_schema("images/image_gallery_list.json"),
        implementation=image_gallery_list.run,
        capabilities=image_gallery_list.capabilities,
    )
    registry.register(
        "image_analyze",
        schema=_load_schema("images/image_analyze.json"),
        implementation=image_analyze.run,
        capabilities=image_analyze.capabilities,
    )

    # ---------------- UI / BRIDGE ----------------
    registry.register(
        "ui_inspect",
        schema=_load_schema("ui/ui_inspect.json"),
        implementation=ui_inspect.run,
        capabilities=ui_inspect.capabilities,
    )
    registry.register(
        "ui_dom_tree",
        schema=_load_schema("ui/ui_dom_tree.json"),
        implementation=ui_dom_tree.run,
        capabilities=ui_dom_tree.capabilities,
    )
    registry.register(
        "ui_navigate",
        schema=_load_schema("ui/ui_navigate.json"),
        implementation=ui_navigate.run,
        capabilities=ui_navigate.capabilities,
    )
    registry.register(
        "ui_screenshot_full",
        schema=_load_schema("ui/ui_screenshot_full.json"),
        implementation=ui_screenshot_full.run,
        capabilities=ui_screenshot_full.capabilities,
    )
    registry.register(
        "ui_screenshot_element",
        schema=_load_schema("ui/ui_screenshot_element.json"),
        implementation=ui_screenshot_element.run,
        capabilities=ui_screenshot_element.capabilities,
    )
    registry.register(
        "ui_screenshot_annotated",
        schema=_load_schema("ui/ui_screenshot_annotated.json"),
        implementation=ui_screenshot_annotated.run,
        capabilities=ui_screenshot_annotated.capabilities,
    )
    registry.register(
        "ui_ocr_search",
        schema=_load_schema("ui/ui_ocr_search.json"),
        implementation=ui_ocr_search.run,
        capabilities=ui_ocr_search.capabilities,
    )
    registry.register(
        "ui_image_match",
        schema=_load_schema("ui/ui_image_match.json"),
        implementation=ui_image_match.run,
        capabilities=ui_image_match.capabilities,
    )
    registry.register(
        "ui_highlight",
        schema=_load_schema("ui/ui_highlight.json"),
        implementation=ui_highlight.run,
        capabilities=ui_highlight.capabilities,
    )
    registry.register(
        "ui_locate_element",
        schema=_load_schema("ui/ui_locate_element.json"),
        implementation=ui_locate_element.run,
        capabilities=ui_locate_element.capabilities,
    )
    registry.register(
        "screen_info",
        schema=_load_schema("ui/screen_info.json"),
        implementation=screen_info.run,
        capabilities=screen_info.capabilities,
    )
    registry.register(
        "mouse_move",
        schema=_load_schema("ui/mouse_move.json"),
        implementation=mouse_move.run,
        capabilities=mouse_move.capabilities,
    )
    registry.register(
        "mouse_click",
        schema=_load_schema("ui/mouse_click.json"),
        implementation=mouse_click.run,
        capabilities=mouse_click.capabilities,
    )
    registry.register(
        "right_click",
        schema=_load_schema("ui/right_click.json"),
        implementation=right_click.run,
        capabilities=right_click.capabilities,
    )
    registry.register(
        "double_click",
        schema=_load_schema("ui/double_click.json"),
        implementation=double_click.run,
        capabilities=double_click.capabilities,
    )
    registry.register(
        "hover",
        schema=_load_schema("ui/hover.json"),
        implementation=hover.run,
        capabilities=hover.capabilities,
    )
    registry.register(
        "scroll",
        schema=_load_schema("ui/scroll.json"),
        implementation=scroll.run,
        capabilities=scroll.capabilities,
    )
    registry.register(
        "drag",
        schema=_load_schema("ui/drag.json"),
        implementation=drag.run,
        capabilities=drag.capabilities,
    )
    registry.register(
        "drag_offset",
        schema=_load_schema("ui/drag_offset.json"),
        implementation=drag_offset.run,
        capabilities=drag_offset.capabilities,
    )
    registry.register(
        "keyboard_type",
        schema=_load_schema("ui/keyboard_type.json"),
        implementation=keyboard_type.run,
        capabilities=keyboard_type.capabilities,
    )
    registry.register(
        "hotkey",
        schema=_load_schema("ui/hotkey.json"),
        implementation=hotkey.run,
        capabilities=hotkey.capabilities,
    )
    registry.register(
        "monitors",
        schema=_load_schema("ui/monitors.json"),
        implementation=monitors.run,
        capabilities=monitors.capabilities,
    )
    registry.register(
        "move_to_monitor",
        schema=_load_schema("ui/move_to_monitor.json"),
        implementation=move_to_monitor.run,
        capabilities=move_to_monitor.capabilities,
    )
    registry.register(
        "record_start",
        schema=_load_schema("ui/record_start.json"),
        implementation=record_start.run,
        capabilities=record_start.capabilities,
    )
    registry.register(
        "record_stop",
        schema=_load_schema("ui/record_stop.json"),
        implementation=record_stop.run,
        capabilities=record_stop.capabilities,
    )
    registry.register(
        "record_log",
        schema=_load_schema("ui/record_log.json"),
        implementation=record_log.run,
        capabilities=record_log.capabilities,
    )

    # ---------------- MEMORY (Maximos Memory Server) ----------------
    registry.register(
        "memory_search",
        schema=_load_schema("memory/memory_search.json"),
        implementation=memory_search.run,
        capabilities=memory_search.capabilities,
    )
    registry.register(
        "memory_recall_summary",
        schema=_load_schema("memory/memory_recall_summary.json"),
        implementation=memory_recall_summary.run,
        capabilities=memory_recall_summary.capabilities,
    )
    registry.register(
        "memory_recall_details",
        schema=_load_schema("memory/memory_recall_details.json"),
        implementation=memory_recall_details.run,
        capabilities=memory_recall_details.capabilities,
    )

    # ---------------- POST-IT BOARD (Maximos Memory Server) ----------------
    registry.register(
        "board_list",
        schema=_load_schema("board/board_list.json"),
        implementation=board_list.run,
        capabilities=board_list.capabilities,
    )
    registry.register(
        "board_post",
        schema=_load_schema("board/board_post.json"),
        implementation=board_post.run,
        capabilities=board_post.capabilities,
    )
    registry.register(
        "board_edit",
        schema=_load_schema("board/board_edit.json"),
        implementation=board_edit.run,
        capabilities=board_edit.capabilities,
    )

    # ---------------- COLLAB (agent-initiated cross-character discussions) ----------------
    registry.register(
        "collab_start_discussion",
        schema=_load_schema("collab/collab_start_discussion.json"),
        implementation=collab_start_discussion.run,
        capabilities=collab_start_discussion.capabilities,
    )
    registry.register(
        "collab_rate_limit_grant",
        schema=_load_schema("collab/collab_rate_limit_grant.json"),
        implementation=collab_rate_limit_grant.run,
        capabilities=collab_rate_limit_grant.capabilities,
    )
    registry.register(
        "board_delete",
        schema=_load_schema("board/board_delete.json"),
        implementation=board_delete.run,
        capabilities=board_delete.capabilities,
    )

    # ---------------- BROKERAGE (Alpaca) ----------------
    registry.register(
        "alpaca_get_account",
        schema=_load_schema("brokerage/alpaca_get_account.json"),
        implementation=alpaca_get_account.run,
        capabilities=alpaca_get_account.capabilities,
    )
    registry.register(
        "alpaca_research_stock",
        schema=_load_schema("brokerage/alpaca_research_stock.json"),
        implementation=alpaca_research_stock.run,
        capabilities=alpaca_research_stock.capabilities,
    )
    registry.register(
        "alpaca_get_positions",
        schema=_load_schema("brokerage/alpaca_get_positions.json"),
        implementation=alpaca_get_positions.run,
        capabilities=alpaca_get_positions.capabilities,
    )
    registry.register(
        "alpaca_list_orders",
        schema=_load_schema("brokerage/alpaca_list_orders.json"),
        implementation=alpaca_list_orders.run,
        capabilities=alpaca_list_orders.capabilities,
    )
    registry.register(
        "alpaca_place_order",
        schema=_load_schema("brokerage/alpaca_place_order.json"),
        implementation=alpaca_place_order.run,
        capabilities=alpaca_place_order.capabilities,
    )

    # ---------------- MARKET DATA (Massive) ----------------
    registry.register(
        "massive_get_bars",
        schema=_load_schema("brokerage/massive_get_bars.json"),
        implementation=massive_get_bars.run,
        capabilities=massive_get_bars.capabilities,
    )

    # ---------------- SCHEDULER ----------------
    registry.register(
        "schedule_job",
        schema=_load_schema("scheduler/schedule_job.json"),
        implementation=schedule_job.run,
        capabilities=schedule_job.capabilities,
    )
    registry.register(
        "schedule_list",
        schema=_load_schema("scheduler/schedule_list.json"),
        implementation=schedule_list.run,
        capabilities=schedule_list.capabilities,
    )
    registry.register(
        "schedule_cancel",
        schema=_load_schema("scheduler/schedule_cancel.json"),
        implementation=schedule_cancel.run,
        capabilities=schedule_cancel.capabilities,
    )
    registry.register(
        "schedule_log_create",
        schema=_load_schema("scheduler/schedule_log_create.json"),
        implementation=schedule_log_create.run,
        capabilities=schedule_log_create.capabilities,
    )
    registry.register(
        "scheduler_set_recurring_pace",
        schema=_load_schema("scheduler/scheduler_set_recurring_pace.json"),
        implementation=set_recurring_pace.run,
        capabilities=set_recurring_pace.capabilities,
    )

    # ---------------- ATLAS PRIVATE REFERENCE ----------------
    registry.register(
        "atlas_system_specs_lookup",
        schema=_load_schema("atlas/atlas_system_specs_lookup.json"),
        implementation=atlas_system_specs_lookup.run,
        capabilities=atlas_system_specs_lookup.capabilities,
    )

    # ---------------- BUILD AN EXPERT ----------------
    registry.register(
        "expert_library_lookup",
        schema=_load_schema("characters/expert_library_lookup.json"),
        implementation=expert_library_lookup.run,
        capabilities=expert_library_lookup.capabilities,
    )

    # ---------------- RELATIONSHIPS ----------------
    registry.register(
        "relationship_propose_upgrade",
        schema=_load_schema("relationships/propose_upgrade.json"),
        implementation=propose_upgrade.run,
        capabilities=propose_upgrade.capabilities,
    )
    registry.register(
        "relationship_respond_to_proposal",
        schema=_load_schema("relationships/respond_to_proposal.json"),
        implementation=respond_to_proposal.run,
        capabilities=respond_to_proposal.capabilities,
    )

    # ---------------- SHARED AGENT SQL DATABASES ----------------
    registry.register(
        "db_create",
        schema=_load_schema("database/db_create.json"),
        implementation=db_create.run,
        capabilities=db_create.capabilities,
    )
    registry.register(
        "db_list",
        schema=_load_schema("database/db_list.json"),
        implementation=db_list.run,
        capabilities=db_list.capabilities,
    )
    registry.register(
        "db_query",
        schema=_load_schema("database/db_query.json"),
        implementation=db_query.run,
        capabilities=db_query.capabilities,
    )
    registry.register(
        "db_share",
        schema=_load_schema("database/db_share.json"),
        implementation=db_share.run,
        capabilities=db_share.capabilities,
    )
    registry.register(
        "db_unshare",
        schema=_load_schema("database/db_unshare.json"),
        implementation=db_unshare.run,
        capabilities=db_unshare.capabilities,
    )

    # ---------------- ATHENA NET ----------------
    registry.register(
        "athena_net_upload_file",
        schema=_load_schema("athena_net/upload_file.json"),
        implementation=athena_net_upload_file.run,
        capabilities=athena_net_upload_file.capabilities,
    )
    registry.register(
        "athena_net_list_files",
        schema=_load_schema("athena_net/list_files.json"),
        implementation=athena_net_list_files.run,
        capabilities=athena_net_list_files.capabilities,
    )

    # ---------------- EMAIL ----------------
    registry.register(
        "email_send",
        schema=_load_schema("email/email_send.json"),
        implementation=email_send.run,
        capabilities=email_send.capabilities,
    )
    registry.register(
        "email_list_accounts",
        schema=_load_schema("email/email_list_accounts.json"),
        implementation=email_list_accounts.run,
        capabilities=email_list_accounts.capabilities,
    )
    registry.register(
        "email_list_inbox",
        schema=_load_schema("email/email_list_inbox.json"),
        implementation=email_list_inbox.run,
        capabilities=email_list_inbox.capabilities,
    )
    registry.register(
        "email_read_message",
        schema=_load_schema("email/email_read_message.json"),
        implementation=email_read_message.run,
        capabilities=email_read_message.capabilities,
    )
    registry.register(
        "email_delete_message",
        schema=_load_schema("email/email_delete_message.json"),
        implementation=email_delete_message.run,
        capabilities=email_delete_message.capabilities,
    )
    registry.register(
        "email_delete_messages",
        schema=_load_schema("email/email_delete_messages.json"),
        implementation=email_delete_messages.run,
        capabilities=email_delete_messages.capabilities,
    )
    registry.register(
        "email_cleanup_rule_add",
        schema=_load_schema("email/email_cleanup_rule_add.json"),
        implementation=email_cleanup_rule_add.run,
        capabilities=email_cleanup_rule_add.capabilities,
    )
    registry.register(
        "email_cleanup_rule_search",
        schema=_load_schema("email/email_cleanup_rule_search.json"),
        implementation=email_cleanup_rule_search.run,
        capabilities=email_cleanup_rule_search.capabilities,
    )

    # ---------------- CRM ----------------
    registry.register(
        "crm_add_customer",
        schema=_load_schema("crm/crm_add_customer.json"),
        implementation=crm_add_customer.run,
        capabilities=crm_add_customer.capabilities,
    )
    registry.register(
        "crm_list_customers",
        schema=_load_schema("crm/crm_list_customers.json"),
        implementation=crm_list_customers.run,
        capabilities=crm_list_customers.capabilities,
    )
    registry.register(
        "crm_log_activity",
        schema=_load_schema("crm/crm_log_activity.json"),
        implementation=crm_log_activity.run,
        capabilities=crm_log_activity.capabilities,
    )
    registry.register(
        "crm_update_stage",
        schema=_load_schema("crm/crm_update_stage.json"),
        implementation=crm_update_stage.run,
        capabilities=crm_update_stage.capabilities,
    )
    registry.register(
        "crm_update_contact_info",
        schema=_load_schema("crm/crm_update_contact_info.json"),
        implementation=crm_update_contact_info.run,
        capabilities=crm_update_contact_info.capabilities,
    )

    # ---------------- TROUBLESHOOTING TIPS ----------------
    registry.register(
        "troubleshooting_tip_search",
        schema=_load_schema("troubleshooting/troubleshooting_tip_search.json"),
        implementation=troubleshooting_tip_search.run,
        capabilities=troubleshooting_tip_search.capabilities,
    )
    registry.register(
        "troubleshooting_tip_add",
        schema=_load_schema("troubleshooting/troubleshooting_tip_add.json"),
        implementation=troubleshooting_tip_add.run,
        capabilities=troubleshooting_tip_add.capabilities,
    )

    # ---------------- MARKETING TIPS ----------------
    registry.register(
        "marketing_tip_search",
        schema=_load_schema("marketing/marketing_tip_search.json"),
        implementation=marketing_tip_search.run,
        capabilities=marketing_tip_search.capabilities,
    )
    registry.register(
        "marketing_tip_add",
        schema=_load_schema("marketing/marketing_tip_add.json"),
        implementation=marketing_tip_add.run,
        capabilities=marketing_tip_add.capabilities,
    )

    # ---------------- NEWSLETTER ----------------
    registry.register(
        "newsletter_subscribe_customer",
        schema=_load_schema("newsletter/newsletter_subscribe_customer.json"),
        implementation=newsletter_subscribe_customer.run,
        capabilities=newsletter_subscribe_customer.capabilities,
    )
    registry.register(
        "newsletter_list_subscribers",
        schema=_load_schema("newsletter/newsletter_list_subscribers.json"),
        implementation=newsletter_list_subscribers.run,
        capabilities=newsletter_list_subscribers.capabilities,
    )
    registry.register(
        "newsletter_send_campaign",
        schema=_load_schema("newsletter/newsletter_send_campaign.json"),
        implementation=newsletter_send_campaign.run,
        capabilities=newsletter_send_campaign.capabilities,
    )
    registry.register(
        "newsletter_save_draft",
        schema=_load_schema("newsletter/newsletter_save_draft.json"),
        implementation=newsletter_save_draft.run,
        capabilities=newsletter_save_draft.capabilities,
    )

    # ---------------- ARTIFACTS ----------------
    registry.register(
        "render_artifact",
        schema=_load_schema("artifacts/render_artifact.json"),
        implementation=render_artifact.run,
        capabilities=render_artifact.capabilities,
    )
    registry.register(
        "coin_toss",
        schema=_load_schema("artifacts/coin_toss.json"),
        implementation=coin_toss.run,
        capabilities=coin_toss.capabilities,
    )

    # ---------------- TWILIO ----------------
    registry.register(
        "sms_check_capability",
        schema=_load_schema("twilio/sms_check_capability.json"),
        implementation=sms_check_capability.run,
        capabilities=sms_check_capability.capabilities,
    )
    registry.register(
        "sms_send",
        schema=_load_schema("twilio/sms_send.json"),
        implementation=sms_send.run,
        capabilities=sms_send.capabilities,
    )
    registry.register(
        "call_place",
        schema=_load_schema("twilio/call_place.json"),
        implementation=call_place.run,
        capabilities=call_place.capabilities,
    )

    # ---------------- COMPETITOR TRACKING ----------------
    registry.register(
        "competitor_add",
        schema=_load_schema("competitors/competitor_add.json"),
        implementation=competitor_add.run,
        capabilities=competitor_add.capabilities,
    )
    registry.register(
        "competitor_scrape",
        schema=_load_schema("competitors/competitor_scrape.json"),
        implementation=competitor_scrape.run,
        capabilities=competitor_scrape.capabilities,
    )
    registry.register(
        "competitor_list",
        schema=_load_schema("competitors/competitor_list.json"),
        implementation=competitor_list.run,
        capabilities=competitor_list.capabilities,
    )

    # ---------------- CALENDAR ----------------
    registry.register(
        "calendar_add_event",
        schema=_load_schema("athena_calendar/calendar_add_event.json"),
        implementation=calendar_add_event.run,
        capabilities=calendar_add_event.capabilities,
    )
    registry.register(
        "calendar_list_events",
        schema=_load_schema("athena_calendar/calendar_list_events.json"),
        implementation=calendar_list_events.run,
        capabilities=calendar_list_events.capabilities,
    )

    # ---------------- SOCIAL MEDIA ----------------
    registry.register(
        "social_media_check_capability",
        schema=_load_schema("social_media/social_media_check_capability.json"),
        implementation=social_media_check_capability.run,
        capabilities=social_media_check_capability.capabilities,
    )
    registry.register(
        "social_media_post_x",
        schema=_load_schema("social_media/social_media_post_x.json"),
        implementation=social_media_post_x.run,
        capabilities=social_media_post_x.capabilities,
    )
    registry.register(
        "social_media_draft_manual_post",
        schema=_load_schema("social_media/social_media_draft_manual_post.json"),
        implementation=social_media_draft_manual_post.run,
        capabilities=social_media_draft_manual_post.capabilities,
    )
    registry.register(
        "social_media_post_facebook",
        schema=_load_schema("social_media/social_media_post_facebook.json"),
        implementation=social_media_post_facebook.run,
        capabilities=social_media_post_facebook.capabilities,
    )
    registry.register(
        "social_media_post_moltbook",
        schema=_load_schema("social_media/social_media_post_moltbook.json"),
        implementation=social_media_post_moltbook.run,
        capabilities=social_media_post_moltbook.capabilities,
    )
    registry.register(
        "social_media_register_moltbook_agent",
        schema=_load_schema("social_media/social_media_register_moltbook_agent.json"),
        implementation=social_media_register_moltbook_agent.run,
        capabilities=social_media_register_moltbook_agent.capabilities,
    )
    registry.register(
        "social_media_moltbook_check_feed",
        schema=_load_schema("social_media/social_media_moltbook_check_feed.json"),
        implementation=social_media_moltbook_check_feed.run,
        capabilities=social_media_moltbook_check_feed.capabilities,
    )
    registry.register(
        "social_media_moltbook_explore",
        schema=_load_schema("social_media/social_media_moltbook_explore.json"),
        implementation=social_media_moltbook_explore.run,
        capabilities=social_media_moltbook_explore.capabilities,
    )
    registry.register(
        "social_media_moltbook_comment",
        schema=_load_schema("social_media/social_media_moltbook_comment.json"),
        implementation=social_media_moltbook_comment.run,
        capabilities=social_media_moltbook_comment.capabilities,
    )
    registry.register(
        "social_media_x_check_mentions",
        schema=_load_schema("social_media/social_media_x_check_mentions.json"),
        implementation=social_media_x_check_mentions.run,
        capabilities=social_media_x_check_mentions.capabilities,
    )
    registry.register(
        "social_media_x_reply",
        schema=_load_schema("social_media/social_media_x_reply.json"),
        implementation=social_media_x_reply.run,
        capabilities=social_media_x_reply.capabilities,
    )
    registry.register(
        "social_media_x_like",
        schema=_load_schema("social_media/social_media_x_like.json"),
        implementation=social_media_x_like.run,
        capabilities=social_media_x_like.capabilities,
    )
    registry.register(
        "social_media_x_retweet",
        schema=_load_schema("social_media/social_media_x_retweet.json"),
        implementation=social_media_x_retweet.run,
        capabilities=social_media_x_retweet.capabilities,
    )
    registry.register(
        "social_media_x_get_tweet",
        schema=_load_schema("social_media/social_media_x_get_tweet.json"),
        implementation=social_media_x_get_tweet.run,
        capabilities=social_media_x_get_tweet.capabilities,
    )
    registry.register(
        "social_media_x_check_dms",
        schema=_load_schema("social_media/social_media_x_check_dms.json"),
        implementation=social_media_x_check_dms.run,
        capabilities=social_media_x_check_dms.capabilities,
    )
    registry.register(
        "social_media_x_send_dm",
        schema=_load_schema("social_media/social_media_x_send_dm.json"),
        implementation=social_media_x_send_dm.run,
        capabilities=social_media_x_send_dm.capabilities,
    )

    # ---------------- SPREADSHEETS ----------------
    registry.register(
        "spreadsheet_list",
        schema=_load_schema("spreadsheets/spreadsheet_list.json"),
        implementation=spreadsheet_list.run,
        capabilities=spreadsheet_list.capabilities,
    )
    registry.register(
        "spreadsheet_create",
        schema=_load_schema("spreadsheets/spreadsheet_create.json"),
        implementation=spreadsheet_create.run,
        capabilities=spreadsheet_create.capabilities,
    )
    registry.register(
        "spreadsheet_save_as_template",
        schema=_load_schema("spreadsheets/spreadsheet_save_as_template.json"),
        implementation=spreadsheet_save_as_template.run,
        capabilities=spreadsheet_save_as_template.capabilities,
    )
    registry.register(
        "spreadsheet_create_from_template",
        schema=_load_schema("spreadsheets/spreadsheet_create_from_template.json"),
        implementation=spreadsheet_create_from_template.run,
        capabilities=spreadsheet_create_from_template.capabilities,
    )
    registry.register(
        "spreadsheet_add_row",
        schema=_load_schema("spreadsheets/spreadsheet_add_row.json"),
        implementation=spreadsheet_add_row.run,
        capabilities=spreadsheet_add_row.capabilities,
    )
    registry.register(
        "spreadsheet_update_row",
        schema=_load_schema("spreadsheets/spreadsheet_update_row.json"),
        implementation=spreadsheet_update_row.run,
        capabilities=spreadsheet_update_row.capabilities,
    )
    registry.register(
        "spreadsheet_export",
        schema=_load_schema("spreadsheets/spreadsheet_export.json"),
        implementation=spreadsheet_export.run,
        capabilities=spreadsheet_export.capabilities,
    )

    # ---------------- SUB-AGENT ----------------
    registry.register(
        "run_subagent",
        schema=_load_schema("subagent/run_subagent.json"),
        implementation=run_subagent,
        capabilities=run_subagent_capabilities,
    )

    return registry
