﻿# AthenaUI v3.5 — Character API Router (Merged + Updated)
# File: backend/api/routes/characters.py
# Created: 2026-04-10 22:34 CDT
# Updated: 2026-07-27 19:49 CDT

from fastapi import APIRouter, HTTPException, UploadFile, File, Form, Depends, Response
from fastapi.responses import FileResponse
from pathlib import Path
import shutil
import uuid

# ---------------- Existing Imports ----------------

from characters.system.temp_store import (
    create_temp_character,
    load_temp_character,
    save_temp_character,
    delete_temp_character,
)
from temp_system.service import create_temp_dir

from characters.system.create import (
    generate_full_character_no_input,
    generate_character_from_partial,
    finalize_character_from_full_input,
)

from characters.system.save import save_character
from characters.system.list import list_all_characters, SYNERGY_CHARACTER_NAME
from characters.system.load import load_character
from characters.system.gallery import list_character_gallery
from characters.system.migrate import migrate_old_character

# ---------------- Engines ----------------

from characters.research_engine.fetch import fetch_research_data
from characters.research_engine.summarize import summarize_research_text
from characters.research_engine.builder import build_research_character

from characters.export_engine.full_export import export_full_backup
from characters.export_engine.character_export import export_character_only
from characters.export_engine.history_export import export_guardian_history

from characters.import_engine.loader import load_imported_character

from characters.backstory_engine.generator import generate_backstory
from characters.system.schema import new_character_base
import characters.expert_library.service as expert_library_service
from characters.system.relationships import (
    validate_profile_update,
    apply_mutual_relationship,
    propose_relationship_upgrade,
    respond_to_relationship_proposal,
    next_allowed_statuses,
    is_system_character,
    RelationshipError,
    RELATIONSHIP_LEVELS,
)

# ---------------- External Systems ----------------

from chat.history.service import export_chat_history, restore_chat_history
from vault.service import restore_character_backup
from vault.controller import VaultController
from vault.errors import VaultError
from llm.image_generation.service import ImageGenerationService

from voice.service import list_voices, assign_character_voice, VoiceAssignmentError
from voice.elevenlabs_client import (
    text_to_speech,
    get_voice_settings,
    set_voice_settings,
    VoiceProviderError,
)

from auth.service import get_current_user
from core.runtime.runtime import get_runtime

_image_service = ImageGenerationService()

router = APIRouter(prefix="/api/characters", tags=["characters"])


def _avatar_candidates(username: str, name: str, char: dict) -> list[Path]:
    runtime = get_runtime()
    user_root = runtime.env.DATA_DIR / "users" / username / "characters" / name / "gallery"

    candidates: list[Path] = []

    # 1) Explicit avatar path from character payload
    avatar = char.get("avatar") if isinstance(char, dict) else None
    if isinstance(avatar, dict):
        avatar_path = avatar.get("path")
        if isinstance(avatar_path, str) and avatar_path.strip():
            raw = avatar_path.strip()
            p = Path(raw)
            if not p.is_absolute():
                p = (runtime.env.ROOT_DIR / raw).resolve()
            candidates.append(p)

    # 2) First image in user modern gallery
    modern_dir = user_root / "modern"
    if modern_dir.exists() and modern_dir.is_dir():
        for image_path in sorted(modern_dir.iterdir(), key=lambda x: x.name.lower()):
            if image_path.is_file() and image_path.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp", ".gif"}:
                candidates.append(image_path)
                break

    # 3) First image in seeded system-agent modern gallery
    system_modern = runtime.env.BACKEND_DIR / "characters" / "system" / "system_agents" / name / "gallery" / "modern"
    if system_modern.exists() and system_modern.is_dir():
        for image_path in sorted(system_modern.iterdir(), key=lambda x: x.name.lower()):
            if image_path.is_file() and image_path.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp", ".gif"}:
                candidates.append(image_path)
                break

    return candidates


def _to_data_url(path_str: str | None) -> str | None:
    """
    Converts an absolute or CWD-relative filesystem path under
    Env.DATA_DIR into a URL servable by the /data static mount
    (see backend/main.py::create_app).
    """
    if not path_str:
        return None
    runtime = get_runtime()
    p = Path(path_str)
    if not p.is_absolute():
        p = (runtime.env.ROOT_DIR / path_str).resolve()
    try:
        rel = p.resolve().relative_to(runtime.env.DATA_DIR.resolve())
    except ValueError:
        return None
    return "/data/" + rel.as_posix()


# ============================================================
#  TEMP CHARACTER SYSTEM
# ============================================================

@router.post("/temp/start")
def start_temp_character():
    temp_id = create_temp_character()
    return {"temp_id": temp_id}


@router.get("/temp/{temp_id}")
def get_temp_character(temp_id: str):
    char = load_temp_character(temp_id)
    return {"character": char}


@router.post("/temp/{temp_id}/update")
def update_temp_character(temp_id: str, character: dict):
    save_temp_character(temp_id, character)
    return {"message": "Temp character updated."}


@router.post("/temp/{temp_id}/generate/auto")
def generate_auto_character(temp_id: str, user=Depends(get_current_user)):
    username = user["username"]
    char = generate_full_character_no_input(username)
    save_temp_character(temp_id, char)
    return {"character": char}


@router.post("/temp/{temp_id}/generate/partial")
def generate_from_partial(temp_id: str, character: dict, user=Depends(get_current_user)):
    username = user["username"]
    char = generate_character_from_partial(character, username)
    save_temp_character(temp_id, char)
    return {"character": char}


@router.post("/temp/{temp_id}/finalize")
def finalize_character(temp_id: str, character: dict, user=Depends(get_current_user)):
    username = user["username"]  # FIXED
    char = finalize_character_from_full_input(character)
    save_character(username, char)
    delete_temp_character(temp_id)
    return {"character": char}


@router.post("/temp/{temp_id}/discard")
def discard_temp_character(temp_id: str):
    delete_temp_character(temp_id)
    return {"message": "Temp character discarded."}


@router.get("/temp/{temp_id}/avatar")
def get_temp_character_avatar(temp_id: str):
    """
    Serves whichever avatar image (uploaded or AI-generated) is currently
    attached to an in-progress temp character, for wizard preview.
    """
    char = load_temp_character(temp_id)
    if not char:
        raise HTTPException(status_code=404, detail="Temp character not found.")

    avatar = char.get("avatar") if isinstance(char, dict) else None
    avatar_path = avatar.get("path") if isinstance(avatar, dict) else None
    if not avatar_path:
        raise HTTPException(status_code=404, detail="No avatar set for this temp character.")

    path = Path(avatar_path)
    if not path.is_absolute():
        path = (get_runtime().env.ROOT_DIR / avatar_path).resolve()

    if not path.exists() or not path.is_file():
        raise HTTPException(status_code=404, detail="Avatar file not found.")

    return FileResponse(path)


# ============================================================
#  CHARACTER LIST
# ============================================================

@router.get("/list")
def list_characters(user=Depends(get_current_user)):
    username = user["username"]  # FIXED
    characters = list_all_characters(username)
    # Synergy has a minimal vault record (see characters/system/list.py) only
    # so avatar/voice assignment can reuse this same per-character machinery
    # -- it's never a real persona and must not appear in the normal
    # character grid/dropdowns that are driven by this list.
    characters = {k: v for k, v in characters.items() if k != SYNERGY_CHARACTER_NAME}
    return {
        "characters": characters,
        "character_names": sorted(list(characters.keys())),
    }


# ============================================================
#  RESEARCH-BASED CHARACTER CREATION
# ============================================================

@router.post("/research")
def research_character(name: str, user=Depends(get_current_user)):
    username = user["username"]
    data = fetch_research_data(name)
    corrected = data.get("corrected_name")
    raw = data.get("raw_text", "")

    if not raw:
        raise HTTPException(status_code=404, detail="No research data found.")

    summary = summarize_research_text(raw)
    char = build_research_character(corrected or name, summary, username)

    temp_id = create_temp_character()
    save_temp_character(temp_id, char)

    return {
        "temp_id": temp_id,
        "character": char,
        "corrected_name": corrected,
        "sources": data.get("sources", []),
    }


# ============================================================
#  IMPORT CHARACTER
# ============================================================

@router.post("/import")
def import_character(file: UploadFile = File(...)):
    temp_dir = create_temp_dir("characters")

    zip_path = temp_dir / file.filename
    with zip_path.open("wb") as f:
        shutil.copyfileobj(file.file, f)

    try:
        char_data = load_imported_character(zip_path, temp_dir / "unpacked")
    except Exception as e:
        shutil.rmtree(temp_dir, ignore_errors=True)
        raise HTTPException(status_code=400, detail=f"Import failed: {e}")

    if "meta" not in char_data or char_data["meta"].get("version") != "3.0":
        char_data = migrate_old_character(char_data)

    temp_id = create_temp_character()
    save_temp_character(temp_id, char_data)

    shutil.rmtree(temp_dir, ignore_errors=True)

    return {"temp_id": temp_id, "character": char_data}


# ============================================================
#  EXPORT
# ============================================================

@router.post("/export/full/{name}")
def export_full(name: str, user=Depends(get_current_user)):
    username = user["username"]  # FIXED
    path = export_full_backup(username, name)
    return {"path": str(path)}


@router.post("/export/character/{name}")
def export_character_only_route(name: str, user=Depends(get_current_user)):
    username = user["username"]  # FIXED
    path = export_character_only(username, name)
    return {"path": str(path)}


@router.post("/export/history/{guardian}")
def export_guardian_history_route(guardian: str, user=Depends(get_current_user)):
    username = user["username"]  # FIXED
    path = export_guardian_history(username, guardian)
    return {"path": str(path)}


# ============================================================
#  GALLERY
# ============================================================

@router.get("/{name}/gallery")
def get_gallery(name: str, user=Depends(get_current_user)):
    username = user["username"]  # FIXED
    gallery = list_character_gallery(username, name)
    return {"gallery": gallery}


@router.post("/{name}/avatar/upload")
def upload_avatar(name: str, file: UploadFile = File(...), user=Depends(get_current_user)):
    username = user["username"]  # FIXED
    existing = load_character(username, name)
    if existing and existing.get("avatar", {}).get("locked"):
        raise HTTPException(status_code=400, detail=f"{name}'s avatar is locked and can't be changed.")

    runtime = get_runtime()
    base = runtime.env.DATA_DIR / "users" / username / "characters" / name / "gallery" / "modern"
    base.mkdir(parents=True, exist_ok=True)

    ext = Path(file.filename).suffix or ".jpg"
    dest = base / f"{name}_avatar_{uuid.uuid4().hex}{ext}"

    with dest.open("wb") as f:
        shutil.copyfileobj(file.file, f)

    char = load_character(username, name)
    if char:
        char.setdefault("avatar", {})
        char["avatar"]["type"] = "uploaded"
        char["avatar"]["path"] = str(dest)
        # `key=name` pins the write to the URL's (canonical vault) key --
        # some system agents' display `name` field differs from it (e.g.
        # "Sol Lumos" vs vault key "Sol_Lumos"), and saving without `key`
        # would silently create a second, disconnected vault row instead of
        # updating the real one.
        save_character(username, char, key=name)

    return {"status": "ok", "path": str(dest)}


@router.post("/{name}/avatar/select")
def select_avatar(name: str, payload: dict, user=Depends(get_current_user)):
    """
    Sets an EXISTING image already in this character's own "modern" gallery
    as their avatar, instead of uploading a new file.
    """
    username = user["username"]
    existing = load_character(username, name)
    if existing and existing.get("avatar", {}).get("locked"):
        raise HTTPException(status_code=400, detail=f"{name}'s avatar is locked and can't be changed.")

    raw_path = payload.get("path") if isinstance(payload, dict) else None
    if not isinstance(raw_path, str) or not raw_path.strip():
        raise HTTPException(status_code=400, detail="Missing 'path'.")

    runtime = get_runtime()
    gallery_root = (
        runtime.env.DATA_DIR / "users" / username / "characters" / name / "gallery" / "modern"
    ).resolve()

    raw = raw_path.strip()
    if raw.startswith("/data/"):
        candidate = (runtime.env.DATA_DIR / raw[len("/data/"):]).resolve()
    else:
        candidate = Path(raw)
        if not candidate.is_absolute():
            candidate = (runtime.env.ROOT_DIR / raw).resolve()

    try:
        within_gallery = candidate == gallery_root or candidate.is_relative_to(gallery_root)
    except AttributeError:
        within_gallery = candidate == gallery_root or gallery_root in candidate.parents

    if not within_gallery or not candidate.exists() or not candidate.is_file():
        raise HTTPException(
            status_code=400,
            detail="Image must be an existing file in this character's own modern gallery.",
        )

    char = load_character(username, name)
    if not char:
        raise HTTPException(status_code=404, detail="Character not found.")

    char.setdefault("avatar", {})
    char["avatar"]["type"] = "selected"
    char["avatar"]["path"] = str(candidate)
    save_character(username, char, key=name)

    return {"status": "ok", "path": str(candidate), "url": _to_data_url(str(candidate))}


@router.post("/{name}/gallery/upload")
def upload_gallery_image(name: str, file: UploadFile = File(...), user=Depends(get_current_user)):
    username = user["username"]  # FIXED
    runtime = get_runtime()
    base = runtime.env.DATA_DIR / "users" / username / "characters" / name / "gallery" / "modern"
    base.mkdir(parents=True, exist_ok=True)

    ext = Path(file.filename).suffix or ".jpg"
    dest = base / f"{name}_gallery_{uuid.uuid4().hex}{ext}"

    with dest.open("wb") as f:
        shutil.copyfileobj(file.file, f)

    return {"status": "ok", "url": _to_data_url(str(dest))}


@router.post("/{name}/gallery/delete")
def delete_gallery_image(name: str, payload: dict, user=Depends(get_current_user)):
    username = user["username"]  # FIXED
    url = payload.get("url")
    if not url:
        raise HTTPException(status_code=400, detail="Missing image URL.")

    runtime = get_runtime()
    rel = url[len("/data/"):] if url.startswith("/data/") else url.lstrip("/")
    path = runtime.env.DATA_DIR / rel
    if path.exists():
        path.unlink()

    return {"status": "deleted", "url": url}


@router.get("/{name}/gallery/list")
def list_gallery(name: str, user=Depends(get_current_user)):
    username = user["username"]  # FIXED
    gallery = list_character_gallery(username, name)
    return {"gallery": gallery}


# ============================================================
#  CHARACTER PROFILE
# ============================================================

@router.get("/{name}")
def get_character_profile(name: str, user=Depends(get_current_user)):
    username = user["username"]  # FIXED
    char = load_character(username, name)
    if not char:
        raise HTTPException(status_code=404, detail="Character not found.")
    return {"character": char}


@router.get("/{name}/avatar")
def get_character_avatar(name: str, user=Depends(get_current_user)):
    username = user["username"]
    merged = list_all_characters(username)
    char = merged.get(name)
    if not char:
        raise HTTPException(status_code=404, detail="Character not found.")

    for candidate in _avatar_candidates(username, name, char):
        if candidate.exists() and candidate.is_file():
            return FileResponse(candidate)

    raise HTTPException(status_code=404, detail="Avatar not found.")


@router.get("/{name}/avatar/status")
def get_character_avatar_status(name: str, user=Depends(get_current_user)):
    """
    Tells the frontend whether `name` currently has ANY reference photo
    (explicit avatar, own gallery, or seeded system gallery) to build new
    reference-driven images (selfies) from, and whether they're a system
    agent. Used by the Gallery/"Change Avatar" page to decide whether to
    offer the reference-based "Generate Selfie" flow or fall back to a
    prompt-only "generate from description" flow for brand-new, non-system
    characters that don't have a photo yet (system agents always ship with
    a seeded reference photo, so this never applies to them).
    """
    username = user["username"]
    merged = list_all_characters(username)
    char = merged.get(name) or {}
    has_reference = bool(_avatar_candidates(username, name, char))
    return {"has_reference": has_reference, "is_system": is_system_character(char, name)}


@router.post("/{name}/update")
def update_character(name: str, updates: dict, user=Depends(get_current_user)):
    username = user["username"]  # FIXED
    char = load_character(username, name)
    if not char:
        raise HTTPException(status_code=404, detail="Character not found.")

    try:
        validate_profile_update(char, updates, name)
    except RelationshipError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    for key, value in updates.items():
        char[key] = value

    save_character(username, char, key=name)
    return {"status": "updated", "character": char}


# ============================================================
#  CHARACTER-TO-CHARACTER RELATIONSHIPS
# ============================================================

@router.get("/{name}/relationship/options")
def get_relationship_options(name: str, user=Depends(get_current_user)):
    """
    Returns this character's current relationship status/partner, whether
    it's locked (e.g. Maximos/Sol are permanently married to each other),
    and which statuses (if any) it could still progress to.
    """
    username = user["username"]
    char = load_character(username, name)
    if not char:
        raise HTTPException(status_code=404, detail="Character not found.")

    return {
        "relationship_rules": char.get("relationship_rules") or {"status": "single", "partner": ""},
        "locked": bool((char.get("locked") or {}).get("relationship_locked")),
        "next_allowed_statuses": next_allowed_statuses(char),
        "all_statuses": RELATIONSHIP_LEVELS,
        "pending_proposal": (char.get("relationship_rules") or {}).get("pending_proposal"),
    }


@router.post("/{name}/relationship")
def set_relationship(name: str, payload: dict, user=Depends(get_current_user)):
    """
    Sets/progresses a mutual relationship between `name` and `payload.partner`
    (e.g. Orion Lumos <-> Meera Patel, status "dating"). Updates both
    characters' `relationship_rules` in lockstep and persists both. Rejected
    if either side is relationship-locked (Maximos/Sol), if it would
    downgrade an existing status, or if it would redirect an already-
    committed partner elsewhere. Once a pair is already committed (past
    "single"), further escalation is rejected here -- use the
    propose/respond endpoints instead so both characters must agree.
    """
    username = user["username"]
    partner_name = (payload.get("partner") or "").strip()
    status = (payload.get("status") or "").strip()

    if not partner_name:
        raise HTTPException(status_code=400, detail="Missing partner character name.")

    char = load_character(username, name)
    if not char:
        raise HTTPException(status_code=404, detail="Character not found.")

    partner = load_character(username, partner_name)
    if not partner:
        raise HTTPException(status_code=404, detail="Partner character not found.")

    try:
        char, partner = apply_mutual_relationship(char, name, partner, partner_name, status)
    except RelationshipError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    save_character(username, char, key=name)
    save_character(username, partner, key=partner_name)

    return {"status": "updated", "character": char, "partner": partner}


@router.post("/{name}/relationship/propose")
def propose_relationship(name: str, payload: dict, user=Depends(get_current_user)):
    """
    `name` proposes upgrading its existing relationship with `payload.partner`
    to `payload.to_status` (e.g. Orion proposes "engaged" to Meera). Nothing
    changes yet -- the partner must accept via /relationship/respond.
    """
    username = user["username"]
    partner_name = (payload.get("partner") or "").strip()
    to_status = (payload.get("to_status") or "").strip()

    if not partner_name:
        raise HTTPException(status_code=400, detail="Missing partner character name.")

    char = load_character(username, name)
    if not char:
        raise HTTPException(status_code=404, detail="Character not found.")

    partner = load_character(username, partner_name)
    if not partner:
        raise HTTPException(status_code=404, detail="Partner character not found.")

    try:
        char, partner = propose_relationship_upgrade(char, name, partner, partner_name, to_status)
    except RelationshipError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    save_character(username, char, key=name)
    save_character(username, partner, key=partner_name)

    return {"status": "proposed", "character": char, "partner": partner}


@router.post("/{name}/relationship/respond")
def respond_to_relationship(name: str, payload: dict, user=Depends(get_current_user)):
    """
    `name` (the partner who did NOT propose) accepts or declines the
    pending relationship proposal. If accepted, the new status is applied
    automatically to both characters; if the newly-applied status is
    "married", the response includes a `ceremony_message` nudging the user
    to roleplay a little celebration in a group chat with both characters.
    """
    username = user["username"]
    partner_name = (payload.get("partner") or "").strip()
    accept = bool(payload.get("accept"))

    if not partner_name:
        raise HTTPException(status_code=400, detail="Missing partner character name.")

    char = load_character(username, name)
    if not char:
        raise HTTPException(status_code=404, detail="Character not found.")

    partner = load_character(username, partner_name)
    if not partner:
        raise HTTPException(status_code=404, detail="Partner character not found.")

    try:
        char, partner, ceremony_required = respond_to_relationship_proposal(
            char, name, partner, partner_name, name, accept
        )
    except RelationshipError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    save_character(username, char, key=name)
    save_character(username, partner, key=partner_name)

    display_a = char.get("name") or name
    display_b = partner.get("name") or partner_name

    result = {"status": "accepted" if accept else "declined", "character": char, "partner": partner}
    if accept and ceremony_required:
        result["ceremony_message"] = (
            f"{display_a} and {display_b} are getting married! Consider opening a group chat with "
            "both of them and roleplaying a little pretend wedding ceremony to celebrate."
        )
    return result


@router.post("/{name}/delete")
def delete_character_route(name: str, user=Depends(get_current_user)):
    username = user["username"]
    VaultController.delete_character(username, name)
    base = Path(f"backend/data/users/{username}/characters/{name}")
    if base.exists():
        shutil.rmtree(base, ignore_errors=True)
    return {"status": "deleted"}


# ============================================================
#  BACKSTORY GENERATION
# ============================================================

@router.post("/backstory/generate")
def generate_backstory_route(payload: dict, user=Depends(get_current_user)):
    username = user["username"]
    seed = payload.get("seed")
    name = payload.get("name", "")
    gender = payload.get("gender", "")
    personality = payload.get("personality", "")
    mood = payload.get("mood", "")

    character = new_character_base()
    character["name"] = name
    character["profile"]["full_name"] = name
    character["profile"]["gender"] = gender
    if personality:
        character["profile"]["traits"] = [personality]
    if mood:
        character["relationship_to_user"]["mode"] = mood

    backstory = generate_backstory(character, username, user_prompt=seed)

    return {"backstory": backstory}


# ============================================================
#  AVATAR GENERATION
# ============================================================

@router.post("/avatar/generate")
async def generate_avatar(payload: dict, user=Depends(get_current_user)):
    username = user["username"]
    prompt = payload.get("prompt")
    character = payload.get("character")

    if not prompt:
        raise HTTPException(status_code=400, detail="Missing avatar prompt.")

    result = await _image_service.generate_avatar(username=username, prompt=prompt, character=character)
    return {"url": _to_data_url(result.get("path")), "path": result.get("path")}


@router.post("/{name}/selfie/generate")
async def generate_selfie_route(name: str, payload: dict, user=Depends(get_current_user)):
    """
    Generates a NEW photo of `name` using their existing avatar/gallery
    photo as a reference image, so the model keeps the same person's
    identity/likeness instead of drawing a fresh, unrelated face.

    `prompt` (optional): an explicit user request for what the selfie should
    show (e.g. "at the beach, sunset"). `emotion` (optional): an emotional
    cue (e.g. "very_happy"/"very_sad") used instead when no explicit prompt
    is given -- this is how chat-triggered "emotional selfies" steer the
    photo without the user having to ask.
    """
    username = user["username"]
    prompt = payload.get("prompt")
    emotion = payload.get("emotion")

    result = await _image_service.generate_selfie(username=username, character=name, prompt=prompt, emotion=emotion)
    return {**result, "url": _to_data_url(result.get("path"))}


@router.post("/pair/generate")
async def generate_pair_route(payload: dict, user=Depends(get_current_user)):
    """
    Combines two characters' existing reference photos into a single new
    image (e.g. "Sol and Maximos at a cafe"), keeping each character's own
    face/identity from their own reference photo. The resulting image is
    saved into BOTH characters' gallery/pair/ folders.
    """
    username = user["username"]
    character_a = payload.get("character_a")
    character_b = payload.get("character_b")
    prompt = payload.get("prompt")

    if not character_a or not character_b:
        raise HTTPException(status_code=400, detail="character_a and character_b are required.")
    if not prompt:
        raise HTTPException(status_code=400, detail="A prompt describing the scene is required.")

    result = await _image_service.generate_pair_image(
        username=username, character_a=character_a, character_b=character_b, prompt=prompt
    )
    return {**result, "urls": [_to_data_url(p) for p in result.get("paths", [])]}


@router.post("/avatar/generate-family")
async def generate_family_avatar_route(payload: dict, user=Depends(get_current_user)):
    """
    Generates a NEW (not-yet-saved) character's avatar using an EXISTING
    character's reference photo, so the new character visibly resembles a
    close relative (sibling/parent/child) instead of getting a completely
    unrelated AI-invented face. Used by the character-creation wizard's
    "based on an existing relative" flow.
    """
    username = user["username"]
    character = payload.get("character")
    source_character = payload.get("source_character")
    relation = payload.get("relation") or "family member"
    prompt = payload.get("prompt")

    if not character or not source_character:
        raise HTTPException(status_code=400, detail="character and source_character are required.")

    result = await _image_service.generate_family_avatar(
        username=username,
        character=character,
        source_character=source_character,
        relation=relation,
        prompt=prompt,
    )
    return {**result, "url": _to_data_url(result.get("path"))}


# ============================================================
#  VOICE SYSTEM
# ============================================================

@router.get("/voices/list")
def voices_list_route():
    """The general 20-voice catalog (10 male, 10 female) that user-created
    characters pick from. System characters aren't in this list -- each has
    its own unique voice_id hardcoded directly on its own record."""
    return {"voices": list_voices()}


@router.get("/voices/settings")
def voices_settings_get_route(user=Depends(get_current_user)):
    """Whether ElevenLabs is turned on and whether an API key is saved
    (never returns the key itself)."""
    return get_voice_settings(user["username"])


@router.post("/voices/settings")
def voices_settings_post_route(payload: dict, user=Depends(get_current_user)):
    enabled = payload.get("enabled")
    api_key = payload.get("api_key")
    return set_voice_settings(
        user["username"],
        enabled=bool(enabled) if enabled is not None else None,
        api_key=api_key if isinstance(api_key, str) else None,
    )


@router.post("/{name}/voice")
def assign_voice_route(name: str, payload: dict, user=Depends(get_current_user)):
    """Assigns one of the 20 catalog voices to a (non-system) character."""
    voice_id = payload.get("voice_id") or payload.get("voice") or ""
    try:
        char = assign_character_voice(user["username"], name, voice_id)
    except VoiceAssignmentError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"status": "updated", "voice_id": char.get("voice_id")}


@router.post("/{name}/voice/speak")
def speak_voice_route(name: str, payload: dict, user=Depends(get_current_user)):
    """Synthesizes `text` in this character's voice_id and returns raw MP3
    audio. Used for both the voice-settings preview button and the
    simulated phone call feature."""
    username = user["username"]
    char = load_character(username, name)
    if not char:
        raise HTTPException(status_code=404, detail="Character not found.")

    text = str(payload.get("text") or "").strip()
    if not text:
        raise HTTPException(status_code=400, detail="Missing 'text' to speak.")

    voice_id = char.get("voice_id")
    if not voice_id:
        raise HTTPException(status_code=409, detail=f"{char.get('name') or name} doesn't have a voice set yet.")

    try:
        audio = text_to_speech(username, voice_id, text)
    except VoiceProviderError as exc:
        raise HTTPException(status_code=exc.status_code, detail=str(exc))

    return Response(content=audio, media_type="audio/mpeg")


@router.post("/voices/{voice_id}/preview")
def preview_voice_route(voice_id: str, user=Depends(get_current_user)):
    """Speaks a short canned line in the given catalog voice id (used by the
    voice picker's Preview button, before a voice is even assigned to a
    character yet)."""
    try:
        audio = text_to_speech(
            user["username"], voice_id, "Hi, this is a preview of this voice."
        )
    except VoiceProviderError as exc:
        raise HTTPException(status_code=exc.status_code, detail=str(exc))

    return Response(content=audio, media_type="audio/mpeg")


# ============================================================
#  BUILD AN EXPERT (private per-character reference library)
# ============================================================

@router.get("/{name}/expert-library/status")
def expert_library_status_route(name: str, user=Depends(get_current_user)):
    return expert_library_service.get_status(user["username"], name)


@router.get("/{name}/expert-library/content")
def expert_library_content_route(name: str, user=Depends(get_current_user)):
    content = expert_library_service.get_content(user["username"], name)
    if content is None:
        raise HTTPException(status_code=404, detail="No expert library built yet.")
    return {"content": content}


@router.post("/{name}/expert-library/build")
async def expert_library_build_route(
    name: str,
    file: UploadFile = File(None),
    text: str = Form(""),
    website_query: str = Form(""),
    user=Depends(get_current_user),
):
    username = user["username"]
    char = load_character(username, name)
    if not char:
        raise HTTPException(status_code=404, detail="Character not found.")
    if is_system_character(char, name):
        raise HTTPException(status_code=403, detail="System characters can't have a custom expert library.")

    source_text = text or ""
    source_label = "Pasted text"
    if file is not None and file.filename:
        raw = await file.read()
        try:
            source_text = (source_text + "\n\n" + raw.decode("utf-8")).strip()
        except UnicodeDecodeError:
            raise HTTPException(status_code=400, detail="Only plain-text/markdown files are supported right now.")
        source_label = file.filename

    try:
        result = await expert_library_service.build_library(
            username, name, source_text, source_label, website_query
        )
    except expert_library_service.ExpertLibraryError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return result


@router.post("/{name}/expert-library/delete")
def expert_library_delete_route(name: str, user=Depends(get_current_user)):
    expert_library_service.delete_library(user["username"], name)
    return {"status": "deleted"}


# ============================================================
#  BACKUP & RESTORE
# ============================================================

@router.post("/{name}/backup/full")
def backup_full_route(name: str, user=Depends(get_current_user)):
    username = user["username"]  # FIXED
    char = load_character(username, name)
    if char and is_system_character(char, name):
        raise HTTPException(
            status_code=403,
            detail="System characters only support chat history backup, not a full backup.",
        )
    path = export_full_backup(username, name)
    return {"status": "ok", "path": str(path)}


@router.post("/{name}/backup/chat")
def backup_chat_route(name: str, user=Depends(get_current_user)):
    username = user["username"]  # FIXED
    path = export_chat_history(username, name)
    return {"status": "ok", "path": str(path)}


@router.post("/{name}/backup/gallery")
def backup_gallery_route(name: str, user=Depends(get_current_user)):
    username = user["username"]  # FIXED
    gallery = list_character_gallery(username, name)
    return {"status": "ok", "count": len(gallery)}


@router.post("/{name}/restore/full")
def restore_full_route(name: str, user=Depends(get_current_user)):
    username = user["username"]  # FIXED
    char = load_character(username, name)
    if char and is_system_character(char, name):
        raise HTTPException(
            status_code=403,
            detail="System characters only support chat history restore, not a full restore.",
        )
    try:
        restore_character_backup(username, name)
    except VaultError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    return {"status": "restored"}


@router.post("/{name}/restore/chat")
def restore_chat_route(name: str, user=Depends(get_current_user)):
    username = user["username"]  # FIXED
    restore_chat_history(username, name)
    return {"status": "restored"}


@router.post("/{name}/restore/gallery")
def restore_gallery_route(name: str, user=Depends(get_current_user)):
    return {"status": "restored"}

