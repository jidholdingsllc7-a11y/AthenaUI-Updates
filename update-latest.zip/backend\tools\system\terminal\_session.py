# AthenaUI v3.5 — Terminal Session Helpers
# File: backend/tools/system/terminal/_session.py
# Shared, in-process state for visible terminal sessions used by both
# terminal_run (executes commands) and terminal_check (peeks at output),
# so the agent can revisit the same session across multiple tool calls --
# and so it can see anything the user typed manually into a still-open
# window, not just its own command's output.

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict

from temp_system.service import temp_root

SESSION_DIR = temp_root / "terminal_sessions"

# session_id -> {"log_path": Path, "offset": int}. Ephemeral -- cleared on
# backend restart, but the underlying log files (and any still-open windows
# still transcribing to them) survive, so a peek right after a restart just
# starts its offset back at 0 and reports the full history so far.
_SESSIONS: Dict[str, Dict[str, Any]] = {}

_DONE_MARKER = "##ATHENA_TERMINAL_DONE##"
_DONE_RE = re.compile(re.escape(_DONE_MARKER) + r" exit=(-?\d+)")

# Line prefixes Start-Transcript itself adds (header/footer boilerplate) --
# stripped out before showing the log to the agent so it isn't buried in noise.
_TRANSCRIPT_NOISE_PREFIXES = (
    "**********************",
    "Windows PowerShell transcript",
    "Start time:",
    "End time:",
    "Username:",
    "RunAs User:",
    "Configuration Name:",
    "Machine:",
    "Host Application:",
    "Process ID:",
    "PSVersion:",
    "PSEdition:",
    "PSCompatibleVersions:",
    "BuildVersion:",
    "CLRVersion:",
    "WSManStackVersion:",
    "PSRemotingProtocolVersion:",
    "SerializationVersion:",
    "OS:",
    "Transcript started, output file is",
)

# When a session is reused, the next command is invoked via a one-line
# "& 'C:\...\athenaui_terminal_sessions\<id>_<hex>.ps1'" written to the
# shell's stdin (see terminal_run._build_continuation_script usage) -- the
# legacy (non-PSReadLine) console input reader echoes that line back into
# the transcript, along with the "PS <cwd>>" prompt it was typed at. Neither
# is useful to the agent (its own real "> <command>" announcement line right
# after already shows what actually ran), so both are stripped here too.
_CONTINUATION_INVOKE_RE = re.compile(
    r"^(PS [^>]*>\s*)?&\s*'[^']*athenaui_terminal_sessions[^']*\.ps1'\s*$"
)


def session_log_path(session_id: str) -> Path:
    SESSION_DIR.mkdir(parents=True, exist_ok=True)
    return SESSION_DIR / f"{session_id}.log"


def read_log(log_path: Path) -> str:
    """PowerShell's Start-Transcript/Tee-Object write UTF-16LE on some hosts
    and UTF-8-with-BOM on others (observed UTF-8-BOM on this Windows
    PowerShell 5.1 build) -- decoding with the wrong one corrupts every
    character. Sniff the BOM and decode accordingly; strip any BOM
    characters left over (e.g. from a later -Append re-adding one)."""
    try:
        raw = log_path.read_bytes()
    except OSError:
        return ""
    if raw.startswith(b"\xff\xfe"):
        text = raw.decode("utf-16-le", errors="replace")
    elif raw.startswith(b"\xfe\xff"):
        text = raw.decode("utf-16-be", errors="replace")
    else:
        text = raw.decode("utf-8-sig", errors="replace")
    text = text.replace("\ufeff", "")
    lines = [
        ln for ln in text.split("\n")
        if not ln.strip().startswith(_TRANSCRIPT_NOISE_PREFIXES)
        and not _CONTINUATION_INVOKE_RE.match(ln.strip())
    ]
    return "\n".join(lines)


def get_session(session_id: str) -> Dict[str, Any]:
    session = _SESSIONS.get(session_id)
    if session is None:
        # `proc`: the live Popen for this session's shell once one has been
        # started, so terminal_run can feed it further commands via stdin
        # instead of opening a new window every call. `busy`: True while
        # that shell is occupied running a command (including a long-lived
        # one like a dev server that hasn't finished) -- only safe to write
        # more input to the shell when it's back at an idle prompt.
        session = {"log_path": session_log_path(session_id), "offset": 0, "proc": None, "busy": False}
        _SESSIONS[session_id] = session
    return session


def list_sessions() -> Dict[str, Dict[str, Any]]:
    """Every terminal session this backend process currently tracks --
    including ones not currently visible in the user's own UI (opened by an
    earlier turn, a different agent, or a Synergy worker process) -- so
    terminal_list can show the full picture, not just what's on screen."""
    out: Dict[str, Dict[str, Any]] = {}
    for session_id, session in _SESSIONS.items():
        proc = session.get("proc")
        alive = proc is not None and proc.poll() is None
        out[session_id] = {
            "pid": proc.pid if proc is not None else None,
            "alive": alive,
            "busy": bool(session.get("busy")) and alive,
            "log_path": str(session["log_path"]),
        }
    return out


def get_proc(session_id: str):
    """Raw Popen for a tracked session, or None if untracked/never started."""
    session = _SESSIONS.get(session_id)
    return session.get("proc") if session else None


def forget_session(session_id: str) -> None:
    """Drops a session from tracking (e.g. after terminal_kill) -- the log
    file on disk is left alone, only the in-memory bookkeeping is cleared."""
    _SESSIONS.pop(session_id, None)
