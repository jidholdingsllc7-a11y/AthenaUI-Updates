﻿# AthenaUI v3.5 — Code Suite Changeset Service
# File: backend/code_suite/changes/service.py
# Created: 2026-04-07 13:22 CDT
# Updated: 2026-08-24

import json
from typing import Any, Dict, Optional
from dataclasses import dataclass, field, asdict
import uuid
import time

from code_suite.workspace.service import WorkspaceService, WorkspaceError


def _pending_changes_path():
    from pathlib import Path
    from core.runtime.runtime import get_runtime

    path: Path = get_runtime().env.DATA_DIR / "changesets"
    path.mkdir(parents=True, exist_ok=True)
    return path / "pending.json"


@dataclass
class PendingChange:
    id: str
    username: str
    rel_path: str
    new_content: str
    created_at: float = field(default_factory=time.time)
    type: str = "edit"  # "edit" | "delete" | "tool_call"
    tool_name: Optional[str] = None
    tool_arguments: Optional[Dict[str, Any]] = None
    reason: Optional[str] = None
    task_id: Optional[str] = None  # set when this approval was raised by a
    # Task Builder job (tasks/engine/service.py), so the task can be paused
    # and later resumed once the user resolves it.
    character: Optional[str] = None  # which chat character/agent asked for this
    # tool call, so approval can auto-resume that same conversation afterward.
    original_content: Optional[str] = None  # edit: the pre-edit snapshot. The
    # new content is already live on disk by the time this change exists (see
    # workspace.service.write_file_tracked) -- Keep archives this snapshot,
    # Revert restores it live and archives the rejected attempt instead.


class ChangesetService:
    """
    Holds pending changes that require user confirmation:
    - edit: Keep / Revert
    - delete: Allow / Deny
    - tool_call: Allow / Deny for any capability-flagged dangerous tool call
      (e.g. terminal_run), gated by tools/executor/executor.py's general
      approval gate. Reuses the exact same pending-action/Allow-Deny UI
      already built for file deletions -- no frontend changes required.

    Persisted to disk (data/changesets/pending.json) on every mutation --
    a dev backend restarts constantly (uvicorn --reload on every source
    edit), and a pure in-memory dict here would silently orphan any
    approval the user hadn't clicked yet: the Allow/Deny UI would
    reference a change_id the freshly-restarted process never heard of,
    so clicking it would just fail with "Change not found" (or worse,
    since the frontend doesn't re-fetch pending state on its own, the
    button could sit there looking clickable forever with no way to
    resolve it). Reloading from disk on startup keeps a pending approval
    valid across restarts.
    """

    def __init__(self):
        self._changes: Dict[str, PendingChange] = {}
        self._load()

    def _load(self) -> None:
        try:
            path = _pending_changes_path()
            if not path.exists():
                return
            raw = json.loads(path.read_text(encoding="utf-8"))
            for item in raw:
                self._changes[item["id"]] = PendingChange(**item)
        except Exception:
            # A missing/corrupt state file shouldn't block startup -- just
            # start with no pending changes.
            pass

    def _persist(self) -> None:
        try:
            path = _pending_changes_path()
            path.write_text(
                json.dumps([asdict(c) for c in self._changes.values()], indent=2),
                encoding="utf-8",
            )
        except Exception:
            pass

    def create_live_edit(
        self,
        username: str,
        rel_path: str,
        original_content: Optional[str],
        character: Optional[str] = None,
    ) -> PendingChange:
        """Called by write_file_tracked AFTER the new content is already live
        on disk -- records the pre-edit snapshot so the user's Keep/Revert
        decision has something to archive/restore. `character` (when the
        write came from an agent tool call rather than a direct Code Suite
        edit) lets _build_pending_action scope the resulting Keep/Revert
        prompt to that same character's conversation, instead of it bleeding
        into every other character's chat."""
        # A path can already have an unresolved pending edit when this is
        # called again (e.g. a character makes two write_file_tracked calls
        # to the same file in close succession). Left alone, the OLDER entry
        # would keep resurfacing its own Keep/Revert prompt
        # (_build_pending_action always shows the most recent pending item,
        # cycling back to older ones once newer ones are resolved) even
        # though it's now superseded, and clicking Revert on it would wipe
        # out this newer edit entirely by restoring a now-stale snapshot.
        # Auto-finalize (same effect as the user clicking Keep) any older
        # pending edit for this same path first, since its content is
        # already fully subsumed by the edit we're about to record.
        for stale_id, stale in list(self._changes.items()):
            if stale.type == "edit" and stale.username == username and stale.rel_path == rel_path:
                if stale.original_content is not None:
                    WorkspaceService(username).archive_content(stale.rel_path, stale.original_content, tag="pre-edit")
                del self._changes[stale_id]

        change_id = str(uuid.uuid4())
        change = PendingChange(
            id=change_id,
            username=username,
            rel_path=rel_path,
            new_content="",
            type="edit",
            original_content=original_content,
            character=character,
        )
        self._changes[change_id] = change
        self._persist()
        return change

    def create_delete_change(self, username: str, rel_path: str) -> PendingChange:
        change_id = str(uuid.uuid4())
        change = PendingChange(
            id=change_id,
            username=username,
            rel_path=rel_path,
            new_content="",
            type="delete",
        )
        self._changes[change_id] = change
        self._persist()
        return change

    def create_tool_approval(
        self,
        username: str,
        tool_name: str,
        arguments: Dict[str, Any],
        reason: str = "",
        task_id: Optional[str] = None,
        character: Optional[str] = None,
    ) -> PendingChange:
        change_id = str(uuid.uuid4())
        change = PendingChange(
            id=change_id,
            username=username,
            rel_path=tool_name,
            new_content="",
            type="tool_call",
            tool_name=tool_name,
            tool_arguments=dict(arguments or {}),
            reason=reason,
            task_id=task_id,
            character=character,
        )
        self._changes[change_id] = change
        self._persist()
        return change

    def get(self, change_id: str) -> Optional[PendingChange]:
        return self._changes.get(change_id)

    def list_pending_for_user(self, username: str):
        return [
            change
            for change in self._changes.values()
            if change.username == username
        ]

    async def apply(self, change_id: str, scope: str = "once"):
        change = self._changes.pop(change_id, None)
        if not change:
            return None
        self._persist()

        if change.type == "tool_call":
            # Actually execute the originally-requested tool call now that the
            # user has clicked Allow. Marked pre-approved so the executor
            # skips creating a second pending approval for this same call --
            # MAP hard-block checks still run unconditionally.
            from tools.registry.loader import load_tools
            from tools.executor.executor import ToolExecutor
            from safety import approvals

            registry = load_tools()
            executor = ToolExecutor(registry)
            args = dict(change.tool_arguments or {})
            args.setdefault("username", change.username)
            try:
                result = await executor.execute(change.tool_name, args, _map_preapproved=True)
                applied: Dict[str, Any] = {
                    "status": "applied",
                    "type": "tool_call",
                    "tool_name": change.tool_name,
                    "result": result,
                    "username": change.username,
                    "character": change.character,
                }
                if scope == "session":
                    # "Allow for Session" -- also grant this whole category
                    # (e.g. "terminal") so the agent doesn't have to stop and
                    # wait for another Allow/Deny click on the same kind of
                    # action until the user leaves Code Suite or the next
                    # daily reset, whichever comes first.
                    tool_meta = registry.get(change.tool_name) or {}
                    category = approvals.category_for_tool(change.tool_name, tool_meta.get("capabilities", {}))
                    expires_at = approvals.approve_category_for_session(change.username, category)
                    applied["session_approved_category"] = category
                    applied["session_expires_at"] = expires_at
                return applied
            except Exception as e:
                return {
                    "status": "error",
                    "type": "tool_call",
                    "tool_name": change.tool_name,
                    "error": str(e),
                    "username": change.username,
                    "character": change.character,
                }

        ws = WorkspaceService(change.username)

        if change.type == "edit":
            # New content is already live on disk (written by
            # write_file_tracked the moment the edit happened) -- Keep just
            # finalizes it by archiving the pre-edit snapshot.
            if change.original_content is not None:
                ws.archive_content(change.rel_path, change.original_content, tag="pre-edit")
            return {"status": "applied", "type": "edit"}

        if change.type == "delete":
            # move to archive instead of hard delete
            ws.archive_file(change.rel_path)
            ws.delete_file(change.rel_path)
            return {"status": "applied", "type": "delete"}

        return None

    async def revert(self, change_id: str):
        # For edits: the live file currently holds the rejected attempt --
        # archive that attempt (so nothing is lost) and restore the
        # pre-edit original as the live file.
        # For deletes: just drop pending change; file remains (never touched).
        # For tool_call: drop pending change; the tool is never executed.
        change = self._changes.pop(change_id, None)
        if not change:
            return None
        self._persist()

        if change.type == "tool_call":
            return {"status": "denied", "type": "tool_call", "tool_name": change.tool_name}

        if change.type == "edit":
            ws = WorkspaceService(change.username)
            try:
                attempted = ws.read_file(change.rel_path)
                ws.archive_content(change.rel_path, attempted, tag="rejected-edit")
            except WorkspaceError:
                pass
            ws.write_file(change.rel_path, change.original_content or "")
            return {"status": "reverted", "type": "edit"}

        return {"status": "reverted", "type": change.type}


# Shared singleton used across API routes that manage proposal approvals.
changeset_service = ChangesetService()
