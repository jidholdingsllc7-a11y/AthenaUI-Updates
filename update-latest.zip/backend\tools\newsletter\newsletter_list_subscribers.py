# AthenaUI v3.5 — newsletter_list_subscribers Tool
# File: backend/tools/newsletter/newsletter_list_subscribers.py
#
# Lists everyone currently opted into the newsletter (or unsubscribed, if
# asked) -- read this before drafting/sending a campaign so you know who
# it's going to and roughly how many people.

from typing import Any, Dict

from newsletter.service import NewsletterError, list_subscribers

capabilities = {
    "needs_filesystem": True,
    "needs_bridge": False,
    "needs_network": False,
    "needs_user": True,
}


async def run(args: Dict[str, Any]) -> str:
    try:
        username = args.get("username")
        if not username:
            return "[ERROR] Missing 'username' argument."

        status = args.get("status", "subscribed")
        subs = list_subscribers(username, status=status)
        if not subs:
            return f"No subscribers found with status '{status}'."

        lines = [f"{len(subs)} subscriber(s) with status '{status}':"]
        for s in subs:
            lines.append(f"- {s['email']}" + (f" ({s['name']})" if s.get("name") else ""))
        return "\n".join(lines)
    except NewsletterError as e:
        return f"[ERROR] {e}"
    except Exception as e:
        return f"[ERROR] Failed to list subscribers: {str(e)}"
