# AthenaUI — Athena Link: local-network address helper
# File: backend/athena_link/network.py
# Created: 2026-11-02 CST
#
# Lets a user pick "use my LAN address" instead of guessing their own IP --
# only useful when both installs are on the same local network, but it's
# the simplest zero-setup option when that's the case.

from __future__ import annotations

import socket

# Must match electron/main.js's BACKEND_PORT constant.
BACKEND_PORT = 8000


def get_lan_address() -> str:
    """Best-effort local-network IP via the classic outbound-UDP-socket
    trick -- connect() on a UDP socket never actually sends a packet, it
    just asks the OS to pick which local interface/IP would be used to
    route to that destination, which is exactly the LAN-facing IP other
    devices on the same network could reach this machine at."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("8.8.8.8", 80))
        ip = sock.getsockname()[0]
    except OSError:
        ip = "127.0.0.1"
    finally:
        sock.close()
    return f"http://{ip}:{BACKEND_PORT}"
