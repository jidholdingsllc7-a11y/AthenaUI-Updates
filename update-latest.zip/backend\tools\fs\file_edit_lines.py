# AthenaUI v3.5 — File Edit Lines Tool
# File: backend/tools/fs/file_edit_lines.py
# Created: 2026-10-16

from workspace.service import WorkspaceService
from typing import Any, Dict

capabilities = {
    "needs_filesystem": True,
    "needs_bridge": False,
    "needs_network": False,
    "needs_user": True,
}

async def run(args: Dict[str, Any]) -> str:
    try:
        username = args.get("username")
        path = args.get("path")
        start_line = args.get("start_line")
        end_line = args.get("end_line")
        new_text = args.get("new_text", "")

        if not username or not path:
            return "[ERROR] Missing required arguments (username, path)."
        if not isinstance(start_line, int) or not isinstance(end_line, int):
            return "[ERROR] start_line and end_line must be integers."

        ws = WorkspaceService.get_workspace(username)
        if ws is None:
            return f"[ERROR] Workspace not available for user '{username}'."

        try:
            original = ws.read_file(path)
        except FileNotFoundError:
            return f"[ERROR] File not found: {path}. Use file_write to create a new file first."

        lines = original.splitlines(keepends=True)
        total = len(lines)

        if start_line < 1 or start_line > total + 1:
            return f"[ERROR] start_line {start_line} out of range -- file has {total} line(s)."
        if end_line < start_line - 1:
            return "[ERROR] end_line must be >= start_line - 1 (use end_line = start_line - 1 to insert without replacing anything)."
        if end_line > total:
            return f"[ERROR] end_line {end_line} out of range -- file has {total} line(s)."

        new_block = new_text.splitlines(keepends=True) if new_text else []
        if new_block and not new_block[-1].endswith("\n") and end_line < total:
            # keep whatever follows on its own line when inserting/replacing mid-file
            new_block[-1] += "\n"

        updated = lines[:start_line - 1] + new_block + lines[end_line:]
        new_content = "".join(updated)

        return ws.write_file_tracked(path, new_content, character=args.get("character"))

    except Exception as e:
        return f"[ERROR] Failed to edit file: {str(e)}"
