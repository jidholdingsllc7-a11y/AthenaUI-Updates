# AthenaUI v3.7 — Batch File Read Tool
# File: backend/tools/fs/file_read_multiple.py
# Created: 2026-10-25

from workspace.service import WorkspaceService
from typing import Any, Dict, List

capabilities = {
    "needs_filesystem": True,
    "needs_bridge": False,
    "needs_network": False,
    "needs_user": True,
}

async def run(args: Dict[str, Any]) -> str:
    """
    Read several files from the user's workspace in a single call, instead
    of one file_read per file. Any individual file that fails to read is
    reported inline as its own error section rather than failing the whole
    call.
    """
    try:
        username = args.get("username")
        paths = args.get("paths")

        if not username:
            return "[ERROR] Missing 'username' in tool arguments."
        if not paths or not isinstance(paths, list):
            return "[ERROR] Missing or invalid 'paths' argument for file_read_multiple tool (expected a non-empty list of file paths)."

        ws = WorkspaceService.get_workspace(username)
        if ws is None:
            return f"[ERROR] Workspace not available for user '{username}'. Cannot read files."

        sections: List[str] = []
        for path in paths:
            try:
                content = ws.read_file(path)
                sections.append(f"=== {path} ===\n{content}")
            except Exception as e:
                sections.append(f"=== {path} (ERROR) ===\n{str(e)}")

        return "\n\n".join(sections)

    except Exception as e:
        return f"[ERROR] Failed to read files: {str(e)}"
