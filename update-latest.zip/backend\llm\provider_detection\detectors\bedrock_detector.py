﻿# AthenaUI v3.5 — Bedrock Provider Auto-Detection
# File: backend/llm/provider_detection/detectors/bedrock_detector.py
# Created: 2026-03-28 10:48 CDT
# Updated: 2026-07-27 19:49 CDT

import boto3
import requests
from botocore.exceptions import BotoCoreError, NoCredentialsError
from typing import List, Optional

from llm.provider_detection.detector_base import ProviderDetectorBase, ProviderDetectionResult
from llm.routers.providers import PROVIDER_BEDROCK


class BedrockDetector(ProviderDetectorBase):
    provider_id = PROVIDER_BEDROCK

    def __init__(
        self,
        aws_access_key: Optional[str] = None,
        aws_secret_key: Optional[str] = None,
        region: str = "us-east-1",
        bearer_token: Optional[str] = None,
    ):
        self.aws_access_key = aws_access_key
        self.aws_secret_key = aws_secret_key
        self.region = region
        self.bearer_token = bearer_token

    def detect(self) -> ProviderDetectionResult:
        if not self.bearer_token and not (self.aws_access_key and self.aws_secret_key):
            return ProviderDetectionResult(False, error="Missing AWS credentials.")

        try:
            models = self.list_models()
        except Exception as e:
            return ProviderDetectionResult(False, error=str(e))

        warnings = ["Bedrock model availability varies by region."]
        return ProviderDetectionResult(True, models, warnings)

    def list_models(self) -> List[str]:
        if self.bearer_token:
            # Bedrock API keys (bearer tokens) aren't picked up reliably by boto3's
            # control-plane "bedrock" client in all SDK versions -- call the
            # ListFoundationModels REST endpoint directly instead (same approach as
            # bedrock_router.py's bearer-token chat path).
            url = f"https://bedrock.{self.region}.amazonaws.com/foundation-models"
            try:
                response = requests.get(
                    url,
                    headers={"Authorization": f"Bearer {self.bearer_token}"},
                    timeout=15,
                )
            except requests.RequestException as e:
                raise RuntimeError(f"Could not reach Bedrock: {e}")

            if response.status_code != 200:
                raise RuntimeError(
                    f"Invalid Bedrock API key or access not enabled (HTTP {response.status_code})."
                )

            data = response.json()
            return sorted([m["modelId"] for m in data.get("modelSummaries", [])])

        try:
            client = boto3.client(
                "bedrock",
                region_name=self.region,
                aws_access_key_id=self.aws_access_key,
                aws_secret_access_key=self.aws_secret_key,
            )
            response = client.list_foundation_models()
        except (BotoCoreError, NoCredentialsError):
            raise RuntimeError("Invalid AWS credentials or Bedrock access not enabled.")

        return sorted([m["modelId"] for m in response.get("modelSummaries", [])])
