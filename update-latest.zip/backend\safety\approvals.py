# AthenaUI v3.5 — Generic Agent Action Approval
# File: backend/safety/approvals.py
#
# Two things live here:
#
# 1. Category pre-approval: lets a user grant an entire category of action
#    (e.g. "terminal") up front, so an agent working on a long task doesn't
#    have to stop and wait for an Allow/Deny click on every single dangerous
#    call. Backed by the same VaultService preference store used elsewhere
#    (e.g. build_map.py's approve_all pattern). No dedicated UI ships with
#    this change -- the full task-level pre-approval UI is later work -- but
#    the mechanism is ready to be wired to Settings or the Task Builder.
#
# 2. Helpers for turning a "this tool call needs approval" decision into a
#    pending action the existing Allow/Deny sidebar UI can render, by
#    reusing code_suite.changes.service.changeset_service (see its
#    create_tool_approval()).

from __future__ import annotations

import json
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, Optional

from vault.service import VaultService


class ApprovalRequiredError(Exception):
    """Raised by tools/executor/executor.py when a capability-flagged
    dangerous tool call needs the user to Allow/Deny it first. Caught by the
    chat engine's tool loop and surfaced as a clean tool-error message rather
    than crashing the chat turn; the actual pending action shows up in the
    sidebar via api/routes/chat.py::_build_pending_action().

    `change_id` (when present) is the code_suite changeset id of the pending
    tool_call approval that was created, so callers that raise/catch this
    synchronously (e.g. the Task Builder engine) can track exactly which
    approval a paused task is waiting on without re-parsing the message."""

    def __init__(self, message: str, change_id: Optional[str] = None):
        super().__init__(message)
        self.change_id = change_id


_PREF_KEY_PREFIX = "agent_permissions.category."

# Maps a specific tool name straight to a category. Anything not listed
# falls back to a capability-flag-based guess below.
_TOOL_CATEGORY_OVERRIDES = {
    "terminal_run": "terminal",
    "project_build_check": "terminal",
    "project_lint_test": "terminal",
}

_KNOWN_CATEGORIES = ["terminal", "network", "filesystem", "ui_automation", "brokerage", "other"]

# Public alias -- used by api/routes/tasks.py to populate the permission
# checkbox list in the Task Builder UI.
KNOWN_CATEGORIES = _KNOWN_CATEGORIES


def category_for_tool(tool_name: str, capabilities: Dict[str, Any]) -> str:
    if tool_name in _TOOL_CATEGORY_OVERRIDES:
        return _TOOL_CATEGORY_OVERRIDES[tool_name]
    if tool_name.startswith("alpaca_"):
        return "brokerage"
    if capabilities.get("needs_bridge"):
        return "ui_automation"
    if capabilities.get("needs_network"):
        return "network"
    if capabilities.get("needs_filesystem"):
        return "filesystem"
    return "other"


def is_category_preapproved(username: str, category: str) -> bool:
    return bool(VaultService.get_preference(username, f"{_PREF_KEY_PREFIX}{category}", False))


def set_category_preapproval(username: str, category: str, enabled: bool) -> None:
    if category not in _KNOWN_CATEGORIES:
        raise ValueError(f"Unknown permission category: {category}")
    VaultService.set_preference(username, f"{_PREF_KEY_PREFIX}{category}", bool(enabled))


def get_all_category_preapprovals(username: str) -> Dict[str, bool]:
    return {c: is_category_preapproved(username, c) for c in _KNOWN_CATEGORIES}


# ---------------------------------------------------------------------------
# Task-scoped permission grants.
#
# Distinct from the GLOBAL per-user preference above: these are granted once,
# at Task Builder creation time, and only apply while that specific task is
# executing (checked via safety.task_context.get_current_task_id()). This is
# what lets a user grant "network + brokerage" for one 10-hour trading task
# without permanently toggling on that category for every future chat.
# In-memory only, matching the rest of the (in-process, non-persistent) task
# engine -- cleared once a task finishes, fails, or is cancelled.
# ---------------------------------------------------------------------------

_TASK_PERMISSIONS: Dict[str, Dict[str, bool]] = {}


def set_task_permissions(task_id: str, permissions: Dict[str, bool]) -> None:
    _TASK_PERMISSIONS[task_id] = {k: bool(v) for k, v in (permissions or {}).items()}


def get_task_permissions(task_id: str) -> Dict[str, bool]:
    return dict(_TASK_PERMISSIONS.get(task_id, {}))


def is_task_category_approved(task_id: str, category: str) -> bool:
    return bool(_TASK_PERMISSIONS.get(task_id, {}).get(category, False))


def clear_task_permissions(task_id: str) -> None:
    _TASK_PERMISSIONS.pop(task_id, None)


# ---------------------------------------------------------------------------
# Session-scoped category grants ("Allow for Session").
#
# A third, lighter-weight tier between the one-off Allow/Deny click and the
# permanent per-user Settings toggle above: clicking "Allow for Session" on
# a single Allow/Deny prompt in the Code Suite sidebar approves that whole
# category (e.g. "terminal") so the agent can keep working without stopping
# for another prompt, until whichever comes first:
#   1. the user navigates away from Code Suite (frontend calls
#      /code_suite/session_approvals/clear on route change), or
#   2. the next daily 00:01 local-time reset, even if the frontend never
#      calls clear (e.g. the tab was just closed).
# Persisted to disk (mirrors code_suite/changes/service.py's ChangesetService)
# so an uvicorn --reload mid-session doesn't silently drop an active grant.
# ---------------------------------------------------------------------------

_SESSION_APPROVALS: Dict[str, Dict[str, float]] = {}
_session_approvals_loaded = False


def _session_approvals_path() -> Path:
    from core.runtime.runtime import get_runtime

    path: Path = get_runtime().env.DATA_DIR / "session_approvals.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _load_session_approvals() -> None:
    global _session_approvals_loaded
    if _session_approvals_loaded:
        return
    _session_approvals_loaded = True
    try:
        path = _session_approvals_path()
        if path.exists():
            _SESSION_APPROVALS.update(json.loads(path.read_text(encoding="utf-8")))
    except Exception:
        pass


def _persist_session_approvals() -> None:
    try:
        _session_approvals_path().write_text(
            json.dumps(_SESSION_APPROVALS, indent=2), encoding="utf-8"
        )
    except Exception:
        pass


def _next_daily_reset(now: Optional[float] = None) -> float:
    """Epoch timestamp of the next 00:01 local-time boundary strictly after
    `now` (current time if omitted) -- always the *next* occurrence, so a
    grant made at 14:00 lasts until tonight's 00:01, and one made at 23:58
    lasts only a few minutes."""
    dt = datetime.fromtimestamp(now if now is not None else time.time())
    reset_point = dt.replace(hour=0, minute=1, second=0, microsecond=0)
    if dt >= reset_point:
        reset_point += timedelta(days=1)
    return reset_point.timestamp()


def approve_category_for_session(username: str, category: str) -> float:
    """Grants `category` for the rest of this Code Suite session. Returns the
    epoch timestamp it will automatically expire at."""
    if category not in _KNOWN_CATEGORIES:
        raise ValueError(f"Unknown permission category: {category}")
    _load_session_approvals()
    expires_at = _next_daily_reset()
    _SESSION_APPROVALS.setdefault(username, {})[category] = expires_at
    _persist_session_approvals()
    return expires_at


def is_category_session_approved(username: str, category: str) -> bool:
    _load_session_approvals()
    expires_at = _SESSION_APPROVALS.get(username, {}).get(category)
    if expires_at is None:
        return False
    if time.time() >= expires_at:
        _SESSION_APPROVALS.get(username, {}).pop(category, None)
        _persist_session_approvals()
        return False
    return True


def clear_session_approvals(username: str) -> None:
    """Drops all session-scoped grants for this user -- called when the user
    navigates away from Code Suite."""
    _load_session_approvals()
    if _SESSION_APPROVALS.pop(username, None) is not None:
        _persist_session_approvals()
