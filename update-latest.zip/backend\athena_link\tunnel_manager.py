# AthenaUI — Athena Link: managed Cloudflare Quick Tunnel
# File: backend/athena_link/tunnel_manager.py
# Created: 2026-11-02 CST
#
# Spawns `cloudflared tunnel --url http://localhost:<port>` as a child
# process, parses the generated https://*.trycloudflare.com URL out of its
# stdout, and keeps it running (auto-restarting + re-detecting the URL,
# which rotates on every restart) for as long as the user has it enabled --
# so nobody has to run cloudflared by hand or re-paste a new address every
# time a quick tunnel drops. No Cloudflare account is required for this;
# see cloudflared's own disclaimer (no uptime guarantee) printed at startup.
#
# Process-global singleton (one tunnel per backend instance), matching the
# style of other singletons in this codebase (SystemVault, VaultService).

from __future__ import annotations

import re
import shutil
import subprocess
import threading
import time
from pathlib import Path
from typing import Callable, Optional

from core.env.env_loader import Env

from .network import BACKEND_PORT

_URL_RE = re.compile(r"https://[a-z0-9-]+\.trycloudflare\.com")
_RESTART_CHECK_SECONDS = 5


class TunnelError(Exception):
    pass


def find_cloudflared() -> str:
    """Looks for the cloudflared binary: an explicit override, then next
    to this install's own backend/frontend/athena_bridge trees (where a
    future packaged build would ship it as a bundled resource), then
    whatever's on PATH."""
    import os

    override = os.environ.get("ATHENAUI_CLOUDFLARED_PATH")
    if override and Path(override).exists():
        return override

    bundled = Env.ROOT_DIR / "cloudflared.exe"
    if bundled.exists():
        return str(bundled)

    found = shutil.which("cloudflared")
    if found:
        return found

    raise TunnelError(
        "cloudflared.exe was not found. Download it from "
        "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe "
        f"and place it at {Env.ROOT_DIR / 'cloudflared.exe'}, or set ATHENAUI_CLOUDFLARED_PATH."
    )


class _TunnelState:
    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.proc: Optional[subprocess.Popen] = None
        self.url: Optional[str] = None
        self.wanted = False
        self.monitor_thread: Optional[threading.Thread] = None
        self.on_url_change: Optional[Callable[[str], None]] = None


_state = _TunnelState()


def _reader_loop(proc: subprocess.Popen) -> None:
    assert proc.stdout is not None
    for raw_line in iter(proc.stdout.readline, b""):
        line = raw_line.decode("utf-8", errors="replace")
        match = _URL_RE.search(line)
        if not match:
            continue
        url = match.group(0)
        with _state.lock:
            if _state.url == url:
                continue
            _state.url = url
            callback = _state.on_url_change
        if callback:
            callback(url)


def _spawn() -> None:
    cloudflared_path = find_cloudflared()
    proc = subprocess.Popen(
        [cloudflared_path, "tunnel", "--url", f"http://localhost:{BACKEND_PORT}"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )
    with _state.lock:
        _state.proc = proc
        _state.url = None
    threading.Thread(target=_reader_loop, args=(proc,), daemon=True).start()


def _monitor_loop() -> None:
    while True:
        time.sleep(_RESTART_CHECK_SECONDS)
        with _state.lock:
            wanted = _state.wanted
            proc = _state.proc
        if not wanted:
            continue
        if proc is None or proc.poll() is not None:
            try:
                _spawn()
            except TunnelError:
                # Binary went missing mid-run (unlikely) -- stop trying
                # until the user explicitly starts it again.
                with _state.lock:
                    _state.wanted = False


def start(on_url_change: Optional[Callable[[str], None]] = None) -> None:
    """Idempotent: if already running, just updates the callback."""
    with _state.lock:
        _state.wanted = True
        _state.on_url_change = on_url_change
        already_running = _state.proc is not None and _state.proc.poll() is None
        needs_monitor = _state.monitor_thread is None or not _state.monitor_thread.is_alive()

    if not already_running:
        _spawn()

    if needs_monitor:
        thread = threading.Thread(target=_monitor_loop, daemon=True)
        thread.start()
        with _state.lock:
            _state.monitor_thread = thread


def stop() -> None:
    with _state.lock:
        _state.wanted = False
        proc = _state.proc
        _state.proc = None
        _state.url = None
    if proc and proc.poll() is None:
        proc.terminate()


def status() -> dict:
    with _state.lock:
        running = _state.proc is not None and _state.proc.poll() is None
        return {"running": running, "url": _state.url}
