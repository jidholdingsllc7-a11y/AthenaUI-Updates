# AthenaUI v3.5 — Maximos Memory Server LLM Proxy
# File: backend/api/routes/maximos.py
#
# Lets the (separately-installed) Maximos Memory Server generate AI chat
# summaries (for /import and /restore's summary-backfill) through AthenaUI's
# already-configured provider/API key instead of needing its own hardcoded
# OPENAI_API_KEY. Once a user has set up a chat provider in AthenaUI, MMS
# automatically gets summaries "for free" -- no separate key to manage, lose,
# or accidentally expose.
#
# Trust model: this endpoint has no AthenaUI user session (MMS has no login
# token), so it's gated instead by a random local shared secret, auto-
# generated on first use and persisted at a fixed, well-known path
# (`%APPDATA%\AthenaUI\keys\mms_proxy_key.txt`) -- MMS discovers the same
# file the same way AthenaUI already discovers MMS's own global API key
# (see chat/memory/maximos_client.py's `_discover_global_key`). Also rejects
# any request that didn't originate from localhost, as defense in depth
# (the dev server binds 0.0.0.0, so this isn't implied by the port alone).

from __future__ import annotations

import os
import secrets
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from characters.backstory_engine.generator import call_llm

router = APIRouter(prefix="/maximos", tags=["maximos"])

_LOOPBACK_HOSTS = {"127.0.0.1", "::1", "localhost"}


def _proxy_key_path() -> Path:
    appdata = os.environ.get("APPDATA", str(Path.home()))
    return Path(appdata) / "AthenaUI" / "keys" / "mms_proxy_key.txt"


def _get_or_create_proxy_key() -> str:
    path = _proxy_key_path()
    try:
        existing = path.read_text(encoding="utf-8").strip()
        if existing:
            return existing
    except OSError:
        pass

    key = secrets.token_hex(32)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(key, encoding="utf-8")
    return key


class MmsCompleteRequest(BaseModel):
    username: str
    user_content: str
    system_prompt: Optional[str] = None


@router.post("/complete")
def mms_complete(body: MmsCompleteRequest, request: Request):
    """
    One-off, tool-free chat completion run on behalf of `username`, using
    whatever chat provider/key that user already has configured in AthenaUI.
    Called by the Maximos Memory Server's import/restore summary generation
    -- never by the frontend.
    """
    client_host = request.client.host if request.client else None
    if client_host not in _LOOPBACK_HOSTS:
        raise HTTPException(status_code=403, detail="This endpoint only accepts local requests.")

    presented = request.headers.get("x-mms-proxy-key", "")
    expected = _get_or_create_proxy_key()
    if not presented or not secrets.compare_digest(presented, expected):
        raise HTTPException(status_code=401, detail="Invalid or missing X-MMS-Proxy-Key.")

    try:
        content = call_llm(body.user_content, body.username, system_prompt=body.system_prompt)
    except RuntimeError as e:
        # No chat provider/key configured yet for this user -- MMS treats
        # this the same as its old "OPENAI_API_KEY not configured" soft
        # fail (summaries just won't be generated this time, nothing breaks).
        raise HTTPException(status_code=503, detail=str(e)) from e

    return {"content": content}
