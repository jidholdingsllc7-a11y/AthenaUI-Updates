# AthenaUI v3.5 — Image Analyze Tool
# File: backend/tools/system/images/image_analyze.py
# Purpose: Lets an agent actually LOOK AT and describe one of their own
# existing saved photos (not generate a new one), via a real vision-capable
# model call. Complements image_gallery_list, which only lists paths/
# metadata -- this is the piece that was missing for characters who could
# generate new photos but couldn't analyze/react to existing ones.
# Created: 2026-08-06

import base64
from pathlib import Path
from typing import Any, Dict, Optional

from characters.system.gallery import list_character_gallery

capabilities = {
    "needs_bridge": False,
    "needs_filesystem": True,
    "needs_network": True,
    "needs_user": True,
}


def _most_recent_image(gallery: dict) -> Optional[str]:
    for cat in ("modern", "pair", "pets", "images"):
        images = gallery.get(cat) or []
        if images:
            return images[-1]
    return None


async def run(args: Dict[str, Any]):
    username = args.get("username", "system")
    character = args.get("character") or args.get("character_id")
    image_path = args.get("image_path")
    question = args.get("question") or (
        "Describe this photo in detail -- who/what is in it, the setting, mood, and clothing."
    )

    if not character:
        return {"error": "Missing character for image analysis"}

    if not image_path:
        gallery = list_character_gallery(username, character)
        image_path = _most_recent_image(gallery)
        if not image_path:
            return {"chat_message": "I don't have any saved photos yet to look at."}

    # image_path looks like "/data/users/<u>/characters/<c>/gallery/<cat>/<file>"
    rel = image_path.lstrip("/")
    if rel.startswith("data/"):
        rel = rel[len("data/"):]
    file_path = Path("data") / rel
    if not file_path.is_file():
        return {"error": f"Image not found: {image_path}"}

    ext = file_path.suffix.lstrip(".").lower() or "png"
    data_uri = f"data:image/{ext};base64,{base64.b64encode(file_path.read_bytes()).decode('ascii')}"

    # Imported lazily to avoid a circular import (chat.engine.service ->
    # chat.tools.executor -> tools.registry.loader -> this module at
    # package-load time).
    from chat.engine.service import ChatEngine

    engine = ChatEngine(username)
    try:
        # Uses the dedicated "analyze" pipeline (Settings -> Image Analysis)
        # so this works regardless of whether the user's chosen chat model
        # itself supports vision -- falls back to the chat model/provider
        # automatically when no dedicated analyze model has been configured.
        provider_id, model_id = engine._get_active_analyze_model()
        api_key = engine._get_api_key(provider_id, category="analyze")
        engine._inject_provider_api_key(provider_id, api_key, category="analyze")
        router = engine.router_selector.select(provider_id=provider_id, model_id=model_id, mode="chat")
        response = router.chat([
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": question},
                    {"type": "image_url", "image_url": {"url": data_uri}},
                ],
            }
        ])
    except Exception as e:
        return {
            "error": str(e),
            "chat_message": (
                "I tried to actually look at the photo but couldn't -- my current "
                "model/provider may not support vision (try a gpt-4o-family or "
                "other vision-capable model in Settings)."
            ),
        }

    description = ChatEngine._normalize_assistant_text(response) if isinstance(response, dict) else str(response)
    return {"image_path": image_path, "description": description, "chat_message": description}
