# AthenaUI v3.5 — marketing_tip_search Tool
# File: backend/tools/marketing/marketing_tip_search.py
#
# STEP 1 tool for marketing work -- checks the shared marketing tips library
# before you use the CRM/newsletter/SMS/call tools, in case another AI
# already figured out the best way to do it.

from typing import Any, Dict

from marketing_tips.service import MarketingTipsError, search_tips

capabilities = {
    "needs_filesystem": True,
    "needs_bridge": False,
    "needs_network": False,
    "needs_user": True,
}


async def run(args: Dict[str, Any]) -> str:
    try:
        username = args.get("username")
        if not username:
            return "[ERROR] Missing 'username' argument."

        tips = search_tips(
            username,
            query=args.get("query"),
            tags=args.get("tags"),
            tool_name=args.get("tool_name"),
            limit=args.get("limit", 10),
        )
        if not tips:
            return "No matching tips found in the marketing tips library yet."

        lines = [f"Found {len(tips)} tip(s):"]
        for t in tips:
            tag_str = f" [tags: {t['tags']}]" if t.get("tags") else ""
            tool_str = f" (tool: {t['tool_name']})" if t.get("tool_name") else ""
            lines.append(f"- {t['title']}{tool_str}{tag_str}: {t['tip']}")
        return "\n".join(lines)
    except MarketingTipsError as e:
        return f"[ERROR] {e}"
    except Exception as e:
        return f"[ERROR] Failed to search marketing tips: {str(e)}"
