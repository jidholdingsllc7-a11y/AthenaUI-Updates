# AthenaUI — Athena Link API Routes
# File: backend/api/routes/athena_link.py
# Created: 2026-11-02 11:18 CST
# Updated: 2026-11-02 11:18 CST

from __future__ import annotations

import asyncio

from fastapi import APIRouter, Body, Depends, HTTPException

from api.deps.auth_middleware import get_current_user
from athena_link.service import AthenaLinkError, AthenaLinkService

router = APIRouter(prefix="/athena_link", tags=["athena_link"])


def _username_from_user(user) -> str:
    username = user.get("username") if isinstance(user, dict) else getattr(user, "username", None)
    if not username:
        raise HTTPException(status_code=401, detail="Authentication required.")
    return str(username)


@router.get("/status")
async def status(user=Depends(get_current_user)):
    username = _username_from_user(user)
    return AthenaLinkService.get_status(username)


@router.get("/lan_address")
async def lan_address(user=Depends(get_current_user)):
    _username_from_user(user)
    return {"address": AthenaLinkService.get_lan_address()}


@router.post("/tunnel/start")
async def start_tunnel(user=Depends(get_current_user)):
    username = _username_from_user(user)
    try:
        return await asyncio.to_thread(AthenaLinkService.start_auto_tunnel, username)
    except AthenaLinkError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/tunnel/status")
async def tunnel_status(user=Depends(get_current_user)):
    _username_from_user(user)
    return AthenaLinkService.get_tunnel_status()


@router.post("/tunnel/stop")
async def stop_tunnel(user=Depends(get_current_user)):
    username = _username_from_user(user)
    return AthenaLinkService.stop_auto_tunnel(username)


@router.post("/register")
async def register(payload: dict = Body(...), user=Depends(get_current_user)):
    username = _username_from_user(user)
    link_username = str(payload.get("link_username", "")).strip()
    passphrase = str(payload.get("passphrase", ""))
    if not link_username:
        raise HTTPException(status_code=400, detail="link_username is required")
    try:
        return AthenaLinkService.register_or_link(username, link_username, passphrase)
    except AthenaLinkError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/enable")
async def enable(payload: dict = Body(...), user=Depends(get_current_user)):
    username = _username_from_user(user)
    enabled = bool(payload.get("enabled"))
    try:
        return AthenaLinkService.set_enabled(username, enabled)
    except AthenaLinkError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/address")
async def set_address(payload: dict = Body(...), user=Depends(get_current_user)):
    username = _username_from_user(user)
    address = str(payload.get("address", ""))
    try:
        return AthenaLinkService.set_address(username, address)
    except AthenaLinkError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/install_name")
async def set_install_name(payload: dict = Body(...), user=Depends(get_current_user)):
    username = _username_from_user(user)
    name = str(payload.get("name", ""))
    try:
        return AthenaLinkService.set_install_name(username, name)
    except AthenaLinkError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/heartbeat")
async def heartbeat(user=Depends(get_current_user)):
    username = _username_from_user(user)
    try:
        return AthenaLinkService.send_heartbeat(username)
    except AthenaLinkError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/resolve/{link_username}")
async def resolve(link_username: str, user=Depends(get_current_user)):
    try:
        return AthenaLinkService.resolve(link_username)
    except AthenaLinkError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/agents")
async def list_agents(user=Depends(get_current_user)):
    """Local characters eligible for cross-install export (for this
    install's own Settings UI, e.g. picking which agent to pull FROM
    another install -- the remote install's own roster is fetched via
    `import_agent`'s resolve step, not this route)."""
    username = _username_from_user(user)
    return {"agents": AthenaLinkService.list_local_agents(username)}


@router.get("/remote_agents")
async def list_remote_agents(source_address: str | None = None, user=Depends(get_current_user)):
    """Asks another install sharing this identity what characters it has
    available to import from."""
    username = _username_from_user(user)
    try:
        return {"agents": AthenaLinkService.list_remote_agents(username, source_address)}
    except AthenaLinkError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/agents/{character_name}/import")
async def import_agent(character_name: str, payload: dict = Body(default={}), user=Depends(get_current_user)):
    username = _username_from_user(user)
    source_address = payload.get("source_address") if isinstance(payload, dict) else None
    try:
        return AthenaLinkService.import_agent(username, character_name, source_address)
    except AthenaLinkError as e:
        raise HTTPException(status_code=400, detail=str(e))


# ---------------------------------------------------------
# Peer-to-peer routes -- called directly by ANOTHER install sharing this
# same Athena Link identity, never through a normal browser session (no
# Depends(get_current_user) here; authentication is the Ed25519 signature
# itself, verified against this install's own stored public key).
# ---------------------------------------------------------


@router.post("/remote/agents")
async def remote_list_agents(payload: dict = Body(...)):
    link_username = str(payload.get("link_username", ""))
    timestamp = payload.get("timestamp")
    signature = str(payload.get("signature", ""))
    try:
        app_username = AthenaLinkService.verify_peer_request(
            link_username, timestamp, signature, ["link:agents:list", link_username, timestamp]
        )
    except AthenaLinkError as e:
        raise HTTPException(status_code=401, detail=str(e))
    return {"agents": AthenaLinkService.list_local_agents(app_username)}


@router.post("/remote/agents/{character_name}/export")
async def remote_export_agent(character_name: str, payload: dict = Body(...)):
    link_username = str(payload.get("link_username", ""))
    timestamp = payload.get("timestamp")
    signature = str(payload.get("signature", ""))
    try:
        app_username = AthenaLinkService.verify_peer_request(
            link_username,
            timestamp,
            signature,
            ["link:agents:export", link_username, character_name, timestamp],
        )
    except AthenaLinkError as e:
        raise HTTPException(status_code=401, detail=str(e))
    try:
        return {"blob": AthenaLinkService.export_agent_bundle(app_username, character_name)}
    except AthenaLinkError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/remote/agents/{character_name}/receive_memory")
async def remote_receive_memory(character_name: str, payload: dict = Body(...)):
    """Reciprocal half of import_agent's two-way sync: the OTHER install
    pushes its own (just-merged) memory bundle here so this install ends
    up with the same union, not just whatever it pulled."""
    link_username = str(payload.get("link_username", ""))
    timestamp = payload.get("timestamp")
    signature = str(payload.get("signature", ""))
    blob = str(payload.get("blob", ""))
    try:
        app_username = AthenaLinkService.verify_peer_request(
            link_username,
            timestamp,
            signature,
            ["link:agents:receive_memory", link_username, character_name, timestamp],
        )
    except AthenaLinkError as e:
        raise HTTPException(status_code=401, detail=str(e))
    try:
        return AthenaLinkService.receive_memory_push(app_username, character_name, blob)
    except AthenaLinkError as e:
        raise HTTPException(status_code=400, detail=str(e))
