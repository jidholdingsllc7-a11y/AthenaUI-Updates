﻿# AthenaUI v3.5 — System Vault
# File: backend/system_vault/system_vault.py
# Created: 2026-07-17 14:58 MTZ
# Updated: 2026-07-30 22:11 CDT

import json
import re
import sqlite3
from pathlib import Path
from typing import Any, Optional, Tuple

from utils.crypto.encryption import load_or_create_master_key, encrypt_value, decrypt_value
from core.env.env_loader import Env

# Legacy plaintext seed file ships (if at all) next to this module inside the
# install directory -- read-only migration source, never written back to.
BASE_DIR = Path(__file__).resolve().parent
PLAINTEXT_PATH = BASE_DIR / "system_secrets.json"

# The encrypted DB + its DPAPI-protected master key must live in the writable
# per-user root, not next to this module -- a packaged install's own
# directory (Program Files) isn't writable by a standard user.
WRITABLE_DIR = Env.WRITABLE_ROOT / "system_vault"
DB_PATH = WRITABLE_DIR / "system_secrets.db"

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS system_secrets (
    key TEXT PRIMARY KEY,
    value BLOB NOT NULL
);
"""


class SystemVault:
    """
    Global, installer-provisioned secrets (default LLM/voice provider
    keys, etc.) -- distinct from the per-user Vault. Uses the SAME
    storage engine as the per-user vault (SQLite + AES-256-GCM +
    DPAPI-protected master key, see vault/controller.py and
    utils/crypto/encryption.py) so there is only one encryption
    implementation in the app, just a single flat key/value table here
    instead of per-user normalized tables, since this store is
    installer-written and read-mostly at runtime.

    One-time migration: if no system_secrets.db exists yet but a
    legacy plaintext system_secrets.json is present, its contents are
    imported into the encrypted database the first time the vault is
    opened. After that, system_secrets.json is never read again --
    delete it (it should never ship in a build or be committed to
    source control).
    """

    @classmethod
    def _connect(cls) -> Tuple[sqlite3.Connection, bytes]:
        WRITABLE_DIR.mkdir(parents=True, exist_ok=True)
        is_new = not DB_PATH.exists()
        master_key = load_or_create_master_key(WRITABLE_DIR)

        conn = sqlite3.connect(str(DB_PATH))
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.executescript(_SCHEMA_SQL)

        if is_new:
            cls._import_plaintext(conn, master_key)

        return conn, master_key

    @staticmethod
    def _import_plaintext(conn: sqlite3.Connection, master_key: bytes) -> None:
        """
        One-time seed of the new encrypted DB from the legacy plaintext
        system_secrets.json, if present. No-op if that file doesn't exist.
        """
        if not PLAINTEXT_PATH.exists():
            return

        try:
            raw = PLAINTEXT_PATH.read_text(encoding="utf-8")
            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                # Development resilience: tolerate trailing commas in JSON.
                sanitized = re.sub(r",\s*([}\]])", r"\1", raw)
                data = json.loads(sanitized)
        except Exception:
            return

        if not isinstance(data, dict):
            return

        for key, value in data.items():
            conn.execute(
                "INSERT OR REPLACE INTO system_secrets (key, value) VALUES (?, ?)",
                (key, encrypt_value(value, master_key)),
            )
        conn.commit()

    @classmethod
    def load(cls) -> dict:
        """
        Returns the full system vault as a plain (decrypted) dict.
        """
        conn, master_key = cls._connect()
        try:
            rows = conn.execute("SELECT key, value FROM system_secrets").fetchall()
            return {row["key"]: decrypt_value(row["value"], master_key) for row in rows}
        finally:
            conn.close()

    @classmethod
    def get(cls, key: str, default: Any = None) -> Any:
        conn, master_key = cls._connect()
        try:
            row = conn.execute("SELECT value FROM system_secrets WHERE key=?", (key,)).fetchone()
            if not row:
                return default
            return decrypt_value(row["value"], master_key, default)
        finally:
            conn.close()

    @classmethod
    def set(cls, key: str, value: Any) -> None:
        """
        Sets/updates a single system secret (single-row upsert, e.g. for
        rotating the default provider API key). Intended for
        installer/admin use, not end-user-facing request paths.
        """
        conn, master_key = cls._connect()
        try:
            conn.execute(
                "INSERT INTO system_secrets (key, value) VALUES (?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, encrypt_value(value, master_key)),
            )
            conn.commit()
        finally:
            conn.close()

