﻿# AthenaUI v3.5 — Build Map Service
# File: backend/code_suite/build_map/service.py
# Created: 2026-04-09 16:53 CDT
# Updated: 2026-07-27 19:49 CDT

import json
import os
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from pydantic import BaseModel, Field, validator


# ---------------------------------------------------------
# Build Map Schema (v1.0)
# ---------------------------------------------------------

class BuildMapProject(BaseModel):
    id: str
    name: str
    description: str
    workspace_root: str  # always relative


class BuildMapConstraint(BaseModel):
    languages: List[str] = []
    frameworks: List[str] = []
    max_file_lines: int = 300
    avoid_absolute_paths: bool = True
    notes: Optional[str] = None


class BuildMapModule(BaseModel):
    name: str
    description: str
    responsibilities: List[str] = []
    dependencies: List[str] = []


class BuildMapArchitecture(BaseModel):
    overview: str
    modules: List[BuildMapModule] = []


class BuildMapDirectory(BaseModel):
    path: str
    description: Optional[str] = None
    children: Optional[List["BuildMapDirectory"]] = None


BuildMapDirectory.update_forward_refs()


class BuildMapFile(BaseModel):
    path: str
    purpose: str
    module: Optional[str] = None
    depends_on: List[str] = []
    initial_content: Optional[str] = None

    @validator("path")
    def prevent_absolute_file_paths(cls, v):
        if os.path.isabs(v):
            raise ValueError(f"File path '{v}' must be relative, not absolute.")
        return v


class BuildMapStep(BaseModel):
    step_id: str
    description: str
    files_created: List[str] = []


class BuildMapExecutionRules(BaseModel):
    create_missing_directories: bool = True
    overwrite_existing_files: bool = False
    validate_dependencies: bool = True
    stop_on_error: bool = True


class BuildMapVerification(BaseModel):
    checks: List[str] = []


class BuildMap(BaseModel):
    version: str = "1.0"
    project: BuildMapProject
    constraints: BuildMapConstraint
    architecture: BuildMapArchitecture
    directory_tree: List[BuildMapDirectory]
    files: List[BuildMapFile]
    build_order: List[BuildMapStep]
    execution_rules: BuildMapExecutionRules
    verification: BuildMapVerification

    @validator("project")
    def ensure_relative_workspace(cls, v):
        if os.path.isabs(v.workspace_root):
            raise ValueError("workspace_root must be relative, not absolute.")
        return v


# ---------------------------------------------------------
# Build Map Service
# ---------------------------------------------------------

class BuildMapService:
    """
    Handles creation, loading, updating, validation, execution,
    and verification of Build Maps inside the user's workspace.
    """

    BUILD_MAP_FILENAME = "build_map.json"

    def __init__(self, workspace_root: str):
        self.workspace_root = Path(workspace_root).resolve()
        self.athena_dir = self.workspace_root / ".athena"
        self.athena_dir.mkdir(parents=True, exist_ok=True)

        self.build_map_path = self.athena_dir / self.BUILD_MAP_FILENAME

    def _safe_path(self, rel_path: str) -> Path:
        """
        Resolve rel_path against workspace_root and verify it doesn't escape
        the workspace. The BuildMapFile validator only rejects OS-absolute
        paths (os.path.isabs) -- it does NOT catch relative traversal like
        "../../Windows/System32/evil.dll", and BuildMapDirectory.path has no
        validator at all. Since build map JSON content is agent-supplied,
        this containment check is required at execution time.
        """
        candidate = (self.workspace_root / rel_path).resolve()
        try:
            is_inside = candidate == self.workspace_root or candidate.is_relative_to(self.workspace_root)
        except AttributeError:
            is_inside = candidate == self.workspace_root or self.workspace_root in candidate.parents
        if not is_inside:
            raise ValueError(f"Path escapes workspace root: {rel_path}")
        return candidate

    # -----------------------------------------------------
    # CRUD
    # -----------------------------------------------------

    def save(self, build_map: BuildMap):
        with open(self.build_map_path, "w", encoding="utf-8") as f:
            json.dump(build_map.dict(), f, indent=2)

    def load(self) -> Optional[BuildMap]:
        if not self.build_map_path.exists():
            return None
        with open(self.build_map_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return BuildMap(**data)

    # -----------------------------------------------------
    # Build log (durable, survives backend restarts/resume)
    # -----------------------------------------------------

    BUILD_LOG_FILENAME = "build_log.txt"

    def append_build_log(self, message: str) -> None:
        """Append one timestamped line to .athena/build_log.txt so the full
        build history (dev or final) is inspectable on disk even after a
        resume or a backend restart, not just in the in-memory progress
        tail log."""
        from datetime import datetime as _dt

        log_path = self.athena_dir / self.BUILD_LOG_FILENAME
        line = f"[{_dt.utcnow().isoformat()}Z] {message}\n"
        try:
            with open(log_path, "a", encoding="utf-8") as f:
                f.write(line)
        except Exception:
            # Logging must never break a build.
            pass

    def read_build_log(self, max_chars: int = 20000) -> str:
        log_path = self.athena_dir / self.BUILD_LOG_FILENAME
        if not log_path.exists():
            return ""
        try:
            text = log_path.read_text(encoding="utf-8")
        except Exception:
            return ""
        if len(text) > max_chars:
            return text[-max_chars:]
        return text

    def create(self, data: Dict[str, Any]) -> BuildMap:
        build_map = BuildMap(**data)
        self.save(build_map)
        return build_map

    def update(self, updates: Dict[str, Any]) -> BuildMap:
        existing = self.load()
        if not existing:
            raise RuntimeError("No existing Build Map to update.")

        updated = existing.copy(update=updates)
        self.save(updated)
        return updated

    def apply_edit(self, edit: Dict[str, Any]) -> BuildMap:
        """Applies a PARTIAL, line-level edit to the existing Build Map
        instead of requiring the whole plan to be resent every time (which
        is what `update()`/`create()` above still do for whole top-level
        fields like `files` -- replacing the entire list even to change one
        entry). `edit` is a dict where every key is optional -- only send
        what's actually changing:
            {
              "set": {
                  "project": {...partial fields, shallow-merged...},
                  "constraints": {...partial fields, shallow-merged...},
                  "execution_rules": {...partial fields, shallow-merged...},
                  "architecture_overview": "...",
              },
              "files_upsert": [BuildMapFile-shaped dicts, matched/replaced by "path"],
              "files_remove": ["path", ...],
              "modules_upsert": [BuildMapModule-shaped dicts, matched/replaced by "name"],
              "modules_remove": ["name", ...],
              "directories_upsert": [BuildMapDirectory-shaped dicts, matched/replaced
                  by "path" -- TOP-LEVEL directory_tree entries only; to edit a nested
                  directory, resend its top-level ancestor's entry with the updated
                  "children" subtree],
              "directories_remove": ["path", ...],
              "build_order_upsert": [BuildMapStep-shaped dicts, matched/replaced by "step_id"],
              "build_order_remove": ["step_id", ...],
              "verification_checks_add": ["..."],
              "verification_checks_remove": ["..."],
            }
        Existing entries not mentioned in an upsert/remove list are left
        exactly as they are (not duplicated, not dropped) -- this is what
        makes it a real incremental edit instead of a full replace. Raises
        RuntimeError if there's no existing Build Map to edit."""
        existing = self.load()
        if not existing:
            raise RuntimeError("No existing Build Map to edit -- create one first.")

        data = existing.dict()

        set_block = edit.get("set") if isinstance(edit.get("set"), dict) else {}
        if isinstance(set_block.get("project"), dict):
            data["project"] = {**data["project"], **set_block["project"]}
        if isinstance(set_block.get("constraints"), dict):
            data["constraints"] = {**data["constraints"], **set_block["constraints"]}
        if isinstance(set_block.get("execution_rules"), dict):
            data["execution_rules"] = {**data["execution_rules"], **set_block["execution_rules"]}
        if isinstance(set_block.get("architecture_overview"), str):
            data["architecture"]["overview"] = set_block["architecture_overview"]

        def _upsert_by_key(items: Any, upserts: Any, remove: Any, key: str) -> List[Dict[str, Any]]:
            by_key: Dict[Any, Dict[str, Any]] = {}
            for item in (items or []):
                if isinstance(item, dict) and item.get(key) is not None:
                    by_key[item[key]] = item
            if isinstance(upserts, list):
                for entry in upserts:
                    if isinstance(entry, dict) and entry.get(key) is not None:
                        by_key[entry[key]] = entry
            if isinstance(remove, list):
                for k in remove:
                    by_key.pop(k, None)
            return list(by_key.values())

        data["files"] = _upsert_by_key(data.get("files"), edit.get("files_upsert"), edit.get("files_remove"), "path")
        data["architecture"]["modules"] = _upsert_by_key(
            data.get("architecture", {}).get("modules"), edit.get("modules_upsert"), edit.get("modules_remove"), "name",
        )
        data["directory_tree"] = _upsert_by_key(
            data.get("directory_tree"), edit.get("directories_upsert"), edit.get("directories_remove"), "path",
        )
        data["build_order"] = _upsert_by_key(
            data.get("build_order"), edit.get("build_order_upsert"), edit.get("build_order_remove"), "step_id",
        )

        checks = list(data.get("verification", {}).get("checks") or [])
        for c in (edit.get("verification_checks_add") or []):
            if c not in checks:
                checks.append(c)
        remove_checks = set(edit.get("verification_checks_remove") or [])
        if remove_checks:
            checks = [c for c in checks if c not in remove_checks]
        data.setdefault("verification", {})["checks"] = checks

        updated = BuildMap(**data)
        self.save(updated)
        return updated

    # -----------------------------------------------------
    # Execution Engine (Full Version)
    # -----------------------------------------------------

    def execute(self, progress_callback: Optional[Callable[[str, Dict[str, Any]], None]] = None, phase: str = "all") -> Dict[str, Any]:
        """
        Execute build based on phase:
        - 'create_dirs': Create all directories only
        - 'create_files': Create empty files only
        - 'populate_content': Populate file content only
        - 'all': Do all phases (legacy behavior)
        """
        build_map = self.load()
        if not build_map:
            raise RuntimeError("No Build Map found to execute.")

        results: Dict[str, Any] = {
            "phase": phase,
            "created_directories": [],
            "created_files": [],
            "populated_files": [],
            "skipped_files": [],
            "errors": [],
        }

        def emit(action: str, payload: Dict[str, Any]) -> None:
            if progress_callback:
                progress_callback(action, payload)

        # Phase 1: Create directories
        if phase in ("create_dirs", "all"):
            for entry in build_map.directory_tree:
                self._create_directory_recursive(entry, results, progress_callback=progress_callback)
                if results["errors"] and build_map.execution_rules.stop_on_error:
                    if phase == "create_dirs":
                        return results
                    break
            if phase == "create_dirs":
                return results

        # Phase 2: Create empty files
        if phase in ("create_files", "all"):
            file_index: Dict[str, BuildMapFile] = {f.path: f for f in build_map.files}
            for file_meta in build_map.files:
                try:
                    abs_path = self._safe_path(file_meta.path)
                    abs_path.parent.mkdir(parents=True, exist_ok=True)
                    
                    if abs_path.exists() and abs_path.is_file():
                        results["skipped_files"].append(file_meta.path)
                        emit("file_skipped", {"path": file_meta.path, "absolute_path": str(abs_path.resolve())})
                        continue
                    
                    abs_path.write_text("", encoding="utf-8")
                    results["created_files"].append(file_meta.path)
                    emit("file_created_empty", {"path": file_meta.path, "absolute_path": str(abs_path.resolve())})
                
                except Exception as e:
                    error_message = f"Error creating empty file '{file_meta.path}': {e}"
                    results["errors"].append(error_message)
                    emit("file_error", {"path": file_meta.path, "error": error_message})
                    if build_map.execution_rules.stop_on_error:
                        return results
            
            if phase == "create_files":
                return results

        # Phase 3: Populate file content
        if phase in ("populate_content", "all"):
            for file_meta in build_map.files:
                result = self.populate_single_file(build_map, file_meta)
                status = result["status"]
                if status == "populated":
                    results["populated_files"].append(file_meta.path)
                    emit("file_content_populated", result["payload"])
                elif status == "skipped":
                    results["skipped_files"].append(file_meta.path)
                    emit("file_content_skipped", result["payload"])
                else:
                    results["errors"].append(result["payload"]["error"])
                    emit("file_error", result["payload"])
                    if build_map.execution_rules.stop_on_error:
                        return results
        
        return results

    def populate_single_file(self, build_map: BuildMap, file_meta: BuildMapFile) -> Dict[str, Any]:
        """Writes one file's already-generated `initial_content` to disk,
        honoring the same skip/overwrite rules as the batch `populate_content`
        phase above. Used for a cancellable, incremental one-file-at-a-time
        build pass instead of writing every file in one uninterruptible
        sweep."""
        try:
            abs_path = self._safe_path(file_meta.path)
            initial_content = file_meta.initial_content or ""

            if not initial_content or not str(initial_content).strip():
                return {
                    "status": "skipped",
                    "payload": {"path": file_meta.path, "reason": "No content available"},
                }

            if not abs_path.exists():
                abs_path.parent.mkdir(parents=True, exist_ok=True)
                abs_path.write_text("", encoding="utf-8")

            if not build_map.execution_rules.overwrite_existing_files:
                existing = abs_path.read_text(encoding="utf-8") if abs_path.exists() else ""
                if existing and existing.strip():
                    return {
                        "status": "skipped",
                        "payload": {"path": file_meta.path, "reason": "File already has content"},
                    }

            abs_path.write_text(initial_content, encoding="utf-8")
            return {
                "status": "populated",
                "payload": {
                    "path": file_meta.path,
                    "absolute_path": str(abs_path.resolve()),
                    "content_length": len(initial_content),
                },
            }
        except Exception as e:
            error_message = f"Error populating content for '{file_meta.path}': {e}"
            return {
                "status": "error",
                "payload": {"path": file_meta.path, "error": error_message},
            }

    # -----------------------------------------------------
    # Verification
    # -----------------------------------------------------

    def verify(self) -> Dict[str, Any]:
        """
        Lightweight verification pass:
        - Ensures all files_created exist.
        - Ensures no absolute paths slipped in.
        - Ensures .athena/build_map.json is consistent with the tree.
        """
        build_map = self.load()
        if not build_map:
            return {"ok": False, "errors": ["No Build Map found."]}

        errors = []
        warnings = []
        ok = True

        # 1. Check .athena and build_map.json
        if not self.athena_dir.exists():
            ok = False
            errors.append(".athena directory is missing.")

        if not self.build_map_path.exists():
            ok = False
            errors.append("build_map.json is missing.")

        # 2. Check for absolute paths
        if os.path.isabs(build_map.project.workspace_root):
            ok = False
            errors.append("workspace_root is absolute — must be relative.")

        for f in build_map.files:
            if os.path.isabs(f.path):
                ok = False
                errors.append(f"Absolute file path detected: {f.path}")

        for step in build_map.build_order:
            for p in step.files_created:
                if os.path.isabs(p):
                    ok = False
                    errors.append(f"Absolute path in build_order: {p}")

        # 3. Check that all files_created exist
        for step in build_map.build_order:
            for rel_path in step.files_created:
                try:
                    abs_path = self._safe_path(rel_path)
                except ValueError as e:
                    ok = False
                    errors.append(str(e))
                    continue
                if not abs_path.exists():
                    ok = False
                    errors.append(f"Missing file: {rel_path}")

        # 4. Check directory tree consistency
        for entry in build_map.directory_tree:
            self._verify_directory_recursive(entry, errors)

        return {
            "ok": ok,
            "errors": errors,
            "warnings": warnings,
        }

    def _verify_directory_recursive(self, entry: BuildMapDirectory, errors: List[str]):
        try:
            abs_path = self._safe_path(entry.path)
        except ValueError as e:
            errors.append(str(e))
            return
        if not abs_path.exists():
            errors.append(f"Missing directory: {entry.path}")

        if entry.children:
            for child in entry.children:
                self._verify_directory_recursive(child, errors)

    # -----------------------------------------------------
    # Helpers
    # -----------------------------------------------------

    def _create_directory_recursive(
        self,
        entry: BuildMapDirectory,
        results: Dict[str, Any],
        progress_callback: Optional[Callable[[str, Dict[str, Any]], None]] = None,
    ):
        try:
            abs_path = self._safe_path(entry.path)
            abs_path.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            error_message = f"Error creating directory '{entry.path}': {e}"
            results["errors"].append(error_message)
            if progress_callback:
                progress_callback("dir_error", {"path": entry.path, "error": error_message})
            return

        results["created_directories"].append(entry.path)
        if progress_callback:
            progress_callback("dir_created", {"path": entry.path, "absolute_path": str(abs_path.resolve())})

        if entry.children:
            for child in entry.children:
                self._create_directory_recursive(child, results, progress_callback=progress_callback)
