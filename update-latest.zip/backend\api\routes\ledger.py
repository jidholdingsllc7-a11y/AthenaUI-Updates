# AthenaUI -- Marketing Ledger API Routes
# File: backend/api/routes/ledger.py
#
# Read access to the signed marketing-activity ledger, the human-only
# manual-post confirmation step (closes the loop for posts pasted to
# platforms without API access), and SCDO push-target configuration.

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any, Dict, Optional

from fastapi import APIRouter, Body, Depends, File, Form, HTTPException, Query, UploadFile

from api.deps.auth_middleware import get_current_user
from ledger import service as ledger_service
from vault.service import VaultService

router = APIRouter(prefix="/ledger", tags=["ledger"])

PROOF_DIR = Path(__file__).resolve().parents[2] / "ledger" / "proofs"


def _username(user: Any) -> str:
    username = user.get("username") if isinstance(user, dict) else getattr(user, "username", None)
    if not username:
        raise HTTPException(status_code=401, detail="Authentication required.")
    return str(username)


@router.get("/records")
async def get_records(status: Optional[str] = Query(None), user: Dict[str, Any] = Depends(get_current_user)):
    username = _username(user)
    return {"records": ledger_service.list_records(username, status=status)}


@router.get("/manual-posts/pending")
async def get_pending_manual_posts(user: Dict[str, Any] = Depends(get_current_user)):
    username = _username(user)
    return {"records": ledger_service.list_records(username, status="manual_pending_proof")}


@router.post("/manual-posts/{record_id}/confirm")
async def confirm_manual_post(
    record_id: str,
    proof_url: str = Form(...),
    screenshot: Optional[UploadFile] = File(None),
    user: Dict[str, Any] = Depends(get_current_user),
):
    username = _username(user)
    screenshot_path = None
    if screenshot is not None:
        PROOF_DIR.mkdir(parents=True, exist_ok=True)
        ext = Path(screenshot.filename or "").suffix or ".png"
        screenshot_path = str(PROOF_DIR / f"{record_id}{ext}")
        contents = await screenshot.read()
        with open(screenshot_path, "wb") as f:
            f.write(contents)

    try:
        record = await asyncio.to_thread(
            ledger_service.confirm_manual_post, username, record_id, proof_url, screenshot_path
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"ok": True, "record": record}


@router.get("/scdo-config")
async def get_scdo_config(user: Dict[str, Any] = Depends(get_current_user)):
    username = _username(user)
    base_url = VaultService.get_preference(username, "ledger.scdo_base_url", "") or ""
    return {"base_url": base_url, "configured": bool(base_url)}


@router.post("/scdo-config")
async def set_scdo_config(payload: Dict[str, Any] = Body(...), user: Dict[str, Any] = Depends(get_current_user)):
    username = _username(user)
    base_url = str(payload.get("base_url") or "").strip()
    api_key = str(payload.get("api_key") or "").strip()
    VaultService.set_preference(username, "ledger.scdo_base_url", base_url)
    if api_key:
        VaultService.set_secret(username, "ledger.scdo_api_key", api_key)
    return {"ok": True}
