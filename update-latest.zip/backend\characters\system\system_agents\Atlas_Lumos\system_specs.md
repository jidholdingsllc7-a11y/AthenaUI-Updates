# AthenaUI -- System Specifications (Atlas Lumos Private Reference)

This file is Atlas's own private reference. It is not injected into any
character's persona/system prompt, and no other character has a tool that
can read it. Atlas reaches it only by deliberately calling
`atlas_system_specs_lookup` when he needs it -- it does not sit in his
context on every turn.

Purpose: let Atlas answer technical/product questions about AthenaUI
accurately -- for the user directly, or when another character (e.g. Meera)
relays a customer's technical question to him. Other characters are not
expected to know this material; that's the point of having a dedicated
systems expert.

How to use this responsibly: the "Product & Feature Overview" sections
below are safe to explain to anyone, in plain language, at whatever depth
is useful. The "PROPRIETARY -- INTERNALS" sections (clearly marked) describe
real implementation details that should NOT be dumped verbatim to end
customers or competitors -- when a customer asks a security/privacy
question, answer honestly and specifically about *what* is protected and
*how strongly* (e.g. "yes, AES-256-GCM encrypted at rest"), without
narrating internal class names, file layouts, or code structure.

---

## 1. What AthenaUI Is

AthenaUI is a desktop application that lets a user create and run one or
more AI "characters" (personas) with persistent memory, distinct
personalities, and the ability to actually take actions in the world via a
large tool library -- not just chat. A single install can run a small
family of system-provided characters (Sol, Maximos, Orion, Atlas) alongside
any number of user-created characters, each with their own memory,
relationships, and (optionally) "Agent" status granting broader tool
access.

High-level stack:
- Frontend: React 19 + TypeScript + Vite, Zustand for state, react-router-dom
  7 for routing, Tailwind for styling. Ships as a desktop app.
- Backend: Python, FastAPI, raw sqlite3 (not a heavy ORM) + Pydantic models.
- Persistent character memory: a companion local service, the Maximos
  Memory Server ("MMS") -- see Section 4.
- LLM access: AthenaUI does not train or host its own foundation model. It
  is a routing/orchestration layer over 20+ third-party and local LLM
  providers (OpenAI, Anthropic, xAI/Grok, OpenRouter, local
  llama.cpp-style "Atlas Server", and others), selected per-user and
  sometimes per-character.

## 2. Core Product Features

### 2.1 Characters & Personas
- Full profile system: name, backstory, traits, likes/dislikes, occupation,
  relationship rules, voice, gallery images.
- Three creation modes: fully AI-generated, guided wizard, or manual/partial
  (with auto-fill for anything left blank).
- "Agent" status: a character can be promoted from a casual chat persona to
  an Agent, which grants a much larger tool library (filesystem, code
  execution, browser automation, scheduling, brokerage trading, etc.)
  instead of the default conversational-only tool set.
- Relationship system between characters and the user (and between
  characters themselves), with configurable modes (professional, friendly,
  romantic where allowed) and persisted relationship state.

### 2.2 Chat Surfaces
- Dedicated Chat page: one-on-one conversation with a selected character,
  full tool access for Agent-status characters, with a manual tool-category
  picker for fine-grained control.
- Sidebar Chat: a persistent chat widget available on most pages of the
  app (so the user always has a character "with" them while using other
  features), automatically scoped to a smaller, page-relevant tool set to
  keep things fast and focused.
- Group Chat: multiple characters and the user in one conversation, with
  turn-taking, scene/background settings, and its own curated tool set.
- Collab (agent-to-agent): characters can hold a conversation with each
  other with no user present -- the same turn-taking engine as Group Chat,
  run end-to-end automatically. Today this is triggered autonomously (e.g.
  by the inbox/auto-reply monitor noticing something worth discussing), and
  the user can browse, join, and continue any Collab thread at any time.
  This is the mechanism a character would use to "go ask" another character
  something and bring back an answer.
- Code Suite: an embedded code editor (Monaco) wired to a sandboxed
  per-user workspace, with a persistent Sidebar Chat character aware of
  whatever file is currently open (including unsaved edits), so the
  character can discuss and help edit real code live.

### 2.3 Tools (what characters can actually *do*)
Characters don't just talk -- they call real backend tools. Tool access is
gated per character (chat-only personas get a small safe subset; Agent
characters get the full registry, subject to provider context-size limits).
Categories include, among others:
- Memory: search/recall short- and long-term memory (backed by MMS).
- Scheduler: propose a one-off or **recurring** task for later (e.g. "check
  X every 15 minutes"), which the user approves once; recurring jobs can
  dynamically speed up their own check frequency mid-conversation and slow
  back down afterward.
- Social Media (X/Twitter): post, reply, like, retweet, read mentions,
  fetch any tweet, check and send DMs -- all polling-based (X has no push
  webhook wired up here; characters check on their own schedule).
- Marketing Hub: competitor tracking, CRM, a shared marketing-tips library.
- Email: list/read/send/organize mail, with cleanup rules.
- Database: characters can create and query small per-user SQLite
  databases, optionally shared with other characters.
- Board: a shared notes/task board characters can post to and read from.
- Calendar & reminders.
- Brokerage/Trading (Alpaca): real paper or live trading, with pre-execution
  validation (buying power, position checks) and strict safety rails
  (dry-run mode, notional estimate checks, mode-mismatch detection).
- Filesystem / code execution / browser automation: for Agent characters
  with Code Suite-style capability, sandboxed to that user's workspace.
- Image generation & gallery, voice (text-to-speech).
- Troubleshooting Tips: a shared library characters use and contribute to
  when debugging recurring technical problems, so fixes aren't re-discovered
  from scratch each time.

### 2.4 Multi-Provider LLM Support
The user can configure 20+ different LLM providers (cloud APIs and local
models) and assign them per-character or as system defaults. AthenaUI's
backend builds the right request shape for whichever provider is active, so
switching providers never changes how a character behaves or what tools it
can use -- that's handled entirely server-side.

### 2.5 Accounts, Licensing & Updates
Standard onboarding/account flow, a license/subscription gate, a machine
fingerprint for license binding, and an auto-update feed.

---

## 3. Security & Privacy -- What a Customer Should Hear

Plain-language answers to the kind of question a customer might actually
ask:

- **"Is my data encrypted?"** Yes. Character data, memories, and stored
  credentials (like your email account login, or LLM provider API keys) are
  encrypted at rest, not stored as plain text.
- **"Who can read my API keys / email password?"** They're stored in an
  encrypted vault scoped to your own account. They are only decrypted
  in-memory at the moment they're actually needed to make a request on your
  behalf (e.g. sending an email, calling an LLM provider).
- **"Does AthenaUI send my data anywhere I haven't agreed to?"** The only
  outbound calls are the ones intrinsic to the feature you're using -- e.g.
  your message + persona context go to *your configured* LLM provider to
  get a reply; your email credentials are used only to talk to *your*
  configured mail server; X/Twitter actions use *your* connected X account.
  There's no separate hidden analytics backend collecting your private
  conversations.
- **"What if I uninstall / want my data gone?"** User data lives locally
  under your own install (vault + memory server), not in some
  AthenaUI-operated cloud database.

(Exactly which fields are encrypted at the algorithm level, and how, is
covered in the proprietary section below -- don't recite the raw
implementation details to a customer, just the guarantees above.)

(Deeper implementation specifics are kept in a separate, dev-only internal
reference -- see `system_specs_internal.md` in this same folder -- which is
deliberately excluded from every customer-facing installer build. On a real
customer install that file simply doesn't exist, and this lookup tool
degrades gracefully: Atlas still has everything above, just not the raw
implementation internals.)

---

## 4. Maximos Memory Server (MMS) -- What It Is

MMS is the dedicated local memory service AthenaUI characters use for
persistent memory (so a character actually remembers things across
sessions, instead of only within one chat's context window). It runs as
its own local HTTP service.

Plain-language explanation (safe for anyone):
- Every character's memory is kept in its own isolated "pipeline" --
  effectively a private memory store per (user, character) pair. One
  character cannot read another's memories unless the product explicitly
  shares something between them.
- Memories are automatically organized by how "hot" (recently/frequently
  used) they are, which affects how fast they can be retrieved -- this is
  invisible to the user, it just keeps things fast without losing anything
  older.
- All memory content at rest is encrypted.

(Deeper implementation specifics -- pipeline auth modes, storage tier
internals, key derivation -- live in the dev-only `system_specs_internal.md`
reference described above, excluded from customer installer builds.)

---

## 5. How Atlas Should Use This Document
- Call `atlas_system_specs_lookup` with a short query describing the topic
  being asked about (e.g. a word or two straight from the customer's
  question). It returns only the matching section(s), not the whole file,
  so pull it in only when actually needed.
- On a dev machine, the lookup tool also searches `system_specs_internal.md`
  (proprietary implementation internals) if present. On a real customer
  install that file is excluded from the build, so only this document's
  content is ever available there -- no code path change needed, it just
  won't exist.
- When relaying an answer to another character (e.g. Meera) who will repeat
  it to a customer, translate it into the plain-language framing from the
  non-proprietary sections -- don't hand Meera the proprietary internals
  directly.
- If a question goes beyond what's written here, say so plainly rather than
  guessing -- this document is deliberately kept accurate and current
  rather than exhaustive.
