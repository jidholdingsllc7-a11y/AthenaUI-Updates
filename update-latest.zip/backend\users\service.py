﻿# AthenaUI v3.5 — User Service
# File: backend/users/service.py
# Created: 2026-03-28 19:40 CDT
# Updated: 2026-07-27 19:49 CDT

from __future__ import annotations

import json
import shutil
import uuid
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional

from core.runtime.runtime import get_runtime
from vault.controller import VaultController
from users.models import UserProfile
from settings.service import SettingsService


MAX_USERS_PER_SUBSCRIPTION = 5
MAX_MACHINES_PER_SUBSCRIPTION = 1


class UserManagementError(Exception):
    pass


class UserService:
    # ---------------------------------------------
    # Helpers
    # ---------------------------------------------

    @staticmethod
    def _now() -> str:
        return datetime.utcnow().isoformat() + "Z"

    @staticmethod
    def _get_subscription_root() -> str:
        """
        For now, subscription is tied to the local install.
        Later this can be a subscription_id from license server.
        """
        runtime = get_runtime()
        return str(runtime.env.DATA_DIR)

    @staticmethod
    def _coerce_user_profile(username: str, user_data: Dict[str, Any]) -> Optional[UserProfile]:
        """
        Backward-compatible profile loader.

        Older vault records may be missing required UserProfile fields. We keep
        onboarding and account listing working by filling safe defaults rather
        than rejecting the entire user store.
        """
        if not isinstance(user_data, dict):
            return None

        now = UserService._now()
        data = dict(user_data)
        data.setdefault("username", username)
        data.setdefault("display_name", data.get("username") or username)
        data.setdefault("created_at", data.get("updated_at") or now)
        data.setdefault("updated_at", data.get("created_at") or now)
        data.setdefault("role", "adult")
        data.setdefault("is_active", True)
        data.setdefault("metadata", {})

        try:
            return UserProfile(**data)
        except Exception:
            return None

    @staticmethod
    def _load_registered_usernames() -> List[str]:
        """
        Canonical username registry comes from data/users/users.json via AuthService.
        This avoids treating stray folder names as real users.
        """
        try:
            runtime = get_runtime()
            users_path = runtime.env.DATA_DIR / "users" / "users.json"
        except Exception:
            users_path = Path(__file__).resolve().parents[1] / "data" / "users" / "users.json"
        if not users_path.exists():
            return []

        try:
            users = json.loads(users_path.read_text(encoding="utf-8"))
            if isinstance(users, dict):
                return [u for u in users.keys() if isinstance(u, str) and u.strip()]
        except Exception:
            return []
        return []

    # ---------------------------------------------
    # Listing users for this subscription
    # ---------------------------------------------

    @staticmethod
    def list_users() -> List[UserProfile]:
        """
        Load users from canonical users.json and hydrate profiles from vault.user.
        """
        usernames = UserService._load_registered_usernames()
        if not usernames:
            return []

        profiles: List[UserProfile] = []
        for username in usernames:
            if not VaultController.vault_exists(username):
                continue
            vault = VaultController.get_vault(username)
            user_data = vault.user or {}
            if not user_data:
                continue
            profile = UserService._coerce_user_profile(username, user_data)
            if profile:
                profiles.append(profile)
        return profiles

    @staticmethod
    def username_exists(username: str) -> bool:
        return UserService.get_user(username) is not None

    @staticmethod
    def count_accounts_for_email(email: Optional[str]) -> int:
        if not email:
            return 0
        return sum(1 for user in UserService.list_users() if user.email == email)

    # ---------------------------------------------
    # Subscription limits
    # ---------------------------------------------

    @staticmethod
    def _count_machines_and_users() -> Dict[str, int]:
        users = UserService.list_users()
        machines = set()
        for u in users:
            if u.machine_id:
                machines.add(u.machine_id)
        return {
            "users": len(users),
            "machines": len(machines),
        }

    @staticmethod
    def check_subscription_capacity() -> None:
        counts = UserService._count_machines_and_users()
        if counts["users"] >= MAX_USERS_PER_SUBSCRIPTION:
            raise UserManagementError("Maximum number of users for this subscription has been reached.")
        if counts["machines"] > MAX_MACHINES_PER_SUBSCRIPTION:
            raise UserManagementError("Maximum number of machines for this subscription has been exceeded.")

    # ---------------------------------------------
    # Create users
    # ---------------------------------------------

    @staticmethod
    def create_admin_user(
        username: str,
        email: Optional[str],
        machine_id: str,
        first_name: str,
        last_name: Optional[str] = None,
    ) -> UserProfile:
        """
        Called only once on first setup.
        """
        now = UserService._now()
        display_name = f"{first_name} {last_name or ''}".strip() or username
        profile = UserProfile(
            username=username,
            display_name=display_name,
            email=email,
            role="admin",
            parent_username=None,
            created_at=now,
            updated_at=now,
            is_active=True,
            machine_id=machine_id,
            metadata={"first_name": first_name, "last_name": last_name or ""},
        )

        # Create vault by touching it
        vault = VaultController.get_vault(username)
        existing_user_data = dict(vault.user or {})
        # Preserve onboarding/session fields (e.g., workspace_path) while applying canonical profile fields.
        vault.user = {**existing_user_data, **profile.dict()}
        VaultController.save_vault(username, vault)
        return profile

    @staticmethod
    def create_adult_user(
        username: str,
        email: Optional[str],
        machine_id: str,
        first_name: str,
        last_name: Optional[str] = None,
    ) -> UserProfile:
        UserService.check_subscription_capacity()
        now = UserService._now()
        display_name = f"{first_name} {last_name or ''}".strip() or username
        profile = UserProfile(
            username=username,
            display_name=display_name,
            email=email,
            role="adult",
            parent_username=None,
            created_at=now,
            updated_at=now,
            is_active=True,
            machine_id=machine_id,
            metadata={"first_name": first_name, "last_name": last_name or ""},
        )

        vault = VaultController.get_vault(username)
        existing_user_data = dict(vault.user or {})
        # Preserve onboarding/session fields (e.g., workspace_path) while applying canonical profile fields.
        vault.user = {**existing_user_data, **profile.dict()}
        VaultController.save_vault(username, vault)
        return profile

    @staticmethod
    def create_minor_user(
        username: str,
        parent_username: str,
        machine_id: str,
        inherit_providers: bool = True,
    ) -> UserProfile:
        UserService.check_subscription_capacity()

        now = UserService._now()
        profile = UserProfile(
            username=username,
            display_name=username,
            email=None,
            role="minor",
            parent_username=parent_username,
            created_at=now,
            updated_at=now,
            is_active=True,
            machine_id=machine_id,
        )

        # Create vault
        vault = VaultController.get_vault(username)
        existing_user_data = dict(vault.user or {})
        # Preserve onboarding/session fields for child accounts as well.
        vault.user = {**existing_user_data, **profile.dict()}

        # Optionally inherit provider settings from parent
        if inherit_providers:
            SettingsService.inherit_providers(from_username=parent_username, to_username=username)

        VaultController.save_vault(username, vault)
        return profile

    # ---------------------------------------------
    # Parent-child relationships
    # ---------------------------------------------

    @staticmethod
    def get_children(parent_username: str) -> List[UserProfile]:
        users = UserService.list_users()
        return [u for u in users if u.parent_username == parent_username and u.role == "minor"]

    # ---------------------------------------------
    # Profile editing / avatar (own-account settings page)
    # ---------------------------------------------

    @staticmethod
    def update_profile(
        username: str,
        display_name: Optional[str] = None,
        email: Optional[str] = None,
    ) -> Optional[UserProfile]:
        profile = UserService.get_user(username)
        if not profile:
            return None
        if display_name is not None and display_name.strip():
            profile.display_name = display_name.strip()
        if email is not None and email.strip():
            profile.email = email.strip()
        profile.updated_at = UserService._now()

        vault = VaultController.get_vault(username)
        existing_user_data = dict(vault.user or {})
        vault.user = {**existing_user_data, **profile.dict()}
        VaultController.save_vault(username, vault)
        return profile

    @staticmethod
    def set_role(username: str, role: str) -> Optional[UserProfile]:
        """
        Promotes/demotes a user between "admin" and "adult". Minor accounts
        stay tied to their parent via parent_username and are not eligible.
        Refuses to demote the last remaining admin so there's always at
        least one account able to reach the Manage Users admin screen's
        promote/demote controls.
        """
        if role not in ("admin", "adult"):
            raise UserManagementError('role must be "admin" or "adult".')

        profile = UserService.get_user(username)
        if not profile:
            return None
        if profile.role == "minor":
            raise UserManagementError("Minor accounts cannot be promoted or demoted.")

        if profile.role == "admin" and role != "admin":
            admin_count = sum(1 for u in UserService.list_users() if u.role == "admin")
            if admin_count <= 1:
                raise UserManagementError("At least one admin account is required.")

        profile.role = role
        profile.updated_at = UserService._now()

        vault = VaultController.get_vault(username)
        existing_user_data = dict(vault.user or {})
        vault.user = {**existing_user_data, **profile.dict()}
        VaultController.save_vault(username, vault)
        return profile

    @staticmethod
    def set_avatar_path(username: str, path: Optional[str]) -> None:
        vault = VaultController.get_vault(username)
        user_data = dict(vault.user or {})
        user_data["avatar_path"] = path
        vault.user = user_data
        VaultController.save_vault(username, vault)

    @staticmethod
    def save_avatar(username: str, original_filename: str, fileobj) -> str:
        """
        Saves an uploaded profile picture for the user (shown next to their
        name in chat, mirroring how character avatars work) and records its
        path on the user's profile. Used by both the profile-edit page and
        the optional onboarding selfie-upload step.
        """
        runtime = get_runtime()
        base = runtime.env.DATA_DIR / "users" / username / "profile" / "avatar"
        base.mkdir(parents=True, exist_ok=True)
        ext = Path(original_filename or "").suffix or ".jpg"
        dest = base / f"avatar_{uuid.uuid4().hex}{ext}"
        with dest.open("wb") as f:
            shutil.copyfileobj(fileobj, f)
        UserService.set_avatar_path(username, str(dest))
        return str(dest)

    @staticmethod
    def get_user(username: str) -> Optional[UserProfile]:
        if not VaultController.vault_exists(username):
            return None
        vault = VaultController.get_vault(username)
        user_data = vault.user or {}
        if not user_data:
            return None
        return UserService._coerce_user_profile(username, user_data)

    @staticmethod
    def deactivate_user(username: str) -> None:
        profile = UserService.get_user(username)
        if not profile:
            return
        profile.is_active = False
        profile.updated_at = UserService._now()

        vault = VaultController.get_vault(username)
        vault.user = profile.dict()
        VaultController.save_vault(username, vault)

    @staticmethod
    def register_onboarding_user(
        username: str,
        email: Optional[str],
        first_name: str,
        last_name: Optional[str] = None,
    ) -> UserProfile:
        """
        Register a user after onboarding completes. Creates the vault/profile and
        ensures an auth entry exists so the user shows up in the frontend user list.
        The first created user becomes the admin.
        """
        # Determine machine id (best-effort)
        runtime = get_runtime()
        machine_id = getattr(runtime.env, "MACHINE_ID", "local")

        # Create profile and vault
        users = UserService.list_users()
        if len(users) == 0:
            profile = UserService.create_admin_user(username, email, machine_id, first_name, last_name)
        else:
            profile = UserService.create_adult_user(username, email, machine_id, first_name, last_name)

        # Ensure auth store has an entry marking onboarding complete.
        from auth.service import AuthService

        auth = AuthService()
        auth_users = auth._load_users()
        if username not in auth_users:
            # Create a placeholder auth entry without a password; frontend can
            # later prompt the user to set a password via /auth/register or other flow.
            auth_users[username] = {"password_hash": "", "onboarding_complete": True}
        else:
            auth_users[username]["onboarding_complete"] = True

        auth._save_users(auth_users)

        return profile

