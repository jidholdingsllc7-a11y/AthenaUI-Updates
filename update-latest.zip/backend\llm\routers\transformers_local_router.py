﻿# AthenaUI v3.5 — Provider-specific router for local HuggingFace Transformers models
# File: backend/llm/routers/transformers_local_router.py
# Created: 2026-03-28 21:59 CDT
# Updated: 2026-07-27 19:49 CDT

import json
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from typing import Any, Dict, List, Optional

from llm.routers.base import BaseLLMRouter
from llm.router_selector.router_selector import RouterSelector
from llm.routers.providers import PROVIDER_TRANSFORMERS_LOCAL
from core.runtime.runtime import get_runtime

from tools.registry.tool_examples import TOOL_EXAMPLES



class TransformersLocalRouter(BaseLLMRouter):
    """
    Provider-specific router for local HuggingFace Transformers models.
    Supports:
    - chat (prompt-based)
    - tool calling (emulated)
    - streaming (stub)
    """

    _model_cache = {}
    _tokenizer_cache = {}

    # ---------------------------------------------------------
    # Model Loader
    # ---------------------------------------------------------

    def _load_model(self):
        if self.model_id in self._model_cache:
            return self._model_cache[self.model_id], self._tokenizer_cache[self.model_id]

        runtime = get_runtime()
        device = runtime.env.TRANSFORMERS_DEVICE or "cpu"

        tokenizer = AutoTokenizer.from_pretrained(self.model_id)
        model = AutoModelForCausalLM.from_pretrained(
            self.model_id,
            torch_dtype=torch.float16 if device != "cpu" else torch.float32,
            device_map="auto" if device != "cpu" else None,
        )

        self._model_cache[self.model_id] = model
        self._tokenizer_cache[self.model_id] = tokenizer

        return model, tokenizer

    # ---------------------------------------------------------
    # Build system prompt with tool examples
    # ---------------------------------------------------------

    def _build_system_prompt(self, base_prompt: Optional[str], *, include_tool_examples: bool = True) -> str:
        if not include_tool_examples:
            return base_prompt if base_prompt else "You are AthenaUI v3.1."

        examples_json = json.dumps(TOOL_EXAMPLES, indent=2)

        tool_usage_block = f"""
This is a local Transformers model with NO native tool calling.
To call a tool, output ONLY a JSON object describing the tool call.

Here are examples of correct tool usage:
{examples_json}

If you need to call a tool, do NOT explain â€” just output the JSON.
"""

        if base_prompt:
            return base_prompt + "\n\n" + tool_usage_block

        return "You are AthenaUI v3.1.\n\n" + tool_usage_block

    # ---------------------------------------------------------
    # Build prompt from messages
    # ---------------------------------------------------------

    def _build_prompt(self, system_prompt: str, messages: List[Dict[str, Any]], tools: Optional[List[Dict[str, Any]]]):
        parts = [f"[SYSTEM]: {system_prompt}"]

        for msg in messages:
            role = msg["role"].upper()
            content = msg["content"]
            parts.append(f"[{role}]: {content}")

        if tools:
            tool_desc = json.dumps(tools, indent=2)
            parts.append(
                "[SYSTEM]: You have access to the following tools:\n"
                f"{tool_desc}\n"
                "Respond ONLY with a JSON object describing the tool call."
            )

        return "\n".join(parts)

    # ---------------------------------------------------------
    # Chat Completion
    # ---------------------------------------------------------

    def chat(
        self,
        messages: List[Dict[str, Any]],
        *,
        tools: Optional[List[Dict[str, Any]]] = None,
        tool_choice: Optional[str] = None,  # ignored
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = 512,
    ) -> Dict[str, Any]:

        model, tokenizer = self._load_model()

        # Build system prompt with examples
        extracted_prompt, remaining_messages = self._extract_system_prompt(messages)
        final_system_prompt = self._build_system_prompt(system_prompt or extracted_prompt, include_tool_examples=bool(tools))

        # Build full prompt
        prompt = self._build_prompt(final_system_prompt, remaining_messages, tools)

        # Tokenize
        inputs = tokenizer(prompt, return_tensors="pt").to(model.device)

        # Generate
        output = model.generate(
            **inputs,
            max_new_tokens=max_tokens,
            temperature=temperature,
            do_sample=True,
        )

        decoded = tokenizer.decode(output[0], skip_special_tokens=True)

        # Extract assistant message
        if "[ASSISTANT]:" in decoded:
            content = decoded.split("[ASSISTANT]:")[-1].strip()
        else:
            content = decoded.strip()

        return {
            "id": None,
            "model": self.model_id,
            "content": content,
            "tool_calls": None,  # No native tool calling
            "finish_reason": "stop",
            "raw": decoded,
        }

    # ---------------------------------------------------------
    # Streaming (stub)
    # ---------------------------------------------------------

    def stream_chat(self, *args, **kwargs):
        raise NotImplementedError("Transformers local streaming not implemented yet.")


# ---------------------------------------------------------
# Register Router
# ---------------------------------------------------------

RouterSelector.register_router(PROVIDER_TRANSFORMERS_LOCAL, TransformersLocalRouter)

