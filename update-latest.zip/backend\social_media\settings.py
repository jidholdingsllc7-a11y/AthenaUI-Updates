# AthenaUI -- Social Media Credentials Settings Helper
# File: backend/social_media/settings.py
#
# Per-user credential storage for the three agent-facing social platforms
# (X/Twitter, Facebook, Moltbook), mirroring brokerage/settings.py's and
# brokerage/massive_settings.py's established pattern: everything is stored
# via VaultController's encrypted per-app "app key" slots, one slot per
# platform, never accepted as a raw argument from the LLM/agent -- only a
# human, through the Settings UI, can write these.
#
# Moltbook is different from X/Facebook: it's an agent-only network, and
# each of the user's characters/agents can have its own Moltbook account
# (rather than one shared account for the whole program), so its
# credentials are keyed per-character instead of per-user. See the
# "MOLTBOOK (PER-CHARACTER)" section below.

from __future__ import annotations

from typing import Any, Dict, List, Optional

from vault.controller import VaultController
from vault.service import VaultService

PLATFORMS = ("x", "facebook")

_APP_NAME = {
    "x": "social_media_x",
    "facebook": "social_media_facebook",
}

# Preference key for X's "upgraded account" (higher character limit) toggle.
# Not a secret, so it lives in the plain preference store rather than the
# encrypted app-key vault, matching VaultService.set_preference's existing
# use for non-sensitive user choices.
_X_UPGRADED_PREF_KEY = "social_media.x.upgraded_account"


def _validate_platform(platform: str) -> str:
    platform = (platform or "").strip().lower()
    if platform not in PLATFORMS:
        raise ValueError(f"Unknown platform '{platform}'. Must be one of {PLATFORMS}.")
    return platform


def get_credentials(username: str, platform: str) -> Optional[Dict[str, Any]]:
    platform = _validate_platform(platform)
    data = VaultController.get_app_key(username, _APP_NAME[platform]) or {}
    return data or None


def set_credentials(username: str, platform: str, key_data: Dict[str, Any]) -> None:
    platform = _validate_platform(platform)
    VaultController.set_app_key(username, _APP_NAME[platform], key_data)


def clear_credentials(username: str, platform: str) -> None:
    platform = _validate_platform(platform)
    VaultController.set_app_key(username, _APP_NAME[platform], {})


def has_credentials(username: str, platform: str) -> bool:
    platform = _validate_platform(platform)
    data = get_credentials(username, platform)
    if not data:
        return False
    if platform == "x":
        required = ("api_key", "api_secret", "access_token", "access_token_secret", "bearer_token")
    else:  # facebook
        required = ("page_access_token", "page_id")
    return all(bool(data.get(field)) for field in required)


def get_x_credentials(username: str) -> Optional[Dict[str, str]]:
    data = get_credentials(username, "x") or {}
    if not all(data.get(f) for f in ("api_key", "api_secret", "access_token", "access_token_secret", "bearer_token")):
        return None
    return {
        "api_key": str(data["api_key"]),
        "api_secret": str(data["api_secret"]),
        "access_token": str(data["access_token"]),
        "access_token_secret": str(data["access_token_secret"]),
        "bearer_token": str(data["bearer_token"]),
    }


def get_facebook_credentials(username: str) -> Optional[Dict[str, str]]:
    data = get_credentials(username, "facebook") or {}
    if not data.get("page_access_token") or not data.get("page_id"):
        return None
    return {"page_access_token": str(data["page_access_token"]), "page_id": str(data["page_id"])}


def get_x_upgraded_account(username: str) -> bool:
    return bool(VaultService.get_preference(username, _X_UPGRADED_PREF_KEY, False))


def set_x_upgraded_account(username: str, enabled: bool) -> None:
    VaultService.set_preference(username, _X_UPGRADED_PREF_KEY, bool(enabled))


# Tracks the newest mention id already surfaced to the agent, so repeated
# social_media_x_check_mentions calls only return mentions seen since last time.
_X_LAST_MENTION_PREF_KEY = "social_media.x.last_mention_id"


def get_x_last_mention_id(username: str) -> str:
    return str(VaultService.get_preference(username, _X_LAST_MENTION_PREF_KEY, "") or "")


def set_x_last_mention_id(username: str, tweet_id: str) -> None:
    VaultService.set_preference(username, _X_LAST_MENTION_PREF_KEY, str(tweet_id))


_X_LAST_DM_EVENT_PREF_KEY = "social_media.x.last_dm_event_id"


def get_x_last_dm_event_id(username: str) -> str:
    return str(VaultService.get_preference(username, _X_LAST_DM_EVENT_PREF_KEY, "") or "")


def set_x_last_dm_event_id(username: str, event_id: str) -> None:
    VaultService.set_preference(username, _X_LAST_DM_EVENT_PREF_KEY, str(event_id))


# ---------------------------------------------------------
# MOLTBOOK (PER-CHARACTER)
#
# Moltbook is an agent-only network -- every character/agent the user has
# can register and/or link its own independent Moltbook account, so
# credentials are keyed by (username, character) rather than a single
# per-user slot. VaultController has no "list keys by prefix" method, so a
# small index of linked character names is maintained alongside the
# per-character credential slots.
# ---------------------------------------------------------

_MOLTBOOK_INDEX_APP_NAME = "social_media_moltbook_index"


def _moltbook_app_name(character: str) -> str:
    character = (character or "").strip()
    if not character:
        raise ValueError("A character/agent name is required for Moltbook credentials.")
    return f"social_media_moltbook::{character}"


def list_moltbook_characters(username: str) -> List[str]:
    data = VaultController.get_app_key(username, _MOLTBOOK_INDEX_APP_NAME) or {}
    return list(data.get("characters", []))


def _add_moltbook_character(username: str, character: str) -> None:
    characters = list_moltbook_characters(username)
    if character not in characters:
        characters.append(character)
        VaultController.set_app_key(username, _MOLTBOOK_INDEX_APP_NAME, {"characters": characters})


def _remove_moltbook_character(username: str, character: str) -> None:
    characters = [c for c in list_moltbook_characters(username) if c != character]
    VaultController.set_app_key(username, _MOLTBOOK_INDEX_APP_NAME, {"characters": characters})


def get_moltbook_credentials(username: str, character: str) -> Optional[Dict[str, str]]:
    data = VaultController.get_app_key(username, _moltbook_app_name(character)) or {}
    if not data.get("api_key"):
        return None
    return {"api_key": str(data["api_key"]), "moltbook_username": str(data.get("moltbook_username") or "")}


def set_moltbook_credentials(username: str, character: str, api_key: str, moltbook_username: str = "") -> None:
    VaultController.set_app_key(username, _moltbook_app_name(character), {
        "api_key": api_key,
        "moltbook_username": moltbook_username,
    })
    _add_moltbook_character(username, character)


def clear_moltbook_credentials(username: str, character: str) -> None:
    VaultController.set_app_key(username, _moltbook_app_name(character), {})
    _remove_moltbook_character(username, character)


def has_moltbook_credentials(username: str, character: str) -> bool:
    return get_moltbook_credentials(username, character) is not None


def moltbook_status(username: str) -> Dict[str, Dict[str, Any]]:
    """Per-character Moltbook link status, for the Settings/Marketing UI and the check-capability tool."""
    return {
        character: {
            "configured": True,
            "moltbook_username": (get_moltbook_credentials(username, character) or {}).get("moltbook_username") or None,
        }
        for character in list_moltbook_characters(username)
    }


def capability_status(username: str) -> Dict[str, Any]:
    """
    Read-only status summary for both the Settings/Marketing UI and the
    `social_media_check_capability` agent tool: which platforms have working
    direct-post credentials configured, so the agent (or the user) knows
    whether it can post directly or must copy/paste instead.
    """
    return {
        "x": {
            "configured": has_credentials(username, "x"),
            "upgraded_account": get_x_upgraded_account(username),
        },
        "facebook": {"configured": has_credentials(username, "facebook")},
        "moltbook": {"characters": moltbook_status(username)},
    }
