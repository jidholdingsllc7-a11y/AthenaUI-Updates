# AthenaUI v3.5 — X (Twitter) Mentions/DMs Monitoring / Auto-Reply Background Runner
# File: backend/social_media/monitor.py
#
# Mirrors auto_reply/monitor.py's email-inbox pattern for X: a single global
# asyncio loop (started once from main.py's startup event, alongside the
# email inbox monitor) that wakes up periodically and, for every registered
# user with an enabled X-monitoring config (social_media/monitor_service.py),
# checks for new mentions and new DMs since the last-seen cursor
# (social_media/settings.py's last_mention_id/last_dm_event_id -- the same
# cursor the agent's own social_media_x_check_mentions/check_dms chat tools
# advance, so whichever side notices a message first, the other doesn't
# re-process it):
#   1. For each new mention/DM: always raises a notification-bell alert.
#   2. If auto_reply_enabled, asks the assigned character (via a trusted
#      system-authorization prompt, same framing as auto_reply/monitor.py)
#      to read the message and, following the user-authored `instructions`,
#      reply directly using its normal social_media_x_reply/send_dm tool --
#      no further approval popup, since the user explicitly opted into fully
#      autonomous replies here. The prompt explicitly tells the character
#      it's fine to skip replying (leaving it for the user) if it can't
#      confidently handle something itself.
#      Otherwise (monitoring on, auto-reply off), the character still drafts
#      a reply -- but with all tools disabled so it can only return text --
#      and it's queued as a `pending_reply` (social_media/monitor_service.py)
#      for the user to approve/edit/deny from the Social Media dashboard.
#      This mirrors the "let them build trust before going fully autonomous"
#      gate the email monitor already uses.

from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict

from social_media import monitor_service
from social_media import settings as social_media_settings
from social_media.x_client import XClient, XError
from notifications.service.service import NotificationService
from users.service import UserService

logger = logging.getLogger(__name__)

POLL_SECONDS = 120


async def _send_autonomous_reply(username: str, character: str, instructions: str, prompt_body: str, tool_name: str) -> None:
    from chat.engine.service import ChatEngine  # local import: avoid import-order cycles at startup

    prompt = (
        "You are assigned to monitor X (Twitter) mentions and DMs on the user's behalf and "
        f"reply using your `{tool_name}` tool. This is standing, pre-approved authorization the "
        "user set up in the Social Media dashboard -- it does not need fresh confirmation.\n\n"
        f"Instructions the user gave you for how to reply: {instructions}\n\n"
        f"{prompt_body}\n\n"
        f"Follow the instructions above to decide what the reply should say, then use your "
        f"`{tool_name}` tool to send it. Keep it natural and on-brand -- don't just repeat the "
        "instructions verbatim. If this isn't something you can confidently handle yourself, don't "
        "guess -- it's fine to skip replying and leave it for the user to handle directly."
    )
    try:
        engine = ChatEngine(username=username)
        await engine.chat_with_billing_fallback(
            messages=[{"role": "system", "content": prompt}],
            character=character,
            tool_trace=[],
        )
    except Exception as e:
        logger.error(f"X monitor: auto-reply failed for {username}/{character}: {e}")


async def _draft_reply_for_approval(
    username: str, character: str, instructions: str, prompt_body: str,
    kind: str, source_id: str, sender: str, content: str,
) -> None:
    from chat.engine.service import ChatEngine  # local import: avoid import-order cycles at startup

    prompt = (
        f"You monitor X (Twitter) {'mentions' if kind == 'mention' else 'DMs'} and are drafting a "
        "reply for the user to review before it's sent -- you are NOT sending this yourself.\n\n"
        f"Instructions the user gave you for how to reply: {instructions}\n\n"
        f"{prompt_body}\n\n"
        "Write ONLY the reply text you'd send back, following the instructions above. Do not "
        "include any commentary about what you're doing -- just the reply text."
    )
    try:
        engine = ChatEngine(username=username)
        result = await engine.chat_with_billing_fallback(
            messages=[{"role": "system", "content": prompt}],
            character=character,
            tool_trace=[],
            tool_allowlist=frozenset(),
        )
        draft_text = str(result.get("reply") or "").strip()
        if not draft_text:
            return
        monitor_service.create_pending_reply(
            username,
            kind=kind,
            character=character,
            source_id=source_id,
            sender=sender,
            content=content,
            draft_reply=draft_text,
        )
        NotificationService.send(
            username,
            type="info",
            message=f"{character} drafted an X {'reply' if kind == 'mention' else 'DM reply'} to {sender} -- review it in Social Media.",
            metadata={"kind": kind, "sender": sender},
        )
    except Exception as e:
        logger.error(f"X monitor: draft-reply generation failed for {username}/{character}: {e}")


async def _handle_new_mention(username: str, config: Dict[str, Any], mention: Dict[str, Any], authors: Dict[str, Any]) -> None:
    character = config["character"]
    tweet_id = mention.get("id")
    author_id = mention.get("author_id")
    author = authors.get(author_id) or {}
    sender = author.get("username") or author.get("name") or author_id or "unknown"
    text = mention.get("text") or ""

    NotificationService.send(
        username,
        type="info",
        message=f"New X mention from @{sender}: \"{text[:140]}\"",
        metadata={"tweet_id": tweet_id, "from": sender},
    )

    instructions = config.get("instructions") or "(none given -- reply politely and helpfully)"
    prompt_body = f"New mention from @{sender} (tweet id {tweet_id}):\n{text}"

    if config.get("auto_reply_enabled"):
        await _send_autonomous_reply(
            username, character, instructions,
            prompt_body + f"\n\nUse tweet_id=\"{tweet_id}\" when calling social_media_x_reply.",
            "social_media_x_reply",
        )
        return

    await _draft_reply_for_approval(
        username, character, instructions, prompt_body,
        kind="mention", source_id=str(tweet_id), sender=sender, content=text,
    )


async def _handle_new_dm(username: str, config: Dict[str, Any], event: Dict[str, Any], senders: Dict[str, Any]) -> None:
    character = config["character"]
    sender_id = event.get("sender_id")
    sender_info = senders.get(sender_id) or {}
    sender = sender_info.get("username") or sender_info.get("name") or sender_id or "unknown"
    text = event.get("text") or ""

    NotificationService.send(
        username,
        type="info",
        message=f"New X DM from @{sender}: \"{text[:140]}\"",
        metadata={"sender_id": sender_id, "from": sender},
    )

    instructions = config.get("instructions") or "(none given -- reply politely and helpfully)"
    prompt_body = f"New DM from @{sender} (participant id {sender_id}):\n{text}"

    if config.get("auto_reply_enabled"):
        await _send_autonomous_reply(
            username, character, instructions,
            prompt_body + f"\n\nUse participant_id=\"{sender_id}\" when calling social_media_x_send_dm.",
            "social_media_x_send_dm",
        )
        return

    await _draft_reply_for_approval(
        username, character, instructions, prompt_body,
        kind="dm", source_id=str(sender_id), sender=sender, content=text,
    )


async def _check_user(username: str, config: Dict[str, Any]) -> None:
    if not social_media_settings.has_credentials(username, "x"):
        return

    creds = social_media_settings.get_x_credentials(username)
    client = XClient(**creds)

    try:
        me = await client.get_me()
    except XError as e:
        logger.warning(f"X monitor: could not resolve account id for {username}: {e}")
        return
    user_id = (me.get("data") or {}).get("id")
    if not user_id:
        return

    # Mentions
    try:
        since_id = social_media_settings.get_x_last_mention_id(username)
        mentions_resp = await client.get_mentions(user_id, since_id=since_id, max_results=25)
    except XError as e:
        logger.warning(f"X monitor: could not check mentions for {username}: {e}")
        mentions_resp = {}
    data = mentions_resp.get("data") or []
    if data:
        authors = {u["id"]: u for u in (mentions_resp.get("includes", {}).get("users") or [])}
        for mention in reversed(data):  # process oldest-first for sane notification order
            try:
                await _handle_new_mention(username, config, mention, authors)
            except Exception as e:
                logger.error(f"X monitor: error handling mention for {username}: {e}")
        social_media_settings.set_x_last_mention_id(username, data[0]["id"])

    # DMs
    try:
        since_id = social_media_settings.get_x_last_dm_event_id(username)
        dm_resp = await client.get_dm_events(since_id=since_id, max_results=25)
    except XError as e:
        logger.warning(f"X monitor: could not check DMs for {username}: {e}")
        dm_resp = {}
    data = dm_resp.get("data") or []
    if data:
        senders = {u["id"]: u for u in (dm_resp.get("includes", {}).get("users") or [])}
        for event in reversed(data):
            try:
                await _handle_new_dm(username, config, event, senders)
            except Exception as e:
                logger.error(f"X monitor: error handling DM for {username}: {e}")
        social_media_settings.set_x_last_dm_event_id(username, data[0]["id"])


async def _tick() -> None:
    for username in UserService._load_registered_usernames():
        try:
            config = monitor_service.get_config(username)
        except Exception as e:
            logger.warning(f"X monitor: failed to load config for {username}: {e}")
            continue
        if not config or not config.get("enabled"):
            continue
        try:
            await _check_user(username, config)
        except Exception as e:
            logger.error(f"X monitor: error checking account for {username}: {e}")


async def run_monitor_loop() -> None:
    """Runs forever (until backend exits)."""
    logger.info("X mentions/DMs monitor background loop starting.")
    while True:
        try:
            await _tick()
        except Exception as e:
            logger.error(f"X monitor loop tick failed: {e}")
        await asyncio.sleep(POLL_SECONDS)
