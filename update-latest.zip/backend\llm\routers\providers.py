﻿# AthenaUI v3.5 — LLM Provider Constants
# File: backend/llm/routers/providers.py
# Created: 2026-03-28 20:28 CDT
# Updated: 2026-07-27 19:49 CDT

PROVIDER_OPENAI = "openai"
PROVIDER_ANTHROPIC = "anthropic"
PROVIDER_XAI = "xai"
PROVIDER_GROQ = "groq"
PROVIDER_MISTRAL = "mistral"
PROVIDER_FIREWORKS = "fireworks"
PROVIDER_TOGETHER = "together"
PROVIDER_GEMINI = "gemini"
PROVIDER_DEEPSEEK = "deepseek"
PROVIDER_PERPLEXITY = "perplexity"
PROVIDER_COHERE = "cohere"
PROVIDER_AI21 = "ai21"
PROVIDER_AZURE_OPENAI = "azure_openai"
PROVIDER_BEDROCK = "bedrock"
PROVIDER_OPENROUTER = "openrouter"

# ---------------------------------------------------------
# HuggingFace Providers
# ---------------------------------------------------------

PROVIDER_HUGGINGFACE = "huggingface"          # HF Inference API
PROVIDER_HF_TGI = "hf_tgi"                    # Text Generation Inference

# ---------------------------------------------------------
# Local Providers
# ---------------------------------------------------------

PROVIDER_OLLAMA = "ollama"
PROVIDER_LMSTUDIO = "lmstudio"
PROVIDER_TRANSFORMERS_LOCAL = "transformers_local"
PROVIDER_ATLAS_SERVER = "atlas_server"

# ---------------------------------------------------------
# Custom / Generic HTTP Provider
# ---------------------------------------------------------

PROVIDER_CUSTOM_HTTP = "custom_http"

# ---------------------------------------------------------
# Master Provider List
# ---------------------------------------------------------

ALL_PROVIDERS = [
    # Cloud
    PROVIDER_OPENAI,
    PROVIDER_ANTHROPIC,
    PROVIDER_XAI,
    PROVIDER_GROQ,
    PROVIDER_MISTRAL,
    PROVIDER_FIREWORKS,
    PROVIDER_TOGETHER,
    PROVIDER_GEMINI,
    PROVIDER_DEEPSEEK,
    PROVIDER_PERPLEXITY,
    PROVIDER_COHERE,
    PROVIDER_AI21,
    PROVIDER_AZURE_OPENAI,
    PROVIDER_BEDROCK,
    PROVIDER_OPENROUTER,

    # HuggingFace
    PROVIDER_HUGGINGFACE,
    PROVIDER_HF_TGI,

    # Local
    PROVIDER_OLLAMA,
    PROVIDER_LMSTUDIO,
    PROVIDER_TRANSFORMERS_LOCAL,
    PROVIDER_ATLAS_SERVER,

    # Custom
    PROVIDER_CUSTOM_HTTP,
]
