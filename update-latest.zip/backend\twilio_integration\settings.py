# AthenaUI v3.5 — Twilio Credentials Settings Helper
# File: backend/twilio_integration/settings.py
#
# Per-user Twilio credential storage, mirroring social_media/settings.py's
# established pattern: stored via VaultController's encrypted per-app "app
# key" slot (vault/controller.py already lists Twilio by name in its
# set_app_key docstring), never accepted as a raw argument from the
# LLM/agent -- only a human, through Settings, can write these.
#
# Twilio now recommends API Keys (SID + Secret) over the master Auth Token
# for authenticating the REST client, and Messaging Services (a sender
# pool SID) over a single "from" number for sending SMS -- both are
# supported here. `phone_number` is still required because Messaging
# Services don't apply to Voice calls; it also acts as the SMS fallback
# when no Messaging Service SID is configured.

from __future__ import annotations

from typing import Any, Dict, Optional

from vault.controller import VaultController

_APP_NAME = "twilio"

_REQUIRED_FIELDS = ("account_sid", "api_key_sid", "api_key_secret", "phone_number")


def get_credentials(username: str) -> Optional[Dict[str, str]]:
    data = VaultController.get_app_key(username, _APP_NAME) or {}
    if not all(data.get(f) for f in _REQUIRED_FIELDS):
        return None
    return {
        "account_sid": str(data["account_sid"]),
        "api_key_sid": str(data["api_key_sid"]),
        "api_key_secret": str(data["api_key_secret"]),
        "phone_number": str(data["phone_number"]),
        "messaging_service_sid": str(data.get("messaging_service_sid") or ""),
    }


def set_credentials(
    username: str,
    account_sid: str,
    api_key_sid: str,
    api_key_secret: str,
    phone_number: str,
    messaging_service_sid: Optional[str] = None,
) -> None:
    VaultController.set_app_key(username, _APP_NAME, {
        "account_sid": account_sid,
        "api_key_sid": api_key_sid,
        "api_key_secret": api_key_secret,
        "phone_number": phone_number,
        "messaging_service_sid": messaging_service_sid or "",
    })


def clear_credentials(username: str) -> None:
    VaultController.set_app_key(username, _APP_NAME, {})


def has_credentials(username: str) -> bool:
    return get_credentials(username) is not None


def capability_status(username: str) -> Dict[str, Any]:
    return {"twilio": {"configured": has_credentials(username)}}
