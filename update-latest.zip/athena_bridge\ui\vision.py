# Vision utilities: screenshots, OCR, image matching, highlight
# File: ui/vision.py
# Created: 2026-04-09 11:21 CDT
# Updated: 2026-07-31 (fixed element screenshot/annotate coordinate-space bug,
# pointed pytesseract at an explicit binary path, made highlight actually show
# live on screen)

import asyncio
import os
import tempfile
import threading

import pyautogui
import pytesseract
import cv2
import numpy as np
from PIL import Image, ImageDraw

from .dom import ensure_browser

# pytesseract only shells out to the real tesseract.exe binary -- it does not
# ship it. On Windows the installer does not reliably add it to PATH, so point
# at the well-known install location explicitly (falls back to PATH lookup if
# not found there, so this still works on machines where it *is* on PATH).
_DEFAULT_TESSERACT_PATH = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
if os.path.isfile(_DEFAULT_TESSERACT_PATH):
    pytesseract.pytesseract.tesseract_cmd = _DEFAULT_TESSERACT_PATH

async def screenshot_full_impl():
    img = pyautogui.screenshot()
    path = os.path.join(tempfile.gettempdir(), "full_screenshot.png")
    img.save(path)
    return {"status": "ok", "path": path}

async def cursor_marker_screenshot_impl():
    # pyautogui.screenshot() (PIL ImageGrab under the hood) never draws the
    # real OS cursor icon, so a plain screenshot taken right after a mouse
    # move can't show where the cursor actually landed. Work around this by
    # reading the real current position back from the OS (the same win32
    # call pair SetCursorPos/GetCursorPos that moveTo() itself uses, so this
    # is ground truth, not just an echo of the originally requested x/y) and
    # drawing an unmistakable marker on top of a fresh screenshot.
    x, y = pyautogui.position()
    img = pyautogui.screenshot().convert("RGB")
    draw = ImageDraw.Draw(img)
    radius = 18
    draw.ellipse([x - radius, y - radius, x + radius, y + radius], outline=(255, 0, 0), width=4)
    draw.line([x - radius - 10, y, x + radius + 10, y], fill=(255, 0, 0), width=2)
    draw.line([x, y - radius - 10, x, y + radius + 10], fill=(255, 0, 0), width=2)
    path = os.path.join(tempfile.gettempdir(), "cursor_marker_screenshot.png")
    img.save(path)
    return {"status": "ok", "path": path, "cursor_x": x, "cursor_y": y}

async def screenshot_element_impl(selector: str):
    page = await ensure_browser()
    element = await page.query_selector(selector)
    if not element:
        return {"status": "not_found"}

    box = await element.bounding_box()
    if not box:
        return {"status": "no_box"}

    # Use Playwright's own element screenshot instead of cropping a
    # pyautogui desktop screenshot. element.bounding_box() is relative to the
    # browser's page viewport, NOT the OS desktop, so cropping a full-desktop
    # screenshot with those coordinates grabs the wrong region entirely.
    # Playwright's native screenshot renders directly from the browser (no OS
    # coordinate translation needed) and works even if the browser window is
    # not visible/focused/on top.
    path = os.path.join(tempfile.gettempdir(), "element_screenshot.png")
    await element.screenshot(path=path)
    return {"status": "ok", "path": path, "box": box}

async def screenshot_annotated_impl(selector: str):
    page = await ensure_browser()
    element = await page.query_selector(selector)
    if not element:
        return {"status": "not_found"}

    box = await element.bounding_box()
    if not box:
        return {"status": "no_box"}

    # Same coordinate-space bug as screenshot_element_impl. Fix: draw the
    # annotation directly in the page (viewport-relative, matching
    # bounding_box()'s coordinate space exactly) via a temporary injected
    # overlay <div>, then take a Playwright page screenshot -- entirely
    # within the browser's own rendering, no OS desktop coordinates involved.
    overlay_id = "__athena_annotate_overlay__"
    await page.evaluate(
        """({ box, id }) => {
            const el = document.createElement('div');
            el.id = id;
            el.style.position = 'fixed';
            el.style.left = box.x + 'px';
            el.style.top = box.y + 'px';
            el.style.width = box.width + 'px';
            el.style.height = box.height + 'px';
            el.style.border = '3px solid red';
            el.style.boxSizing = 'border-box';
            el.style.pointerEvents = 'none';
            el.style.zIndex = '2147483647';
            document.body.appendChild(el);
        }""",
        {"box": box, "id": overlay_id},
    )
    path = os.path.join(tempfile.gettempdir(), "element_annotated.png")
    try:
        await page.screenshot(path=path)
    finally:
        await page.evaluate(
            """(id) => {
                const el = document.getElementById(id);
                if (el) el.remove();
            }""",
            overlay_id,
        )
    return {"status": "ok", "path": path, "box": box}

async def ocr_search_impl(text: str):
    img = pyautogui.screenshot()
    full_text = pytesseract.image_to_string(img)
    found = text.lower() in full_text.lower()
    return {"status": "ok", "found": found, "text": full_text}

async def image_match_impl(template_path: str, threshold: float):
    screenshot = pyautogui.screenshot()
    screenshot_np = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)

    template = cv2.imread(template_path, cv2.IMREAD_COLOR)
    if template is None:
        return {"status": "error", "error": "template not found"}

    result = cv2.matchTemplate(screenshot_np, template, cv2.TM_CCOEFF_NORMED)
    _, max_val, _, max_loc = cv2.minMaxLoc(result)

    if max_val >= threshold:
        h, w = template.shape[:2]
        return {
            "status": "ok",
            "match": True,
            "confidence": float(max_val),
            "location": {"x": max_loc[0], "y": max_loc[1], "width": w, "height": h},
        }

    return {"status": "ok", "match": False, "confidence": float(max_val)}

def _show_live_overlay(x: int, y: int, width: int, height: int, duration: float):
    # Runs on its own thread: a borderless, click-through, always-on-top
    # window whose background is fully transparent except for a drawn
    # border, positioned at real OS desktop coordinates. Disappears on its
    # own after `duration` seconds.
    import tkinter as tk

    root = tk.Tk()
    root.overrideredirect(True)
    root.geometry(f"{width}x{height}+{x}+{y}")
    root.attributes("-topmost", True)

    transparent_color = "magenta"
    root.configure(bg=transparent_color)
    root.attributes("-transparentcolor", transparent_color)

    canvas = tk.Canvas(root, bg=transparent_color, highlightthickness=0)
    canvas.pack(fill="both", expand=True)
    border = 4
    canvas.create_rectangle(
        border // 2, border // 2, width - border // 2, height - border // 2,
        outline="yellow", width=border,
    )

    root.after(max(int(duration * 1000), 1), root.destroy)
    root.mainloop()

async def highlight_impl(x: float, y: float, width: float, height: float, duration: float):
    # Still save a static annotated screenshot (kept for logging/recorder
    # purposes / anyone relying on the returned path), but ALSO actually show
    # a live overlay on screen for `duration` seconds -- the tool's name
    # implies a real on-screen highlight, which the previous implementation
    # never did (it only ever wrote a PNG to disk).
    img = pyautogui.screenshot()
    overlay = img.copy()
    draw = ImageDraw.Draw(overlay)
    x1, y1, x2, y2 = x, y, x + width, y + height
    draw.rectangle([x1, y1, x2, y2], outline="yellow", width=4)
    highlighted = Image.blend(img, overlay, alpha=0.5)
    path = os.path.join(tempfile.gettempdir(), "highlight_overlay.png")
    highlighted.save(path)

    thread = threading.Thread(
        target=_show_live_overlay,
        args=(int(x), int(y), int(width), int(height), duration),
        daemon=True,
    )
    thread.start()
    await asyncio.to_thread(thread.join)

    return {"status": "ok", "path": path, "shown_live": True}
