﻿# AthenaUI v3.5 — File Write Proposal Tool (RETIRED, 2026-10-16)
# File: backend/tools/fs/file_write_proposal.py
#
# No longer imported/registered anywhere (see tools/registry/loader.py) --
# the deferred-write proposal flow this tool implemented has been replaced
# by file_write / file_edit_lines writing live immediately and automatically
# creating a Keep/Revert pending change via
# workspace.service.WorkspaceService.write_file_tracked whenever an existing
# file is overwritten. Left on disk only for history; not wired into
# anything. Safe to delete.

from typing import Any, Dict

capabilities = {
    "needs_filesystem": True,
    "needs_bridge": False,
    "needs_network": False,
    "needs_user": True,
}

async def run(args: Dict[str, Any]) -> str:
    return "[ERROR] file_write_proposal is retired -- use file_write or file_edit_lines instead."
