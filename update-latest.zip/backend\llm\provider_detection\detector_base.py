﻿# AthenaUI v3.5 — Provider Detection Base Class
# File: backend/llm/provider_detection/detector_base.py
# Updated: 2026-07-27 19:49 CDT

from typing import Optional, List, Dict


class ProviderDetectionResult:
    def __init__(
        self,
        available: bool,
        models: Optional[List[str]] = None,
        warnings: Optional[List[str]] = None,
        error: Optional[str] = None,
        model_pricing: Optional[Dict[str, Dict[str, float]]] = None,
    ):
        self.available = available
        self.models = models or []
        self.warnings = warnings or []
        self.error = error
        # Optional live pricing per model, e.g. {"openai/gpt-4o": {"prompt_per_m": 2.5,
        # "completion_per_m": 10.0}}. Only populated by detectors whose provider API
        # actually returns pricing (currently just OpenRouter); other providers fall
        # back to the static table in pricing_data.py.
        self.model_pricing = model_pricing or {}


class ProviderDetectorBase:
    """
    Base class for provider auto-detection.
    Each provider detector must implement:
    - detect()
    - list_models()
    """

    provider_id: str = "unknown"

    def detect(self) -> ProviderDetectionResult:
        raise NotImplementedError

    def list_models(self) -> List[str]:
        raise NotImplementedError

