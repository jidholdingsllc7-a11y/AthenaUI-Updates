﻿# AthenaUI v3.5 — Settings Defaults
# File: backend/settings/defaults.py
# Created: 2026-04-16 13:35 CDT
# Updated: 2026-07-27 19:49 CDT

DEFAULT_SETTINGS = {
    "google": {
        "permissions": {
            "calendar": False,
            "gmail": False,
            "drive": False,
            "photos": False,
            "maps": False,
            "subscriptions": False,
            "system_email": False,
        },
        "preferences": {
            "default_calendar_id": "primary",
            "default_drive_backup_folder": "AthenaUI_Backups",
            "default_email_signature": "",
            "subscription_monitoring_enabled": True,
        },
        "user_email_credentials": None,
        "system_email_credentials": None,
    },

    "calendar": {
        "default_manager": "Sol_Lumos",
        "timezone": "America/Chicago",
        "notification_style": "voice+text",
    },

    "tasks": {
        "default_manager": "Sol_Lumos",
        "auto_confirm_safe_actions": False,
    },

    "notifications": {
        "enabled": True,
        "missed_event_alerts": True,
    },

    # Opt-in: if a scheduled task or inbox-monitoring agent's LLM call fails
    # with a billing/insufficient-funds error, automatically switch to the
    # next provider/model in `chain` (in order) instead of silently failing
    # the task/missing a customer message. Never applies to interactive
    # chat -- a human is present there and can react to the error directly.
    # `chain` is an ordered list of {"provider_id": str, "model_id": str}
    # -- position 0 is the primary provider to use first, each subsequent
    # entry is the next fallback tried on a billing error.
    "billing_fallback": {
        "enabled": False,
        "notify_channel": "email",  # "email" | "sms" | "none"
        "notify_phone_number": "",
        "chain": [],
    },

    "ui": {
        "theme": "dark",
        "animations": True,
    },

    "backups": {
        "auto_backup_enabled": False,
        "backup_location": "local",
    },

    # Provider-agnostic, dual-pipeline API keys
    "api_keys": {
        "chat": {
            # "<provider_id>": {
            #     "api_key": "...",
            #     "model": "...",
            #     "image_model": None,
            #     "custom_config": {},
            # }
        },
        "image": {
            # "<provider_id>": {
            #     "api_key": "...",
            #     "model": "...",
            #     "custom_config": {},
            # }
        },
        "code": {
            # "<provider_id>": {
            #     "api_key": "...",
            #     "model": "...",
            #     "custom_config": {},
            # }
        },
        "chat_default_provider": None,
        "image_default_provider": None,
        "code_default_provider": None,
    },

    # Hardware-level settings (camera permission, device selection)
    "hardware": {
        "camera": {
            "enabled": False,
            "device_id": None,  # OS/device identifier when selected
        },
    },

    # Parental controls (behavioral + safety)
    "parental_controls": {
        "enabled": False,

        # Task system access
        "allow_task_system": True,  # if False, child cannot directly use task tools

        # Character creation rules
        "character_creation": {
            "allow_minor_to_create_characters": False,
            "require_parent_approval_for_new_characters": True,
        },

        # Web / browsing rules
        "web": {
            # "open" | "school_only" | "school_preferred"
            "mode": "open",
            "allowed_domains": [],
            "allow_general_search": True,
            "max_off_task_minutes": 15,
        },

        # Camera behavior rules (not hardware permission)
        "camera": {
            "enabled": False,
            "send_camera_photos": False,
            "send_camera_photos_on_idle": False,
            "idle_minutes_before_photo": 15,
            "send_camera_photos_on_offtask": False,
            "send_camera_photos_on_disallowed_activity": False,
            "detect_unauthorized_camera_access": True,
            "block_unauthorized_camera_access": False,
        },

        # Bathroom logic
        "bathroom": {
            "enabled": True,
            "timeout_minutes": 10,
        },

        # “Parent called me away” notifications
        "parent_called_away": {
            "notify_parent": True,
        },

        # Emotional response rules
        "response_rules": {
            "on_mild_distress": "comfort_and_encourage",
            "on_moderate_distress": "comfort_and_notify_parent",
            "on_severe_distress": "deescalate_and_notify_parent_immediately",
        },
    },

    # Reporting / summaries
    "reporting": {
        "daily_behavior_report": True,
        "weekly_behavior_report": True,
        "monthly_behavior_report": True,
        "quarterly_behavior_report": True,
        "yearly_behavior_report": True,
    },
}

