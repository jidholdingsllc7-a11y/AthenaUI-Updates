# AthenaUI v3.5 — Static Model Pricing Table
# File: backend/llm/provider_detection/pricing_data.py
#
# Purpose:
#   Most provider "/models" APIs (OpenAI, Anthropic, Gemini, Groq, Mistral,
#   etc.) do NOT return live per-token pricing -- that data only exists on
#   each vendor's public pricing page. OpenRouter is the one exception: its
#   /api/v1/models response genuinely includes a `pricing` object per model,
#   which is extracted live in openrouter_detector.py instead of using this
#   table.
#
#   For every other provider, this module supplies a manually-maintained,
#   best-effort snapshot of publicly published pricing so the Settings model
#   dropdowns can still show an approximate "$ per million tokens" figure.
#   THESE NUMBERS ARE NOT LIVE and WILL drift out of date as vendors change
#   pricing -- update PRICING_TABLE below when that happens. Local/self-hosted
#   providers (Ollama, LM Studio, HuggingFace TGI, transformers_local,
#   custom_http) are intentionally omitted since they have no fixed vendor
#   price.
#
# Matching:
#   Model IDs vary by dated suffix (e.g. "gpt-4o-2024-08-06") so lookups use
#   longest-prefix matching against the keys below rather than exact match.

from typing import Dict, Optional, Tuple

# provider_id -> { model_id_prefix: (prompt_price_per_million, completion_price_per_million) }
# Prices are USD per 1,000,000 tokens.
PRICING_TABLE: Dict[str, Dict[str, Tuple[float, float]]] = {
    "openai": {
        "gpt-4o-mini": (0.15, 0.60),
        "gpt-4o": (2.50, 10.00),
        "gpt-4.1-nano": (0.10, 0.40),
        "gpt-4.1-mini": (0.40, 1.60),
        "gpt-4.1": (2.00, 8.00),
        "gpt-4-turbo": (10.00, 30.00),
        "gpt-4": (30.00, 60.00),
        "gpt-3.5-turbo": (0.50, 1.50),
        "o3-mini": (1.10, 4.40),
        "o1-mini": (1.10, 4.40),
        "o1": (15.00, 60.00),
    },
    "azure_openai": {
        "gpt-4o-mini": (0.15, 0.60),
        "gpt-4o": (2.50, 10.00),
        "gpt-4.1-mini": (0.40, 1.60),
        "gpt-4.1": (2.00, 8.00),
        "gpt-4-turbo": (10.00, 30.00),
        "gpt-4": (30.00, 60.00),
        "gpt-3.5-turbo": (0.50, 1.50),
        "o1-mini": (1.10, 4.40),
        "o1": (15.00, 60.00),
    },
    "anthropic": {
        "claude-opus-4": (15.00, 75.00),
        "claude-sonnet-4": (3.00, 15.00),
        "claude-3-7-sonnet": (3.00, 15.00),
        "claude-3-5-sonnet": (3.00, 15.00),
        "claude-3-5-haiku": (0.80, 4.00),
        "claude-3-opus": (15.00, 75.00),
        "claude-3-sonnet": (3.00, 15.00),
        "claude-3-haiku": (0.25, 1.25),
    },
    "gemini": {
        "gemini-2.5-pro": (1.25, 10.00),
        "gemini-2.5-flash": (0.30, 2.50),
        "gemini-2.0-flash-lite": (0.075, 0.30),
        "gemini-2.0-flash": (0.10, 0.40),
        "gemini-1.5-pro": (1.25, 5.00),
        "gemini-1.5-flash-8b": (0.0375, 0.15),
        "gemini-1.5-flash": (0.075, 0.30),
    },
    "groq": {
        "llama-3.3-70b": (0.59, 0.79),
        "llama-3.1-8b": (0.05, 0.08),
        "llama-3.1-70b": (0.59, 0.79),
        "mixtral-8x7b": (0.24, 0.24),
        "gemma2-9b": (0.20, 0.20),
    },
    "mistral": {
        "mistral-large": (2.00, 6.00),
        "mistral-small": (0.20, 0.60),
        "mistral-medium": (2.70, 8.10),
        "codestral": (0.20, 0.60),
        "open-mixtral-8x22b": (2.00, 6.00),
        "open-mixtral-8x7b": (0.70, 0.70),
        "open-mistral-7b": (0.25, 0.25),
    },
    "deepseek": {
        "deepseek-reasoner": (0.55, 2.19),
        "deepseek-chat": (0.27, 1.10),
    },
    "xai": {
        "grok-4": (3.00, 15.00),
        "grok-3-mini": (0.30, 0.50),
        "grok-3": (3.00, 15.00),
        "grok-2": (2.00, 10.00),
        "grok-beta": (5.00, 15.00),
    },
    "perplexity": {
        "sonar-reasoning-pro": (2.00, 8.00),
        "sonar-reasoning": (1.00, 5.00),
        "sonar-pro": (3.00, 15.00),
        "sonar": (1.00, 1.00),
    },
    "cohere": {
        "command-r-plus": (2.50, 10.00),
        "command-r": (0.15, 0.60),
        "command-light": (0.30, 0.60),
        "command": (1.00, 2.00),
    },
    "ai21": {
        "jamba-1.5-large": (2.00, 8.00),
        "jamba-1.5-mini": (0.20, 0.40),
    },
    "fireworks": {
        "llama-v3p3-70b": (0.90, 0.90),
        "llama-v3p1-8b": (0.20, 0.20),
        "llama-v3p1-70b": (0.90, 0.90),
        "mixtral-8x7b": (0.50, 0.50),
    },
    "together": {
        "meta-llama/Llama-3.3-70B": (0.88, 0.88),
        "meta-llama/Llama-3.1-8B": (0.18, 0.18),
        "meta-llama/Llama-3.1-70B": (0.88, 0.88),
        "mistralai/Mixtral-8x7B": (0.60, 0.60),
    },
    "bedrock": {
        "anthropic.claude-3-5-sonnet": (3.00, 15.00),
        "anthropic.claude-3-haiku": (0.25, 1.25),
        "anthropic.claude-3-opus": (15.00, 75.00),
        "meta.llama3-1-70b": (0.72, 0.72),
        "meta.llama3-1-8b": (0.22, 0.22),
        "amazon.titan-text": (0.20, 0.60),
    },
}


def get_static_pricing(provider_id: str, model_id: str) -> Optional[Dict[str, float]]:
    """
    Best-effort static pricing lookup using longest-prefix matching, since
    provider model IDs commonly carry a dated/version suffix
    (e.g. "gpt-4o-2024-08-06" should match the "gpt-4o" table entry).
    Returns None when the provider has no static table or no prefix matches.
    """
    table = PRICING_TABLE.get(str(provider_id or "").strip().lower())
    if not table:
        return None

    model_id = str(model_id or "")
    best_prefix: Optional[str] = None
    for prefix in table:
        if model_id.startswith(prefix):
            if best_prefix is None or len(prefix) > len(best_prefix):
                best_prefix = prefix

    if best_prefix is None:
        return None

    prompt_price, completion_price = table[best_prefix]
    return {"prompt_per_m": prompt_price, "completion_per_m": completion_price}


def format_price_label(pricing: Optional[Dict[str, float]]) -> Optional[str]:
    """Formats a pricing dict as "$X.XX / $Y.YY per M tok" (prompt / completion)."""
    if not pricing:
        return None
    prompt_price = pricing.get("prompt_per_m")
    completion_price = pricing.get("completion_per_m")
    if prompt_price is None or completion_price is None:
        return None
    return f"${prompt_price:.2f}/${completion_price:.2f} per M tok"
