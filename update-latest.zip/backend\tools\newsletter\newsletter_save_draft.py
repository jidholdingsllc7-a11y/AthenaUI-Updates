# AthenaUI v3.5 — newsletter_save_draft Tool
# File: backend/tools/newsletter/newsletter_save_draft.py
#
# Saves a PROPOSED newsletter issue for the user to review on the Marketing
# Email dashboard instead of sending it immediately -- use this by default
# when asked to "write" or "come up with" a newsletter. The user (or you,
# once explicitly told to send it) can send a saved draft from that page.
# This does NOT send anything -- it's completely safe, no approval needed.

from typing import Any, Dict

from newsletter.service import NewsletterError, save_draft

capabilities = {
    "needs_filesystem": True,
    "needs_bridge": False,
    "needs_network": False,
    "needs_user": True,
}


async def run(args: Dict[str, Any]) -> str:
    try:
        username = args.get("username")
        character = args.get("character")
        subject = args.get("subject")
        body = args.get("body")

        if not username:
            return "[ERROR] Missing 'username' argument."
        if not subject:
            return "[ERROR] Missing 'subject' argument."
        if not body:
            return "[ERROR] Missing 'body' argument."

        draft = save_draft(username, subject=subject, body=body, character=character)
        return (
            f"Newsletter draft saved for review (id={draft['id']}). The user can view it on the "
            "Marketing Email page and send it from there when ready."
        )
    except NewsletterError as e:
        return f"[ERROR] {e}"
    except Exception as e:
        return f"[ERROR] Failed to save newsletter draft: {str(e)}"
