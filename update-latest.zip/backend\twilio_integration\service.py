# AthenaUI v3.5 — Twilio SMS/Voice Service
# File: backend/twilio_integration/service.py
#
# Thin wrapper around the Twilio REST API (SDK already installed --
# requirements.txt lists it under "Email / SMS") for sending SMS and placing
# outbound voice calls that just speak a message via TwiML <Say>. Mirrors
# social_media/x_client.py's pattern: a small client class, a dedicated
# Error type, and a verify_credentials() used both by the Settings save
# endpoint and (implicitly) by any real send.
#
# NOTE ON COMPLIANCE: Twilio (and carriers, for A2P 10DLC / toll-free
# verification) require a documented opt-in/opt-out process for SMS before
# they'll approve a number for messaging at any real volume -- see
# api/routes/newsletter.py's public subscribe/unsubscribe endpoints, which
# double as that documented mechanism. Every SMS this service sends appends
# a short "Reply STOP to unsubscribe" notice unless the caller opts out of
# that (e.g. for a one-off transactional message), which is both a carrier
# requirement and the right thing to do.

from __future__ import annotations

from typing import Any, Dict, Optional

from twilio.base.exceptions import TwilioRestException
from twilio.rest import Client

from twilio_integration import settings as twilio_settings


class TwilioServiceError(Exception):
    pass


_STOP_NOTICE = " Reply STOP to unsubscribe."


def _client(username: str) -> Client:
    creds = twilio_settings.get_credentials(username)
    if not creds:
        raise TwilioServiceError(
            "No Twilio credentials configured. Ask the user to add them in Settings."
        )
    client = Client(creds["api_key_sid"], creds["api_key_secret"], creds["account_sid"])
    return client, creds["phone_number"], creds.get("messaging_service_sid") or None


def verify_credentials(account_sid: str, api_key_sid: str, api_key_secret: str) -> None:
    """Raises TwilioServiceError if the API Key SID/Secret pair is invalid for this account."""
    try:
        Client(api_key_sid, api_key_secret, account_sid).api.accounts(account_sid).fetch()
    except TwilioRestException as e:
        raise TwilioServiceError(f"Twilio rejected these credentials: {e}") from e


def send_sms(username: str, to: str, body: str, include_stop_notice: bool = True) -> Dict[str, Any]:
    client, from_number, messaging_service_sid = _client(username)
    to = (to or "").strip()
    body = (body or "").strip()
    if not to:
        raise TwilioServiceError("'to' phone number is required.")
    if not body:
        raise TwilioServiceError("'body' is required.")
    if include_stop_notice and "stop" not in body.lower():
        body = body + _STOP_NOTICE

    try:
        if messaging_service_sid:
            message = client.messages.create(body=body, messaging_service_sid=messaging_service_sid, to=to)
        else:
            message = client.messages.create(body=body, from_=from_number, to=to)
    except TwilioRestException as e:
        raise TwilioServiceError(f"Twilio failed to send the SMS: {e}") from e

    return {"sid": message.sid, "status": message.status, "to": to, "from": messaging_service_sid or from_number}


def place_call(username: str, to: str, message: str) -> Dict[str, Any]:
    client, from_number, _messaging_service_sid = _client(username)
    to = (to or "").strip()
    message = (message or "").strip()
    if not to:
        raise TwilioServiceError("'to' phone number is required.")
    if not message:
        raise TwilioServiceError("'message' is required.")

    # Escape for safe embedding inside TwiML XML.
    escaped = (
        message.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    )
    twiml = f"<Response><Say>{escaped}</Say></Response>"

    try:
        call = client.calls.create(twiml=twiml, from_=from_number, to=to)
    except TwilioRestException as e:
        raise TwilioServiceError(f"Twilio failed to place the call: {e}") from e

    return {"sid": call.sid, "status": call.status, "to": to, "from": from_number}
