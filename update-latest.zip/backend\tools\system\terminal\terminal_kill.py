# AthenaUI -- Terminal Kill Tool
# File: backend/tools/system/terminal/terminal_kill.py
#
# Forcefully stops a terminal session opened by terminal_run (its whole
# process tree, same approach as process_kill) and forgets it -- for a
# hung/stuck session_id a plain terminal_check can no longer usefully
# recover (e.g. a wedged dev server, or a session the agent is done with).
# Destructive -- same approval tier as terminal_run/process_kill.

from __future__ import annotations

import os
from typing import Any, Dict

import psutil

from . import _session

capabilities = {
    "needs_filesystem": False,
    "needs_bridge": False,
    "needs_network": False,
    "needs_user": True,
    "is_dangerous": True,
}


def _self_protected_pids() -> set:
    """AthenaUI's own backend process and its ancestors -- never killable
    through this tool, even by mistake."""
    protected = set()
    try:
        proc = psutil.Process(os.getpid())
        while proc is not None:
            protected.add(proc.pid)
            proc = proc.parent()
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        pass
    return protected


async def run(args: Dict[str, Any]) -> Dict[str, Any]:
    session_id = args.get("session_id")
    if not session_id:
        return {"status": "error", "error": "Missing required argument: session_id."}

    proc = _session.get_proc(session_id)
    if proc is None or proc.poll() is not None:
        _session.forget_session(session_id)
        return {"status": "ok", "killed": [], "note": "Session's process was already stopped (or never existed); removed from tracking."}

    if proc.pid in _self_protected_pids():
        return {"status": "error", "error": "Refusing to kill AthenaUI's own backend process."}

    killed = []
    try:
        target = psutil.Process(proc.pid)
        procs = [target] + target.children(recursive=True)
        for p in procs:
            try:
                name = p.name()
                p.terminate()
                killed.append({"pid": p.pid, "name": name})
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        _, alive = psutil.wait_procs(procs, timeout=3)
        for p in alive:
            try:
                p.kill()
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
    except psutil.NoSuchProcess:
        pass

    _session.forget_session(session_id)
    return {"status": "ok", "killed": killed}
