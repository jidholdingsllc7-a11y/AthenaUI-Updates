"""
Static end-user-facing grouping of the tool registry's ~138 tools into
labeled categories, mirroring the `# ---- LABEL ----` comment banners in
loader.py (the registry itself carries no category metadata). Used to power
the tool picker on the dedicated /chat page (see GET /chat/tool_catalog and
ChatEngine._agent_tool_names' explicit_tool_names path) -- NOT used for any
access-control decision on its own, just UI grouping.
"""

from __future__ import annotations

from typing import Any, Dict, List, TypedDict


class ToolCategory(TypedDict):
    id: str
    label: str
    tool_names: List[str]
    always_on: bool


TOOL_CATEGORIES: List[ToolCategory] = [
    {
        "id": "memory",
        "label": "Memory (MMS)",
        "tool_names": ["memory_search", "memory_recall_summary", "memory_recall_details"],
        "always_on": True,
    },
    {
        "id": "fs",
        "label": "Files & Code",
        "tool_names": [
            "file_read", "file_write", "file_edit_lines", "file_delete",
            "file_delete_proposal", "file_diff", "file_search", "grep_search",
            "file_list_dir", "file_list_dir_recursive", "workspace_overview",
            "file_mkdir", "file_copy", "file_move", "file_metadata", "select_language",
            "file_read_multiple", "list_allowed_directories",
        ],
        "always_on": False,
    },
    {
        "id": "http",
        "label": "HTTP / Webhooks",
        "tool_names": ["http_request", "webhook_trigger"],
        "always_on": False,
    },
    {
        "id": "terminal",
        "label": "Terminal",
        "tool_names": ["terminal_run", "terminal_check", "terminal_list", "terminal_kill"],
        "always_on": False,
    },
    {
        "id": "build_check",
        "label": "Build & Test",
        "tool_names": ["project_build_check", "project_lint_test"],
        "always_on": False,
    },
    {
        "id": "process",
        "label": "Process / Port",
        "tool_names": ["process_list", "port_check", "process_kill"],
        "always_on": False,
    },
    {
        "id": "git",
        "label": "Git",
        "tool_names": ["git_diff", "git_log", "git_blame"],
        "always_on": False,
    },
    {
        "id": "search",
        "label": "Web Search",
        "tool_names": ["web_search"],
        "always_on": False,
    },
    {
        "id": "build_map",
        "label": "Build Map",
        "tool_names": [
            "build_map.create", "build_map.update", "build_map.get",
            "build_map.execute", "build_map.verify",
        ],
        "always_on": False,
    },
    {
        "id": "images",
        "label": "Images",
        "tool_names": [
            "image_generate", "image_generate_avatar", "image_generate_character",
            "image_generate_campaign", "image_check_capability",
            "image_save_to_workspace", "image_generate_selfie",
            "image_generate_pair", "image_generate_group",
            "image_gallery_list", "image_analyze", "avatar_set_glow",
        ],
        "always_on": True,
    },
    {
        "id": "ui",
        "label": "UI Automation",
        "tool_names": [
            "ui_inspect", "ui_dom_tree", "ui_navigate", "ui_screenshot_full",
            "ui_screenshot_element", "ui_screenshot_annotated", "ui_ocr_search",
            "ui_image_match", "ui_highlight", "ui_locate_element", "screen_info",
            "mouse_move", "mouse_click", "right_click", "double_click", "hover",
            "scroll", "drag", "drag_offset", "keyboard_type", "hotkey", "monitors",
            "move_to_monitor", "record_start", "record_stop", "record_log",
        ],
        "always_on": False,
    },
    {
        "id": "board",
        "label": "Post-it Board",
        "tool_names": ["board_list", "board_post", "board_edit", "board_delete"],
        "always_on": False,
    },
    {
        "id": "brokerage",
        "label": "Brokerage (Alpaca)",
        "tool_names": [
            "alpaca_get_account", "alpaca_research_stock", "alpaca_get_positions",
            "alpaca_list_orders", "alpaca_place_order",
        ],
        "always_on": False,
    },
    {
        "id": "market_data",
        "label": "Market Data",
        "tool_names": ["massive_get_bars"],
        "always_on": False,
    },
    {
        "id": "scheduler",
        "label": "Scheduler",
        "tool_names": ["schedule_job", "schedule_list", "schedule_cancel", "schedule_log_create", "scheduler_set_recurring_pace"],
        "always_on": False,
    },
    {
        "id": "atlas_reference",
        "label": "Atlas Reference",
        "tool_names": ["atlas_system_specs_lookup"],
        "always_on": False,
    },
    {
        "id": "expert_library",
        "label": "Build an Expert",
        "tool_names": ["expert_library_lookup"],
        "always_on": False,
    },
    {
        "id": "relationships",
        "label": "Relationships",
        "tool_names": ["relationship_propose_upgrade", "relationship_respond_to_proposal"],
        "always_on": True,
    },
    {
        "id": "database",
        "label": "Shared SQL Databases",
        "tool_names": ["db_create", "db_list", "db_query", "db_share", "db_unshare"],
        "always_on": False,
    },
    {
        "id": "athena_net",
        "label": "Athena Net (Shared Team Folder)",
        "tool_names": ["athena_net_upload_file", "athena_net_list_files"],
        "always_on": False,
    },
    {
        "id": "email",
        "label": "Email",
        "tool_names": [
            "email_send", "email_list_accounts", "email_list_inbox",
            "email_read_message", "email_delete_message", "email_delete_messages",
            "email_cleanup_rule_add", "email_cleanup_rule_search",
        ],
        "always_on": False,
    },
    {
        "id": "crm",
        "label": "CRM",
        "tool_names": [
            "crm_add_customer", "crm_list_customers", "crm_log_activity",
            "crm_update_stage", "crm_update_contact_info",
        ],
        "always_on": False,
    },
    {
        "id": "troubleshooting",
        "label": "Troubleshooting Tips",
        "tool_names": ["troubleshooting_tip_search", "troubleshooting_tip_add"],
        "always_on": False,
    },
    {
        "id": "marketing_tips",
        "label": "Marketing Tips",
        "tool_names": ["marketing_tip_search", "marketing_tip_add"],
        "always_on": False,
    },
    {
        "id": "newsletter",
        "label": "Newsletter",
        "tool_names": [
            "newsletter_subscribe_customer", "newsletter_list_subscribers",
            "newsletter_send_campaign", "newsletter_save_draft",
        ],
        "always_on": False,
    },
    {
        "id": "artifacts",
        "label": "Artifacts",
        "tool_names": ["render_artifact", "coin_toss"],
        "always_on": False,
    },
    {
        "id": "twilio",
        "label": "Twilio (SMS / Calls)",
        "tool_names": ["sms_check_capability", "sms_send", "call_place"],
        "always_on": False,
    },
    {
        "id": "competitors",
        "label": "Competitor Tracking",
        "tool_names": ["competitor_add", "competitor_scrape", "competitor_list"],
        "always_on": False,
    },
    {
        "id": "calendar",
        "label": "Calendar",
        "tool_names": ["calendar_add_event", "calendar_list_events"],
        "always_on": False,
    },
    {
        "id": "social_media",
        "label": "Social Media",
        "tool_names": [
            "social_media_check_capability", "social_media_post_x",
            "social_media_draft_manual_post",
            "social_media_x_check_mentions", "social_media_x_reply",
            "social_media_x_like", "social_media_x_retweet",
            "social_media_x_get_tweet", "social_media_x_check_dms",
            "social_media_x_send_dm",
            "social_media_post_facebook", "social_media_post_moltbook",
            "social_media_register_moltbook_agent", "social_media_moltbook_check_feed",
            "social_media_moltbook_explore", "social_media_moltbook_comment",
        ],
        "always_on": False,
    },
    {
        "id": "spreadsheets",
        "label": "Spreadsheets",
        "tool_names": [
            "spreadsheet_list", "spreadsheet_create", "spreadsheet_save_as_template",
            "spreadsheet_create_from_template", "spreadsheet_add_row",
            "spreadsheet_update_row", "spreadsheet_export",
        ],
        "always_on": False,
    },
    {
        "id": "subagent",
        "label": "Sub-Agent",
        "tool_names": ["run_subagent"],
        "always_on": False,
    },
    {
        "id": "collab",
        "label": "Collab Chat",
        "tool_names": ["collab_start_discussion", "collab_rate_limit_grant"],
        "always_on": True,
    },
]


def tool_catalog_payload() -> Dict[str, Any]:
    """JSON-serializable payload for GET /chat/tool_catalog."""
    return {"categories": TOOL_CATEGORIES}
