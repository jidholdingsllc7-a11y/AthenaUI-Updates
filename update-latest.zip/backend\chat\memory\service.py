﻿# AthenaUI v3.5 — Memory Manager
# File: backend/chat/memory/service.py
# Created: 2026-04-06 21:21 CDT
# Updated: 2026-07-30 22:10 CDT
"""
Handles long-term memory (Maximos Memory Server) -- extracted/"remembered"
facts, distinct from the raw chat transcript (see chat/history/service.py's
HistoryManager, also Maximos-backed). Both used to also lean on Redis for a
short-term buffer; that's gone now -- Maximos was built to replace Redis AND
the old Vault-blob storage for agent memory entirely, and the raw transcript
already covers "recent turns" via HistoryManager, so a second short-term
Redis buffer here was pure duplication (its append path was never even
called anywhere).

IMPORTANT: memory is scoped per (username, character) -- every method below
takes `character` as an explicit parameter (same pattern as
chat/persona/service.py's PersonaManager). Passing `character=None` targets
a distinct, explicitly-shared "global" bucket (for chats with no character
selected) -- it does NOT silently merge every character's memory together.
"""

import logging
import re
from typing import List, Optional

from chat.memory.maximos_client import get_client as get_maximos_client
from chat.history.service import CHANNEL_JOB_NOTE, CHANNEL_AGENT_SUMMARY

logger = logging.getLogger(__name__)

# Dedicated channel for Task Builder job completion notes (see
# tasks/engine/service.py), kept separate from ordinary chat turns.
JOB_NOTE_CHANNEL = CHANNEL_JOB_NOTE


def job_note_tag(job_key: str) -> str:
    """The literal substring every note/search for a given job is tagged
    with. Maximos's search matches ALL whitespace-split tokens as
    substrings, so this must stay a single unbroken token."""
    slug = re.sub(r"[^a-zA-Z0-9]+", "_", job_key.strip()).strip("_").lower()
    return f"[job:{slug or 'untitled'}]"


class MemoryManager:
    def __init__(self, username: str):
        self.username = username
        self.maximos = get_maximos_client()

    @staticmethod
    def _agent_id(character: Optional[str]) -> str:
        return character or "global"

    # ---------------------------------------------------------
    # Long-term memory (Maximos Memory Server) -- per character
    # ---------------------------------------------------------
    def load_long_memory(self, character: Optional[str], query_text: str, limit: int = 5) -> List[str]:
        """Returns long-term memory entries for this character relevant to
        `query_text` (server-side substring search against that character's
        own isolated [user_id][agent_id] pipeline)."""
        if not query_text:
            return []
        entries = self.maximos.search(self.username, self._agent_id(character), query_text, limit=limit)
        return [str(e["content"]) for e in entries if e.get("content")]

    def load_recent_memory(self, character: Optional[str], limit: int = 10) -> List[str]:
        """Returns this character's most recent long-term memory entries by
        recency, ignoring keyword relevance entirely (an empty query on the
        Maximos server returns everything, sorted newest-first). Used to
        proactively give a brand-new conversation (private OR group) context
        about a returning user instead of only reacting to whatever keywords
        happen to appear in their first message."""
        entries = self.maximos.search(self.username, self._agent_id(character), "", limit=limit)
        return [str(e["content"]) for e in entries if e.get("content")]

    def append_long_memory(self, character: Optional[str], text: str):
        self.maximos.store_memory(self.username, self._agent_id(character), text)

    # ---------------------------------------------------------
    # Agent summaries -- a short, LLM-generated recollection of ONE
    # interaction (one user message + one agent reply), timestamped to when
    # that interaction actually happened rather than when the summary was
    # generated, plus a pointer back to the raw entries it summarizes. This
    # is a denser, purpose-built recall index -- searching it is much more
    # signal-rich than keyword-matching raw transcript text for "have we
    # talked about this before?"-style questions spanning a long history.
    # ---------------------------------------------------------
    def append_summary(
        self,
        character: Optional[str],
        summary: str,
        *,
        created_at: str,
        source_entry_ids: List[str],
    ) -> Optional[str]:
        summary = (summary or "").strip()
        if not summary:
            return None
        return self.maximos.store_memory(
            self.username,
            self._agent_id(character),
            summary,
            channel=CHANNEL_AGENT_SUMMARY,
            created_at=created_at,
            source_entry_ids=source_entry_ids,
        )

    def recall_summaries(self, character: Optional[str], query_text: str, limit: int = 5) -> List[dict]:
        """Searches this character's agent-summary layer for `query_text`
        (or returns the most recent summaries if blank), newest first. Each
        result keeps its real `created_at` (the original interaction's
        timestamp, not the summary's) and `source_entry_ids` so the caller
        can fetch the exact raw exchange for verbatim quoting."""
        return self.maximos.search(
            self.username, self._agent_id(character), query_text, channel=CHANNEL_AGENT_SUMMARY, limit=limit
        )

    def get_summary_sources(self, character: Optional[str], entry_ids: List[str]) -> List[dict]:
        """Fetches the raw entries a summary's `source_entry_ids` point to,
        for verbatim quoting. Silently skips any id that fails to fetch
        (e.g. it aged out or was deleted)."""
        agent_id = self._agent_id(character)
        out = []
        for entry_id in entry_ids:
            entry = self.maximos.get_memory(self.username, agent_id, entry_id)
            if entry:
                out.append(entry)
        return out

    # ---------------------------------------------------------
    # Per-job memory (Task Builder "teach the agent" notes)
    # ---------------------------------------------------------
    def append_job_note(self, character: Optional[str], job_key: str, note: str) -> None:
        """Records one durable note about a Task Builder job run (outcome,
        turns used, final update), tagged so `load_job_notes` can reliably
        find only this job's own history later, independent of the 50-turn
        short-history window or generic keyword luck."""
        tag = job_note_tag(job_key)
        self.maximos.store_memory(
            self.username, self._agent_id(character), f"{tag} {note}", channel=JOB_NOTE_CHANNEL
        )

    def load_job_notes(self, character: Optional[str], job_key: str, limit: int = 5) -> List[str]:
        """Returns this job's own past completion notes, newest first, with
        the internal tag stripped back off for display/injection."""
        tag = job_note_tag(job_key)
        entries = self.maximos.search(
            self.username, self._agent_id(character), tag, channel=JOB_NOTE_CHANNEL, limit=limit
        )
        notes = [str(e["content"]) for e in entries if e.get("content")]
        return [n[len(tag):].strip() if n.startswith(tag) else n for n in notes]

    # ---------------------------------------------------------
    # Combined memory for injection
    # ---------------------------------------------------------
    def build_memory_prompt(self, character: Optional[str] = None, query_text: str = "") -> str:
        """
        Returns a single string of long-term memories relevant to
        `query_text` (Maximos Memory Server), scoped to this character.
        Recent raw turns are handled separately by HistoryManager and
        already get injected as real role-tagged messages, so they're
        deliberately not duplicated here.
        """
        long = self.load_long_memory(character, query_text)
        if not long:
            return ""
        return "\n".join(f"- {m}" for m in long)
