# AthenaUI v3.7 -- expert_library_lookup Tool
# File: backend/tools/system/characters/expert_library_lookup.py
#
# Generic "Build an Expert" lookup -- unlike atlas_system_specs_lookup (which
# is hardcoded to one character name), this resolves PER CALLER: whichever
# character is actually chatting gets THEIR OWN private expert_library.md,
# if they have one built. Gated the same way (character-name check inside
# the tool itself, not just allowlist placement) so a character without a
# library -- or querying on someone else's behalf -- can't read another
# character's library.

from __future__ import annotations

import re
from typing import Any, Dict

capabilities = {
    "needs_bridge": False,
    "needs_filesystem": True,
    "needs_network": False,
    "needs_user": True,
}


def _split_sections(text: str):
    """Splits on top-level (##) headings, keeping each heading with its body."""
    parts = re.split(r"(?m)^(?=## )", text)
    return [p for p in parts if p.strip()]


async def run(args: Dict[str, Any]):
    character = (args.get("character") or "").strip()
    username = (args.get("username") or "").strip()
    if not character or not username:
        return {"error": "No character/user context -- this tool must be called from an active chat."}

    from characters.expert_library.service import get_status, get_content

    status = get_status(username, character)
    if not status["enabled"]:
        return {"error": f"{character} doesn't have an expert library built yet."}

    text = get_content(username, character)
    if not text:
        return {"error": "Expert library file is missing."}

    query = (args.get("query") or "").strip().lower()
    if not query:
        return {"content": text}

    sections = _split_sections(text)
    words = [w for w in re.split(r"\W+", query) if w]
    scored = [(sum(s.lower().count(w) for w in words), s) for s in sections]
    scored = [pair for pair in scored if pair[0] > 0]
    if scored:
        scored.sort(key=lambda pair: pair[0], reverse=True)
        top_score = scored[0][0]
        best = [s for score, s in scored if score >= top_score * 0.5]
        return {"content": "\n\n".join(best[:2])}

    headings = [re.match(r"## .+", s).group(0) for s in sections if re.match(r"## .+", s)]
    return {
        "content": (
            f"No section matched '{args.get('query')}'. Available sections:\n"
            + "\n".join(f"- {h}" for h in headings)
            + "\n\nCall again with no query to get the full document, or try a different query term."
        )
    }
