# AthenaUI v3.5 — Backup File Encryption
# File: backend/backup/crypto.py
#
# Proprietary passphrase-based encryption for the ".athenabak" full-system
# backup file, mirroring the Maximos Memory Server's own ".mxbak" backup
# scheme (see maximos-memory-server-v1-3/src/storage/mod.rs +
# storage/tiers.rs): AES-256-GCM with a key derived from the user's
# passphrase via SHA-256, a random 96-bit nonce per encryption, and a magic
# header so a restore attempt can immediately recognize/reject a file that
# isn't an AthenaUI backup at all (before ever trying to decrypt it).
#
# This is deliberately independent from any of the individual Maximos
# Memory Server ".mxbak" blobs that get embedded *inside* an AthenaUI
# backup archive (see backup/service.py) -- those are already encrypted by
# the Maximos Memory Server itself (same passphrase, its own AES-256-GCM
# scheme) and are stored here as opaque bytes, never re-derived or
# double-encrypted.

from __future__ import annotations

import hashlib
import os

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.exceptions import InvalidTag

BACKUP_MAGIC = b"ATHNABK1"
NONCE_LEN = 12


class BackupCryptoError(Exception):
    pass


def _derive_key(passphrase: str) -> bytes:
    if not passphrase:
        raise BackupCryptoError("A passphrase is required.")
    return hashlib.sha256(passphrase.encode("utf-8")).digest()


def encrypt_blob(passphrase: str, plaintext: bytes) -> bytes:
    """Encrypts `plaintext` with a key derived from `passphrase`. Returns
    MAGIC || nonce || ciphertext (ciphertext includes the AES-GCM auth
    tag)."""
    key = _derive_key(passphrase)
    nonce = os.urandom(NONCE_LEN)
    ciphertext = AESGCM(key).encrypt(nonce, plaintext, None)
    return BACKUP_MAGIC + nonce + ciphertext


def decrypt_blob(passphrase: str, blob: bytes) -> bytes:
    """Decrypts a blob produced by `encrypt_blob`. Raises BackupCryptoError
    if the magic header is missing/wrong, the blob is truncated, or the
    passphrase is wrong / the data was tampered with (GCM tag mismatch)."""
    if not blob.startswith(BACKUP_MAGIC):
        raise BackupCryptoError("This does not look like an AthenaUI backup file.")
    offset = len(BACKUP_MAGIC)
    if len(blob) < offset + NONCE_LEN:
        raise BackupCryptoError("This backup file is truncated or corrupted.")
    nonce = blob[offset:offset + NONCE_LEN]
    ciphertext = blob[offset + NONCE_LEN:]
    key = _derive_key(passphrase)
    try:
        return AESGCM(key).decrypt(nonce, ciphertext, None)
    except InvalidTag:
        raise BackupCryptoError("Incorrect passphrase, or this backup file is corrupted.")
