﻿# AthenaUI v3.5 — Onboarding Service
# File: backend/llm/onboarding/service.py
# Created: 2026-04-14 22:31 CDT
# Updated: 2026-07-27 19:49 CDT

from config.loader import ConfigLoader
from llm.provider_detection.provider_auto_detector import detect_provider
from llm.provider_detection.provider_model_cache import ProviderModelCache
from vault.service import VaultService


class OnboardingService:
    """
    Handles onboarding state:
    - Provider selection
    - API key storage
    - Model detection
    - Chat model selection
    - Image model selection
    - Completion flag
    """

    def __init__(self, username: str):
        self.config = ConfigLoader()
        self.cache = ProviderModelCache()
        self.username = username

    # ---------------------------------------------------------
    # Step 1: Provider + API key
    # ---------------------------------------------------------
    def set_provider(self, provider_id: str, api_key: str):
        self.config.onboarding.provider_id = provider_id
        self.config.onboarding.api_key = api_key
        self.config.save_onboarding()

        VaultService.set_secret(self.username, "llm.provider_id", provider_id)
        VaultService.set_secret(self.username, f"llm.{provider_id}.api_key", api_key)
        VaultService.set_provider_key(self.username, "chat", provider_id, {"api_key": api_key})
        VaultService.set_preference(self.username, "llm.provider_id", provider_id)
        VaultService.set_preference(self.username, "llm.provider_source", "custom")

    # ---------------------------------------------------------
    # Step 2: Detect models
    # ---------------------------------------------------------
    def detect_models(self):
        provider_id = self.config.onboarding.provider_id
        api_key = self.config.onboarding.api_key

        result = detect_provider(provider_id, {"api_key": api_key})
        self.cache.update(provider_id, result)
        return result

    # ---------------------------------------------------------
    # Step 3: Select chat model
    # ---------------------------------------------------------
    def save_chat_model(self, model_id: str):
        self.config.onboarding.selected_chat_model = model_id
        self.config.save_onboarding()

        VaultService.set_preference(self.username, "llm.chat_model", model_id)

    # ---------------------------------------------------------
    # Step 4: Select image model
    # ---------------------------------------------------------
    def save_image_model(self, model_id: str):
        self.config.onboarding.selected_image_model = model_id
        self.config.save_onboarding()

        VaultService.set_preference(self.username, "llm.image_model", model_id)

    # ---------------------------------------------------------
    # Step 5: Complete onboarding
    # ---------------------------------------------------------
    def complete(self):
        self.config.onboarding.completed = True
        self.config.save_onboarding()

        VaultService.set_preference(self.username, "onboarding.completed", True)

    def is_complete(self) -> bool:
        return self.config.onboarding.completed

