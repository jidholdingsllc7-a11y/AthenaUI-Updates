# AthenaUI v3.5 — Scheduler Service
# File: backend/scheduler/service.py
#
# Lets any character propose a future scheduled task (buy/sell a symbol,
# a research follow-up, a marketing task, etc.) that sits in
# "awaiting_approval" until the user explicitly reviews and approves it via
# the frontend's checkbox permission popup. Approved jobs are picked up by
# scheduler/runner.py's background loop and executed at their scheduled
# time -- even across a backend restart, since (unlike the in-memory-only
# brokerage task loop) every job is persisted through VaultController's
# per-user encrypted app-key store, mirroring brokerage/settings.py's
# established pattern.

from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from logs_system.system.service import system_logger
from vault.controller import VaultController
from workspace.service import WorkspaceService

JOBS_APP_NAME = "scheduled_jobs"

# Safety rails, independent of anything the model or user provides.
MAX_FUTURE_DAYS = 90
MIN_FUTURE_SECONDS = 30
MAX_ESTIMATED_TURNS = 20

# A recurring job (repeat_every_minutes set) re-executes indefinitely until
# the user cancels its currently-pending occurrence -- keep the interval
# sane so a forgotten recurring check can't hammer a rate-limited API (e.g.
# X's mentions/DM endpoints) or spin the scheduler loop pointlessly fast.
MIN_REPEAT_MINUTES = 5
MAX_REPEAT_MINUTES = 10080  # 1 week

_OPEN_STATUSES = ("awaiting_approval", "approved")


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def parse_iso(value: str) -> datetime:
    """Parses an ISO 8601 datetime, tolerating a trailing 'Z' (which
    Python's datetime.fromisoformat only accepts on 3.11+)."""
    return datetime.fromisoformat(str(value).strip().replace("Z", "+00:00"))


def list_jobs(username: str, status: Optional[str] = None) -> List[Dict[str, Any]]:
    data = VaultController.get_app_key(username, JOBS_APP_NAME) or {}
    jobs = data.get("jobs", [])
    if not isinstance(jobs, list):
        return []
    if status:
        jobs = [j for j in jobs if isinstance(j, dict) and j.get("status") == status]
    return jobs


def _save_jobs(username: str, jobs: List[Dict[str, Any]]) -> None:
    VaultController.set_app_key(username, JOBS_APP_NAME, {"jobs": jobs})


def _find(jobs: List[Dict[str, Any]], job_id: str) -> Optional[Dict[str, Any]]:
    for j in jobs:
        if isinstance(j, dict) and j.get("job_id") == job_id:
            return j
    return None


def prune_expired_awaiting_approval_jobs(username: str) -> int:
    jobs = list_jobs_raw(username)
    now = datetime.now(timezone.utc)
    kept: List[Dict[str, Any]] = []
    removed = 0

    for job in jobs:
        if not isinstance(job, dict):
            continue
        if job.get("status") == "awaiting_approval":
            try:
                run_at = parse_iso(job["run_at"])
            except Exception:
                run_at = None
            if run_at is None or run_at < now:
                removed += 1
                continue
        kept.append(job)

    if removed:
        _save_jobs(username, kept)
    return removed


def list_jobs_raw(username: str) -> List[Dict[str, Any]]:
    data = VaultController.get_app_key(username, JOBS_APP_NAME) or {}
    jobs = data.get("jobs", [])
    return jobs if isinstance(jobs, list) else []


def delete_all_jobs(username: str) -> int:
    jobs = list_jobs_raw(username)
    pending_jobs = [job for job in jobs if isinstance(job, dict) and job.get("status") == "awaiting_approval"]
    if not pending_jobs:
        return 0
    kept = [job for job in jobs if not (isinstance(job, dict) and job.get("status") == "awaiting_approval")]
    _save_jobs(username, kept)
    _log_tail_event(
        username,
        "Deleted all pending scheduled jobs.",
        {"deleted": len(pending_jobs), "job_ids": [job.get("job_id") for job in pending_jobs if job.get("job_id")]},
    )
    return len(pending_jobs)


def delete_pending_jobs(username: str, job_ids: List[str]) -> int:
    pending_ids = {str(job_id) for job_id in job_ids if str(job_id).strip()}
    if not pending_ids:
        return 0

    jobs = list_jobs_raw(username)
    kept: List[Dict[str, Any]] = []
    removed = 0

    for job in jobs:
        if not isinstance(job, dict):
            continue
        job_id = str(job.get("job_id") or "")
        if job_id in pending_ids and job.get("status") == "awaiting_approval":
            removed += 1
            if job.get("log_file"):
                append_log(
                    username,
                    job.get("log_file"),
                    f"- [{_now_iso()}] Job {job_id} deleted before approval.",
                )
            _log_tail_event(
                username,
                f"Deleted pending scheduled job {job_id}.",
                {"job_id": job_id, "character": job.get("character"), "run_at": job.get("run_at")},
            )
            continue
        kept.append(job)

    if removed:
        _save_jobs(username, kept)
    return removed


def get_job(username: str, job_id: str) -> Optional[Dict[str, Any]]:
    """Looks up a single job by id (used by conditional-scheduling to resolve
    a job's `depends_on_job_id`)."""
    return _find(list_jobs(username), job_id)


def find_time_collision(username: str, parsed: datetime) -> Optional[Dict[str, Any]]:
    """Returns the first still-open job (any character -- the scheduler is
    shared across every character this user talks to, not per-agent) already
    booked for the exact same instant, so two agents don't silently collide
    on the same run_at time."""
    for job in list_jobs(username):
        if job.get("status") not in _OPEN_STATUSES:
            continue
        try:
            if parse_iso(job["run_at"]) == parsed:
                return job
        except Exception:
            continue
    return None


# Allowed values for a job's `condition` field (only meaningful together with
# `depends_on_job_id`) -- kept as a plain tuple rather than an enum since jobs
# are stored as plain dicts through VaultController, same as every other field.
CONDITIONS = ("prior_success", "prior_success_and_position_open")


def create_job(
    username: str,
    character: str,
    task_description: str,
    run_at: str,
    reasoning: str,
    estimated_turns: int = 3,
    log_file: Optional[str] = None,
    depends_on_job_id: Optional[str] = None,
    condition: Optional[str] = None,
    condition_symbol: Optional[str] = None,
    dry_run: bool = False,
    validate_brokerage: bool = False,
    notional_estimate: Optional[float] = None,
    repeat_every_minutes: Optional[int] = None,
    active_repeat_every_minutes: Optional[int] = None,
) -> Dict[str, Any]:
    parsed = parse_iso(run_at)
    now = datetime.now(timezone.utc)
    if (parsed - now).total_seconds() < MIN_FUTURE_SECONDS:
        raise ValueError("run_at must be at least 30 seconds in the future.")
    if (parsed - now).days > MAX_FUTURE_DAYS:
        raise ValueError(f"run_at cannot be more than {MAX_FUTURE_DAYS} days in the future.")

    # 0 (and other falsy values) mean "no recurrence", same as omitting the
    # field entirely -- a caller/character scheduling a one-off task may
    # naturally pass 0 rather than leaving the key out, so treat both the
    # same instead of rejecting 0 against the >=5 minimum below.
    repeat_every_minutes = repeat_every_minutes or None
    active_repeat_every_minutes = active_repeat_every_minutes or None

    if repeat_every_minutes is not None:
        repeat_every_minutes = int(repeat_every_minutes)
        if repeat_every_minutes < MIN_REPEAT_MINUTES or repeat_every_minutes > MAX_REPEAT_MINUTES:
            raise ValueError(
                f"repeat_every_minutes must be between {MIN_REPEAT_MINUTES} and {MAX_REPEAT_MINUTES}."
            )
    if active_repeat_every_minutes is not None:
        active_repeat_every_minutes = int(active_repeat_every_minutes)
        if active_repeat_every_minutes < MIN_REPEAT_MINUTES or active_repeat_every_minutes > MAX_REPEAT_MINUTES:
            raise ValueError(
                f"active_repeat_every_minutes must be between {MIN_REPEAT_MINUTES} and {MAX_REPEAT_MINUTES}."
            )

    if depends_on_job_id and not get_job(username, depends_on_job_id):
        raise ValueError(f"depends_on_job_id '{depends_on_job_id}' does not match any existing job.")
    if condition and condition not in CONDITIONS:
        raise ValueError(f"condition must be one of {CONDITIONS}.")
    if condition == "prior_success_and_position_open" and not condition_symbol:
        raise ValueError("condition_symbol is required for condition='prior_success_and_position_open'.")

    collision = find_time_collision(username, parsed)
    if collision:
        raise ValueError(
            f"That time slot is taken -- {collision.get('character')} already has a task "
            f"scheduled for {collision['run_at']} (job_id={collision['job_id']}). "
            "Please pick a different run_at/delay_minutes."
        )

    # Best-effort snapshot of the active paper/live mode at SCHEDULE time --
    # if the user flips modes before this job actually runs, the runner can
    # detect the mismatch and refuse to execute rather than silently trading
    # in the wrong account. Never blocks job creation if brokerage isn't
    # configured/importable for some reason.
    expected_mode: Optional[str] = None
    try:
        from brokerage import settings as brokerage_settings
        expected_mode = brokerage_settings.get_active_mode(username)
    except Exception:
        pass

    jobs = list_jobs(username)
    job: Dict[str, Any] = {
        "job_id": str(uuid.uuid4()),
        "username": username,
        "character": character,
        "task_description": task_description,
        "reasoning": reasoning,
        "run_at": parsed.isoformat(),
        "estimated_turns": max(1, min(int(estimated_turns), MAX_ESTIMATED_TURNS)),
        "status": "awaiting_approval",
        "created_at": _now_iso(),
        "decided_at": None,
        "executed_at": None,
        "result": None,
        "error": None,
        "log_file": log_file,
        "depends_on_job_id": depends_on_job_id,
        "condition": condition,
        "condition_symbol": condition_symbol,
        "dry_run": bool(dry_run),
        "validate_brokerage": bool(validate_brokerage) or bool(dry_run),
        "notional_estimate": notional_estimate,
        "expected_mode": expected_mode,
        "repeat_every_minutes": repeat_every_minutes,
        "active_repeat_every_minutes": active_repeat_every_minutes,
        "recurring_group_id": str(uuid.uuid4()) if repeat_every_minutes else None,
        "next_pace": None,
    }
    jobs.append(job)
    _save_jobs(username, jobs)
    return job


def set_next_pace(username: str, job_id: str, pace: str, reason: Optional[str] = None) -> Dict[str, Any]:
    """Called (via the scheduler_set_recurring_pace tool) by a character
    WHILE a recurring job is executing, to control how soon its NEXT
    occurrence should run: 'active' uses active_repeat_every_minutes (a
    short interval, for an ongoing back-and-forth that needs fast
    re-checks), 'idle' uses the job's normal repeat_every_minutes. Only
    affects the occurrence schedule_next_occurrence creates right after this
    run finishes -- every new occurrence starts back at 'idle' by default,
    so staying fast requires calling this again each cycle the conversation
    is still ongoing."""
    if pace not in ("active", "idle"):
        raise ValueError("pace must be 'active' or 'idle'.")
    jobs = list_jobs(username)
    job = _find(jobs, job_id)
    if not job:
        raise ValueError("Job not found.")
    if not job.get("repeat_every_minutes"):
        raise ValueError("This job is not recurring -- there is no next occurrence to adjust.")
    job["next_pace"] = pace
    job["next_pace_reason"] = reason
    _save_jobs(username, jobs)
    return job


def schedule_next_occurrence(username: str, completed_job: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Called by scheduler/runner.py right after a recurring job (one with
    repeat_every_minutes set) finishes -- success or failure, so a transient
    error (e.g. a rate limit) doesn't silently kill the whole recurring
    check. Creates the next occurrence already in 'approved' status, with NO
    fresh approval popup -- the user approved the recurring nature of this
    task once, when they approved its very first occurrence. Returns None
    (does nothing) if the job isn't recurring. To stop a chain, the user
    cancels its currently-pending occurrence (POST /scheduler/jobs/{id}/cancel,
    already supported since cancel_job() allows 'approved' status) -- there's
    always at most one pending occurrence per chain, so this fully stops it.
    """
    interval = completed_job.get("repeat_every_minutes")
    if not interval:
        return None

    pace = completed_job.get("next_pace") or "idle"
    active_interval = completed_job.get("active_repeat_every_minutes")
    effective_interval = active_interval if (pace == "active" and active_interval) else interval

    run_at = (datetime.now(timezone.utc) + timedelta(minutes=int(effective_interval))).isoformat()
    jobs = list_jobs(username)
    job: Dict[str, Any] = {
        "job_id": str(uuid.uuid4()),
        "username": username,
        "character": completed_job.get("character"),
        "task_description": completed_job.get("task_description"),
        "reasoning": completed_job.get("reasoning"),
        "run_at": run_at,
        "estimated_turns": completed_job.get("estimated_turns", 3),
        "status": "approved",
        "created_at": _now_iso(),
        "decided_at": _now_iso(),
        "executed_at": None,
        "result": None,
        "error": None,
        "log_file": completed_job.get("log_file"),
        "depends_on_job_id": None,
        "condition": None,
        "condition_symbol": None,
        "dry_run": False,
        "validate_brokerage": False,
        "notional_estimate": None,
        "expected_mode": completed_job.get("expected_mode"),
        "repeat_every_minutes": interval,
        "active_repeat_every_minutes": active_interval,
        "recurring_group_id": completed_job.get("recurring_group_id"),
        "next_pace": None,
        "next_pace_reason": None,
    }
    jobs.append(job)
    _save_jobs(username, jobs)
    return job


def decide_job(username: str, job_id: str, approve: bool) -> Dict[str, Any]:
    jobs = list_jobs(username)
    job = _find(jobs, job_id)
    if not job:
        raise ValueError("Job not found.")
    if job.get("status") != "awaiting_approval":
        raise ValueError(f"Job is not awaiting approval (status={job.get('status')}).")
    job["status"] = "approved" if approve else "rejected"
    job["decided_at"] = _now_iso()
    if not approve:
        job["result"] = "Rejected by user."
        if job.get("log_file"):
            append_log(
                username,
                job.get("log_file"),
                f"- [{job['decided_at']}] Job {job_id} REJECTED by user.",
            )
        _log_tail_event(
            username,
            f"Rejected scheduled job {job_id}.",
            {"job_id": job_id, "character": job.get("character"), "run_at": job.get("run_at")},
        )
    _save_jobs(username, jobs)
    return job


def cancel_job(username: str, job_id: str) -> Dict[str, Any]:
    jobs = list_jobs(username)
    job = _find(jobs, job_id)
    if not job:
        raise ValueError("Job not found.")
    if job.get("status") not in _OPEN_STATUSES:
        raise ValueError(f"Cannot cancel a job with status={job.get('status')}.")
    job["status"] = "cancelled"
    job["decided_at"] = _now_iso()
    _save_jobs(username, jobs)
    return job


def mark_result(username: str, job_id: str, ok: bool, result: Optional[str] = None, error: Optional[str] = None) -> None:
    jobs = list_jobs(username)
    job = _find(jobs, job_id)
    if not job:
        return
    job["status"] = "completed" if ok else "failed"
    job["executed_at"] = _now_iso()
    job["result"] = result
    job["error"] = error
    _save_jobs(username, jobs)


def mark_skipped(username: str, job_id: str, reason: str) -> None:
    """Terminal state for a conditional job whose dependency resolved to
    'do not run' (e.g. the buy failed, or the position isn't open) --
    distinct from 'failed' so the user can tell 'the condition correctly
    prevented this' apart from 'this errored out'."""
    jobs = list_jobs(username)
    job = _find(jobs, job_id)
    if not job:
        return
    job["status"] = "skipped"
    job["executed_at"] = _now_iso()
    job["result"] = reason
    _save_jobs(username, jobs)


def has_open_jobs(username: str) -> bool:
    return any(j.get("status") in _OPEN_STATUSES for j in list_jobs(username))


def append_log(username: str, log_file: Optional[str], line: str) -> None:
    """Best-effort append of one line to a workspace-relative scheduled task
    log file. Never raises -- a missing/unwritable log must not block
    scheduling or execution of the underlying job."""
    if not log_file:
        return
    try:
        ws = WorkspaceService.get_workspace(username)
        if ws is None:
            return
        try:
            existing = ws.read_file(log_file)
        except FileNotFoundError:
            existing = ""
        ws.write_file(log_file, existing + line.rstrip("\n") + "\n")
    except Exception:
        pass


def _log_tail_event(username: str, event: str, details: Optional[Dict[str, Any]] = None) -> None:
    try:
        system_logger.log(event=event, agent_state=username, details=details or {})
    except Exception:
        pass
