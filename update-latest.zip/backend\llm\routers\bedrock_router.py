﻿# AthenaUI v3.5 — Provider-specific router for Amazon Bedrock models
# File: backend/llm/routers/bedrock_router.py
# Created: 2026-03-28 21:34 CDT
# Updated: 2026-07-27 19:49 CDT

import json
import hashlib
import hmac
import datetime
import requests
from typing import Any, Dict, List, Optional

from llm.routers.base import BaseLLMRouter
from llm.router_selector.router_selector import RouterSelector
from llm.routers.providers import PROVIDER_BEDROCK
from core.runtime.runtime import get_runtime

from tools.registry.tool_examples import TOOL_EXAMPLES



class BedrockRouter(BaseLLMRouter):
    """
    Provider-specific router for Amazon Bedrock.
    Supports:
    - chat (Anthropic-style messages)
    - tool calling (Anthropic format)
    - streaming (stub)
    """

    SERVICE = "bedrock"
    REGION = "us-east-1"

    # ---------------------------------------------------------
    # Build system prompt with tool examples
    # ---------------------------------------------------------

    def _build_system_prompt(self, base_prompt: Optional[str], *, include_tool_examples: bool = True) -> str:
        if not include_tool_examples:
            return base_prompt if base_prompt else "You are AthenaUI v3.1."

        examples_json = json.dumps(TOOL_EXAMPLES, indent=2)

        tool_usage_block = f"""
You have access to a set of tools. Use them whenever needed.

Here are examples of correct tool usage:
{examples_json}

Amazon Bedrock (Anthropic models) tool calling rules:
- Tools are declared in "tools"
- Tool calls appear as content blocks of type "tool_use"
- Arguments appear in "input"

If you need to call a tool, do NOT explain â€” just call it.
"""

        if base_prompt:
            return base_prompt + "\n\n" + tool_usage_block

        return "You are AthenaUI v3.1.\n\n" + tool_usage_block

    # ---------------------------------------------------------
    # AWS Signature V4 Signing
    # ---------------------------------------------------------

    def _sign_request(self, method: str, url: str, body: str, runtime, region: str):
        access_key = runtime.env.AWS_ACCESS_KEY_ID
        secret_key = runtime.env.AWS_SECRET_ACCESS_KEY
        session_token = runtime.env.AWS_SESSION_TOKEN

        if not access_key or not secret_key:
            raise RuntimeError("AWS credentials not set for Bedrock.")

        t = datetime.datetime.utcnow()
        amz_date = t.strftime("%Y%m%dT%H%M%SZ")
        date_stamp = t.strftime("%Y%m%d")

        canonical_uri = "/model/" + self.model_id + "/invoke"
        canonical_querystring = ""
        canonical_headers = (
            f"content-type:application/json\n"
            f"host:{url}\n"
            f"x-amz-date:{amz_date}\n"
        )

        if session_token:
            canonical_headers += f"x-amz-security-token:{session_token}\n"

        signed_headers = (
            "content-type;host;x-amz-date"
            + (";x-amz-security-token" if session_token else "")
        )

        payload_hash = hashlib.sha256(body.encode("utf-8")).hexdigest()

        canonical_request = (
            f"{method}\n"
            f"{canonical_uri}\n"
            f"{canonical_querystring}\n"
            f"{canonical_headers}\n"
            f"{signed_headers}\n"
            f"{payload_hash}"
        )

        algorithm = "AWS4-HMAC-SHA256"
        credential_scope = f"{date_stamp}/{region}/{self.SERVICE}/aws4_request"
        string_to_sign = (
            f"{algorithm}\n"
            f"{amz_date}\n"
            f"{credential_scope}\n"
            f"{hashlib.sha256(canonical_request.encode('utf-8')).hexdigest()}"
        )

        def sign(key, msg):
            return hmac.new(key, msg.encode("utf-8"), hashlib.sha256).digest()

        k_date = sign(("AWS4" + secret_key).encode("utf-8"), date_stamp)
        k_region = sign(k_date, region)
        k_service = sign(k_region, self.SERVICE)
        k_signing = sign(k_service, "aws4_request")

        signature = hmac.new(
            k_signing, string_to_sign.encode("utf-8"), hashlib.sha256
        ).hexdigest()

        authorization_header = (
            f"{algorithm} "
            f"Credential={access_key}/{credential_scope}, "
            f"SignedHeaders={signed_headers}, "
            f"Signature={signature}"
        )

        headers = {
            "Content-Type": "application/json",
            "X-Amz-Date": amz_date,
            "Authorization": authorization_header,
        }

        if session_token:
            headers["X-Amz-Security-Token"] = session_token

        return headers

    # ---------------------------------------------------------
    # Chat Completion
    # ---------------------------------------------------------

    def chat(
        self,
        messages: List[Dict[str, Any]],
        *,
        tools: Optional[List[Dict[str, Any]]] = None,
        tool_choice: Optional[str] = None,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> Dict[str, Any]:

        runtime = get_runtime()

        region = runtime.env.AWS_REGION or self.REGION
        host = f"bedrock-runtime.{region}.amazonaws.com"

        # Build system prompt with examples
        extracted_prompt, remaining_messages = self._extract_system_prompt(messages)
        final_system_prompt = self._build_system_prompt(system_prompt or extracted_prompt, include_tool_examples=bool(tools))

        # System prompt and tools are cached (cache_control breakpoints) --
        # Bedrock's InvokeModel body for Anthropic models accepts the same
        # Messages API system/cache_control shape as the direct Anthropic API.
        payload: Dict[str, Any] = {
            "anthropic_version": "bedrock-2023-05-31",
            "messages": self._to_anthropic_messages(remaining_messages),
            "system": self._anthropic_system_with_cache(final_system_prompt),
            "temperature": temperature,
            "max_tokens": max_tokens or 2048,
        }

        # Tool calling (Anthropic format)
        if tools:
            payload["tools"] = self._anthropic_tools_with_cache(self._to_anthropic_tools(tools))
            anthropic_tool_choice = self._to_anthropic_tool_choice(tool_choice)
            if anthropic_tool_choice:
                payload["tool_choice"] = anthropic_tool_choice

        body = json.dumps(payload)

        # Bedrock API keys (bearer tokens, generated from the console's
        # "API keys" tab) skip SigV4 signing entirely -- prefer that over
        # the access key/secret pair when present.
        bearer_token = runtime.env.AWS_BEARER_TOKEN_BEDROCK
        if bearer_token:
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {bearer_token}",
            }
        else:
            headers = self._sign_request("POST", host, body, runtime, region)

        # Invoke Bedrock model
        invoke_url = f"https://{host}/model/{self.model_id}/invoke"
        response = requests.post(invoke_url, data=body, headers=headers, timeout=280)
        response.raise_for_status()

        data = response.json()

        # Normalize Bedrock response (Anthropic-style)
        output = data.get("output", {})
        content = output.get("content", [])
        text_content = None
        tool_calls = []

        for block in content:
            if block.get("type") == "text":
                text_content = block.get("text")
            elif block.get("type") == "tool_use":
                tool_calls.append({
                    "id": block.get("id"),
                    "type": "function",
                    "function": {
                        "name": block.get("name"),
                        "arguments": json.dumps(block.get("input") or {}),
                    },
                })

        return {
            "id": data.get("id"),
            "model": self.model_id,
            "content": text_content,
            "tool_calls": tool_calls or None,
            "finish_reason": output.get("stop_reason"),
            "raw": data,
        }

    # ---------------------------------------------------------
    # Streaming (stub)
    # ---------------------------------------------------------

    def stream_chat(self, *args, **kwargs):
        raise NotImplementedError("Bedrock streaming not implemented yet.")


# ---------------------------------------------------------
# Register Router
# ---------------------------------------------------------

RouterSelector.register_router(PROVIDER_BEDROCK, BedrockRouter)

