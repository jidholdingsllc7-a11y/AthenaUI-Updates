﻿# AthenaUI v3.5 — Athena Code Suite API Routes
# File: backend/api/routes/code_suite.py
# Created: 2026-04-07 13:22 CDT
# Updated: 2026-07-27 19:49 CDT

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from typing import Dict, Any

from api.deps.auth_middleware import get_current_user
from code_suite.workspace.service import WorkspaceService, WorkspaceError
from code_suite.changes.service import changeset_service
from code_suite.terminal.service import TerminalService

router = APIRouter(prefix="/code_suite", tags=["code_suite"])


# ---------------- Dependencies ----------------

def _username_from_user(user: Any) -> str:
    if isinstance(user, dict):
        username = user.get("username")
    else:
        username = getattr(user, "username", None)

    if not username:
        raise HTTPException(status_code=401, detail="Authentication required.")
    return str(username)


def get_workspace(user: Any = Depends(get_current_user)) -> WorkspaceService:
    return WorkspaceService(_username_from_user(user))


def get_terminal(user: Any = Depends(get_current_user)) -> TerminalService:
    return TerminalService(_username_from_user(user))


# ---------------- Workspace: read/list/write/create ----------------

@router.get("/tree")
def get_tree(
    path: str = Query(default=".", description="Relative path from workspace root"),
    ws: WorkspaceService = Depends(get_workspace),
):
    try:
        entries = ws.list_dir(path)
        return {"path": path, "entries": entries}
    except WorkspaceError as e:
        return {"error": str(e)}


@router.get("/file")
def read_file(
    path: str = Query(..., description="Relative file path from workspace root"),
    ws: WorkspaceService = Depends(get_workspace),
):
    try:
        content = ws.read_file(path)
        return {"path": path, "content": content}
    except WorkspaceError as e:
        return {"error": str(e)}


@router.post("/file/write")
def write_file(
    payload: Dict[str, Any],
    ws: WorkspaceService = Depends(get_workspace),
):
    """
    Direct write endpoint (for user-driven edits, not agent proposals).
    """
    path = payload["path"]
    content = payload["content"]
    try:
        ws.write_file(path, content)
        return {"status": "ok", "path": path}
    except WorkspaceError as e:
        return {"error": str(e)}


@router.post("/file/create")
def create_file(
    payload: Dict[str, Any],
    ws: WorkspaceService = Depends(get_workspace),
):
    path = payload["path"]
    content = payload.get("content", "")
    try:
        ws.create_file(path, content)
        return {"status": "ok", "path": path}
    except WorkspaceError as e:
        return {"error": str(e)}
    

# ---------------- Agent proposals: delete (pending changes) ----------------
# NOTE: file edits no longer go through a propose/defer step here -- agents
# write live via the file_write / file_edit_lines tools (see
# workspace.service.write_file_tracked), which automatically creates the
# Keep/Revert pending change itself. Deletes are unchanged.

@router.post("/agent/propose_delete")
def agent_propose_delete(
    payload: Dict[str, Any],
    user: Dict[str, Any] = Depends(get_current_user),
):
    """
    Agent calls this to propose a file deletion.
    Does NOT delete yet.
    """
    path = payload["path"]
    username = _username_from_user(user)
    change = changeset_service.create_delete_change(username, path)
    return {
        "change_id": change.id,
        "type": change.type,
        "path": change.rel_path,
    }


# ---------------- User decisions: Keep / Revert, Allow / Deny ----------------

async def _apply_one(change_id: str, scope: str = "once") -> Dict[str, Any]:
    result = await changeset_service.apply(change_id, scope=scope)
    if not result:
        return {"error": "Change not found", "change_id": change_id}

    if result.get("type") == "tool_call" and result.get("status") == "applied":
        from api.routes.chat import resume_after_tool_approval

        try:
            result["agent_continuation"] = await resume_after_tool_approval(
                result["username"], result.get("character"), result["tool_name"], result["result"],
            )
        except Exception as e:
            result["agent_continuation"] = {"reply": f"(Couldn't auto-continue: {e})", "done": True}

    result["change_id"] = change_id
    return result


@router.post("/changes/apply")
async def apply_change(payload: Dict[str, Any]):
    """
    User clicked:
    - Keep (for edit)
    - Allow (for delete / tool_call)

    For a tool_call approval, the character that requested it already
    finished its turn by the time the user gets to click Allow (its final
    reply is what told the user a prompt was waiting) -- so once the tool
    actually runs here, the character is automatically handed the result and
    given a fresh turn to react and keep going (see resume_after_tool_approval),
    instead of leaving the user to type "ok"/paste the result back in.
    """
    change_id = payload["change_id"]
    scope = payload.get("scope", "once")
    return await _apply_one(change_id, scope=scope)


@router.post("/changes/revert")
async def revert_change(payload: Dict[str, Any]):
    """
    User clicked:
    - Revert (for edit) -- restores the pre-edit file content live and
      archives the rejected edit attempt instead.
    - Deny (for delete)
    """
    change_id = payload["change_id"]
    result = await changeset_service.revert(change_id)
    if not result:
        return {"error": "Change not found"}
    return result


@router.post("/changes/apply_all")
async def apply_all_changes(payload: Dict[str, Any]):
    """
    Batch version of /changes/apply -- applies (Keep/Allow) every change_id
    in `change_ids` in one call, so a whole backlog from one task (e.g. a
    multi-file edit) can be resolved at once instead of one popup at a time.
    Each entry's own result (including any per-tool_call agent_continuation)
    is returned so the frontend can surface them individually.
    """
    change_ids = payload.get("change_ids") or []
    scope = payload.get("scope", "once")
    results = [await _apply_one(change_id, scope=scope) for change_id in change_ids]
    return {"results": results}


@router.post("/changes/revert_all")
async def revert_all_changes(payload: Dict[str, Any]):
    """Batch version of /changes/revert -- reverts every change_id in
    `change_ids` in one call."""
    change_ids = payload.get("change_ids") or []
    results = []
    for change_id in change_ids:
        result = await changeset_service.revert(change_id)
        results.append(result or {"error": "Change not found", "change_id": change_id})
    return {"results": results}


@router.post("/session_approvals/clear")
def clear_session_approvals(user: Dict[str, Any] = Depends(get_current_user)):
    """
    Called when the user navigates away from Code Suite -- drops any
    "Allow for Session" category grants (see safety/approvals.py) so leaving
    the page always ends the reduced-friction session, even before the
    daily 00:01 reset.
    """
    from safety import approvals

    approvals.clear_session_approvals(_username_from_user(user))
    return {"status": "cleared"}


# ---------------- Terminal + live tail log ----------------

@router.post("/terminal/run")
def terminal_run(
    payload: Dict[str, Any],
    term: TerminalService = Depends(get_terminal),
):
    command = payload["command"]

    async def streamer():
        async for line in term.run_command(command):
            yield line

    return StreamingResponse(streamer(), media_type="text/plain")
