# AthenaUI v3.5 — Collab Group Chat Orchestrator
# File: backend/chat/collab/orchestrator.py
#
# Entry point for running an autonomous "Collab Group Chat" discussion --
# agents talking to each other, no user required to be present. Reuses the
# same GroupChatRouter turn-taking/tool-execution/history-persistence engine
# as regular (user-led) Group Chat, just driven end-to-end in one call
# (load-or-create -> run up to `turn_cap` turns -> save -> notify) instead of
# one frontend-polled turn per request.
#
# Callers (e.g. auto_reply/monitor.py, or any future autonomous trigger)
# just need a list of participant character names and a plain-text
# `context` describing why the agents are talking -- everything else
# (persistence, turn cap, the CONCLUDE early-stop marker, notifying the
# user) is handled here.

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from chat.collab import service as collab_service

logger = logging.getLogger(__name__)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


async def run_collab_discussion(
    username: str,
    participants: List[str],
    context: str,
    turn_cap: int = 3,
    origin: str = "manual",
    title: Optional[str] = None,
) -> Dict[str, Any]:
    """Loads (or creates) the persistent Collab thread for this exact set of
    agents, runs up to `turn_cap` more autonomous turns, saves the result
    back to disk, and notifies the user. Returns the turns that were run
    plus whether/why the discussion concluded early, so callers (e.g. the
    inbox monitor) can use the discussion's outcome."""
    # Local imports: avoid import-order cycles at startup (mirrors the
    # pattern already used by auto_reply/monitor.py for ChatEngine).
    from chat.group.router import GroupChatRouter
    from chat.engine.service import ChatEngine
    from characters.system.load import load_character
    from users.service import UserService
    from notifications.service.service import NotificationService

    participants = [p for p in dict.fromkeys(str(p).strip() for p in participants) if p]
    if len(participants) < 2:
        raise ValueError("A Collab discussion needs at least two participating agents.")

    session_id = collab_service.session_id_for_participants(participants)
    existing = collab_service.get_session(username, session_id)

    def get_safety_role(name: str) -> int:
        char = load_character(username, name)
        return char.get("safety_role", 0) if char else 0

    def get_delay_seconds() -> float:
        return 0.0  # autonomous discussion -- no artificial pacing delay

    profile = UserService.get_user(username)
    user_display_name = profile.display_name if profile and getattr(profile, "display_name", None) else username

    engine = ChatEngine(username=username)
    provider, model = engine._get_active_chat_model()

    if existing:
        session = GroupChatRouter.from_saved_state(
            existing, get_safety_role=get_safety_role, get_delay_seconds=get_delay_seconds,
        )
        # Re-open for this new round of discussion and refresh the context.
        session.state.is_collab = True
        session.state.concluded = False
        session.state.concluded_reason = None
        if context:
            session.state.scene_description = context
    else:
        session = GroupChatRouter(
            username=username,
            user_display_name=user_display_name,
            character_names=participants,
            provider=provider,
            model=model,
            get_safety_role=get_safety_role,
            get_delay_seconds=get_delay_seconds,
            is_introduction=False,
            is_collab=True,
            name=title or ", ".join(sorted(participants)),
            scene_description=context,
        )

    turns_run: List[Dict[str, Any]] = []
    for _ in range(max(1, turn_cap)):
        result = await session.next_turn()
        if result is None:
            break
        turns_run.append(result)
        if session.state.concluded:
            break

    data = session.to_dict()
    data.update({
        "id": session_id,
        "title": (existing.get("title") if existing else None) or title or ", ".join(sorted(participants)),
        "origin": origin,
        "turn_cap": turn_cap,
        "status": "concluded" if session.state.concluded else "active",
        "concluded_reason": session.state.concluded_reason,
        "created_at": (existing or {}).get("created_at") or _now_iso(),
        "last_activity_at": _now_iso(),
    })
    collab_service.save_session(username, session_id, data)

    if turns_run:
        last = turns_run[-1]
        preview = last["message"][:140] + ("..." if len(last["message"]) > 140 else "")
        try:
            NotificationService.send(
                username,
                type="info",
                message=f"{', '.join(sorted(participants))} had a conversation in Collab: \"{preview}\"",
                metadata={"collab_session_id": session_id},
            )
        except Exception:
            logger.debug("Collab notification failed for session=%s", session_id, exc_info=True)

    return {
        "session_id": session_id,
        "turns": turns_run,
        "concluded": session.state.concluded,
        "concluded_reason": session.state.concluded_reason,
    }
