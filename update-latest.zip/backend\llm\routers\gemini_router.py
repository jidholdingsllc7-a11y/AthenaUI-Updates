﻿# AthenaUI v3.5 — Provider-specific router for Google Gemini models
# File: backend/llm/routers/gemini_router.py
# Created: 2026-03-28 20:46 CDT
# Updated: 2026-07-27 19:49 CDT

import json
import uuid
import requests
from typing import Any, Dict, List, Optional

from llm.routers.base import BaseLLMRouter
from llm.router_selector.router_selector import RouterSelector
from llm.routers.providers import PROVIDER_GEMINI
from core.runtime.runtime import get_runtime

from tools.registry.tool_examples import TOOL_EXAMPLES



class GeminiRouter(BaseLLMRouter):
    """
    Provider-specific router for Google Gemini models.
    Supports:
    - chat
    - tool calling (Gemini functionCall format)
    - streaming (stub)
    """

    API_URL = (
        "https://generativelanguage.googleapis.com/v1beta/models/"
        "{model}:generateContent"
    )

    # ---------------------------------------------------------
    # Build system prompt with tool examples
    # ---------------------------------------------------------

    def _build_system_prompt(self, base_prompt: Optional[str], *, include_tool_examples: bool = True) -> str:
        if not include_tool_examples:
            return base_prompt if base_prompt else "You are AthenaUI v3.1."

        examples_json = json.dumps(TOOL_EXAMPLES, indent=2)

        tool_usage_block = f"""
You have access to a set of tools. Use them whenever needed.

Here are examples of correct tool usage:
{examples_json}

Gemini tool calling rules:
- Tools are declared in "tools"
- Tool calls appear as "functionCall" blocks
- Arguments appear in "args"
- Use "toolConfig" to control tool calling behavior

If you need to call a tool, do NOT explain â€” just call it.
"""

        if base_prompt:
            return base_prompt + "\n\n" + tool_usage_block

        return "You are AthenaUI v3.1.\n\n" + tool_usage_block

    # ---------------------------------------------------------
    # Convert OpenAI-style messages â†’ Gemini format
    # ---------------------------------------------------------

    def _convert_messages(self, messages: List[Dict[str, Any]]):
        """Converts OpenAI-style messages into Gemini's contents list. Gemini's
        generateContent endpoint only accepts roles USER and MODEL -- no
        'system' or 'tool' role -- so assistant turns become 'model' (with
        any tool_calls turned into functionCall parts) and tool-result turns
        become a 'user' turn carrying a functionResponse part instead."""
        gemini_messages = []
        call_id_to_name: Dict[str, str] = {}

        for msg in messages:
            role = msg.get("role")
            if role == "assistant":
                parts = []
                content = msg.get("content")
                if content:
                    parts.append({"text": content})
                for call in (msg.get("tool_calls") or []):
                    fn = call.get("function") or {}
                    name = fn.get("name")
                    if name and call.get("id"):
                        call_id_to_name[call["id"]] = name
                    try:
                        args = json.loads(fn.get("arguments") or "{}")
                    except (TypeError, ValueError):
                        args = {}
                    part: Dict[str, Any] = {"functionCall": {"name": name, "args": args}}
                    # Gemini requires any thoughtSignature that was originally
                    # attached to this functionCall part to be echoed back
                    # verbatim on replay, or it rejects the request outright
                    # ("Function call is missing a thought_signature...").
                    thought_signature = call.get("thought_signature")
                    if thought_signature:
                        part["thoughtSignature"] = thought_signature
                    parts.append(part)
                gemini_messages.append({"role": "model", "parts": parts or [{"text": ""}]})
            elif role == "tool":
                name = call_id_to_name.get(msg.get("tool_call_id"), "unknown")
                raw_content = msg.get("content")
                try:
                    response_payload = json.loads(raw_content) if isinstance(raw_content, str) else raw_content
                except (TypeError, ValueError):
                    response_payload = {"result": raw_content}
                if not isinstance(response_payload, dict):
                    response_payload = {"result": response_payload}
                gemini_messages.append({
                    "role": "user",
                    "parts": [{"functionResponse": {"name": name, "response": response_payload}}],
                })
            else:
                # "user" (and any unrecognized role) becomes a plain user text turn.
                gemini_messages.append({
                    "role": "user",
                    "parts": [{"text": msg.get("content") or ""}],
                })

        return gemini_messages

    # ---------------------------------------------------------
    # Chat Completion
    # ---------------------------------------------------------

    def chat(
        self,
        messages: List[Dict[str, Any]],
        *,
        tools: Optional[List[Dict[str, Any]]] = None,
        tool_choice: Optional[str] = None,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> Dict[str, Any]:

        runtime = get_runtime()
        api_key = runtime.env.GEMINI_API_KEY

        if not api_key:
            raise RuntimeError("Gemini API key not set.")

        # Build system prompt with examples
        extracted_prompt, remaining_messages = self._extract_system_prompt(messages)
        final_system_prompt = self._build_system_prompt(system_prompt or extracted_prompt, include_tool_examples=bool(tools))

        # Convert messages
        gemini_messages = self._convert_messages(remaining_messages)

        # Build request URL
        url = self.API_URL.format(model=self.model_id) + f"?key={api_key}"

        # Build payload
        payload: Dict[str, Any] = {
            "contents": gemini_messages,
            "systemInstruction": {"parts": [{"text": final_system_prompt}]},
            "generationConfig": {
                "temperature": temperature,
            },
        }

        if max_tokens is not None:
            payload["generationConfig"]["maxOutputTokens"] = max_tokens

        # Tool calling
        if tools:
            payload["tools"] = self._to_gemini_tools(tools)
            gemini_tool_choice = self._to_gemini_tool_choice(tool_choice)
            if gemini_tool_choice:
                payload["toolConfig"] = {
                    "functionCallingConfig": gemini_tool_choice
                }

        # Send request
        response = requests.post(url, json=payload)
        response.raise_for_status()
        data = response.json()

        # Normalize Gemini response
        candidates = data.get("candidates", [])
        if not candidates:
            return {
                "id": None,
                "model": self.model_id,
                "content": None,
                "tool_calls": None,
                "finish_reason": None,
                "raw": data,
            }

        candidate = candidates[0]
        parts = candidate.get("content", {}).get("parts", [])

        text_content = None
        tool_calls = []

        for part in parts:
            if "text" in part:
                text_content = part["text"]
            elif "functionCall" in part:
                fc = part["functionCall"]
                call_entry: Dict[str, Any] = {
                    "id": f"call_{uuid.uuid4().hex}",
                    "type": "function",
                    "function": {
                        "name": fc.get("name"),
                        "arguments": json.dumps(fc.get("args") or {}),
                    },
                }
                # Preserve the part-level thoughtSignature (if present) so it
                # can be echoed back verbatim when this tool call is replayed
                # in a later turn -- see _convert_messages().
                thought_signature = part.get("thoughtSignature")
                if thought_signature:
                    call_entry["thought_signature"] = thought_signature
                tool_calls.append(call_entry)

        return {
            "id": data.get("id"),
            "model": self.model_id,
            "content": text_content,
            "tool_calls": tool_calls or None,
            "finish_reason": candidate.get("finishReason"),
            "raw": data,
        }

    # ---------------------------------------------------------
    # Streaming (stub)
    # ---------------------------------------------------------

    def stream_chat(self, *args, **kwargs):
        raise NotImplementedError("Gemini streaming not implemented yet.")


# ---------------------------------------------------------
# Register Router
# ---------------------------------------------------------

RouterSelector.register_router(PROVIDER_GEMINI, GeminiRouter)

