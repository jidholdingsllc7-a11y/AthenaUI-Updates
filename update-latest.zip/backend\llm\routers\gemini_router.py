﻿# AthenaUI v3.5 — Provider-specific router for Google Gemini models
# File: backend/llm/routers/gemini_router.py
# Created: 2026-03-28 20:46 CDT
# Updated: 2026-07-27 19:49 CDT

import json
import requests
from typing import Any, Dict, List, Optional

from llm.routers.base import BaseLLMRouter
from llm.router_selector.router_selector import RouterSelector
from llm.routers.providers import PROVIDER_GEMINI
from core.runtime.runtime import get_runtime

from tools.registry.tool_examples import TOOL_EXAMPLES



class GeminiRouter(BaseLLMRouter):
    """
    Provider-specific router for Google Gemini models.
    Supports:
    - chat
    - tool calling (Gemini functionCall format)
    - streaming (stub)
    """

    API_URL = (
        "https://generativelanguage.googleapis.com/v1beta/models/"
        "{model}:generateContent"
    )

    # ---------------------------------------------------------
    # Build system prompt with tool examples
    # ---------------------------------------------------------

    def _build_system_prompt(self, base_prompt: Optional[str], *, include_tool_examples: bool = True) -> str:
        if not include_tool_examples:
            return base_prompt if base_prompt else "You are AthenaUI v3.1."

        examples_json = json.dumps(TOOL_EXAMPLES, indent=2)

        tool_usage_block = f"""
You have access to a set of tools. Use them whenever needed.

Here are examples of correct tool usage:
{examples_json}

Gemini tool calling rules:
- Tools are declared in "tools"
- Tool calls appear as "functionCall" blocks
- Arguments appear in "args"
- Use "toolConfig" to control tool calling behavior

If you need to call a tool, do NOT explain â€” just call it.
"""

        if base_prompt:
            return base_prompt + "\n\n" + tool_usage_block

        return "You are AthenaUI v3.1.\n\n" + tool_usage_block

    # ---------------------------------------------------------
    # Convert OpenAI-style messages â†’ Gemini format
    # ---------------------------------------------------------

    def _convert_messages(self, system_prompt: str, messages: List[Dict[str, Any]]):
        gemini_messages = []

        # System prompt first
        gemini_messages.append({
            "role": "system",
            "parts": [{"text": system_prompt}],
        })

        # Convert user/assistant messages
        for msg in messages:
            gemini_messages.append({
                "role": msg["role"],
                "parts": [{"text": msg["content"]}],
            })

        return gemini_messages

    # ---------------------------------------------------------
    # Chat Completion
    # ---------------------------------------------------------

    def chat(
        self,
        messages: List[Dict[str, Any]],
        *,
        tools: Optional[List[Dict[str, Any]]] = None,
        tool_choice: Optional[str] = None,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> Dict[str, Any]:

        runtime = get_runtime()
        api_key = runtime.env.GEMINI_API_KEY

        if not api_key:
            raise RuntimeError("Gemini API key not set.")

        # Build system prompt with examples
        extracted_prompt, remaining_messages = self._extract_system_prompt(messages)
        final_system_prompt = self._build_system_prompt(system_prompt or extracted_prompt, include_tool_examples=bool(tools))

        # Convert messages
        gemini_messages = self._convert_messages(final_system_prompt, remaining_messages)

        # Build request URL
        url = self.API_URL.format(model=self.model_id) + f"?key={api_key}"

        # Build payload
        payload: Dict[str, Any] = {
            "contents": gemini_messages,
            "generationConfig": {
                "temperature": temperature,
            },
        }

        if max_tokens is not None:
            payload["generationConfig"]["maxOutputTokens"] = max_tokens

        # Tool calling
        if tools:
            payload["tools"] = tools
            gemini_tool_choice = self._to_gemini_tool_choice(tool_choice)
            if gemini_tool_choice:
                payload["toolConfig"] = {
                    "functionCallingConfig": gemini_tool_choice
                }

        # Send request
        response = requests.post(url, json=payload)
        response.raise_for_status()
        data = response.json()

        # Normalize Gemini response
        candidates = data.get("candidates", [])
        if not candidates:
            return {
                "id": None,
                "model": self.model_id,
                "content": None,
                "tool_calls": None,
                "finish_reason": None,
                "raw": data,
            }

        candidate = candidates[0]
        parts = candidate.get("content", {}).get("parts", [])

        text_content = None
        tool_calls = []

        for part in parts:
            if "text" in part:
                text_content = part["text"]
            elif "functionCall" in part:
                fc = part["functionCall"]
                tool_calls.append({
                    "id": fc.get("name"),
                    "type": fc.get("name"),
                    "arguments": fc.get("args", {}),
                })

        return {
            "id": data.get("id"),
            "model": self.model_id,
            "content": text_content,
            "tool_calls": tool_calls or None,
            "finish_reason": candidate.get("finishReason"),
            "raw": data,
        }

    # ---------------------------------------------------------
    # Streaming (stub)
    # ---------------------------------------------------------

    def stream_chat(self, *args, **kwargs):
        raise NotImplementedError("Gemini streaming not implemented yet.")


# ---------------------------------------------------------
# Register Router
# ---------------------------------------------------------

RouterSelector.register_router(PROVIDER_GEMINI, GeminiRouter)

