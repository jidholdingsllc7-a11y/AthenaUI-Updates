# AthenaUI v3.5 — email_send Tool
# File: backend/tools/email/email_send.py
#
# Sends a real email using one of the email accounts the user has shared
# with this agent (via Settings > Email Accounts), either an account
# shared with "all" agents or one shared specifically with this character.

from typing import Any, Dict

from emailing.service import EmailServiceError, EmailAccountsService

capabilities = {
    "needs_filesystem": False,
    "needs_bridge": False,
    "needs_network": True,
    "needs_user": True,
}


async def run(args: Dict[str, Any]) -> str:
    try:
        username = args.get("username")
        character = args.get("character")
        to = args.get("to")
        subject = args.get("subject")
        body = args.get("body")
        account_label = args.get("account_label")
        attachment_paths = args.get("attachment_paths")

        if not username:
            return "[ERROR] Missing 'username' argument."
        if not character:
            return "[ERROR] No active agent identity -- email access requires one."
        if not to:
            return "[ERROR] Missing 'to' argument."
        if not subject:
            return "[ERROR] Missing 'subject' argument."
        if not body:
            return "[ERROR] Missing 'body' argument."
        if attachment_paths is not None and not isinstance(attachment_paths, list):
            return "[ERROR] 'attachment_paths' must be a list of file paths/URLs."

        result = EmailAccountsService.send_email(
            username=username,
            character=character,
            to=to,
            subject=subject,
            body=body,
            account_label=account_label,
            attachment_paths=attachment_paths,
        )
        attached = result.get("attachments") or []
        suffix = f" with {len(attached)} attachment(s): {', '.join(attached)}" if attached else ""
        return f"Email sent from {result['from']} to {result['to']} (subject: {result['subject']}){suffix}."
    except EmailServiceError as e:
        return f"[ERROR] {e}"
    except Exception as e:
        return f"[ERROR] Failed to send email: {str(e)}"
