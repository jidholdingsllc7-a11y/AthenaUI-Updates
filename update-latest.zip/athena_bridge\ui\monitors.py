# Multi-monitor utilities
# File: ui/monitors.py
# Created: 2026-04-09 11:21 CDT
# Updated: 2026-10-01 (added screen_info_impl)

import pyautogui

async def screen_info_impl():
    # Real physical-pixel resolution, now that bridge.py sets process DPI
    # awareness -- lets callers ground coordinates against the true screen
    # size instead of guessing.
    width, height = pyautogui.size()
    return {"status": "ok", "width": width, "height": height}

async def monitors_impl():
    # pyautogui.getAllScreens() is not universal; fallback to size
    try:
        screens = pyautogui.getAllScreens()
        return {"status": "ok", "monitors": [s._asdict() for s in screens]}
    except Exception:
        width, height = pyautogui.size()
        return {
            "status": "ok",
            "monitors": [
                {"index": 0, "left": 0, "top": 0, "width": width, "height": height}
            ],
        }

async def move_to_monitor_impl(index: int):
    try:
        screens = pyautogui.getAllScreens()
        if index < 0 or index >= len(screens):
            return {"status": "error", "error": "invalid monitor index"}
        screen = screens[index]
        pyautogui.moveTo(screen.left + 10, screen.top + 10)
        return {"status": "ok", "monitor": index}
    except Exception:
        # Fallback: just move to (10,10)
        pyautogui.moveTo(10, 10)
        return {"status": "ok", "monitor": 0}
