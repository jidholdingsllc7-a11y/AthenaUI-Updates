﻿# AthenaUI v3.5 — Email Notification Service
# File: backend/notifications/email/service.py
# Created: 2026-04-11 18:57 CDT
# Updated: 2026-10-09 CDT

from __future__ import annotations

import logging
from typing import Optional

logger = logging.getLogger(__name__)


class EmailService:
    """Sends a system-initiated notification email to the user's own
    registered address, via whichever mailbox they've connected in Settings
    > Email Accounts (there's no AthenaUI-owned SMTP account to send
    from -- see emailing/service.py's send_system_notification_email).
    Fails soft (logs and returns) rather than raising: a missing/broken
    notification channel must never break the underlying feature (e.g. a
    billing-fallback success) that triggered it."""

    @staticmethod
    def send_notification_email(username: str, message: str, subject: str = "AthenaUI Notification") -> None:
        from users.service import UserService
        from emailing.service import EmailAccountsService, EmailServiceError

        user = UserService.get_user(username)
        to = (user.email if user else None) or ""
        if not to:
            logger.warning("Skipping notification email for user=%s: no registered email address on file.", username)
            return

        try:
            EmailAccountsService.send_system_notification_email(username, to, subject, message)
        except EmailServiceError as exc:
            logger.warning("Failed to send notification email to user=%s: %s", username, exc)
