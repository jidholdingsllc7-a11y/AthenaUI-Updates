﻿# AthenaUI v3.5 — Log Exporter API routes
# File: backend/api/routes/log_exports.py
# Created: 2026-04-09 20:48 CDT
# Updated: 2026-07-27 19:49 CDT

from typing import Optional

from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse

from logs_system.exporter.service import log_exporter
from logs_system.viewer.service import log_viewer

router = APIRouter(prefix="/log-exports", tags=["log-exports"])


@router.post("/task/{task_id}")
def export_task_logs(task_id: str):
    """
    Export logs for a specific task_id as a locked, signed PDF.
    Returns the file path.
    """
    try:
        path = log_exporter.export_task_logs_to_pdf(task_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    return {"path": path}


@router.get("/task/{task_id}/download")
def download_task_logs(task_id: str):
    """
    Download the locked, signed PDF for a specific task_id.
    """
    try:
        path = log_exporter.export_task_logs_to_pdf(task_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    return FileResponse(path, media_type="application/pdf", filename=path.split("/")[-1])


def _label_for(value: Optional[str], fallback: str) -> str:
    if not value:
        return fallback
    # value arrives as a UTC ISO datetime string, e.g. "2026-08-09T19:30:00.000Z"
    trimmed = value.split(".")[0].rstrip("Z")
    return trimmed.replace(":", "").replace("-", "").replace("T", "_")


@router.get("/tail-range/download")
def download_tail_range_logs(start: Optional[str] = None, end: Optional[str] = None, agent_state: Optional[str] = None):
    """
    Export the Tail Log (Settings > Tail Log) entries within [start, end]
    to a locked, signed PDF and download it. Either bound may be omitted:
    - no `start` means "from the beginning of what's currently in the log"
    - no `end` means "through the last entry currently in the log"
    `agent_state`, when given (e.g. "Synergy"), exports only that tab's entries.
    """
    entries = log_viewer.get_tail_range(start=start, end=end, agent_state=agent_state)
    if not entries:
        raise HTTPException(status_code=404, detail="No log entries found in the given range.")

    start_label = _label_for(start, "beginning")
    end_label = _label_for(end, "latest")
    if agent_state:
        start_label = f"{agent_state.lower()}_{start_label}"

    try:
        path = log_exporter.export_tail_range_to_pdf(
            entries, start_label=start_label, end_label=end_label
        )
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    return FileResponse(path, media_type="application/pdf", filename=path.split("/")[-1])
