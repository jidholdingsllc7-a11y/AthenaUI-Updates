# UI action recorder
# File: ui/recorder.py
# Created: 2026-04-09 11:21 CDT
# Updated: 2026-04-09 11:21 CDT

from datetime import datetime
from typing import Any, Callable, Awaitable, List, Dict
import asyncio

_recording: bool = False
_log: List[Dict[str, Any]] = []

# Every UI action (mouse/keyboard/screenshot/DOM/navigate) from every caller
# -- Synergy-A, Synergy-B, or any other character's Browser Assist session --
# goes through this one bridge process via recorder_wrap_action, so a single
# lock here serializes them all: whoever's request arrives first finishes its
# action before the next one starts, instead of two agents fighting over the
# same mouse/screen at once.
_action_lock = asyncio.Lock()

def recorder_start_impl():
    global _recording, _log
    _recording = True
    _log = []
    return {"status": "ok", "recording": True}

def recorder_stop_impl():
    global _recording
    _recording = False
    return {"status": "ok", "recording": False}

def recorder_log_impl():
    return {"status": "ok", "log": _log}

async def recorder_wrap_action(name: str, func: Callable[..., Awaitable[Any]], *args, **kwargs):
    global _recording, _log
    async with _action_lock:
        result = await func(*args, **kwargs)
        if _recording:
            _log.append(
                {
                    "timestamp": datetime.utcnow().isoformat() + "Z",
                    "action": name,
                    "args": args,
                    "kwargs": kwargs,
                    "result": result,
                }
            )
    return result
