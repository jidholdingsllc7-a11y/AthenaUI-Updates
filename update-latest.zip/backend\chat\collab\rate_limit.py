# AthenaUI v3.7 — Collab Discussion Rate Limit ("slow mode")
# File: backend/chat/collab/rate_limit.py
#
# Keeps the agent-initiated collab_start_discussion tool from being spammed:
# each character gets a base allowance of BASE_LIMIT discussion-starts per
# rolling WINDOW_SECONDS window. Once exhausted, the tool raises
# ApprovalRequiredError (same Allow/Deny sidebar flow as any other
# capability-gated tool) -- approving grants +GRANT_SIZE more for the
# current burst. The bonus resets back to the base allowance once the
# character has gone a full window with no Collab activity at all, so
# approvals don't stack forever once things quiet back down.

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict, List

BASE_LIMIT = 4
GRANT_SIZE = 4
WINDOW_SECONDS = 3 * 60 * 60


def _store_path() -> Path:
    from core.runtime.runtime import get_runtime

    path: Path = get_runtime().env.DATA_DIR / "collab_rate_limits.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _load() -> Dict[str, Any]:
    path = _store_path()
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save(data: Dict[str, Any]) -> None:
    _store_path().write_text(json.dumps(data, indent=2), encoding="utf-8")


def _entry(data: Dict[str, Any], username: str, character: str) -> Dict[str, Any]:
    user_bucket = data.setdefault(username, {})
    return user_bucket.setdefault(character, {"timestamps": [], "bonus": 0})


def _prune(entry: Dict[str, Any], now: float) -> List[float]:
    timestamps = [t for t in entry.get("timestamps", []) if now - t < WINDOW_SECONDS]
    if not timestamps:
        entry["bonus"] = 0  # a full quiet window clears any earlier approval bonus
    entry["timestamps"] = timestamps
    return timestamps


def try_consume(username: str, character: str) -> bool:
    """Returns True (and records the call) if this character is still under
    its current limit, False if it's exhausted and needs approval."""
    now = time.time()
    data = _load()
    entry = _entry(data, username, character)
    timestamps = _prune(entry, now)
    limit = BASE_LIMIT + int(entry.get("bonus", 0)) * GRANT_SIZE
    if len(timestamps) >= limit:
        _save(data)
        return False
    timestamps.append(now)
    entry["timestamps"] = timestamps
    _save(data)
    return True


def grant_bonus(username: str, character: str) -> int:
    """Approves +GRANT_SIZE more for this character's current burst. Returns the new limit."""
    data = _load()
    entry = _entry(data, username, character)
    _prune(entry, time.time())
    entry["bonus"] = int(entry.get("bonus", 0)) + 1
    _save(data)
    return BASE_LIMIT + entry["bonus"] * GRANT_SIZE
