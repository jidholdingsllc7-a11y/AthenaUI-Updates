﻿# AthenaUI v3.5 — Character Temp Store
# File: backend/characters/system/temp_store.py
# Created: 2026-04-10 22:34 CDT
# Updated: 2026-07-27 19:49 CDT

import uuid
from pathlib import Path

from temp_system.service import (
    temp_root,
    create_temp_dir,
    write_temp_json,
    read_temp_json,
    delete_temp_path,
)

# ---------------------------------------------------------
#  TEMP CHARACTER ROOT
# ---------------------------------------------------------

# All character temp data lives under temp_root/characters/<temp_id>/ --
# temp_root (temp_system/service.py) already creates and owns this
# "characters" subsystem folder, anchored to Env.WRITABLE_ROOT.
#
# This is ephemeral, cleared on logout, and not user-scoped.

def _temp_char_dir(temp_id: str) -> Path:
    return temp_root / "characters" / temp_id


# ---------------------------------------------------------
#  CREATE TEMP CHARACTER
# ---------------------------------------------------------

def create_temp_character() -> str:
    """
    Creates a new temp directory for a character and returns its temp_id.
    """
    temp_id = uuid.uuid4().hex
    path = _temp_char_dir(temp_id)
    path.mkdir(parents=True, exist_ok=True)

    # Create empty character.json
    write_temp_json(path / "character.json", {})

    return temp_id


# ---------------------------------------------------------
#  LOAD TEMP CHARACTER
# ---------------------------------------------------------

def load_temp_character(temp_id: str) -> dict:
    path = _temp_char_dir(temp_id) / "character.json"
    if not path.exists():
        return {}
    return read_temp_json(path)


# ---------------------------------------------------------
#  SAVE TEMP CHARACTER
# ---------------------------------------------------------

def save_temp_character(temp_id: str, character: dict):
    path = _temp_char_dir(temp_id)
    path.mkdir(parents=True, exist_ok=True)
    write_temp_json(path / "character.json", character)


# ---------------------------------------------------------
#  DELETE TEMP CHARACTER
# ---------------------------------------------------------

def delete_temp_character(temp_id: str):
    path = _temp_char_dir(temp_id)
    delete_temp_path(path)
