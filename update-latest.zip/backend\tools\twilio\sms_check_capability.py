# AthenaUI -- Twilio Capability Check Tool
# File: backend/tools/twilio/sms_check_capability.py
#
# Safe, read-only, no-approval tool (mirrors social_media_check_capability.py):
# lets an agent check whether Twilio is configured before attempting to text
# or call someone.

from typing import Any, Dict

capabilities = {
    "needs_bridge": False,
    "needs_filesystem": False,
    "needs_network": False,
    "needs_user": True,
}


async def run(args: Dict[str, Any]):
    username = args.get("username")
    if not username:
        return {"status": "limited", "message": "Username required for Twilio capability check."}

    from twilio_integration import settings as twilio_settings

    try:
        return {"status": "ok", **twilio_settings.capability_status(username)}
    except Exception as e:
        return {"status": "error", "message": str(e)}
