﻿# AthenaUI v3.5 — Character Creation
# File: backend/characters/system/create.py
# Created: 2026-04-10 22:34 CDT
# Updated: 2026-07-27 19:49 CDT

import random
import uuid
from .schema import new_character_base, validate_character_schema
from characters.backstory_engine.generator import generate_backstory, generate_character_details
from characters.skills.registry import SkillRegistry

skill_registry = SkillRegistry()

# Used only when "no input" auto-generation needs a name and the user hasn't
# provided one yet (they can always rename before finalizing).
_AUTO_FIRST_NAMES = [
    "Avery", "Riley", "Jordan", "Casey", "Morgan", "Rowan", "Sage", "Quinn",
    "Elliot", "Marlowe", "Reese", "Dana", "Skyler", "Emerson", "Blair",
]
_AUTO_LAST_NAMES = [
    "Hale", "Carter", "Winters", "Reyes", "Nakamura", "Sinclair", "Brooks",
    "Delgado", "Ashford", "Voss", "Okafor", "Lindqvist", "Marchetti",
]


def _random_auto_name() -> str:
    return f"{random.choice(_AUTO_FIRST_NAMES)} {random.choice(_AUTO_LAST_NAMES)}"


# ---------------------------------------------------------
#  BASE CHARACTER (v3.0 schema)
# ---------------------------------------------------------

def base_character(name: str | None = None):
    """
    Creates a new v3.0-compliant character dictionary using the schema defaults.
    """
    char = new_character_base()
    char["id"] = str(uuid.uuid4())
    char["name"] = name or ""
    char["profile"]["full_name"] = name or ""
    return char


# ---------------------------------------------------------
#  FULL AUTO GENERATION (Russian Roulette Mode)
# ---------------------------------------------------------

def generate_full_character_no_input(username: str):
    """
    Generates a fully automatic character using defaults + backstory engine.
    A random placeholder name is assigned since this mode takes zero user
    input -- the user can still rename the character before finalizing.
    Every profile field (gender, age, occupation, traits, appearance,
    backstory) is invented by the LLM in one call -- not just the backstory
    -- so "Surprise Me" produces a genuinely complete character.
    """
    name = _random_auto_name()
    char = base_character(name)
    char["meta"]["source"] = "auto"

    details = generate_character_details(char, username, user_prompt=None)
    profile = char["profile"]
    for key in ("gender", "age", "occupation", "traits", "appearance", "backstory"):
        if key in details:
            profile[key] = details[key]

    if not profile.get("backstory"):
        # Fallback: a malformed/non-JSON LLM response still shouldn't leave
        # the character with no backstory at all.
        profile["backstory"] = generate_backstory(char, username, user_prompt=None)

    validate_character_schema(char)
    return char


# ---------------------------------------------------------
#  PARTIAL INPUT GENERATION
# ---------------------------------------------------------

def generate_character_from_partial(char: dict, username: str):
    """
    Takes a partially filled character dict and fills missing fields.
    """
    # Ensure schema defaults exist, but don't let empty-string/None values
    # from a partially-filled form clobber real defaults (e.g. an empty
    # "traits": [] submitted by the form is fine, but we still want any
    # field the user genuinely left untouched to keep its default).
    merged = new_character_base()
    _deep_merge(merged, char)

    # A partially-filled form may still have left the name blank -- assign
    # a placeholder so schema validation succeeds; the user can rename
    # before finalizing.
    if not merged.get("name"):
        merged["name"] = _random_auto_name()
    merged["profile"].setdefault("full_name", merged["name"])
    if not merged["profile"].get("full_name"):
        merged["profile"]["full_name"] = merged["name"]
    if not merged.get("id"):
        merged["id"] = str(uuid.uuid4())

    # Fill in whatever the user left blank -- gender, age, occupation,
    # traits, appearance, and/or backstory -- in one LLM call, without
    # touching anything the user actually provided themselves.
    original_profile = char.get("profile", {}) if isinstance(char, dict) else {}
    needs_generation = not all([
        original_profile.get("gender"),
        original_profile.get("age"),
        original_profile.get("occupation"),
        original_profile.get("traits"),
        original_profile.get("appearance"),
        original_profile.get("backstory"),
    ])

    if needs_generation:
        seed = original_profile.get("backstorySeed") or char.get("backstorySeed")
        related_characters = _resolve_family_ties(merged, username)
        details = generate_character_details(
            merged, username, user_prompt=seed, related_characters=related_characters
        )
        for key in ("gender", "age", "occupation", "traits", "appearance", "backstory"):
            if key in details and not original_profile.get(key):
                merged["profile"][key] = details[key]

        if not merged["profile"].get("backstory"):
            merged["profile"]["backstory"] = generate_backstory(
                merged, username, user_prompt=seed, related_characters=related_characters
            )

    merged["meta"]["source"] = "partial"
    validate_character_schema(merged)
    return merged


def _resolve_family_ties(char: dict, username: str) -> list[dict] | None:
    """
    Loads each existing relative named in profile.family_ties so the
    backstory generator can weave their established history (hometown,
    parents, upbringing, etc.) into this new character's backstory.
    Silently skips ties that don't resolve to a real, existing character.
    """
    ties = char.get("profile", {}).get("family_ties") or []
    if not ties:
        return None

    from .load import load_character

    related = []
    for tie in ties:
        source_name = tie.get("character") if isinstance(tie, dict) else None
        if not source_name:
            continue
        source = load_character(username, source_name)
        if not source:
            continue
        related.append({
            "name": source.get("profile", {}).get("full_name") or source.get("name") or source_name,
            "relation": tie.get("relation", "relative"),
            "backstory": source.get("profile", {}).get("backstory", ""),
        })
    return related or None


def _deep_merge(base: dict, override: dict) -> None:
    """
    Recursively merges `override` into `base` in place, only overwriting a
    key when the override actually provides a non-empty value -- so a
    partially-filled form (blank fields included) doesn't wipe out schema
    defaults for the fields the user left alone.
    """
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(base.get(key), dict):
            _deep_merge(base[key], value)
        elif value not in (None, "", [], {}):
            base[key] = value


# ---------------------------------------------------------
#  FULL INPUT FINALIZATION
# ---------------------------------------------------------

def finalize_character_from_full_input(char: dict):
    """
    Final validation step for fully user-defined characters.
    """
    if not char.get("id"):
        char["id"] = str(uuid.uuid4())
    char.setdefault("profile", {})
    if not char["profile"].get("full_name"):
        char["profile"]["full_name"] = char.get("name", "")
    char.setdefault("meta", {})
    char["meta"].setdefault("source", "full")
    validate_character_schema(char)
    return char

