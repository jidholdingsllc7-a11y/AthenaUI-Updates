﻿# AthenaUI v3.5 — Provider-specific router for local Ollama models
# File: backend/llm/routers/ollama_router.py
# Created: 2026-03-28 21:48 CDT
# Updated: 2026-07-27 19:49 CDT

import json
import requests
from typing import Any, Dict, List, Optional

from llm.routers.base import BaseLLMRouter
from llm.router_selector.router_selector import RouterSelector
from llm.routers.providers import PROVIDER_OLLAMA
from core.runtime.runtime import get_runtime

from tools.registry.tool_examples import TOOL_EXAMPLES



class OllamaRouter(BaseLLMRouter):
    """
    Provider-specific router for Ollama local models.
    Supports:
    - chat (prompt-based)
    - tool calling (emulated)
    - streaming (stub)
    """

    API_URL_TEMPLATE = "{base_url}/api/chat"

    # ---------------------------------------------------------
    # Build system prompt with tool examples
    # ---------------------------------------------------------

    def _build_system_prompt(self, base_prompt: Optional[str], *, include_tool_examples: bool = True) -> str:
        if not include_tool_examples:
            return base_prompt if base_prompt else "You are AthenaUI v3.1."

        examples_json = json.dumps(TOOL_EXAMPLES, indent=2)

        tool_usage_block = f"""
Ollama does NOT support native tool calling.
To call a tool, output ONLY a JSON object describing the tool call.

Here are examples of correct tool usage:
{examples_json}

If you need to call a tool, do NOT explain â€” just output the JSON.
"""

        if base_prompt:
            return base_prompt + "\n\n" + tool_usage_block

        return "You are AthenaUI v3.1.\n\n" + tool_usage_block

    # ---------------------------------------------------------
    # Convert OpenAI-style messages â†’ Ollama format
    # ---------------------------------------------------------

    def _convert_messages(self, system_prompt: str, messages: List[Dict[str, Any]]):
        ollama_messages = [{"role": "system", "content": system_prompt}]

        for msg in messages:
            content = msg.get("content")

            if isinstance(content, list):
                # Multimodal content blocks (text + image_url), the shape
                # used elsewhere in this codebase for vision uploads.
                # Ollama's own API is NOT OpenAI-shaped for images: it wants
                # a plain string `content` plus a separate `images` array of
                # raw base64 strings (no data: URI prefix, no content-block
                # wrapper) -- so translate rather than passing the blocks
                # through verbatim.
                text_parts = []
                images = []
                for block in content:
                    if not isinstance(block, dict):
                        continue
                    block_type = block.get("type")
                    if block_type == "text":
                        text_parts.append(block.get("text") or "")
                    elif block_type == "image_url":
                        url = (block.get("image_url") or {}).get("url", "")
                        if url.startswith("data:") and "base64," in url:
                            images.append(url.split("base64,", 1)[1])
                        elif url:
                            images.append(url)

                ollama_msg: Dict[str, Any] = {
                    "role": msg["role"],
                    "content": "\n".join(p for p in text_parts if p),
                }
                if images:
                    ollama_msg["images"] = images
                ollama_messages.append(ollama_msg)
            else:
                ollama_messages.append({
                    "role": msg["role"],
                    "content": content,
                })

        return ollama_messages

    # ---------------------------------------------------------
    # Chat Completion
    # ---------------------------------------------------------

    def chat(
        self,
        messages: List[Dict[str, Any]],
        *,
        tools: Optional[List[Dict[str, Any]]] = None,   # Ollama does NOT support tools natively
        tool_choice: Optional[str] = None,              # ignored
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> Dict[str, Any]:

        runtime = get_runtime()

        base_url = runtime.env.OLLAMA_BASE_URL or "http://localhost:11434"
        url = self.API_URL_TEMPLATE.format(base_url=base_url)

        headers = {"Content-Type": "application/json"}

        # Build system prompt with examples
        extracted_prompt, remaining_messages = self._extract_system_prompt(messages)
        final_system_prompt = self._build_system_prompt(system_prompt or extracted_prompt, include_tool_examples=bool(tools))

        # Convert messages
        ollama_messages = self._convert_messages(final_system_prompt, remaining_messages)

        # Tool emulation
        if tools:
            tool_desc = json.dumps(tools, indent=2)
            ollama_messages.append({
                "role": "system",
                "content": (
                    "Available tools:\n"
                    f"{tool_desc}\n"
                    "Respond ONLY with a JSON object describing the tool call."
                ),
            })

        payload: Dict[str, Any] = {
            "model": self.model_id,
            "messages": ollama_messages,
            "options": {
                "temperature": temperature,
            },
        }

        if max_tokens is not None:
            payload["options"]["num_predict"] = max_tokens

        # Send request
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        data = response.json()

        # Normalize Ollama response
        message = data.get("message", {})
        text_content = message.get("content")

        return {
            "id": None,
            "model": self.model_id,
            "content": text_content,
            "tool_calls": None,  # Ollama cannot return structured tool calls
            "finish_reason": data.get("done_reason"),
            "raw": data,
        }

    # ---------------------------------------------------------
    # Streaming (stub)
    # ---------------------------------------------------------

    def stream_chat(self, *args, **kwargs):
        raise NotImplementedError("Ollama streaming not implemented yet.")


# ---------------------------------------------------------
# Register Router
# ---------------------------------------------------------

RouterSelector.register_router(PROVIDER_OLLAMA, OllamaRouter)

