# AthenaUI v3.5 — Spreadsheets Service
# File: backend/spreadsheets/service.py
#
# SQLite-per-user storage for user-defined named spreadsheets: a name, a
# column schema (list of {key, label}), and rows of {column_key: value}
# data. A "template" is just a spreadsheet flagged is_template=True whose
# column schema (but not rows) can be cloned into brand-new spreadsheets.
#
# Column matching is deliberately forgiving: callers (agent tool calls in
# particular) may refer to a column by its exact key OR its human label,
# case-insensitively -- see _match_columns(). Unmatched keys raise a
# SpreadsheetError that lists the valid column labels, so an LLM tool
# caller can self-correct on its next turn instead of silently dropping data.

from __future__ import annotations

import json
import re
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

from core.runtime.runtime import get_runtime


class SpreadsheetError(Exception):
    pass


def _data_dir(username: str) -> Path:
    runtime = get_runtime()
    root = runtime.env.DATA_DIR / "users" / username / "spreadsheets"
    root.mkdir(parents=True, exist_ok=True)
    return root


def _db_path(username: str) -> Path:
    return _data_dir(username) / "spreadsheets.sqlite"


def _connect(username: str) -> sqlite3.Connection:
    conn = sqlite3.connect(_db_path(username))
    conn.row_factory = sqlite3.Row
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS spreadsheets (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            columns_json TEXT NOT NULL,
            is_template INTEGER NOT NULL DEFAULT 0,
            source_template_id TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS spreadsheet_rows (
            id TEXT PRIMARY KEY,
            spreadsheet_id TEXT NOT NULL,
            row_index INTEGER NOT NULL,
            data_json TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
        """
    )
    try:
        conn.execute("ALTER TABLE spreadsheet_rows ADD COLUMN label TEXT NOT NULL DEFAULT ''")
    except sqlite3.OperationalError:
        pass  # column already exists on this user's db
    try:
        conn.execute("ALTER TABLE spreadsheets ADD COLUMN header_text TEXT NOT NULL DEFAULT ''")
    except sqlite3.OperationalError:
        pass  # column already exists on this user's db
    try:
        conn.execute("ALTER TABLE spreadsheets ADD COLUMN meta_fields_json TEXT NOT NULL DEFAULT '[]'")
    except sqlite3.OperationalError:
        pass  # column already exists on this user's db
    try:
        conn.execute("ALTER TABLE spreadsheets ADD COLUMN footer_table_json TEXT NOT NULL DEFAULT '{}'")
    except sqlite3.OperationalError:
        pass  # column already exists on this user's db
    try:
        conn.execute("ALTER TABLE spreadsheets ADD COLUMN image_pages_json TEXT NOT NULL DEFAULT '[]'")
    except sqlite3.OperationalError:
        pass  # column already exists on this user's db
    conn.commit()
    return conn


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _slugify(label: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "_", (label or "").strip().lower()).strip("_")
    return slug or "col"


def _normalize_columns(columns: Sequence[Any]) -> List[Dict[str, str]]:
    """Accepts a list of plain label strings OR {"key","label","width"} dicts.
    "width" (optional int, in character units) lets a column render narrower
    than its neighbors, e.g. a stacked "Extra Stops" header."""
    normalized: List[Dict[str, Any]] = []
    used_keys: set = set()
    for col in columns or []:
        width: Optional[int] = None
        if isinstance(col, str):
            label = col.strip()
            key = _slugify(label)
        elif isinstance(col, dict):
            label = str(col.get("label") or col.get("key") or "").strip()
            key = _slugify(str(col.get("key") or label))
            raw_width = col.get("width")
            if raw_width not in (None, ""):
                try:
                    width = int(raw_width)
                except (TypeError, ValueError):
                    width = None
        else:
            continue
        if not label:
            continue
        base_key = key
        n = 2
        while key in used_keys:
            key = f"{base_key}_{n}"
            n += 1
        used_keys.add(key)
        entry: Dict[str, Any] = {"key": key, "label": label}
        if width:
            entry["width"] = width
        normalized.append(entry)
    return normalized


def _row_to_dict(row: sqlite3.Row) -> Dict[str, Any]:
    try:
        label = row["label"]
    except (IndexError, KeyError):
        label = ""
    return {
        "id": row["id"],
        "row_index": row["row_index"],
        "updated_at": row["updated_at"],
        "label": label or "",
        "values": json.loads(row["data_json"]),
    }


def _spreadsheet_to_dict(row: sqlite3.Row) -> Dict[str, Any]:
    try:
        header_text = row["header_text"]
    except (IndexError, KeyError):
        header_text = ""
    try:
        meta_fields = json.loads(row["meta_fields_json"])
    except (IndexError, KeyError, TypeError, json.JSONDecodeError):
        meta_fields = []
    try:
        footer_table = json.loads(row["footer_table_json"]) or {}
    except (IndexError, KeyError, TypeError, json.JSONDecodeError):
        footer_table = {}
    if not footer_table:
        footer_table = {"label_heading": "", "columns": [], "rows": []}
    try:
        image_pages = json.loads(row["image_pages_json"])
    except (IndexError, KeyError, TypeError, json.JSONDecodeError):
        image_pages = []
    return {
        "id": row["id"],
        "name": row["name"],
        "columns": json.loads(row["columns_json"]),
        "is_template": bool(row["is_template"]),
        "source_template_id": row["source_template_id"],
        "header_text": header_text or "",
        "meta_fields": meta_fields,
        "footer_table": footer_table,
        "image_pages": [
            {"id": p["id"], "filename": p.get("filename", ""), "order": p.get("order", 0), "url": "/data/" + p["stored_path"]}
            for p in sorted(image_pages, key=lambda p: p.get("order", 0))
        ],
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
    }


def _find_spreadsheet_row(conn: sqlite3.Connection, id_or_name: str) -> sqlite3.Row:
    row = conn.execute("SELECT * FROM spreadsheets WHERE id = ?", (id_or_name,)).fetchone()
    if row:
        return row
    row = conn.execute(
        "SELECT * FROM spreadsheets WHERE lower(name) = lower(?)", (id_or_name,)
    ).fetchone()
    if row:
        return row
    names = [r["name"] for r in conn.execute("SELECT name FROM spreadsheets").fetchall()]
    hint = f" Existing spreadsheets: {', '.join(names)}." if names else " No spreadsheets exist yet."
    raise SpreadsheetError(f"No spreadsheet found named or with id '{id_or_name}'.{hint}")


def create_spreadsheet(
    username: str,
    name: str,
    columns: Sequence[Any],
    is_template: bool = False,
    source_template_id: Optional[str] = None,
    header_text: str = "",
    meta_fields: Optional[Sequence[Dict[str, str]]] = None,
    footer_table: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    name = (name or "").strip()
    if not name:
        raise SpreadsheetError("Spreadsheet name is required.")
    normalized_columns = _normalize_columns(columns)
    normalized_meta_fields = _normalize_meta_fields(meta_fields or [])
    normalized_footer_table = _normalize_footer_table(footer_table or {})
    conn = _connect(username)
    try:
        existing = conn.execute(
            "SELECT id FROM spreadsheets WHERE lower(name) = lower(?)", (name,)
        ).fetchone()
        if existing:
            raise SpreadsheetError(f"A spreadsheet named '{name}' already exists.")
        sid = uuid.uuid4().hex
        now = _now()
        conn.execute(
            "INSERT INTO spreadsheets (id, name, columns_json, is_template, source_template_id, header_text, meta_fields_json, footer_table_json, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                sid,
                name,
                json.dumps(normalized_columns),
                int(is_template),
                source_template_id,
                (header_text or "").strip(),
                json.dumps(normalized_meta_fields),
                json.dumps(normalized_footer_table),
                now,
                now,
            ),
        )
        conn.commit()
        row = conn.execute("SELECT * FROM spreadsheets WHERE id = ?", (sid,)).fetchone()
        return _spreadsheet_to_dict(row)
    finally:
        conn.close()


def list_spreadsheets(username: str, is_template: Optional[bool] = None) -> List[Dict[str, Any]]:
    conn = _connect(username)
    try:
        if is_template is None:
            rows = conn.execute("SELECT * FROM spreadsheets ORDER BY name COLLATE NOCASE").fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM spreadsheets WHERE is_template = ? ORDER BY name COLLATE NOCASE",
                (int(is_template),),
            ).fetchall()
        return [_spreadsheet_to_dict(r) for r in rows]
    finally:
        conn.close()


def get_spreadsheet(username: str, id_or_name: str) -> Dict[str, Any]:
    conn = _connect(username)
    try:
        return _spreadsheet_to_dict(_find_spreadsheet_row(conn, id_or_name))
    finally:
        conn.close()


def rename_spreadsheet(username: str, id_or_name: str, new_name: str) -> Dict[str, Any]:
    new_name = (new_name or "").strip()
    if not new_name:
        raise SpreadsheetError("New name is required.")
    conn = _connect(username)
    try:
        row = _find_spreadsheet_row(conn, id_or_name)
        conn.execute(
            "UPDATE spreadsheets SET name = ?, updated_at = ? WHERE id = ?", (new_name, _now(), row["id"])
        )
        conn.commit()
        row = conn.execute("SELECT * FROM spreadsheets WHERE id = ?", (row["id"],)).fetchone()
        return _spreadsheet_to_dict(row)
    finally:
        conn.close()


def update_header_text(username: str, id_or_name: str, header_text: str) -> Dict[str, Any]:
    conn = _connect(username)
    try:
        row = _find_spreadsheet_row(conn, id_or_name)
        conn.execute(
            "UPDATE spreadsheets SET header_text = ?, updated_at = ? WHERE id = ?",
            ((header_text or "").strip(), _now(), row["id"]),
        )
        conn.commit()
        row = conn.execute("SELECT * FROM spreadsheets WHERE id = ?", (row["id"],)).fetchone()
        return _spreadsheet_to_dict(row)
    finally:
        conn.close()


def _normalize_meta_fields(meta_fields: Sequence[Any]) -> List[Dict[str, str]]:
    """A small ordered list of {label, value} pairs rendered as a single
    stretched, bordered row above the grid (e.g. Driver: ___, Truck#: ___)."""
    normalized: List[Dict[str, str]] = []
    for field in meta_fields or []:
        if not isinstance(field, dict):
            continue
        label = str(field.get("label") or "").strip()
        value = str(field.get("value") or "")
        if not label:
            continue
        normalized.append({"label": label, "value": value})
    return normalized


def update_meta_fields(username: str, id_or_name: str, meta_fields: Sequence[Any]) -> Dict[str, Any]:
    normalized = _normalize_meta_fields(meta_fields)
    conn = _connect(username)
    try:
        row = _find_spreadsheet_row(conn, id_or_name)
        conn.execute(
            "UPDATE spreadsheets SET meta_fields_json = ?, updated_at = ? WHERE id = ?",
            (json.dumps(normalized), _now(), row["id"]),
        )
        conn.commit()
        row = conn.execute("SELECT * FROM spreadsheets WHERE id = ?", (row["id"],)).fetchone()
        return _spreadsheet_to_dict(row)
    finally:
        conn.close()


def _normalize_footer_table(footer_table: Dict[str, Any]) -> Dict[str, Any]:
    """A small, fixed-shape second table (e.g. Expenses/Amounts/Description)
    printed below the main grid with a gap. Stored as one JSON blob since
    it's edited as a whole in the UI, not row-by-row like the main grid."""
    if not isinstance(footer_table, dict):
        return {"label_heading": "", "columns": [], "rows": []}
    label_heading = str(footer_table.get("label_heading") or "").strip()
    columns = _normalize_columns(footer_table.get("columns") or [])
    rows: List[Dict[str, Any]] = []
    for raw_row in footer_table.get("rows") or []:
        if not isinstance(raw_row, dict):
            continue
        label = str(raw_row.get("label") or "").strip()
        try:
            values = _match_columns(columns, raw_row.get("values") or {})
        except SpreadsheetError:
            values = {}
        rows.append({"label": label, "values": values})
    return {"label_heading": label_heading, "columns": columns, "rows": rows}


def update_footer_table(username: str, id_or_name: str, footer_table: Dict[str, Any]) -> Dict[str, Any]:
    normalized = _normalize_footer_table(footer_table)
    conn = _connect(username)
    try:
        row = _find_spreadsheet_row(conn, id_or_name)
        conn.execute(
            "UPDATE spreadsheets SET footer_table_json = ?, updated_at = ? WHERE id = ?",
            (json.dumps(normalized), _now(), row["id"]),
        )
        conn.commit()
        row = conn.execute("SELECT * FROM spreadsheets WHERE id = ?", (row["id"],)).fetchone()
        return _spreadsheet_to_dict(row)
    finally:
        conn.close()


_IMAGE_PAGE_EXTENSIONS = (".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp")


def _image_pages_dir(username: str, spreadsheet_id: str) -> Path:
    runtime = get_runtime()
    d = runtime.env.DATA_DIR / "users" / username / "spreadsheets" / spreadsheet_id / "image_pages"
    d.mkdir(parents=True, exist_ok=True)
    return d


def add_image_page(username: str, id_or_name: str, filename: str, file_bytes: bytes) -> Dict[str, Any]:
    """Saves an uploaded image and appends it to this spreadsheet's ordered
    list of PDF-export "image pages" -- each renders as its own full page in
    the exported PDF (see spreadsheets/pdf_export.py), in stored order."""
    ext = Path(filename or "").suffix.lower() or ".png"
    if ext not in _IMAGE_PAGE_EXTENSIONS:
        raise SpreadsheetError(f"Unsupported image type '{ext}'. Use PNG, JPG, GIF, WEBP, or BMP.")
    conn = _connect(username)
    try:
        row = _find_spreadsheet_row(conn, id_or_name)
        try:
            existing = json.loads(row["image_pages_json"])
        except (TypeError, json.JSONDecodeError):
            existing = []
        image_id = uuid.uuid4().hex
        dest = _image_pages_dir(username, row["id"]) / f"{image_id}{ext}"
        dest.write_bytes(file_bytes)
        runtime = get_runtime()
        stored_path = dest.resolve().relative_to(runtime.env.DATA_DIR.resolve()).as_posix()
        next_order = max((p.get("order", 0) for p in existing), default=-1) + 1
        existing.append({
            "id": image_id,
            "filename": (filename or "").strip() or f"{image_id}{ext}",
            "stored_path": stored_path,
            "order": next_order,
        })
        conn.execute(
            "UPDATE spreadsheets SET image_pages_json = ?, updated_at = ? WHERE id = ?",
            (json.dumps(existing), _now(), row["id"]),
        )
        conn.commit()
        row = conn.execute("SELECT * FROM spreadsheets WHERE id = ?", (row["id"],)).fetchone()
        return _spreadsheet_to_dict(row)
    finally:
        conn.close()


def remove_image_page(username: str, id_or_name: str, image_id: str) -> Dict[str, Any]:
    conn = _connect(username)
    removed: Optional[Dict[str, Any]] = None
    try:
        row = _find_spreadsheet_row(conn, id_or_name)
        try:
            existing = json.loads(row["image_pages_json"])
        except (TypeError, json.JSONDecodeError):
            existing = []
        removed = next((p for p in existing if p.get("id") == image_id), None)
        if removed is None:
            raise SpreadsheetError(f"No image page found with id '{image_id}'.")
        remaining = [p for p in existing if p.get("id") != image_id]
        conn.execute(
            "UPDATE spreadsheets SET image_pages_json = ?, updated_at = ? WHERE id = ?",
            (json.dumps(remaining), _now(), row["id"]),
        )
        conn.commit()
        row = conn.execute("SELECT * FROM spreadsheets WHERE id = ?", (row["id"],)).fetchone()
        result = _spreadsheet_to_dict(row)
    finally:
        conn.close()
    runtime = get_runtime()
    (runtime.env.DATA_DIR / removed["stored_path"]).unlink(missing_ok=True)
    return result


def reorder_image_pages(username: str, id_or_name: str, ordered_ids: Sequence[str]) -> Dict[str, Any]:
    conn = _connect(username)
    try:
        row = _find_spreadsheet_row(conn, id_or_name)
        try:
            existing = json.loads(row["image_pages_json"])
        except (TypeError, json.JSONDecodeError):
            existing = []
        by_id = {p["id"]: p for p in existing}
        if set(ordered_ids) != set(by_id.keys()):
            raise SpreadsheetError("Reorder list must include exactly the existing image page ids, once each.")
        for i, image_id in enumerate(ordered_ids):
            by_id[image_id]["order"] = i
        conn.execute(
            "UPDATE spreadsheets SET image_pages_json = ?, updated_at = ? WHERE id = ?",
            (json.dumps([by_id[image_id] for image_id in ordered_ids]), _now(), row["id"]),
        )
        conn.commit()
        row = conn.execute("SELECT * FROM spreadsheets WHERE id = ?", (row["id"],)).fetchone()
        return _spreadsheet_to_dict(row)
    finally:
        conn.close()


def update_columns(username: str, id_or_name: str, columns: Sequence[Any]) -> Dict[str, Any]:
    normalized_columns = _normalize_columns(columns)
    conn = _connect(username)
    try:
        row = _find_spreadsheet_row(conn, id_or_name)
        conn.execute(
            "UPDATE spreadsheets SET columns_json = ?, updated_at = ? WHERE id = ?",
            (json.dumps(normalized_columns), _now(), row["id"]),
        )
        conn.commit()
        row = conn.execute("SELECT * FROM spreadsheets WHERE id = ?", (row["id"],)).fetchone()
        return _spreadsheet_to_dict(row)
    finally:
        conn.close()


def add_column(username: str, id_or_name: str, label: str, width: Optional[int] = None) -> Dict[str, Any]:
    label = (label or "").strip()
    if not label:
        raise SpreadsheetError("Column label is required.")
    conn = _connect(username)
    try:
        row = _find_spreadsheet_row(conn, id_or_name)
        columns = json.loads(row["columns_json"])
        used_keys = {c["key"] for c in columns}
        key = _slugify(label)
        base_key = key
        n = 2
        while key in used_keys:
            key = f"{base_key}_{n}"
            n += 1
        new_column: Dict[str, Any] = {"key": key, "label": label}
        if width:
            new_column["width"] = int(width)
        columns.append(new_column)
        conn.execute(
            "UPDATE spreadsheets SET columns_json = ?, updated_at = ? WHERE id = ?",
            (json.dumps(columns), _now(), row["id"]),
        )
        conn.commit()
        row = conn.execute("SELECT * FROM spreadsheets WHERE id = ?", (row["id"],)).fetchone()
        return _spreadsheet_to_dict(row)
    finally:
        conn.close()


def rename_column(
    username: str, id_or_name: str, key: str, new_label: Optional[str] = None, width: Optional[int] = None
) -> Dict[str, Any]:
    if new_label is not None:
        new_label = new_label.strip()
        if not new_label:
            raise SpreadsheetError("New column label is required.")
    if new_label is None and width is None:
        raise SpreadsheetError("Nothing to update: provide a label and/or a width.")
    conn = _connect(username)
    try:
        row = _find_spreadsheet_row(conn, id_or_name)
        columns = json.loads(row["columns_json"])
        found = False
        for col in columns:
            if col["key"] == key:
                if new_label is not None:
                    col["label"] = new_label
                if width is not None:
                    if width > 0:
                        col["width"] = int(width)
                    else:
                        col.pop("width", None)
                found = True
                break
        if not found:
            raise SpreadsheetError(f"No column with key '{key}' on '{row['name']}'.")
        conn.execute(
            "UPDATE spreadsheets SET columns_json = ?, updated_at = ? WHERE id = ?",
            (json.dumps(columns), _now(), row["id"]),
        )
        conn.commit()
        row = conn.execute("SELECT * FROM spreadsheets WHERE id = ?", (row["id"],)).fetchone()
        return _spreadsheet_to_dict(row)
    finally:
        conn.close()


def remove_column(username: str, id_or_name: str, key: str) -> Dict[str, Any]:
    conn = _connect(username)
    try:
        row = _find_spreadsheet_row(conn, id_or_name)
        columns = json.loads(row["columns_json"])
        remaining = [c for c in columns if c["key"] != key]
        if len(remaining) == len(columns):
            raise SpreadsheetError(f"No column with key '{key}' on '{row['name']}'.")
        conn.execute(
            "UPDATE spreadsheets SET columns_json = ?, updated_at = ? WHERE id = ?",
            (json.dumps(remaining), _now(), row["id"]),
        )
        conn.commit()
        row = conn.execute("SELECT * FROM spreadsheets WHERE id = ?", (row["id"],)).fetchone()
        return _spreadsheet_to_dict(row)
    finally:
        conn.close()


def delete_spreadsheet(username: str, id_or_name: str) -> None:
    conn = _connect(username)
    try:
        row = _find_spreadsheet_row(conn, id_or_name)
        conn.execute("DELETE FROM spreadsheet_rows WHERE spreadsheet_id = ?", (row["id"],))
        conn.execute("DELETE FROM spreadsheets WHERE id = ?", (row["id"],))
        conn.commit()
    finally:
        conn.close()


def save_as_template(username: str, id_or_name: str, template_name: str) -> Dict[str, Any]:
    conn = _connect(username)
    try:
        row = _find_spreadsheet_row(conn, id_or_name)
        columns = json.loads(row["columns_json"])
        sheet = _spreadsheet_to_dict(row)
    finally:
        conn.close()
    return create_spreadsheet(
        username,
        template_name,
        columns,
        is_template=True,
        header_text=sheet["header_text"],
        meta_fields=sheet["meta_fields"],
        footer_table=sheet["footer_table"],
    )


def export_template(username: str, id_or_name: str) -> Dict[str, Any]:
    """Portable JSON representation of a spreadsheet/template's column
    schema (name + columns only -- no rows, ids, or timestamps) suitable
    for downloading and re-importing later, or sharing/backing up."""
    conn = _connect(username)
    try:
        row = _find_spreadsheet_row(conn, id_or_name)
        columns = json.loads(row["columns_json"])
    finally:
        conn.close()
    return {"name": row["name"], "columns": columns}


def import_template(
    username: str, name: str, columns: Sequence[Any], is_template: bool = True
) -> Dict[str, Any]:
    """Creates a new spreadsheet/template from a previously exported JSON
    file's {name, columns}. Raises SpreadsheetError (name collision, no
    columns key, etc.) same as create_spreadsheet, so the caller can
    prompt for a different name."""
    return create_spreadsheet(username, name=name, columns=columns, is_template=is_template)


def create_from_template(username: str, template_id_or_name: str, new_name: str) -> Dict[str, Any]:
    conn = _connect(username)
    try:
        row = _find_spreadsheet_row(conn, template_id_or_name)
        columns = json.loads(row["columns_json"])
        source_id = row["id"]
        sheet = _spreadsheet_to_dict(row)
    finally:
        conn.close()
    return create_spreadsheet(
        username,
        new_name,
        columns,
        is_template=False,
        source_template_id=source_id,
        header_text=sheet["header_text"],
        meta_fields=sheet["meta_fields"],
        footer_table=sheet["footer_table"],
    )


def list_rows(username: str, id_or_name: str) -> List[Dict[str, Any]]:
    conn = _connect(username)
    try:
        row = _find_spreadsheet_row(conn, id_or_name)
        rows = conn.execute(
            "SELECT * FROM spreadsheet_rows WHERE spreadsheet_id = ? ORDER BY row_index",
            (row["id"],),
        ).fetchall()
        return [_row_to_dict(r) for r in rows]
    finally:
        conn.close()


def _match_columns(columns: List[Dict[str, str]], values: Dict[str, Any]) -> Dict[str, Any]:
    by_label = {c["label"].strip().lower(): c["key"] for c in columns}
    by_key = {c["key"].strip().lower(): c["key"] for c in columns}
    result: Dict[str, Any] = {}
    unmatched: List[str] = []
    for raw_key, value in (values or {}).items():
        norm = str(raw_key).strip().lower()
        # Exact key match must win first: labels can legitimately repeat (e.g. three
        # "Date" columns), so by_label only ever keeps the last matching column and
        # would otherwise hijack writes aimed at any other column sharing that label.
        matched = by_key.get(norm) or by_label.get(norm)
        if not matched:
            unmatched.append(str(raw_key))
            continue
        result[matched] = value
    if unmatched:
        valid = ", ".join(c["label"] for c in columns)
        raise SpreadsheetError(f"Unrecognized column(s): {', '.join(unmatched)}. Valid columns are: {valid}.")
    return result


def add_row(username: str, id_or_name: str, values: Dict[str, Any], label: str = "") -> Dict[str, Any]:
    conn = _connect(username)
    try:
        row = _find_spreadsheet_row(conn, id_or_name)
        columns = json.loads(row["columns_json"])
        matched = _match_columns(columns, values)
        next_index_row = conn.execute(
            "SELECT COALESCE(MAX(row_index), 0) + 1 AS next_index FROM spreadsheet_rows WHERE spreadsheet_id = ?",
            (row["id"],),
        ).fetchone()
        row_index = next_index_row["next_index"]
        rid = uuid.uuid4().hex
        now = _now()
        conn.execute(
            "INSERT INTO spreadsheet_rows (id, spreadsheet_id, row_index, data_json, updated_at, label) VALUES (?, ?, ?, ?, ?, ?)",
            (rid, row["id"], row_index, json.dumps(matched), now, (label or "").strip()),
        )
        conn.execute("UPDATE spreadsheets SET updated_at = ? WHERE id = ?", (now, row["id"]))
        conn.commit()
        r = conn.execute("SELECT * FROM spreadsheet_rows WHERE id = ?", (rid,)).fetchone()
        return _row_to_dict(r)
    finally:
        conn.close()


def update_row(
    username: str, id_or_name: str, row_index: int, values: Dict[str, Any], label: Optional[str] = None
) -> Dict[str, Any]:
    conn = _connect(username)
    try:
        sheet_row = _find_spreadsheet_row(conn, id_or_name)
        columns = json.loads(sheet_row["columns_json"])
        matched = _match_columns(columns, values)
        row_record = conn.execute(
            "SELECT * FROM spreadsheet_rows WHERE spreadsheet_id = ? AND row_index = ?",
            (sheet_row["id"], row_index),
        ).fetchone()
        if not row_record:
            raise SpreadsheetError(f"Row {row_index} does not exist in '{sheet_row['name']}'.")
        existing = json.loads(row_record["data_json"])
        existing.update(matched)
        now = _now()
        if label is not None:
            conn.execute(
                "UPDATE spreadsheet_rows SET data_json = ?, updated_at = ?, label = ? WHERE id = ?",
                (json.dumps(existing), now, label.strip(), row_record["id"]),
            )
        else:
            conn.execute(
                "UPDATE spreadsheet_rows SET data_json = ?, updated_at = ? WHERE id = ?",
                (json.dumps(existing), now, row_record["id"]),
            )
        conn.execute("UPDATE spreadsheets SET updated_at = ? WHERE id = ?", (now, sheet_row["id"]))
        conn.commit()
        r = conn.execute("SELECT * FROM spreadsheet_rows WHERE id = ?", (row_record["id"],)).fetchone()
        return _row_to_dict(r)
    finally:
        conn.close()


def delete_row(username: str, id_or_name: str, row_id: str) -> None:
    conn = _connect(username)
    try:
        sheet_row = _find_spreadsheet_row(conn, id_or_name)
        conn.execute(
            "DELETE FROM spreadsheet_rows WHERE id = ? AND spreadsheet_id = ?", (row_id, sheet_row["id"])
        )
        conn.commit()
    finally:
        conn.close()


def _dedupe_labels(labels: Sequence[str]) -> List[str]:
    """Spreadsheets may deliberately reuse the same column label (e.g. a trip
    sheet with three "Date" columns). CSV headers must be unique, so repeats
    get a distinguishing " (2)", " (3)", ... suffix."""
    seen: Dict[str, int] = {}
    result: List[str] = []
    for label in labels:
        seen[label] = seen.get(label, 0) + 1
        result.append(label if seen[label] == 1 else f"{label} ({seen[label]})")
    return result


def get_export_table(username: str, id_or_name: str) -> Dict[str, Any]:
    """Returns everything needed to render this spreadsheet as CSV or as a
    polished PDF "document": {"name", "columns" (deduped labels, for CSV),
    "rows" (list of dict keyed by deduped label, for CSV), "columns_full"
    (raw {key,label,width} list, position-accurate even with duplicate
    labels), "rows_by_key" (list of dict keyed by column key), plus
    "header_text", "meta_fields", "footer_table" for the letterhead/
    driver-truck row/expenses block."""
    conn = _connect(username)
    try:
        sheet_row = _find_spreadsheet_row(conn, id_or_name)
        columns = json.loads(sheet_row["columns_json"])
        row_records = conn.execute(
            "SELECT * FROM spreadsheet_rows WHERE spreadsheet_id = ? ORDER BY row_index",
            (sheet_row["id"],),
        ).fetchall()
    finally:
        conn.close()
    sheet = _spreadsheet_to_dict(sheet_row)

    deduped_labels = _dedupe_labels([c["label"] for c in columns])
    key_to_deduped_label = {c["key"]: deduped_labels[i] for i, c in enumerate(columns)}
    has_labels = any((r["label"] or "").strip() for r in row_records)
    labels = (["Row Label"] + deduped_labels) if has_labels else deduped_labels

    rows: List[Dict[str, Any]] = []
    rows_by_key: List[Dict[str, Any]] = []
    for r in row_records:
        data = json.loads(r["data_json"])
        row_dict = {key_to_deduped_label.get(k, k): v for k, v in data.items()}
        if has_labels:
            row_dict = {"Row Label": r["label"] or "", **row_dict}
        rows.append(row_dict)
        rows_by_key.append(dict(data))

    runtime = get_runtime()
    try:
        raw_image_pages = json.loads(sheet_row["image_pages_json"])
    except (IndexError, KeyError, TypeError, json.JSONDecodeError):
        raw_image_pages = []
    image_page_paths = [
        str(runtime.env.DATA_DIR / p["stored_path"])
        for p in sorted(raw_image_pages, key=lambda p: p.get("order", 0))
    ]

    return {
        "name": sheet_row["name"],
        "columns": labels,
        "rows": rows,
        "columns_full": columns,
        "rows_by_key": rows_by_key,
        "row_labels": [r["label"] or "" for r in row_records],
        "header_text": sheet["header_text"],
        "meta_fields": sheet["meta_fields"],
        "footer_table": sheet["footer_table"],
        "image_pages": image_page_paths,
    }

    try:
        header_text = sheet_row["header_text"]
    except (IndexError, KeyError):
        header_text = ""
    return {"name": sheet_row["name"], "columns": labels, "rows": rows, "header_text": header_text or ""}
