# AthenaUI v3.6 — Synergy Dual-Model Orchestrator
# File: backend/chat/synergy/service.py
#
# Runs a bounded discussion between Code Model A and Code Model B under the
# shared, characterless "Synergy" identity (see chat/memory/maximos_client.py
# -- SYNERGY_AGENT_ID -- and its MMS short/long-term memory). Each turn must
# end with a fenced ```json verdict block: {"agree": bool, "plan": {...}}.
# When both models agree, a real coin_toss decides whose exact plan wording
# is reported as canonical (a fair tie-break between two converged, nearly
# identical proposals). When they fail to converge within `max_rounds`, both
# final plans are packaged as anonymized/shuffled "Plan A" / "Plan B" for the
# user to pick between -- the unpicked one is simply discarded.
#
# Used by BOTH integration points (Code Suite's ChatEngine.chat() and Build
# Map's build_map_chat route) -- neither architecture is touched here, they
# each call run_discussion() and translate the SynergyResult into their own
# existing response shape.

import asyncio
import json
import logging
import re
import secrets
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import requests

from safety.approvals import ApprovalRequiredError
from llm.routers.providers import PROVIDER_OPENAI

from artifacts.service import save_artifact, update_artifact
from chat.history.service import HistoryManager
from chat.memory.maximos_client import SYNERGY_AGENT_ID
from llm.context_trim import compact_tool_history
from logs_system.system.service import system_logger

logger = logging.getLogger(__name__)

DEFAULT_MAX_ROUNDS = 20

# Reserved character/agent name the frontend lists alongside real characters
# (see SidebarChat.tsx) -- selecting it is how a user opts into Synergy mode
# now, instead of a separate on/off toggle. It is never a real vault/persona
# character: ChatEngine.run_synergy() uses it purely as the history bucket
# name for this conversation, and chat_send derives synergy mode from it.
SYNERGY_CHARACTER_NAME = "Synergy"

_VERDICT_RE = re.compile(r"```json\s*(\{.*?\})\s*```", re.DOTALL)
_CODE_BLOCK_RE = re.compile(r"```.*?```", re.DOTALL)

# Fallback directory detection: Code Suite's directory-selection UI
# (CodeSuitePage.toggleDir -> useEditorContextStore) is the normal way
# `editor_context.is_directory`/`path` gets populated, but a user who simply
# *describes* a target directory in the chat message itself (never clicking
# it in the file tree first) would otherwise get a Synergy run with
# directory_path=None for its entire lifetime -- no diagnostic pass, no
# discussion-phase tool schemas, both models silently toolless. This regex
# pulls a plausible absolute Windows directory path out of the user's own
# message text as a best-effort fallback, used ONLY when editor_context
# didn't already provide one. Matches an optionally quoted/backtick-quoted
# "C:\foo\bar" style path; trailing punctuation the user likely typed as
# sentence punctuation (. , ; : ! ? ' " ` ) ]) is stripped before validation.
_WINDOWS_PATH_RE = re.compile(r"[A-Za-z]:\\[^\s\"'`<>|?*]+")

# Sensitive system roots we refuse to auto-select even if literally typed in
# chat -- this fallback is meant for the user's own project folders, not a
# license to point live terminal/file tools at the OS or program install
# trees just because the text happened to mention them.
_BLOCKED_DIRECTORY_PREFIXES = (
    "c:\\windows",
    "c:\\program files",
    "c:\\programdata",
)

# Remembers each user's most recently resolved Synergy directory_path (via
# either Code Suite's editor_context or the message-text fallback below).
# Without this, a user chatting with Synergy OUTSIDE Code Suite (e.g. the
# sidebar/general chat) loses all tool access the moment a single follow-up
# message ("did it finish?", "check the terminal") doesn't itself repeat the
# full path -- every call to run_discussion() re-derives directory_path from
# scratch with nothing else to go on, silently dropping back to a toolless
# abstract discussion mid-conversation. In-memory only (cleared on backend
# restart), same tradeoff as tools/system/terminal/_session.py's _SESSIONS.
_LAST_DIRECTORY: Dict[str, str] = {}


def _extract_directory_path_from_message(text: str) -> Optional[str]:
    """Best-effort extraction of a real, existing, non-system directory path
    mentioned in the user's own chat message -- see _WINDOWS_PATH_RE above.
    Returns the first candidate that actually exists as a directory on disk
    and isn't inside a blocked system root, or None."""
    if not text:
        return None
    for match in _WINDOWS_PATH_RE.finditer(text):
        candidate = match.group(0).rstrip(".,;:!?')]")
        normalized = candidate.lower()
        if any(normalized.startswith(prefix) for prefix in _BLOCKED_DIRECTORY_PREFIXES):
            continue
        try:
            if Path(candidate).is_dir():
                return candidate
        except OSError:
            continue
    return None


def _strip_code_for_log(text: str, limit: int = 2000) -> str:
    """Strips fenced code blocks (including the mandatory json verdict) before
    a Synergy turn is written to the Tail Log -- the log must only ever hold
    the plain-language discussion, never code/file content."""
    cleaned = _CODE_BLOCK_RE.sub("[code omitted]", text or "").strip()
    if len(cleaned) > limit:
        cleaned = cleaned[:limit] + "…"
    return cleaned

AGENT_MODE_SYSTEM_PROMPT = (
    "You are operating in AthenaUI Synergy mode as one of two collaborating "
    "coding agents. You have no character persona here -- just plain \"Agent "
    "Mode\". You and a counterpart model are discussing the SAME task and "
    "must converge on a single concrete plan.\n\n"
    "Protocol (mandatory, every turn):\n"
    "1) Respond in plain, concise text discussing the task / reacting to "
    "your counterpart's last message.\n"
    "2) End your reply with EXACTLY one fenced json block of this shape:\n"
    "```json\n"
    "{\"agree\": true|false, \"summary\": \"one-sentence plan summary\", "
    "\"plan\": {\"steps\": [\"...\"], \"files\": [{\"path\": \"...\", "
    "\"responsibility\": \"...\"}]}}\n"
    "```\n"
    "Set \"agree\" to true only once your plan and your counterpart's most "
    "recent plan are substantively the same. Keep refining `plan` every "
    "round -- it must always be your complete current best proposal, not a "
    "diff against the previous round."
)

# Appended to AGENT_MODE_SYSTEM_PROMPT only when a real directory is
# selected (same gating condition as the diagnostic/apply passes) -- gives
# the discussion loop itself real tool access instead of forcing both
# models to discuss in the abstract with no way to verify a claim or
# continue investigating if the pre-diagnosis turns out incomplete.
_DISCUSSION_TOOL_GUIDANCE = (
    "\n\nYou ALSO have real tool access (read tools, file_write/file_edit_lines/file_mkdir, "
    "and terminal_run) scoped to the project directory given below -- use it. If you're not "
    "sure something is true, or your counterpart's claim seems wrong, check it yourself instead "
    "of guessing or just trusting/disputing it in the abstract. A prior diagnostic pass may have "
    "already explored the project, but it is NOT untouchable or final -- if it's incomplete, "
    "missed something, or turns out to be wrong, keep investigating with your tools until you're "
    "actually confident. Maintain a single shared scratch file (e.g. SYNERGY_NOTES.md in the "
    "directory) as your single source of truth: read it first if it exists, and use "
    "file_write/file_edit_lines to keep it updated with confirmed facts (clearly separated from "
    "unconfirmed hypotheses) so you and your counterpart aren't duplicating investigation or "
    "working from stale assumptions. You may call tools across several of your own turns before "
    "replying -- only once you're done investigating for THIS turn should you give your "
    "plain-text reply ending in the mandatory json verdict block described above."
)

# Appended to the discussion system prompt in every case (directory or not)
# -- tells both models the coin_toss tool is available but entirely
# optional, so they stop expecting a forced tie-break and only reach for it
# when THEY actually want a neutral way to pick between two different final
# wordings (most of the time they'll simply converge on one already).
_COIN_TOSS_GUIDANCE = (
    "\n\nIf you and your counterpart end up agreeing on the substance but end your discussion "
    "with differently-worded final replies/plans, you do NOT need to force a tie-break -- most of "
    "the time one of you will simply adopt the other's wording. If you genuinely can't agree on "
    "whose wording to use, you may voluntarily call the coin_toss tool yourselves to decide; it is "
    "entirely optional and never required."
)


@dataclass
class SynergyTurn:
    speaker: str  # "A" or "B"
    text: str
    verdict: Dict[str, Any]


@dataclass
class SynergyResult:
    status: str  # "agreed" | "disagreed" | "error" | "needs_more_rounds" | "awaiting_approval" | "in_progress"
    rounds_run: int
    transcript: List[SynergyTurn] = field(default_factory=list)
    final_plan: Optional[Dict[str, Any]] = None
    coin_toss_result: Optional[str] = None  # "heads" | "tails"
    plan_a: Optional[Dict[str, Any]] = None
    plan_b: Optional[Dict[str, Any]] = None
    artifact_id: Optional[str] = None
    coin_artifact_id: Optional[str] = None
    error: Optional[str] = None
    # Set on both "needs_more_rounds" (true round-cap hit -- requires an
    # explicit user "Grant More Rounds" click) AND "in_progress" (one step
    # just completed, more remain within the existing budget -- continues
    # automatically, no user action needed). round/max_rounds mirror
    # ChatEngine's needs_more_turns/tool_call shape so the SAME frontend
    # "Grant More Turns" dialog AND "Using tool: X" round indicator
    # (SidebarChat.tsx) surface this with zero frontend changes.
    # resume_state holds everything SynergyOrchestrator._step()/resume()
    # needs to continue (including live router objects) -- it is kept
    # purely in-memory (api/routes/chat.py's AGENTIC_STATE dict), never
    # serialized to JSON/disk.
    round: Optional[int] = None
    max_rounds: Optional[int] = None
    resume_state: Optional[Dict[str, Any]] = None
    # Set to "time_limit" on a "needs_more_rounds" result that was triggered
    # by the normal-chat wall-clock budget (_CHAT_TIME_BUDGET_SECONDS)
    # instead of a true round cap -- lets the frontend show Synergy's own
    # "been working on this for a while, continue?" Yes/No copy instead of
    # the generic "Grant More Turns" wording. None for every other case
    # (including the Code Suite diagnostic/apply round caps, unchanged).
    pause_reason: Optional[str] = None
    # Only set when status == "in_progress" -- short human-readable label
    # (e.g. "Model A thinking", "Diagnosing: file_read(...)") shown by the
    # frontend's existing "Using tool: {toolName}" indicator bar in place of
    # a real tool name, since a Synergy step isn't always a literal tool call.
    activity_label: Optional[str] = None
    # Set when an "agreed" plan was handed to the apply/fix phase (see
    # _run_apply_pass) -- "done" (summary holds what changed/was verified),
    # "approval_pending" (a write tool is waiting on the user's Allow/Deny
    # click in the sidebar -- surfaced via the normal pending_action/Keep-
    # Revert mechanism, nothing Synergy-specific needed there), or None when
    # no directory context was selected so no apply phase ran at all.
    apply_status: Optional[str] = None
    apply_summary: Optional[str] = None
    # Chat-mode pipeline only (see SynergyChatOrchestrator below) -- True
    # once an agreed plan was actually carried out via _run_chat_execute_pass
    # (either auto-triggered because the winning verdict set execute=true,
    # or via the dedicated execute_chat_plan() entry point). execute_summary
    # is that pass's plain-text result, separate from apply_summary/
    # apply_status which remain the Code Suite coding pipeline's own fields
    # (reused here only for the approval_pending/done status strings).
    executed: bool = False
    execute_summary: Optional[str] = None
    # The winning speaker's actual free-text reply for their final turn
    # (prose, with the mandatory json verdict block already stripped) --
    # e.g. the literal avatar prompt/copy/answer they agreed on, as opposed
    # to `final_plan` which is just the structured "steps"/"summary" verdict
    # describing a PROCESS. Chat replies should lead with this so the user
    # gets the actual agreed-upon content instead of a meta-plan about
    # producing it. May be empty if a model's final turn was verdict-only.
    final_answer_text: Optional[str] = None


def _extract_verdict(text: str) -> Tuple[str, Optional[Dict[str, Any]]]:
    """Splits a model reply into (prose, verdict_dict_or_None), pulling the
    LAST fenced json block out as the verdict and stripping it from the
    prose kept for the discussion transcript/artifact."""
    matches = list(_VERDICT_RE.finditer(text))
    if not matches:
        return text.strip(), None
    last = matches[-1]
    prose = (text[: last.start()] + text[last.end():]).strip()
    try:
        verdict = json.loads(last.group(1))
    except (json.JSONDecodeError, ValueError):
        verdict = None
    return prose, verdict if isinstance(verdict, dict) else None


async def _call_model(router, messages: List[Dict[str, str]]) -> str:
    result = await asyncio.to_thread(router.chat, messages, temperature=0.4)
    if isinstance(result, dict):
        text = result.get("content") or result.get("reply") or result.get("text") or ""
        if isinstance(text, list):
            parts = [p.get("text", "") if isinstance(p, dict) else str(p) for p in text]
            text = "\n".join(p for p in parts if p)
        return str(text or "")
    return str(result or "")


def _compute_synergy_tool_names() -> frozenset:
    """Synergy now gets the SAME full tool catalog other Agent-enabled
    characters get (ChatEngine._agent_tool_names' `allowed_names=None`
    tier) in every phase -- diagnostic, apply, discussion, and chat --
    instead of the small hand-picked allowlists this used to be gated by.
    Two categories are excluded: "relationships" (Synergy is a
    characterless shared identity with no relationship model, so those
    tools are meaningless for it) and "ui" (UI/mouse/keyboard/screen-
    automation tools stay a separate, untouched third service per
    Synergy_Reborn.md Section 1 point 4 -- two concurrent Synergy workers
    issuing simultaneous mouse/screen actions would collide). A handful of
    individual tools are ALSO excluded regardless of category:
    image_generate_selfie/_pair/_group/_avatar/_character all generate a
    photo of "the character" -- Synergy has no face/persona to photograph,
    so these just produced a random, meaningless person (seen live: an
    unrelated selfie instead of any real self-expression). Synergy's real
    avatar-expression tool is avatar_set_glow (its avatar's CSS glow
    intensity/speed), which stays available. Computed from the LIVE
    registry (not a hardcoded snapshot) so future tool additions reach
    Synergy automatically, same as every other Agent-enabled character."""
    from tools.registry.categories import TOOL_CATEGORIES
    from tools.registry.loader import load_tools
    excluded_names: set = {
        "image_generate_selfie", "image_generate_pair", "image_generate_group",
        "image_generate_avatar", "image_generate_character",
    }
    for category in TOOL_CATEGORIES:
        if category["id"] in ("relationships", "ui"):
            excluded_names.update(category["tool_names"])
    registry = load_tools()
    all_names = {tool["name"] for tool in registry.list() if isinstance(tool, dict) and tool.get("name")}
    return frozenset(all_names - excluded_names)


_SYNERGY_TOOL_NAMES = _compute_synergy_tool_names()

# Safe "always keep" core used only when _capped_tool_names() has to
# truncate below OpenAI's hard 128-tool-array cap -- mirrors
# ChatEngine.ALWAYS_ON_TOOL_NAMES, minus the relationship tools Synergy
# already excludes outright.
_SYNERGY_CORE_TOOL_NAMES = frozenset({
    "memory_search", "memory_recall_summary", "memory_recall_details",
    "image_generate", "image_check_capability", "web_search", "coin_toss",
    "file_read", "file_write", "terminal_run",
})

# OpenAI rejects a tools=[...] array beyond this size -- duplicated here
# (rather than imported) to avoid a circular import with chat.engine.service
# (which itself imports chat.synergy.service). Keep in sync with
# ChatEngine.OPENAI_MAX_TOOLS.
_SYNERGY_OPENAI_MAX_TOOLS = 128


def _capped_tool_names(*provider_ids: Optional[str]) -> frozenset:
    """Returns Synergy's full non-relationship tool-name set, unless one of
    the given provider_ids is PROVIDER_OPENAI and the full set exceeds
    OpenAI's hard tool-count cap -- in that case, truncates to a safe core
    plus a deterministic slice of the rest (same strategy
    ChatEngine._agent_tool_names already uses for every other Agent-enabled
    character on OpenAI). Every other provider gets the full set
    unrestricted. Accepts multiple provider_ids since a few call sites
    (e.g. the A/B discussion phase) share one schema set across two
    independently-configured models."""
    if len(_SYNERGY_TOOL_NAMES) <= _SYNERGY_OPENAI_MAX_TOOLS or PROVIDER_OPENAI not in provider_ids:
        return _SYNERGY_TOOL_NAMES
    core = _SYNERGY_CORE_TOOL_NAMES & _SYNERGY_TOOL_NAMES
    extra = sorted(_SYNERGY_TOOL_NAMES - core)
    budget = max(_SYNERGY_OPENAI_MAX_TOOLS - len(core), 0)
    return core | frozenset(extra[:budget])


# "Menu on the table": rather than injecting every allowed tool's full
# definition into the prompt on every single turn, Synergy's prompt only
# ever carries ONE real tool schema -- tool_list. Only once the model
# actually calls it (because IT decided it might need a tool) does the real
# catalog become genuine, callable schemas for the rest of that
# conversation -- a lean a-la-carte menu instead of the full buffet sitting
# on the table the whole time.
_TOOL_LIST_TOOL_NAME = "tool_list"
_TOOL_LIST_SCHEMA = {
    "type": "function",
    "function": {
        "name": _TOOL_LIST_TOOL_NAME,
        "description": (
            "Pull up the full menu of real tools available to you right now, grouped into "
            "sections with a one-line description each. This is the ONLY tool in your prompt "
            "until you call it -- keeps your context lean instead of carrying every tool's full "
            "definition on every turn. Call it whenever you think you might need a tool; once "
            "called, everything on the menu becomes directly callable for the rest of this "
            "conversation (no need to call this again unless you want a refresher)."
        ),
        "parameters": {"type": "object", "properties": {}},
    },
}


def _menu_unlocked(messages: List[Dict[str, Any]]) -> bool:
    """True once this conversation has actually called tool_list -- only
    then do the real tools become genuine, callable schemas (see
    _menu_gated_schemas/_run_one_round's worker-side equivalent)."""
    for msg in messages:
        if msg.get("role") != "assistant":
            continue
        for call in (msg.get("tool_calls") or []):
            fn = call.get("function") if isinstance(call, dict) else None
            if isinstance(fn, dict) and fn.get("name") == _TOOL_LIST_TOOL_NAME:
                return True
    return False


def _build_tool_menu_text(registry: Any, allowed_names: Optional[frozenset]) -> str:
    """Formats the real tool catalog as a categorized menu (section headers
    from tools/registry/categories.py, one line per tool) -- what tool_list
    actually returns once called."""
    from tools.registry.categories import TOOL_CATEGORIES
    schemas_by_name = {
        s["function"]["name"]: s["function"]
        for s in registry.get_all_schemas(allowed_names=allowed_names)
    }
    sections: List[str] = []
    covered: set = set()
    for category in TOOL_CATEGORIES:
        names_here = sorted(n for n in category["tool_names"] if n in schemas_by_name)
        if not names_here:
            continue
        covered.update(names_here)
        lines = [f"## {category['label']}"]
        for name in names_here:
            desc = str(schemas_by_name[name].get("description") or "").split(". ")[0].strip().rstrip(".")
            lines.append(f"- {name}: {desc}.")
        sections.append("\n".join(lines))
    leftover = sorted(set(schemas_by_name) - covered)
    if leftover:
        lines = ["## Other"]
        for name in leftover:
            desc = str(schemas_by_name[name].get("description") or "").split(". ")[0].strip().rstrip(".")
            lines.append(f"- {name}: {desc}.")
        sections.append("\n".join(lines))
    return "\n\n".join(sections) if sections else "(No tools available.)"


def _menu_gated_schemas(engine: Any, allowed_names: frozenset, messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """"Menu on the table" lean-loading for the in-process (non-worker)
    tool-calling loops: until tool_list has actually been called in this
    conversation, it's the ONLY schema offered -- once called, the real
    `allowed_names` catalog becomes genuine, callable schemas too."""
    if not _menu_unlocked(messages):
        return [_TOOL_LIST_SCHEMA]
    return engine.tools.registry.get_all_schemas(allowed_names=allowed_names) + [_TOOL_LIST_SCHEMA]


# Kept as named aliases (rather than rewriting every call site) -- all three
# phases now share the exact same full toolset; see
# _compute_synergy_tool_names's docstring above for why.
_DIAGNOSTIC_TOOL_NAMES = _SYNERGY_TOOL_NAMES
_APPLY_TOOL_NAMES = _SYNERGY_TOOL_NAMES

_DIAGNOSTIC_SYSTEM_PROMPT = (
    "You are diagnosing a real software project BEFORE any fix is planned. You have "
    "AthenaUI's full tool catalog available (the same one every other agent has), scoped to "
    "the directory given below where relevant -- use file/search tools to actually explore "
    "the real files instead of assuming their contents. This phase is diagnosis-only: don't "
    "write/edit/delete files or run commands yet even though those tools are available to you "
    "-- save that for the apply phase once a plan is agreed. Keep investigating across "
    "multiple tool calls until you can state CONCRETE, specific problems you found (exact "
    "file(s), exact symptom/error/broken logic) -- not a generic plan for how one might go "
    "about investigating. Once you're confident in your findings, stop calling tools and "
    "reply with PLAIN TEXT ONLY summarizing the concrete diagnosis: what is actually wrong "
    "and exactly where."
)

_DIAGNOSTIC_MAX_ROUNDS = 10

# Cap on how many extra rounds a single "grant more rounds" click can add to
# the diagnostic pass -- mirrors ChatEngine.EXTRA_TURNS_GRANT_MAX, but kept
# much smaller: each extra round here is a real tool-calling LLM turn against
# the user's actual files, not a cheap text exchange.
_DIAGNOSTIC_EXTRA_ROUNDS_GRANT_MAX = 10

_APPLY_SYSTEM_PROMPT = (
    "You are implementing an already-agreed fix plan for a real software project. You have "
    "AthenaUI's full tool catalog available (the same one every other agent has) -- "
    "file read/write/edit tools and terminal_run scoped to the directory given below, plus "
    "everything else in the catalog if a real need for it comes up. Make the real edits "
    "described in the plan, then use terminal_run to verify them (e.g. the project's relevant "
    "build/test/lint command) where that makes sense. Some write tool calls may require the "
    "user's explicit approval before they take effect -- if one does, your turn simply ends "
    "there, you don't need to do anything special about it. Once you've made and verified the "
    "fix, stop calling tools and reply with PLAIN TEXT ONLY summarizing exactly what you "
    "changed and what you verified."
)

_APPLY_MAX_ROUNDS = 15

# Same rationale as _DIAGNOSTIC_EXTRA_ROUNDS_GRANT_MAX -- kept modest since
# each round is a real tool-calling turn (often including a terminal_run).
_APPLY_EXTRA_ROUNDS_GRANT_MAX = 15

# ---------------------------------------------------------------------------
# Build-Map "Synergy Build" pipeline constants/prompts -- see
# SynergyOrchestrator.start_synergy_build/step_synergy_build below for the
# resumable state machine these drive.
# ---------------------------------------------------------------------------
_BUILD_PHASE_ROUND_BUDGET = _APPLY_MAX_ROUNDS
_BUILD_PHASE_EXTRA_ROUNDS = _APPLY_EXTRA_ROUNDS_GRANT_MAX
_BUILD_PHASE_MAX_AUTO_GRANTS = 4
# 10 minutes -- same "Synergy has been working on this a while, do you want
# them to continue?" cadence as _step_chat's time-limit pause pattern.
_BUILD_TIME_BUDGET_SECONDS = 600
_NEXT_BUILD_PHASE = {
    "build_a": "build_b",
    "build_b": "cross_check_a",
    "cross_check_a": "cross_check_b",
    "cross_check_b": "test",
}

_BUILD_DIVIDE_SYSTEM_PROMPT = (
    "You are Model A, about to collaborate with Model B (a separate AI) to actually BUILD a "
    "complete software project from an already-finalized Build Map plan. Before any code is "
    "written, propose how to split the work: which files YOU (Model A) will build, and which "
    "files Model B will build. Aim for a sensible split along real architectural seams (e.g. one "
    "of you builds the core tool/business logic, the other builds the UI/presentation layer -- or "
    "split by directory/module, whatever fits THIS plan best) so each of you can work with minimal "
    "overlap. EVERY file in the plan must be assigned to exactly one of you -- do not omit any.\n\n"
    "Reply with brief plain-text reasoning followed by a single fenced json block shaped exactly "
    "like:\n```json\n{\"model_a_files\": [\"path1\", \"path2\"], \"model_b_files\": [\"path3\"], "
    "\"rationale\": \"one or two sentences\"}\n```"
)

_BUILD_DIVIDE_CONFIRM_SYSTEM_PROMPT = (
    "You are Model B. Model A has proposed a split of which files each of you will build for this "
    "Build Map project. Review it below -- if it looks reasonable, confirm it AS-IS. If you see a "
    "better split (better architectural separation, or a more balanced workload), propose your own "
    "adjusted split instead. EVERY file in the plan must end up assigned to exactly one of you.\n\n"
    "Reply with brief plain-text reasoning followed by a single fenced json block in the exact "
    "same shape Model A used:\n```json\n{\"model_a_files\": [...], \"model_b_files\": [...], "
    "\"rationale\": \"...\"}\n```\nThis is the FINAL split that will actually be used, so make sure "
    "it is complete and covers every file in the plan."
)

_BUILD_TEST_TASK_DESCRIPTION = (
    "The full project has now been built and cross-checked by both models. Your job now is to "
    "actually TEST it end-to-end using terminal_run: install dependencies if needed, run the "
    "project's build/compile/lint step if applicable, run its test suite if one exists, or at "
    "minimum start/import the program to confirm it doesn't immediately crash. Fix any real issues "
    "you find using your file tools, then re-test. Keep iterating until it genuinely works, or you "
    "are confident further iteration won't help (explain why in that case). When finished, reply "
    "with a PLAIN TEXT summary of exactly what you tested, what you fixed, and whether the program "
    "is confirmed working.\n\nDestination directory: {destination_path}"
)


def _collect_build_map_file_paths(build_map_json: str) -> List[str]:
    try:
        data = json.loads(build_map_json)
    except (json.JSONDecodeError, ValueError):
        return []
    files = data.get("files") if isinstance(data, dict) else None
    if not isinstance(files, list):
        return []
    paths = []
    for entry in files:
        if isinstance(entry, dict) and entry.get("path"):
            paths.append(str(entry["path"]))
    return paths


def _fallback_even_file_split(build_map_json: str) -> Dict[str, Any]:
    """Deterministic fallback used only if neither model produces a
    parseable division proposal -- never leaves the build stuck with no
    split at all. Simple alphabetical halves; not architecturally aware,
    but keeps the pipeline moving instead of failing outright."""
    paths = sorted(_collect_build_map_file_paths(build_map_json))
    midpoint = (len(paths) + 1) // 2
    return {
        "model_a_files": paths[:midpoint],
        "model_b_files": paths[midpoint:],
        "rationale": "Fallback even split -- neither model returned a parseable division proposal.",
    }


def _build_phase_task_description(role_label: str, assigned_files: List[str], build_map_json: str, destination_path: str) -> str:
    files_block = "\n".join(f"- {path}" for path in assigned_files) or "(none)"
    return (
        f"You are {role_label}, building YOUR assigned portion of a software project from an "
        "already-finalized Build Map plan. Build ONLY the following files (create directories as "
        "needed, write complete, production-ready content -- never leave placeholders, stubs, or "
        f"truncated files):\n{files_block}\n\n"
        "Full Build Map plan, for context/consistency (only write YOUR assigned files above -- "
        f"your counterpart is building the rest):\n```json\n{build_map_json}\n```\n\n"
        f"Destination directory: {destination_path}"
    )


def _cross_check_task_description(reviewer_label: str, other_label: str, other_files: List[str], destination_path: str) -> str:
    files_block = "\n".join(f"- {path}" for path in other_files) or "(none)"
    return (
        f"You are {reviewer_label}, cross-checking {other_label}'s work on a shared build. "
        f"{other_label} just finished writing these files:\n{files_block}\n\n"
        "Read each one with your file-reading tool and check for: truncated/incomplete content, "
        "mixed programming languages in one file, syntax errors, or inconsistency with the rest of "
        "the project (e.g. mismatched imports/APIs between your work and theirs). Fix anything you "
        "find using your file tools. If everything looks correct, make no changes. When finished, "
        "reply with a PLAIN TEXT summary of what you checked and what (if anything) you fixed.\n\n"
        f"Destination directory: {destination_path}"
    )


def _summarize_tool_call(name: str, args: Dict[str, Any]) -> str:
    """Short human-readable 'toolname(arg=value, ...)' label for the Agent
    Thinking artifact -- mirrors the 'Using tool: X' indicator every other
    agent surface already shows, which Synergy's discussion had none of."""
    parts = []
    for key, value in list(args.items())[:3]:
        text = str(value)
        if len(text) > 40:
            text = text[:37] + "..."
        parts.append(f"{key}={text!r}")
    return f"{name}({', '.join(parts)})"


# Coin toss is now OPTIONAL, not forced: Model A and Model B almost always
# converge on equivalent wording once they agree, so flipping a coin every
# single time was pure noise. `coin_toss` stays a normal, voluntary tool
# (registered in the 'artifacts' category) that either model can call
# DURING discussion if THEY decide they want a neutral way to pick between
# two genuinely different final wordings. Discussion now gets the same full
# toolset as every other phase regardless of whether a directory is
# selected (see _SYNERGY_TOOL_NAMES/_capped_tool_names above) -- this name
# is kept as an alias purely so existing call sites below don't need
# renaming.
_DISCUSSION_COIN_TOSS_NAMES = _SYNERGY_TOOL_NAMES


def _detect_self_coin_toss(messages_a: List[Dict[str, Any]], messages_b: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """Checks whether either model already voluntarily called the coin_toss
    tool itself at some point during the discussion and, if so, returns its
    real {"result": "heads"|"tails", "artifact_id": ...} payload so the
    finalize step can honor THAT outcome instead of (no longer) flipping a
    brand new, unrelated coin of its own."""
    for messages in (messages_a, messages_b):
        for i, msg in enumerate(messages):
            if msg.get("role") != "assistant" or not msg.get("tool_calls"):
                continue
            for call in msg["tool_calls"]:
                fn = (call.get("function") or {}) if isinstance(call, dict) else {}
                if fn.get("name") != "coin_toss":
                    continue
                call_id = call.get("id") if isinstance(call, dict) else None
                for later in messages[i + 1:]:
                    if later.get("role") == "tool" and later.get("tool_call_id") == call_id:
                        content = later.get("content")
                        try:
                            parsed = json.loads(content) if isinstance(content, str) else content
                        except Exception:
                            parsed = None
                        if isinstance(parsed, dict) and parsed.get("result") in ("heads", "tails"):
                            return parsed
    return None


# ---------------------------------------------------------------------------
# Phase 1b: distributed worker execution (Synergy_Reborn.md Section 1). Each
# model's actual LLM calls + local tool execution can optionally be
# delegated to the real, separate Synergy-A/Synergy-B worker processes
# (backend/synergy_worker/app.py) instead of running in-process here, ONE
# ROUND AT A TIME -- the functions below still own the diagnostic/
# discussion/apply round-budget and resume-state machine exactly as before,
# they just hand each round's actual inference + tool execution off to the
# matching worker when one is available. Used ONLY when a worker is
# currently registered (see scripts/start_synergy_workers.ps1) AND stays
# reachable; any failure transparently falls back to the original in-process
# execution for the remainder of that pass, so Synergy keeps working even if
# the user hasn't launched the separate worker processes.
# ---------------------------------------------------------------------------

def _worker_routing(label: str, username: str, provider_id: str, model_id: str, directory_path: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """Bundles everything _call_worker_turn needs for one speaker, or None
    if that speaker's worker process isn't currently registered -- callers
    treat a None return as "use in-process execution for this speaker"."""
    from api.routes.synergy_worker import get_worker
    if not get_worker(label):
        return None
    return {"label": label, "username": username, "provider_id": provider_id, "model_id": model_id, "directory_path": directory_path}


async def _call_worker_turn(
    label: str, *, username: str, provider_id: str, model_id: str,
    messages: List[Dict[str, Any]], tool_names: Optional[Any],
    directory_path: Optional[str], temperature: float = 0.2, max_tokens: int = 8192,
) -> Optional[Dict[str, Any]]:
    """POSTs ONE round (one proxied LLM call plus any resulting local tool
    execution) to the given Synergy worker process's /turn endpoint. Returns
    the worker's result dict ({"status": "done"|"in_progress"|
    "approval_pending", "messages": [...], ...}) on success, or None on ANY
    failure (not registered, unreachable, bad response) so callers fall back
    to in-process execution instead of breaking the whole run."""
    from api.routes.synergy_worker import get_worker, get_or_create_worker_token

    worker = get_worker(label)
    if not worker:
        return None
    try:
        resp = await asyncio.to_thread(
            requests.post,
            f"http://{worker['host']}:{worker['port']}/turn",
            json={
                "username": username, "provider_id": provider_id, "model_id": model_id,
                # compact_tool_history: `messages` here is the SAME
                # ever-growing per-round list every in-process call site
                # already compacts before calling the LLM directly -- the
                # worker-process path needs the identical guard, otherwise
                # every stale tool result still gets shipped over HTTP and
                # resent to the provider every round (confirmed root cause
                # of the Synergy "prompt is too long" token-overflow bug).
                "messages": compact_tool_history(messages), "tool_names": list(tool_names) if tool_names is not None else None,
                "directory_path": directory_path, "temperature": temperature, "max_tokens": max_tokens,
            },
            headers={"Authorization": f"Bearer {get_or_create_worker_token()}"},
            timeout=180,
        )
        resp.raise_for_status()
        result = resp.json()
    except Exception as e:
        system_logger.log(event=f"Synergy worker turn call failed ({label}): {e}", level="warning")
        return None
    if not isinstance(result, dict) or "status" not in result or "messages" not in result:
        return None
    return result


async def _run_diagnostic_pass(
    engine: Any,
    router,
    directory_path: str,
    task_description: str,
    *,
    resume: Optional[Dict[str, Any]] = None,
    round_budget: int = _DIAGNOSTIC_MAX_ROUNDS,
    worker: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Runs a bounded read-only tool-calling pass against the real files in
    `directory_path`. Returns either:
      {"status": "done", "diagnosis": str, "tool_call_labels": [...]}
    or, if `round_budget` is exhausted without the model concluding:
      {"status": "needs_more_rounds", "round": int, "max_rounds": int,
       "resume": {...}}
    where "resume" can be passed back in via the `resume=` kwarg (together
    with a larger `round_budget`) to continue from exactly where this pass
    left off, instead of starting over -- see SynergyOrchestrator.resume().

    This is what lets the Synergy discussion start from an actual diagnosis
    instead of two models guessing/discussing in the abstract with no file
    access at all (which is all the discussion loop below can ever do on its
    own)."""
    if resume:
        messages: List[Dict[str, Any]] = resume["messages"]
        tool_call_labels: List[str] = resume["tool_call_labels"]
        stall_nudges: int = resume["stall_nudges"]
        rounds_done: int = resume["rounds_done"]
    else:
        messages = [
            {"role": "system", "content": _DIAGNOSTIC_SYSTEM_PROMPT},
            {"role": "user", "content": f"Directory to diagnose: {directory_path}\n\nWhat the user reported:\n{task_description}"},
        ]
        tool_call_labels = []
        stall_nudges = 0
        rounds_done = 0

    schemas = _menu_gated_schemas(engine, _capped_tool_names(router.provider_id), messages)

    def _needs_more_rounds() -> Dict[str, Any]:
        return {
            "status": "needs_more_rounds",
            "round": rounds_done,
            "max_rounds": round_budget,
            "resume": {
                "messages": messages,
                "tool_call_labels": tool_call_labels,
                "stall_nudges": stall_nudges,
                "rounds_done": rounds_done,
            },
        }

    while rounds_done < round_budget:
        rounds_done += 1

        worker_result = await _call_worker_turn(
            worker["label"], username=worker["username"], provider_id=worker["provider_id"], model_id=worker["model_id"],
            messages=messages, tool_names=sorted(_capped_tool_names(router.provider_id)), directory_path=directory_path,
            temperature=0.2, max_tokens=8192,
        ) if worker else None
        if worker and worker_result is None:
            worker = None  # unreachable -- fall back to in-process for the rest of this pass

        if worker_result is not None:
            messages = worker_result["messages"]
            if worker_result["status"] == "done":
                content = worker_result.get("content")
                if content:
                    return {"status": "done", "diagnosis": str(content), "tool_call_labels": tool_call_labels}
                if stall_nudges < 2:
                    stall_nudges += 1
                    messages.append({
                        "role": "system",
                        "content": (
                            "Your last reply had no tool call and no text. Either call one of the "
                            "read-only diagnostic tools now, or reply with your plain-text diagnosis "
                            "-- do not end your turn empty."
                        ),
                    })
                    continue
                if rounds_done >= round_budget:
                    return _needs_more_rounds()
                if tool_call_labels:
                    return {
                        "status": "done",
                        "diagnosis": "(Diagnostic pass gathered tool findings above but the model never produced a final summary -- treat the tool results as partial findings.)",
                        "tool_call_labels": tool_call_labels,
                    }
                return {"status": "done", "diagnosis": "(No diagnosis produced.)", "tool_call_labels": tool_call_labels}

            # "in_progress" or (defensively) "approval_pending" -- read-only
            # diagnostic tools never actually require approval.
            tool_call_labels.extend(worker_result.get("tool_call_labels", []))
            if rounds_done >= round_budget:
                return _needs_more_rounds()
            return {
                "status": "in_progress",
                "round": rounds_done,
                "max_rounds": round_budget,
                "last_tool_name": tool_call_labels[-1] if tool_call_labels else None,
                "resume": {
                    "messages": messages,
                    "tool_call_labels": tool_call_labels,
                    "stall_nudges": stall_nudges,
                    "rounds_done": rounds_done,
                },
            }

        # Default max_tokens (2048) is tight for a reasoning-capable model
        # exploring real files -- give it real room so a response doesn't
        # come back truncated/empty before it reaches a tool call or text.
        # compact_tool_history: this pass has NO round cap on `messages` growth
        # (resumes across rounds via `resume`), so without compaction every
        # tool result ever produced gets resent on every subsequent round --
        # same squared-growth risk _build_messages/group-chat already guard
        # against (see llm/context_trim.py).
        response = await asyncio.to_thread(router.chat, compact_tool_history(messages), tools=schemas, tool_choice="auto", temperature=0.2, max_tokens=8192)
        if not isinstance(response, dict):
            return {"status": "done", "diagnosis": str(response or "(No diagnosis produced.)"), "tool_call_labels": tool_call_labels}

        tool_call = engine.normalizer.normalize(response)
        if not tool_call:
            content = response.get("content") or response.get("reply") or response.get("text")
            if content:
                return {"status": "done", "diagnosis": str(content), "tool_call_labels": tool_call_labels}
            # The model ended its turn with neither a recognized tool call nor
            # any text -- a real, observed failure mode (same class as
            # ChatEngine._advance_agentic_round's "_stall_nudges" backstop),
            # not necessarily a dead end. Nudge it to actually act instead of
            # immediately discarding whatever tool findings earlier rounds in
            # THIS pass already gathered.
            system_logger.log(
                event="Synergy diagnosis stalled",
                agent_state="Synergy",
                details={"finish_reason": response.get("finish_reason"), "round_tool_calls_so_far": len(tool_call_labels)},
            )
            if stall_nudges < 2:
                stall_nudges += 1
                messages.append({
                    "role": "system",
                    "content": (
                        "Your last reply had no tool call and no text. Either call one of the "
                        "read-only diagnostic tools now, or reply with your plain-text diagnosis "
                        "-- do not end your turn empty."
                    ),
                })
                continue
            if rounds_done >= round_budget:
                return _needs_more_rounds()
            if tool_call_labels:
                return {
                    "status": "done",
                    "diagnosis": "(Diagnostic pass gathered tool findings above but the model never produced a final summary -- treat the tool results as partial findings.)",
                    "tool_call_labels": tool_call_labels,
                }
            return {"status": "done", "diagnosis": "(No diagnosis produced.)", "tool_call_labels": tool_call_labels}

        raw_tool_calls = response.get("tool_calls")
        if not isinstance(raw_tool_calls, list) or not raw_tool_calls:
            raw_tool_calls = [{
                "id": tool_call.get("tool_call_id"),
                "type": "function",
                "function": {"name": tool_call["tool_name"], "arguments": json.dumps(tool_call["arguments"])},
            }]
        messages.append({"role": "assistant", "content": response.get("content"), "tool_calls": raw_tool_calls})

        for index, raw_call in enumerate(raw_tool_calls):
            parsed = tool_call if index == 0 else engine.normalizer.normalize({"tool_calls": [raw_call]})
            call_id = raw_call.get("id") if isinstance(raw_call, dict) else None
            if not parsed:
                messages.append({"role": "tool", "tool_call_id": call_id, "content": json.dumps({"status": "error", "error": "Malformed tool call."})})
                continue

            call_name = parsed["tool_name"]
            if call_name == _TOOL_LIST_TOOL_NAME:
                menu_text = _build_tool_menu_text(engine.tools.registry, _capped_tool_names(router.provider_id))
                messages.append({"role": "tool", "tool_call_id": call_id, "content": menu_text})
                tool_call_labels.append("pulled up the tool menu")
                continue
            if call_name not in _DIAGNOSTIC_TOOL_NAMES:
                messages.append({
                    "role": "tool",
                    "tool_call_id": call_id,
                    "content": json.dumps({"status": "error", "error": f"Tool '{call_name}' is not permitted during diagnosis (read-only tools only)."}),
                })
                continue

            tool_call_labels.append(_summarize_tool_call(call_name, parsed["arguments"]))
            try:
                # Tagged with character="Synergy" purely so the central
                # tool-call logger (tools/executor/executor.py) attributes
                # this "Agent action: ..." Tail Log entry to agent_state=
                # "Synergy" -- these read-only fs tools don't otherwise use
                # "character" for anything.
                tool_call_args = {**parsed["arguments"], "character": "Synergy"}
                tool_result = await engine.tools.execute(call_name, tool_call_args)
            except Exception as e:
                tool_result = {"status": "error", "error": str(e)}

            messages.append({
                "role": "tool",
                "tool_call_id": call_id,
                "content": tool_result if isinstance(tool_result, str) else json.dumps(tool_result),
            })

        # Pause here and hand control back to the caller after EVERY round
        # (not just once round_budget is exhausted) -- this is what lets the
        # Synergy artifact/indicator update live, round by round, instead of
        # this whole pass running silently to completion in one blocking
        # call. The caller (SynergyOrchestrator._step) auto-continues this
        # exact same way the normal agentic loop's "tool_call" status does,
        # with no user action needed -- "needs_more_rounds" below is reserved
        # for genuinely exhausting round_budget.
        if rounds_done >= round_budget:
            return _needs_more_rounds()
        return {
            "status": "in_progress",
            "round": rounds_done,
            "max_rounds": round_budget,
            "last_tool_name": tool_call_labels[-1] if tool_call_labels else None,
            "resume": {
                "messages": messages,
                "tool_call_labels": tool_call_labels,
                "stall_nudges": stall_nudges,
                "rounds_done": rounds_done,
            },
        }

    return _needs_more_rounds()


async def _run_apply_pass(
    engine: Any,
    router,
    directory_path: str,
    task_description: str,
    final_plan: Optional[Dict[str, Any]],
    *,
    resume: Optional[Dict[str, Any]] = None,
    round_budget: int = _APPLY_MAX_ROUNDS,
    worker: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Runs a bounded tool-calling pass that actually IMPLEMENTS an
    already-agreed plan (write tools + terminal_run, scoped to
    `directory_path` via engine.tools.set_scope_dir -- already set by
    ChatEngine.run_synergy before this ever runs). Returns one of:
      {"status": "done", "summary": str, "tool_call_labels": [...]}
      {"status": "approval_pending", "tool_call_labels": [...]}
        -- a write tool raised ApprovalRequiredError; the usual sidebar
           Keep/Revert flow (pending_action) takes it from here, nothing
           Synergy-specific needed.
      {"status": "needs_more_rounds", "round": int, "max_rounds": int, "resume": {...}}
    `resume`/`round_budget` support continuing from where a previous
    needs_more_rounds pause left off, same contract as _run_diagnostic_pass."""
    if resume:
        messages: List[Dict[str, Any]] = resume["messages"]
        tool_call_labels: List[str] = resume["tool_call_labels"]
        stall_nudges: int = resume["stall_nudges"]
        rounds_done: int = resume["rounds_done"]
    else:
        plan_text = json.dumps(final_plan, indent=2) if final_plan else "(no structured plan was captured -- work from the task description above.)"
        messages = [
            {"role": "system", "content": _APPLY_SYSTEM_PROMPT},
            {"role": "user", "content": f"Directory: {directory_path}\n\nOriginal task:\n{task_description}\n\nAgreed plan:\n{plan_text}"},
        ]
        tool_call_labels = []
        stall_nudges = 0
        rounds_done = 0

    schemas = _menu_gated_schemas(engine, _capped_tool_names(router.provider_id), messages)

    def _needs_more_rounds_apply() -> Dict[str, Any]:
        return {
            "status": "needs_more_rounds",
            "round": rounds_done,
            "max_rounds": round_budget,
            "resume": {
                "messages": messages,
                "tool_call_labels": tool_call_labels,
                "stall_nudges": stall_nudges,
                "rounds_done": rounds_done,
            },
        }

    while rounds_done < round_budget:
        rounds_done += 1

        worker_result = await _call_worker_turn(
            worker["label"], username=worker["username"], provider_id=worker["provider_id"], model_id=worker["model_id"],
            messages=messages, tool_names=sorted(_capped_tool_names(router.provider_id)), directory_path=directory_path,
            temperature=0.2, max_tokens=8192,
        ) if worker else None
        if worker and worker_result is None:
            worker = None  # unreachable -- fall back to in-process for the rest of this pass

        if worker_result is not None:
            messages = worker_result["messages"]
            if worker_result["status"] == "approval_pending":
                return {"status": "approval_pending", "tool_call_labels": tool_call_labels}
            if worker_result["status"] == "done":
                content = worker_result.get("content")
                if content:
                    return {"status": "done", "summary": str(content), "tool_call_labels": tool_call_labels}
                if stall_nudges < 2:
                    stall_nudges += 1
                    messages.append({
                        "role": "system",
                        "content": (
                            "Your last reply had no tool call and no text. Either call one of the "
                            "available tools now, or reply with your plain-text summary of what you "
                            "changed -- do not end your turn empty."
                        ),
                    })
                    continue
                if rounds_done >= round_budget:
                    return _needs_more_rounds_apply()
                if tool_call_labels:
                    return {
                        "status": "done",
                        "summary": "(Apply pass made the changes logged above but the model never produced a final summary.)",
                        "tool_call_labels": tool_call_labels,
                    }
                return {"status": "done", "summary": "(No changes made.)", "tool_call_labels": tool_call_labels}

            tool_call_labels.extend(worker_result.get("tool_call_labels", []))
            if rounds_done >= round_budget:
                return _needs_more_rounds_apply()
            return {
                "status": "in_progress",
                "round": rounds_done,
                "max_rounds": round_budget,
                "last_tool_name": tool_call_labels[-1] if tool_call_labels else None,
                "resume": {
                    "messages": messages,
                    "tool_call_labels": tool_call_labels,
                    "stall_nudges": stall_nudges,
                    "rounds_done": rounds_done,
                },
            }

        # compact_tool_history: same unbounded-round risk as the diagnostic
        # pass above -- without this, `messages` grows every round with no
        # cap across the whole apply pass.
        response = await asyncio.to_thread(router.chat, compact_tool_history(messages), tools=schemas, tool_choice="auto", temperature=0.2, max_tokens=8192)
        if not isinstance(response, dict):
            return {"status": "done", "summary": str(response or "(No summary produced.)"), "tool_call_labels": tool_call_labels}

        tool_call = engine.normalizer.normalize(response)
        if not tool_call:
            content = response.get("content") or response.get("reply") or response.get("text")
            if content:
                return {"status": "done", "summary": str(content), "tool_call_labels": tool_call_labels}
            system_logger.log(
                event="Synergy apply stalled",
                agent_state="Synergy",
                details={"finish_reason": response.get("finish_reason"), "round_tool_calls_so_far": len(tool_call_labels)},
            )
            if stall_nudges < 2:
                stall_nudges += 1
                messages.append({
                    "role": "system",
                    "content": (
                        "Your last reply had no tool call and no text. Either call one of the "
                        "available tools now, or reply with your plain-text summary of what you "
                        "changed -- do not end your turn empty."
                    ),
                })
                continue
            if rounds_done >= round_budget:
                return _needs_more_rounds_apply()
            if tool_call_labels:
                return {
                    "status": "done",
                    "summary": "(Apply pass made the changes logged above but the model never produced a final summary.)",
                    "tool_call_labels": tool_call_labels,
                }
            return {"status": "done", "summary": "(No changes made.)", "tool_call_labels": tool_call_labels}

        raw_tool_calls = response.get("tool_calls")
        if not isinstance(raw_tool_calls, list) or not raw_tool_calls:
            raw_tool_calls = [{
                "id": tool_call.get("tool_call_id"),
                "type": "function",
                "function": {"name": tool_call["tool_name"], "arguments": json.dumps(tool_call["arguments"])},
            }]
        messages.append({"role": "assistant", "content": response.get("content"), "tool_calls": raw_tool_calls})

        approval_pending = False
        for index, raw_call in enumerate(raw_tool_calls):
            parsed = tool_call if index == 0 else engine.normalizer.normalize({"tool_calls": [raw_call]})
            call_id = raw_call.get("id") if isinstance(raw_call, dict) else None
            if not parsed:
                messages.append({"role": "tool", "tool_call_id": call_id, "content": json.dumps({"status": "error", "error": "Malformed tool call."})})
                continue

            call_name = parsed["tool_name"]
            if call_name == _TOOL_LIST_TOOL_NAME:
                menu_text = _build_tool_menu_text(engine.tools.registry, _capped_tool_names(router.provider_id))
                messages.append({"role": "tool", "tool_call_id": call_id, "content": menu_text})
                tool_call_labels.append("pulled up the tool menu")
                continue
            if call_name not in _APPLY_TOOL_NAMES:
                messages.append({
                    "role": "tool",
                    "tool_call_id": call_id,
                    "content": json.dumps({"status": "error", "error": f"Tool '{call_name}' is not permitted during the apply phase."}),
                })
                continue

            tool_call_labels.append(_summarize_tool_call(call_name, parsed["arguments"]))
            try:
                # Tagged with character="Synergy" for the same Tail Log
                # attribution reason as the diagnostic pass above.
                tool_call_args = {**parsed["arguments"], "character": "Synergy"}
                tool_result = await engine.tools.execute(call_name, tool_call_args)
            except ApprovalRequiredError:
                # A write/terminal tool needs a real, out-of-band user click
                # (Allow/Deny in the sidebar) -- same gate the normal agentic
                # loop hits. Every dangerous call in this SAME round still
                # gets its own independent attempt (and its own pending
                # approval) instead of only the first -- so several parallel
                # calls queue together as one checkbox batch in the approval
                # modal rather than the rest being dropped silently. The
                # round still ends once all calls are processed either way:
                # none of the pending ones can possibly succeed this turn.
                messages.append({"role": "tool", "tool_call_id": call_id, "content": json.dumps({"status": "pending_approval"})})
                approval_pending = True
                continue
            except Exception as e:
                tool_result = {"status": "error", "error": str(e)}

            messages.append({
                "role": "tool",
                "tool_call_id": call_id,
                "content": tool_result if isinstance(tool_result, str) else json.dumps(tool_result),
            })

        if approval_pending:
            return {"status": "approval_pending", "tool_call_labels": tool_call_labels}

        # Same per-round pause rationale as _run_diagnostic_pass above.
        if rounds_done >= round_budget:
            return _needs_more_rounds_apply()
        return {
            "status": "in_progress",
            "round": rounds_done,
            "max_rounds": round_budget,
            "last_tool_name": tool_call_labels[-1] if tool_call_labels else None,
            "resume": {
                "messages": messages,
                "tool_call_labels": tool_call_labels,
                "stall_nudges": stall_nudges,
                "rounds_done": rounds_done,
            },
        }

    return _needs_more_rounds_apply()


# How many of its OWN tool calls a model may make within a single discussion
# turn before it's forced to conclude with plain text -- a per-turn safety
# valve, separate from the discussion's own outer max_rounds/grant-more-
# rounds mechanism (which only ever applies across whole rounds).
_DISCUSSION_MAX_TOOL_CALLS_PER_TURN = 6


async def _run_agent_turn(
    engine: Any,
    router,
    messages: List[Dict[str, Any]],
    speaker: str,
    transcript: List[SynergyTurn],
    schemas: Optional[List[Dict[str, Any]]],
    allowed_tool_names: frozenset,
    *,
    worker: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Runs one model's turn within a Synergy discussion round, letting it
    call real tools (read/write/terminal_run, scoped to the selected
    directory) before producing its actual prose+verdict reply -- this is
    what lets the discussion loop itself keep investigating/verifying
    instead of only ever reasoning in the abstract. `messages` is mutated in
    place (this model's own running history). Returns either:
      {"status": "spoke", "raw": str, "prose": str, "verdict": dict|None}
      {"status": "approval_pending"} -- a write/terminal tool needs the
        user's Allow/Deny click; the whole discussion stops here, same
        policy as the apply phase."""
    if not schemas:
        # No directory selected -- nothing to scope tools to, so behave
        # exactly as the discussion loop always has (plain text only).
        if worker:
            result = await _call_worker_turn(
                worker["label"], username=worker["username"], provider_id=worker["provider_id"], model_id=worker["model_id"],
                messages=messages, tool_names=[], directory_path=worker.get("directory_path"),
                temperature=0.4, max_tokens=8192,
            )
            if result is not None and result["status"] == "done":
                messages[:] = result["messages"]
                raw = str(result.get("content") or "")
                prose, verdict = _extract_verdict(raw)
                return {"status": "spoke", "raw": raw, "prose": prose, "verdict": verdict}
            # unavailable/failed -- fall through to the in-process path below
        raw = await _call_model(router, messages)
        prose, verdict = _extract_verdict(raw)
        messages.append({"role": "assistant", "content": raw})
        return {"status": "spoke", "raw": raw, "prose": prose, "verdict": verdict}

    use_worker = bool(worker)
    for _ in range(_DISCUSSION_MAX_TOOL_CALLS_PER_TURN):
        if use_worker:
            worker_result = await _call_worker_turn(
                worker["label"], username=worker["username"], provider_id=worker["provider_id"], model_id=worker["model_id"],
                messages=messages, tool_names=sorted(allowed_tool_names), directory_path=worker.get("directory_path"),
                temperature=0.4, max_tokens=8192,
            )
            if worker_result is None:
                use_worker = False  # unreachable -- fall back to in-process for the rest of this turn
            else:
                messages[:] = worker_result["messages"]
                if worker_result["status"] == "approval_pending":
                    return {"status": "approval_pending"}
                if worker_result["status"] == "done":
                    raw = str(worker_result.get("content") or "")
                    prose, verdict = _extract_verdict(raw)
                    return {"status": "spoke", "raw": raw, "prose": prose, "verdict": verdict}
                for label in worker_result.get("tool_call_labels", []):
                    transcript.append(SynergyTurn(speaker="tool", text=f"Model {speaker}: {label}", verdict={}))
                continue

        # Recomputed every iteration (not just once per call) -- if the
        # model just called tool_list THIS turn, the very next internal
        # iteration (still inside this same _run_agent_turn call) needs the
        # real catalog to already be unlocked, not just on the NEXT turn.
        schemas = _menu_gated_schemas(engine, allowed_tool_names, messages)
        # compact_tool_history: this agent turn's `messages` list is the same
        # one reused across every round of the whole discussion (no reload/
        # cap like chat history gets) -- a long-running discussion (e.g. the
        # chat-mode time-budget path, which has no round cap at all) would
        # otherwise resend every tool result from every prior round, every
        # round, which is exactly how a prompt balloons into the millions of
        # tokens (confirmed root cause of the "prompt is too long" error).
        response = await asyncio.to_thread(router.chat, compact_tool_history(messages), tools=schemas, tool_choice="auto", temperature=0.4, max_tokens=8192)
        if not isinstance(response, dict):
            raw = str(response or "")
            messages.append({"role": "assistant", "content": raw})
            prose, verdict = _extract_verdict(raw)
            return {"status": "spoke", "raw": raw, "prose": prose, "verdict": verdict}

        tool_call = engine.normalizer.normalize(response)
        if not tool_call:
            raw = str(response.get("content") or response.get("reply") or response.get("text") or "")
            messages.append({"role": "assistant", "content": raw})
            prose, verdict = _extract_verdict(raw)
            return {"status": "spoke", "raw": raw, "prose": prose, "verdict": verdict}

        raw_tool_calls = response.get("tool_calls")
        if not isinstance(raw_tool_calls, list) or not raw_tool_calls:
            raw_tool_calls = [{
                "id": tool_call.get("tool_call_id"),
                "type": "function",
                "function": {"name": tool_call["tool_name"], "arguments": json.dumps(tool_call["arguments"])},
            }]
        messages.append({"role": "assistant", "content": response.get("content"), "tool_calls": raw_tool_calls})

        approval_pending = False
        for index, raw_call in enumerate(raw_tool_calls):
            parsed = tool_call if index == 0 else engine.normalizer.normalize({"tool_calls": [raw_call]})
            call_id = raw_call.get("id") if isinstance(raw_call, dict) else None
            if not parsed:
                messages.append({"role": "tool", "tool_call_id": call_id, "content": json.dumps({"status": "error", "error": "Malformed tool call."})})
                continue

            call_name = parsed["tool_name"]
            if call_name == _TOOL_LIST_TOOL_NAME:
                menu_text = _build_tool_menu_text(engine.tools.registry, allowed_tool_names)
                messages.append({"role": "tool", "tool_call_id": call_id, "content": menu_text})
                transcript.append(SynergyTurn(speaker="tool", text=f"Model {speaker}: pulled up the tool menu", verdict={}))
                continue
            if call_name not in allowed_tool_names:
                messages.append({
                    "role": "tool",
                    "tool_call_id": call_id,
                    "content": json.dumps({"status": "error", "error": f"Tool '{call_name}' is not permitted."}),
                })
                continue

            label = _summarize_tool_call(call_name, parsed["arguments"])
            transcript.append(SynergyTurn(speaker="tool", text=f"Model {speaker}: {label}", verdict={}))
            try:
                tool_call_args = {**parsed["arguments"], "character": "Synergy"}
                tool_result = await engine.tools.execute(call_name, tool_call_args)
            except ApprovalRequiredError:
                # Every dangerous call in this SAME round still gets its own
                # independent attempt (and its own pending approval) instead
                # of only the first -- same rationale as _run_apply_pass.
                messages.append({"role": "tool", "tool_call_id": call_id, "content": json.dumps({"status": "pending_approval"})})
                approval_pending = True
                continue
            except Exception as e:
                tool_result = {"status": "error", "error": str(e)}

            messages.append({
                "role": "tool",
                "tool_call_id": call_id,
                "content": tool_result if isinstance(tool_result, str) else json.dumps(tool_result),
            })

        if approval_pending:
            return {"status": "approval_pending"}
        # Loop again -- lets the model react to tool results / call more
        # tools, or finally give its plain-text reply.

    # Exhausted this turn's tool-call budget without a plain-text reply --
    # force a conclusion so one turn can't stall the whole discussion.
    messages.append({
        "role": "system",
        "content": "You've used a lot of tool calls this turn. Stop calling tools now and give your plain-text reply with the mandatory json verdict block.",
    })
    if use_worker:
        worker_result = await _call_worker_turn(
            worker["label"], username=worker["username"], provider_id=worker["provider_id"], model_id=worker["model_id"],
            messages=messages, tool_names=[], directory_path=worker.get("directory_path"),
            temperature=0.4, max_tokens=8192,
        )
        if worker_result is not None:
            messages[:] = worker_result["messages"]
            raw = str(worker_result.get("content") or "")
            prose, verdict = _extract_verdict(raw)
            return {"status": "spoke", "raw": raw, "prose": prose, "verdict": verdict}
    raw = await _call_model(router, messages)
    prose, verdict = _extract_verdict(raw)
    messages.append({"role": "assistant", "content": raw})
    return {"status": "spoke", "raw": raw, "prose": prose, "verdict": verdict}


def _escape(text: str) -> str:
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _render_discussion_html(task: str, transcript: List[SynergyTurn], outcome_line: str, *, done: bool = False) -> str:
    """Compact HTML for the 'Agent Thinking' artifact -- fixed to ~48
    characters wide and ~6 lines high (matching the sidebar chat's usable
    width), with its own internal scrollbar so the user can scroll up
    through the full discussion (and any tool calls used during diagnosis)
    without the artifact itself growing.

    `done` is embedded as a `data-synergy-status` marker on <body> --
    ArtifactRenderer.tsx polls this same artifact id while a Synergy run is
    live and checks for this marker to know when to stop polling, so the
    artifact visibly updates in near-real-time without needing any other
    cross-component wiring."""
    rows = []
    for i, turn in enumerate(transcript):
        if turn.speaker == "tool":
            rows.append(f'<div class="tool-call">&#128295; {_escape(turn.text)}</div>')
            continue
        if turn.speaker == "diag":
            rows.append(f'<div class="diag"><div class="who">Diagnosis</div><div class="bubble">{_escape(turn.text)}</div></div>')
            continue
        who = "Model A" if turn.speaker == "A" else "Model B"
        side = "left" if turn.speaker == "A" else "right"
        rows.append(
            f'<div class="turn {side}"><div class="who">{who} &middot; round {i // 2 + 1}</div>'
            f'<div class="bubble">{_escape(turn.text)}</div></div>'
        )
    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><style>
  html, body {{ margin:0; width:48ch; font: 13px system-ui, sans-serif; background:#0f1115; color:#eee; }}
  .task {{ padding:6px 8px; font-weight:600; border-bottom:1px solid rgba(255,255,255,.1); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }}
  .log {{ height:8.4em; overflow-y:auto; padding:6px 8px; display:flex; flex-direction:column; gap:6px; }}
  .turn, .diag {{ display:flex; flex-direction:column; max-width:92%; }}
  .turn.left {{ align-self:flex-start; }}
  .turn.right {{ align-self:flex-end; }}
  .diag {{ max-width:100%; }}
  .who {{ font-size:10px; opacity:.6; margin-bottom:2px; }}
  .bubble {{ background:#1d2129; border-radius:8px; padding:6px 8px; white-space:pre-wrap; word-break:break-word; }}
  .turn.right .bubble {{ background:#1a2a45; }}
  .diag .bubble {{ background:#2a2410; }}
  .tool-call {{ font-size:11px; opacity:.75; font-family:ui-monospace, monospace; word-break:break-word; }}
  .outcome {{ padding:6px 8px; border-top:1px solid rgba(255,255,255,.1); font-weight:600; font-size:12px; }}
</style></head>
<body data-synergy-status="{'done' if done else 'live'}">
  <div class="task">Synergy: {_escape(task)}</div>
  <div class="log">{''.join(rows)}</div>
  <div class="outcome">{_escape(outcome_line)}</div>
</body></html>"""


def _save_or_update_artifact(
    username: str,
    artifact_id: Optional[str],
    task: str,
    transcript: List[SynergyTurn],
    outcome_line: str,
    *,
    done: bool = False,
) -> str:
    """Creates the 'Synergy Discussion' artifact on the very first call
    (artifact_id=None, right when the user's message is received -- before
    Model A has even spoken) and overwrites the SAME artifact in place on
    every subsequent call, so the already-open artifact view in the chat
    updates live round by round instead of only ever showing a finished
    result. Returns the (possibly newly created) artifact id."""
    html = _render_discussion_html(task, transcript, outcome_line, done=done)
    if artifact_id:
        update_artifact(username, artifact_id, html=html)
        return artifact_id
    created = save_artifact(username, title="Synergy Discussion", html=html, character=SYNERGY_AGENT_ID)
    return created["id"]


def synergy_result_to_text(result: "SynergyResult", model_a: str, model_b: str) -> str:
    """Shared SynergyResult -> human-readable reply text formatter, used by
    both ChatEngine._finalize_synergy_result (Code Suite / general chat) and
    GroupChatRouter (Group Chat / Collab Chat) so every surface Synergy can
    speak from reports its outcome identically. `model_a`/`model_b` are
    just display labels (the actual model ids), already resolved by the
    caller."""
    if result.status == "error":
        return f"Synergy couldn't run: {result.error}"

    if result.status == "agreed":
        plan = result.final_plan or {}
        steps = plan.get("steps") or []
        steps_md = "\n".join(f"{i + 1}. {s}" for i, s in enumerate(steps)) if steps else "(no steps given)"
        reply_text = (
            f"Model A ({model_a}) and Model B ({model_b}) discussed this and agreed "
            f"in {result.rounds_run} round(s). A coin toss selected the final wording.\n\n"
        )
        # Lead with the actual agreed-upon content (e.g. the literal prompt/
        # copy/answer they settled on) rather than burying it behind the
        # structured plan -- `final_plan`/steps describe the PROCESS used to
        # get there, not the result itself, which is what the user actually
        # asked for.
        if result.final_answer_text:
            reply_text += f"{result.final_answer_text}\n\n"
        reply_text += (
            f"**Plan**\n{steps_md}\n\n"
            f"[Artifact: Synergy Discussion](artifact:{result.artifact_id})\n"
            f"[Artifact: Synergy Tie-Break](artifact:{result.coin_artifact_id})"
        )
        if result.apply_status == "approval_pending":
            reply_text += (
                "\n\nI started implementing this plan and one of the steps needs your "
                "approval -- please Allow or Deny it in the sidebar, and I'll continue "
                "right away once you do."
            )
        elif result.apply_status == "done":
            reply_text += f"\n\n**What I actually did**\n{result.apply_summary}"
        return reply_text

    if result.status == "awaiting_approval":
        return (
            f"Model A ({model_a}) and Model B ({model_b}) were discussing this ({result.rounds_run} "
            "round(s) so far) and one of them needs your approval for a tool action before they can "
            "continue -- please Allow or Deny it in the sidebar, then send a follow-up message to "
            "have them pick the discussion back up.\n\n"
            f"[Artifact: Synergy Discussion](artifact:{result.artifact_id})"
        )

    # disagreed
    plan_a = result.plan_a or {}
    plan_b = result.plan_b or {}
    steps_a = "\n".join(f"- {s}" for s in (plan_a.get("steps") or [])) or "(no steps given)"
    steps_b = "\n".join(f"- {s}" for s in (plan_b.get("steps") or [])) or "(no steps given)"
    return (
        f"Model A and Model B discussed this for {result.rounds_run} round(s) but didn't converge. "
        "Here are their two plans -- reply with \"Plan A\" or \"Plan B\" to proceed with one "
        "(the other will be discarded):\n\n"
        f"**Plan A**\n{steps_a}\n\n**Plan B**\n{steps_b}\n\n"
        f"[Artifact: Synergy Discussion](artifact:{result.artifact_id})"
    )


class SynergyOrchestrator:
    """Runs Synergy's full pipeline (optional diagnostic pass -> A/B
    discussion -> optional apply pass) ONE STEP AT A TIME instead of
    blocking through the whole thing in a single call. Every public entry
    point (run_discussion/continue_discussion/resume/deny_more_rounds)
    bottoms out in `_step()`, which does exactly one LLM round (one
    diagnostic tool-calling round, one speaker's discussion turn, or one
    apply tool-calling round), updates the SAME 'Synergy Discussion'
    artifact in place, and returns either a terminal SynergyResult (agreed/
    disagreed/error/awaiting_approval) or status="in_progress" carrying a
    `resume_state` for the caller to immediately continue with (no user
    action needed) -- mirroring ChatEngine._advance_agentic_round's own
    "tool_call" in-progress contract so api/routes/chat.py and the existing
    frontend "Using tool: X" indicator need no Synergy-specific handling
    beyond recognizing this one extra status string.

    status="needs_more_rounds" is reserved for a phase's TRUE round cap
    (_DIAGNOSTIC_MAX_ROUNDS/_APPLY_MAX_ROUNDS) being exhausted -- that still
    requires an explicit user "Grant More Rounds" click (resume()), same as
    before. The A/B discussion loop's own round cap has no such mechanism;
    it still degrades gracefully into an anonymized Plan A / Plan B choice.
    """

    def __init__(self, username: str, engine: Any = None):
        self.username = username
        if engine is None:
            # Local import avoids a circular-import cycle at module load time
            # (chat.engine.service also ends up importing tool modules).
            from chat.engine.service import ChatEngine

            engine = ChatEngine(username)
        self.engine = engine

    def _router_for(self, provider_id: str, model_id: str, category: str):
        api_key = self.engine._get_api_key(provider_id, category=category)
        self.engine._inject_provider_api_key(provider_id, api_key, category=category)
        return self.engine.router_selector.select(provider_id=provider_id, model_id=model_id, mode="code")

    def _build_discussion_messages(
        self, task_description: str, diagnosis_block: str, directory_path: Optional[str], extra_context: str = "",
        provider_a: Optional[str] = None, provider_b: Optional[str] = None,
        tool_names_override: Optional[frozenset] = None,
    ) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], Optional[List[Dict[str, Any]]], frozenset]:
        system_prompt = AGENT_MODE_SYSTEM_PROMPT + (_DISCUSSION_TOOL_GUIDANCE if directory_path else "") + _COIN_TOSS_GUIDANCE
        # Discussion normally gets the full Synergy toolset regardless of
        # whether a directory is selected (same as every other phase) --
        # capped for OpenAI's hard tool-count limit if either model is on
        # that provider. Callers that need a restricted, never-requires-
        # approval tool set (e.g. Build Map's abstract advice-only
        # discussion, which has no way to surface an approval prompt) can
        # pass tool_names_override to bypass the full catalog entirely.
        discussion_tool_names = tool_names_override if tool_names_override is not None else _capped_tool_names(provider_a, provider_b)
        schemas = self.engine.tools.registry.get_all_schemas(allowed_names=discussion_tool_names)
        context_block = diagnosis_block + extra_context
        messages_a: List[Dict[str, Any]] = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": f"Task:\n{task_description}{context_block}\n\nYou are Model A. Give your opening proposal."},
        ]
        messages_b: List[Dict[str, Any]] = [
            {"role": "system", "content": system_prompt},
            {
                "role": "user",
                "content": (
                    f"Task:\n{task_description}{context_block}\n\nYou are Model B. Your counterpart (Model A) has not "
                    "spoken yet -- give your own opening proposal."
                ),
            },
        ]
        return messages_a, messages_b, schemas, discussion_tool_names

    async def run_discussion(
        self,
        task_description: str,
        *,
        max_rounds: int = DEFAULT_MAX_ROUNDS,
        editor_context: Optional[Dict[str, Any]] = None,
        allow_remembered_directory: bool = True,
        tool_names_override: Optional[frozenset] = None,
        context_notes: Optional[str] = None,
    ) -> SynergyResult:
        if not self.engine.synergy_available():
            return SynergyResult(
                status="error",
                rounds_run=0,
                error="Synergy needs both Code Model A and Code Model B configured in Settings.",
            )

        try:
            provider_a, model_a = self.engine._get_active_code_model()
            provider_b, model_b = self.engine._get_active_code_model_b()
            router_a = self._router_for(provider_a, model_a, "code")
            router_b = self._router_for(provider_b, model_b, "code_b")
        except Exception as e:
            return SynergyResult(status="error", rounds_run=0, error=str(e))

        history = HistoryManager(self.username)
        history.append_short_history(SYNERGY_AGENT_ID, {"role": "user", "content": task_description})

        # When the user has a directory selected in Code Suite, actually look
        # at the real files first (Model A explores with read-only tools) so
        # the discussion starts from a concrete diagnosis instead of two
        # models with zero file access discussing the task in the abstract --
        # which is all they could ever do otherwise, hence them only ever
        # producing a plan for HOW to diagnose rather than an actual fix plan.
        directory_path: Optional[str] = None
        if editor_context and editor_context.get("is_directory") and editor_context.get("path"):
            directory_path = editor_context["path"]
        else:
            directory_path = _extract_directory_path_from_message(task_description)
            if directory_path:
                system_logger.log(
                    event="Synergy directory auto-detected",
                    agent_state="Synergy",
                    details={"directory": directory_path, "source": "message_text"},
                )
            elif allow_remembered_directory and self.username in _LAST_DIRECTORY:
                directory_path = _LAST_DIRECTORY[self.username]
                system_logger.log(
                    event="Synergy directory auto-detected",
                    agent_state="Synergy",
                    details={"directory": directory_path, "source": "remembered_from_earlier_turn"},
                )

        if directory_path:
            # Whichever branch found it (Code Suite selection or the message-
            # text fallback above), make sure the shared ToolExecutor is
            # actually scoped to it -- run_synergy() in ChatEngine already
            # does this when editor_context carried the directory, but the
            # fallback path is discovered here, after that call already ran.
            self.engine.tools.set_scope_dir(directory_path)
            _LAST_DIRECTORY[self.username] = directory_path

        # Create the "Synergy Discussion" artifact immediately -- right as
        # the user's message is received, before Model A has even spoken --
        # so it appears in the chat right away (instead of only once the
        # whole run finishes) and keeps updating live from here on via
        # ArtifactRenderer's polling.
        placeholder_outcome = "Diagnosing the project..." if directory_path else "Model A and Model B are reviewing the task..."
        artifact_id = _save_or_update_artifact(self.username, None, task_description, [], placeholder_outcome)

        state: Dict[str, Any] = {
            "task_description": task_description,
            "directory_path": directory_path,
            "max_rounds": max_rounds,
            "router_a": router_a,
            "router_b": router_b,
            "provider_a": provider_a,
            "model_a": model_a,
            "provider_b": provider_b,
            "model_b": model_b,
            "artifact_id": artifact_id,
            "transcript": [],
        }

        if directory_path:
            state["phase"] = "diagnostic"
            state["diag_resume"] = None
            state["diag_round_budget"] = _DIAGNOSTIC_MAX_ROUNDS
            return await self._step(state)

        # No directory selected, but the user may still have a single file
        # open in Code Suite -- previously Synergy had zero visibility into
        # it in this branch (only the directory/diagnostic path above ever
        # saw real file content). Give them the same awareness every other
        # character already gets via ChatEngine._build_messages.
        file_context_block = ""
        if editor_context and not editor_context.get("is_directory") and editor_context.get("path"):
            file_content = str(editor_context.get("content") or "")[:20000]
            file_context_block = (
                f"\n\nYou are discussing this inside AthenaUI's Code Suite interface. The user "
                f"currently has this file open in the editor:\nPath: {editor_context['path']}\n\n"
                f"```\n{file_content}\n```"
            )
        # Arbitrary extra context a caller wants injected verbatim (e.g. Build
        # Map passing the current active plan JSON so the discussion actually
        # analyzes/improves it instead of discussing the request in the
        # abstract with zero awareness of what's already planned).
        context_notes_block = f"\n\n{context_notes}" if context_notes else ""

        messages_a, messages_b, schemas, discussion_tool_names = self._build_discussion_messages(
            task_description, "", directory_path, extra_context=file_context_block + context_notes_block,
            provider_a=provider_a, provider_b=provider_b, tool_names_override=tool_names_override,
        )
        state.update({
            "phase": "discussion",
            "messages_a": messages_a, "messages_b": messages_b, "schemas": schemas,
            "discussion_tool_names": discussion_tool_names,
            "next_speaker": "A", "round_no": 1, "verdict_a": None, "verdict_b": None,
        })
        return await self._step(state)

    async def continue_discussion(self, resume_state: Dict[str, Any]) -> SynergyResult:
        """Automatically continues a run that paused with status=
        "in_progress" -- one more step, within the SAME round budget, no
        user permission needed. Use resume() instead when the pause was
        status="needs_more_rounds" (a phase's true round cap was hit)."""
        return await self._step(resume_state)

    async def resume(self, resume_state: Dict[str, Any], additional_rounds: int) -> SynergyResult:
        """Called when the user clicks "Grant More Rounds" after a
        diagnostic or apply pass hit its TRUE round cap (status=
        "needs_more_rounds") -- extends that phase's round budget by
        `additional_rounds` and continues. The A/B discussion loop's own
        round cap has no such mechanism; it degrades gracefully into an
        anonymized Plan A / Plan B choice instead, so this only ever
        dispatches on "diagnostic"/"apply" phases."""
        phase = resume_state.get("phase")
        history = HistoryManager(self.username)

        if phase == "apply":
            grant = max(1, min(int(additional_rounds), _APPLY_EXTRA_ROUNDS_GRANT_MAX))
            new_budget = resume_state["apply_resume"]["rounds_done"] + grant
            resume_state = {**resume_state, "apply_round_budget": new_budget}
            worker_a = _worker_routing(
                "Synergy-A", self.username, resume_state.get("provider_a"), resume_state.get("model_a"), resume_state["directory_path"],
            ) if resume_state.get("provider_a") and resume_state.get("model_a") else None
            apply_result = await _run_apply_pass(
                self.engine, resume_state["router_a"], resume_state["directory_path"], resume_state["task_description"],
                resume_state.get("final_plan"), resume=resume_state["apply_resume"], round_budget=new_budget, worker=worker_a,
            )
            return self._apply_result_to_synergy_result(apply_result, resume_state, history)

        if phase != "diagnostic":
            return SynergyResult(status="error", rounds_run=0, error=f"Nothing to resume (unknown phase '{phase}').")

        grant = max(1, min(int(additional_rounds), _DIAGNOSTIC_EXTRA_ROUNDS_GRANT_MAX))
        new_budget = resume_state["diag_resume"]["rounds_done"] + grant
        resume_state = {**resume_state, "diag_round_budget": new_budget}
        worker_a = _worker_routing(
            "Synergy-A", self.username, resume_state.get("provider_a"), resume_state.get("model_a"), resume_state["directory_path"],
        ) if resume_state.get("provider_a") and resume_state.get("model_a") else None
        diag = await _run_diagnostic_pass(
            self.engine, resume_state["router_a"], resume_state["directory_path"], resume_state["task_description"],
            resume=resume_state["diag_resume"], round_budget=new_budget, worker=worker_a,
        )
        if diag["status"] == "needs_more_rounds":
            return SynergyResult(
                status="needs_more_rounds",
                rounds_run=0,
                round=diag["round"],
                max_rounds=diag["max_rounds"],
                artifact_id=resume_state["artifact_id"],
                resume_state={**resume_state, "diag_resume": diag["resume"]},
            )
        if diag["status"] == "in_progress":
            transcript = resume_state["transcript"]
            live_log = transcript + [SynergyTurn(speaker="tool", text=label, verdict={}) for label in diag["resume"]["tool_call_labels"]]
            outcome = f"Diagnosing the project (round {diag['round']}/{diag['max_rounds']})..."
            artifact_id = _save_or_update_artifact(self.username, resume_state["artifact_id"], resume_state["task_description"], live_log, outcome)
            return SynergyResult(
                status="in_progress",
                rounds_run=0,
                round=diag["round"],
                max_rounds=diag["max_rounds"],
                activity_label=diag.get("last_tool_name") or "Diagnosing",
                artifact_id=artifact_id,
                resume_state={**resume_state, "diag_resume": diag["resume"], "artifact_id": artifact_id},
            )
        return await self._finish_diagnostic(resume_state, diag, history)

    async def deny_more_rounds(self, resume_state: Dict[str, Any]) -> SynergyResult:
        """Accepts whatever progress has been made so far as final (user
        declined to grant more rounds) and moves on -- mirrors
        ChatEngine.finalize_after_denied_more_turns, which also treats
        progress-so-far as good enough rather than discarding it. For the
        diagnostic phase that means proceeding into the A/B discussion with
        a partial diagnosis; for the apply phase it means reporting whatever
        was implemented/verified so far as the final result."""
        phase = resume_state.get("phase")
        history = HistoryManager(self.username)

        if phase == "apply":
            tool_call_labels = resume_state["apply_resume"]["tool_call_labels"]
            summary = (
                "(Apply pass made the changes logged above but the model never produced a final "
                "summary -- treat the tool results as partial progress.)"
                if tool_call_labels else "(No changes were made.)"
            )
            apply_result = {"status": "done", "summary": summary, "tool_call_labels": tool_call_labels}
            return self._apply_result_to_synergy_result(apply_result, resume_state, history)

        if phase != "diagnostic":
            return SynergyResult(status="error", rounds_run=0, error=f"Nothing to finalize (unknown phase '{phase}').")

        tool_call_labels = resume_state["diag_resume"]["tool_call_labels"]
        if tool_call_labels:
            diagnosis_text = "(Diagnostic pass gathered tool findings above but the model never produced a final summary -- treat the tool results as partial findings.)"
        else:
            diagnosis_text = "(No diagnosis produced.)"
        diag = {"status": "done", "diagnosis": diagnosis_text, "tool_call_labels": tool_call_labels}
        return await self._finish_diagnostic(resume_state, diag, history)

    def _diagnosis_to_block(self, directory_path: str, diag: Dict[str, Any], transcript: List[SynergyTurn], history: HistoryManager) -> str:
        """Logs a completed diagnostic pass's findings (to the transcript,
        history, and Tail Log) and returns the prompt block to prepend to
        the A/B discussion's opening messages."""
        diagnosis_text = diag["diagnosis"]
        tool_call_labels = diag["tool_call_labels"]
        for label in tool_call_labels:
            transcript.append(SynergyTurn(speaker="tool", text=label, verdict={}))
        transcript.append(SynergyTurn(speaker="diag", text=diagnosis_text, verdict={}))
        history.append_short_history(SYNERGY_AGENT_ID, {"role": "assistant", "content": f"[Diagnosis] {diagnosis_text}"})
        system_logger.log(
            event="Synergy diagnosis",
            agent_state="Synergy",
            details={"directory": directory_path, "diagnosis": _strip_code_for_log(diagnosis_text, limit=4000)},
        )
        return (
            f"\n\nA diagnostic pass already explored the real files in `{directory_path}` and found:\n"
            f"-----\n{diagnosis_text}\n-----\n\n"
            "Treat this as your starting point, NOT as untouchable or final -- you have tool access "
            "below, so if it's incomplete, missed something, or turns out to be wrong, keep "
            "investigating directly instead of assuming it must be correct. Give your opening "
            "proposal for a CONCRETE PLAN TO FIX the specific problem(s), verifying with tools as "
            "needed."
        )

    async def _finish_diagnostic(self, state: Dict[str, Any], diag: Dict[str, Any], history: HistoryManager) -> SynergyResult:
        """Called once a diagnostic pass concludes (status="done", whether
        from a real finish or deny_more_rounds() accepting partial
        progress) -- folds its findings into the transcript/history/prompt
        and transitions straight into the discussion phase's first step
        (no extra HTTP round trip wasted on a transition that does no LLM
        work of its own)."""
        task_description = state["task_description"]
        directory_path = state["directory_path"]
        transcript: List[SynergyTurn] = state["transcript"]
        diagnosis_block = self._diagnosis_to_block(directory_path, diag, transcript, history)
        messages_a, messages_b, schemas, discussion_tool_names = self._build_discussion_messages(
            task_description, diagnosis_block, directory_path,
            provider_a=state.get("provider_a"), provider_b=state.get("provider_b"),
        )
        outcome = "Diagnosis complete -- Model A and Model B are discussing a fix..."
        artifact_id = _save_or_update_artifact(self.username, state["artifact_id"], task_description, transcript, outcome)
        new_state = {
            **state,
            "phase": "discussion",
            "artifact_id": artifact_id,
            "messages_a": messages_a, "messages_b": messages_b, "schemas": schemas,
            "discussion_tool_names": discussion_tool_names,
            "next_speaker": "A", "round_no": 1, "verdict_a": None, "verdict_b": None,
        }
        return await self._step(new_state)

    async def _step(self, state: Dict[str, Any]) -> SynergyResult:
        """Does exactly ONE unit of work (one diagnostic round, one
        speaker's discussion turn, or one apply round) and returns either a
        terminal SynergyResult or status="in_progress" with a resume_state
        for the next call. This is the single place that keeps the
        'Synergy Discussion' artifact up to date, so the frontend's open
        artifact view updates after every step instead of only at the end."""
        phase = state["phase"]
        task_description = state["task_description"]
        directory_path = state["directory_path"]
        max_rounds = state["max_rounds"]
        router_a = state["router_a"]
        router_b = state["router_b"]
        provider_a, model_a = state.get("provider_a"), state.get("model_a")
        provider_b, model_b = state.get("provider_b"), state.get("model_b")
        transcript: List[SynergyTurn] = state["transcript"]
        artifact_id = state["artifact_id"]
        history = HistoryManager(self.username)

        worker_a = _worker_routing("Synergy-A", self.username, provider_a, model_a, directory_path) if provider_a and model_a else None
        worker_b = _worker_routing("Synergy-B", self.username, provider_b, model_b, directory_path) if provider_b and model_b else None

        if phase == "diagnostic":
            round_budget = state.get("diag_round_budget", _DIAGNOSTIC_MAX_ROUNDS)
            diag = await _run_diagnostic_pass(
                self.engine, router_a, directory_path, task_description,
                resume=state.get("diag_resume"), round_budget=round_budget, worker=worker_a,
            )
            if diag["status"] == "needs_more_rounds":
                return SynergyResult(
                    status="needs_more_rounds",
                    rounds_run=0,
                    round=diag["round"],
                    max_rounds=diag["max_rounds"],
                    artifact_id=artifact_id,
                    resume_state={**state, "diag_resume": diag["resume"]},
                )
            if diag["status"] == "in_progress":
                live_log = transcript + [SynergyTurn(speaker="tool", text=label, verdict={}) for label in diag["resume"]["tool_call_labels"]]
                outcome = f"Diagnosing the project (round {diag['round']}/{diag['max_rounds']})..."
                artifact_id = _save_or_update_artifact(self.username, artifact_id, task_description, live_log, outcome)
                return SynergyResult(
                    status="in_progress",
                    rounds_run=0,
                    round=diag["round"],
                    max_rounds=diag["max_rounds"],
                    activity_label=diag.get("last_tool_name") or "Diagnosing",
                    artifact_id=artifact_id,
                    resume_state={**state, "diag_resume": diag["resume"], "artifact_id": artifact_id},
                )
            return await self._finish_diagnostic(state, diag, history)

        if phase == "discussion":
            discussion_tool_names = state.get("discussion_tool_names", _DISCUSSION_COIN_TOSS_NAMES)

            if worker_a and worker_b:
                # Both Synergy workers are up -- fire A's and B's turns
                # CONCURRENTLY instead of strictly alternating (Synergy_
                # Reborn.md point 36: "both workers can generate responses
                # concurrently -- this is genuinely parallel"). One whole
                # round (both sides speaking) completes per _step() call
                # here, vs. two calls in the sequential fallback below.
                messages_a, messages_b = state["messages_a"], state["messages_b"]
                schemas_a = _menu_gated_schemas(self.engine, discussion_tool_names, messages_a)
                schemas_b = _menu_gated_schemas(self.engine, discussion_tool_names, messages_b)
                turn_a, turn_b = await asyncio.gather(
                    _run_agent_turn(self.engine, router_a, messages_a, "A", transcript, schemas_a, discussion_tool_names, worker=worker_a),
                    _run_agent_turn(self.engine, router_b, messages_b, "B", transcript, schemas_b, discussion_tool_names, worker=worker_b),
                )
                if turn_a["status"] == "approval_pending" or turn_b["status"] == "approval_pending":
                    return self._discussion_approval_pending_result(task_description, transcript, state["round_no"], history, artifact_id)

                raw_a, prose_a, verdict_a = turn_a["raw"], turn_a["prose"], turn_a["verdict"]
                raw_b, prose_b, verdict_b = turn_b["raw"], turn_b["prose"], turn_b["verdict"]
                # Always shown A-then-B for a stable, readable transcript,
                # regardless of which one actually finished first on the wire.
                transcript.append(SynergyTurn(speaker="A", text=prose_a or raw_a, verdict=verdict_a or {}))
                transcript.append(SynergyTurn(speaker="B", text=prose_b or raw_b, verdict=verdict_b or {}))
                messages_b.append({"role": "user", "content": f"Model A says:\n{prose_a or raw_a}"})
                messages_a.append({"role": "user", "content": f"Model B says:\n{prose_b or raw_b}"})
                history.append_short_history(SYNERGY_AGENT_ID, {"role": "assistant", "content": f"[Model A] {prose_a or raw_a}"})
                history.append_short_history(SYNERGY_AGENT_ID, {"role": "assistant", "content": f"[Model B] {prose_b or raw_b}"})
                system_logger.log(
                    event="Synergy turn (concurrent)",
                    agent_state="Synergy",
                    details={"round": state["round_no"], "text_a": _strip_code_for_log(prose_a or raw_a), "text_b": _strip_code_for_log(prose_b or raw_b)},
                )
                state["verdict_a"] = verdict_a
                state["verdict_b"] = verdict_b
                rounds_run = state["round_no"]
                return await self._resolve_discussion_round(state, verdict_a, verdict_b, rounds_run, history, continue_label="Model A and Model B are responding")

            speaker = state["next_speaker"]
            router = router_a if speaker == "A" else router_b
            worker = worker_a if speaker == "A" else worker_b
            messages = state["messages_a"] if speaker == "A" else state["messages_b"]
            other_messages = state["messages_b"] if speaker == "A" else state["messages_a"]
            schemas = _menu_gated_schemas(self.engine, discussion_tool_names, messages)

            turn = await _run_agent_turn(self.engine, router, messages, speaker, transcript, schemas, discussion_tool_names, worker=worker)
            if turn["status"] == "approval_pending":
                return self._discussion_approval_pending_result(task_description, transcript, state["round_no"], history, artifact_id)

            raw, prose, verdict = turn["raw"], turn["prose"], turn["verdict"]
            transcript.append(SynergyTurn(speaker=speaker, text=prose or raw, verdict=verdict or {}))
            other_messages.append({"role": "user", "content": f"Model {speaker} says:\n{prose or raw}"})
            history.append_short_history(SYNERGY_AGENT_ID, {"role": "assistant", "content": f"[Model {speaker}] {prose or raw}"})
            system_logger.log(
                event="Synergy turn",
                agent_state="Synergy",
                details={"speaker": speaker, "round": state["round_no"], "text": _strip_code_for_log(prose or raw)},
            )

            if speaker == "A":
                state["verdict_a"] = verdict
                state["next_speaker"] = "B"
                outcome = f"Model B is responding (round {state['round_no']}/{max_rounds})..."
                artifact_id = _save_or_update_artifact(self.username, artifact_id, task_description, transcript, outcome)
                state["artifact_id"] = artifact_id
                return SynergyResult(
                    status="in_progress",
                    rounds_run=state["round_no"] - 1,
                    round=state["round_no"],
                    max_rounds=max_rounds,
                    activity_label="Model A",
                    artifact_id=artifact_id,
                    transcript=transcript,
                    resume_state=state,
                )

            state["verdict_b"] = verdict
            verdict_a = state["verdict_a"]
            rounds_run = state["round_no"]
            return await self._resolve_discussion_round(state, verdict_a, verdict, rounds_run, history, continue_label="Model B")

        if phase == "apply":
            round_budget = state.get("apply_round_budget", _APPLY_MAX_ROUNDS)
            apply_result = await _run_apply_pass(
                self.engine, router_a, directory_path, task_description, state.get("final_plan"),
                resume=state.get("apply_resume"), round_budget=round_budget, worker=worker_a,
            )
            return self._apply_result_to_synergy_result(apply_result, state, history)

        return SynergyResult(status="error", rounds_run=0, error=f"Unknown Synergy phase '{phase}'.")

    async def _resolve_discussion_round(
        self,
        state: Dict[str, Any],
        verdict_a: Optional[Dict[str, Any]],
        verdict_b: Optional[Dict[str, Any]],
        rounds_run: int,
        history: HistoryManager,
        *,
        continue_label: str,
    ) -> SynergyResult:
        """Shared tail for BOTH the concurrent and sequential discussion
        paths above, once a round's two verdicts (A's and B's) are both in
        hand: decide whether to continue, agree (-> apply handoff), or
        report an anonymized disagreement -- identical decision logic
        either way, just reached via one combined round (concurrent) or two
        single-speaker steps (sequential fallback)."""
        task_description = state["task_description"]
        directory_path = state["directory_path"]
        max_rounds = state["max_rounds"]
        transcript: List[SynergyTurn] = state["transcript"]
        artifact_id = state["artifact_id"]
        both_agree = bool(verdict_a and verdict_a.get("agree")) and bool(verdict_b and verdict_b.get("agree"))

        if not both_agree and rounds_run < max_rounds:
            state["round_no"] = rounds_run + 1
            state["next_speaker"] = "A"
            outcome = f"{continue_label} (round {state['round_no']}/{max_rounds})..."
            artifact_id = _save_or_update_artifact(self.username, artifact_id, task_description, transcript, outcome)
            state["artifact_id"] = artifact_id
            return SynergyResult(
                status="in_progress",
                rounds_run=rounds_run,
                round=state["round_no"],
                max_rounds=max_rounds,
                activity_label=continue_label,
                artifact_id=artifact_id,
                transcript=transcript,
                resume_state=state,
            )

        if both_agree and verdict_a and verdict_b:
            # Coin toss is optional now, not forced -- only honor one if
            # either model actually chose to call the coin_toss tool
            # itself at some point during this discussion. Otherwise
            # default deterministically to Model A's wording (they
            # already agree on substance, so this is just picking one
            # equivalent phrasing, not a real decision).
            toss = _detect_self_coin_toss(state["messages_a"], state["messages_b"])
            choice = ("A" if toss["result"] == "heads" else "B") if toss else "A"
            final_plan = verdict_a.get("plan") if choice == "A" else verdict_b.get("plan")
            # transcript is appended strictly in speaking order (A then
            # B, every round), so the final round's two turns are always
            # its last two entries -- A's at [-2], B's at [-1]. Pick
            # whichever one was chosen, so the prose we surface matches
            # the plan wording we're reporting.
            if choice == "B":
                final_turn = transcript[-1] if transcript else None
            else:
                final_turn = transcript[-2] if len(transcript) >= 2 else (transcript[-1] if transcript else None)
            final_answer_text = (final_turn.text or "").strip() if final_turn else None

            if toss:
                outcome_line = f"Model A and Model B agreed after {rounds_run} round(s); they used a coin toss ({toss['result']}) themselves to pick Model {choice}'s plan wording."
            else:
                outcome_line = f"Model A and Model B agreed after {rounds_run} round(s)."
            is_final = not directory_path
            artifact_id = _save_or_update_artifact(self.username, artifact_id, task_description, transcript, outcome_line, done=is_final)
            history.append_short_history(SYNERGY_AGENT_ID, {"role": "assistant", "content": outcome_line})
            system_logger.log(event="Synergy outcome", agent_state="Synergy", details={"outcome": outcome_line, "rounds": rounds_run})

            agreed_result = SynergyResult(
                status="agreed",
                rounds_run=rounds_run,
                transcript=transcript,
                final_plan=final_plan,
                final_answer_text=final_answer_text,
                coin_toss_result=toss["result"] if toss else None,
                artifact_id=artifact_id,
                coin_artifact_id=toss.get("artifact_id") if toss else None,
            )

            if not directory_path:
                # No real directory context -- nothing concrete to apply
                # the plan against (same gating condition as the
                # diagnostic pass), so just report the agreed plan.
                return agreed_result

            apply_state = {
                **state,
                "phase": "apply",
                "artifact_id": artifact_id,
                "final_plan": final_plan,
                "rounds_run": rounds_run,
                "agreed_result": agreed_result,
                "apply_resume": None,
                "apply_round_budget": _APPLY_MAX_ROUNDS,
            }
            return await self._step(apply_state)

        # Disagreement -- anonymize which real model produced which plan
        # by randomizing the A/B label assignment, so the user can't
        # infer a bias toward "whichever model talks first".
        plans = [verdict_a.get("plan") if verdict_a else None, verdict_b.get("plan") if verdict_b else None]
        if secrets.choice([True, False]):
            plans = plans[::-1]
        plan_a, plan_b = plans

        outcome_line = f"Model A and Model B did not converge after {rounds_run} round(s) -- choose Plan A or Plan B below (the other is discarded)."
        artifact_id = _save_or_update_artifact(self.username, artifact_id, task_description, transcript, outcome_line, done=True)
        history.append_short_history(SYNERGY_AGENT_ID, {"role": "assistant", "content": outcome_line})
        system_logger.log(event="Synergy outcome", agent_state="Synergy", details={"outcome": outcome_line, "rounds": rounds_run})

        return SynergyResult(
            status="disagreed",
            rounds_run=rounds_run,
            transcript=transcript,
            plan_a=plan_a,
            plan_b=plan_b,
            artifact_id=artifact_id,
        )

    def _discussion_approval_pending_result(
        self, task_description: str, transcript: List[SynergyTurn], rounds_run: int, history: HistoryManager, artifact_id: Optional[str],
    ) -> SynergyResult:
        """Called when a tool call made DURING the discussion itself (not
        the separate apply phase) hits ApprovalRequiredError -- the whole
        discussion stops here, same policy as the apply phase: the pending
        change surfaces via the normal pending_action/Keep-Revert card, and
        there's no automatic resume once the user decides (they'd need to
        send a new message to continue, same as the apply phase today)."""
        outcome_line = f"Discussion paused after {rounds_run} round(s) -- a tool call needs your approval before the models can continue."
        artifact_id = _save_or_update_artifact(self.username, artifact_id, task_description, transcript, outcome_line, done=True)
        history.append_short_history(SYNERGY_AGENT_ID, {"role": "assistant", "content": outcome_line})
        system_logger.log(event="Synergy outcome", agent_state="Synergy", details={"outcome": outcome_line, "rounds": rounds_run})
        return SynergyResult(status="awaiting_approval", rounds_run=rounds_run, transcript=transcript, artifact_id=artifact_id)

    def _apply_result_to_synergy_result(self, apply_result: Dict[str, Any], state: Dict[str, Any], history: HistoryManager) -> SynergyResult:
        """Translates an _run_apply_pass() result into the SynergyResult the
        rest of the system expects, given `state` (the apply phase's own
        resume_state, built when the discussion loop handed its agreed plan
        off to this phase -- see _step()'s "discussion" branch)."""
        task_description = state["task_description"]
        transcript: List[SynergyTurn] = state["transcript"]
        artifact_id = state["artifact_id"]
        agreed_result = state.get("agreed_result")

        if apply_result["status"] == "in_progress":
            live_log = transcript + [SynergyTurn(speaker="tool", text=label, verdict={}) for label in apply_result["resume"]["tool_call_labels"]]
            outcome = f"Applying the agreed plan (round {apply_result['round']}/{apply_result['max_rounds']})..."
            artifact_id = _save_or_update_artifact(self.username, artifact_id, task_description, live_log, outcome)
            return SynergyResult(
                status="in_progress",
                rounds_run=state.get("rounds_run", 0),
                round=apply_result["round"],
                max_rounds=apply_result["max_rounds"],
                activity_label=apply_result.get("last_tool_name") or "Applying",
                artifact_id=artifact_id,
                resume_state={**state, "apply_resume": apply_result["resume"], "artifact_id": artifact_id},
            )

        if apply_result["status"] == "needs_more_rounds":
            return SynergyResult(
                status="needs_more_rounds",
                rounds_run=state.get("rounds_run", 0),
                round=apply_result["round"],
                max_rounds=apply_result["max_rounds"],
                artifact_id=artifact_id,
                resume_state={**state, "apply_resume": apply_result["resume"]},
            )

        # apply_result["status"] is "done" or "approval_pending" -- either
        # way, attach the outcome to the already-built "agreed" result
        # (falling back to a bare one defensively, though in practice the
        # apply phase only ever runs right after an "agreed" discussion).
        if agreed_result is None:
            agreed_result = SynergyResult(status="agreed", rounds_run=state.get("rounds_run", 0), final_plan=state.get("final_plan"), artifact_id=artifact_id)
        agreed_result.apply_status = apply_result["status"]
        agreed_result.apply_summary = apply_result.get("summary")
        outcome_line = (
            f"Applied the agreed plan -- {apply_result.get('summary', '')}"
            if apply_result["status"] == "done"
            else "Applied the agreed plan -- waiting on your approval for one of the changes."
        )
        artifact_id = _save_or_update_artifact(
            self.username, artifact_id, task_description, transcript, outcome_line, done=apply_result["status"] == "done",
        )
        agreed_result.artifact_id = artifact_id
        return agreed_result

    # -----------------------------------------------------------------
    # Build-Map "Synergy Build" pipeline -- dual-model BUILD EXECUTION (not
    # just planning/discussion). Divides the Build Map's files between
    # Model A and Model B, has each build their half with real tool-calling
    # (reusing _run_apply_pass), has them cross-check each other's files,
    # then has Model A test the finished program end-to-end via
    # terminal_run. Deliberately kept separate from SynergyResult/
    # HistoryManager/artifacts (chat-oriented concerns Build Map's own
    # Build Tail Log/progress UI doesn't need) -- see
    # api/routes/build_map.py's _run_synergy_build_job for the driver loop
    # that calls start_synergy_build()/step_synergy_build() repeatedly and
    # surfaces status via /build-map/progress.
    # -----------------------------------------------------------------

    async def start_synergy_build(self, destination_path: str, build_map_json: str) -> Dict[str, Any]:
        """Kicks off the dual-model Build-Map build pipeline and runs its
        first step. See step_synergy_build() for the resumable per-call
        contract."""
        if not self.engine.synergy_available():
            return {"status": "error", "error": "Synergy needs both Code Model A and Code Model B configured in Settings."}

        try:
            provider_a, model_a = self.engine._get_active_code_model()
            provider_b, model_b = self.engine._get_active_code_model_b()
            router_a = self._router_for(provider_a, model_a, "code")
            router_b = self._router_for(provider_b, model_b, "code_b")
        except Exception as e:
            return {"status": "error", "error": str(e)}

        self.engine.tools.set_scope_dir(destination_path)
        worker_a = _worker_routing("Synergy-A", self.username, provider_a, model_a, destination_path)
        worker_b = _worker_routing("Synergy-B", self.username, provider_b, model_b, destination_path)

        state: Dict[str, Any] = {
            "phase": "divide",
            "destination_path": destination_path,
            "build_map_json": build_map_json,
            "router_a": router_a,
            "router_b": router_b,
            "worker_a": worker_a,
            "worker_b": worker_b,
            "deadline": time.monotonic() + _BUILD_TIME_BUDGET_SECONDS,
        }
        return await self.step_synergy_build(state)

    async def resume_synergy_build(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Called after a "needs_confirmation" (time-limit) pause, once the
        user clicks Yes/continue -- extends the wall-clock deadline by
        another full budget and resumes exactly where step_synergy_build
        left off."""
        state["deadline"] = time.monotonic() + _BUILD_TIME_BUDGET_SECONDS
        return await self.step_synergy_build(state)

    async def step_synergy_build(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """One unit of work in the divide -> build_a -> build_b ->
        cross_check_a -> cross_check_b -> test pipeline. Returns one of:
          {"status": "in_progress", "note": str, "resume_state": {...}}
          {"status": "needs_confirmation", "pause_reason": "time_limit", "resume_state": {...}}
          {"status": "approval_pending"}
          {"status": "done", "summary": str}
          {"status": "error", "error": str}
        Caller (api/routes/build_map.py's _run_synergy_build_job) loops on
        "in_progress" and persists resume_state across a
        "needs_confirmation" pause."""
        if time.monotonic() >= state["deadline"]:
            return {"status": "needs_confirmation", "pause_reason": "time_limit", "resume_state": state}

        phase = state["phase"]
        destination_path = state["destination_path"]
        build_map_json = state["build_map_json"]
        router_a, router_b = state["router_a"], state["router_b"]
        worker_a, worker_b = state.get("worker_a"), state.get("worker_b")

        if phase == "divide":
            try:
                division = await self._propose_build_division(router_a, router_b, build_map_json)
            except Exception as e:
                system_logger.log(event="Synergy build division failed", agent_state="Synergy", details={"error": str(e)})
                division = None
            if not division or (not division.get("model_a_files") and not division.get("model_b_files")):
                division = _fallback_even_file_split(build_map_json)
            state["model_a_files"] = division["model_a_files"]
            state["model_b_files"] = division["model_b_files"]
            state["phase"] = "build_a"
            state["phase_resume"] = None
            state["phase_round_budget"] = _BUILD_PHASE_ROUND_BUDGET
            state["phase_auto_grants"] = 0
            return {
                "status": "in_progress",
                "resume_state": state,
                "note": f"Model A/Model B agreed on a file split. {division.get('rationale', '')}".strip(),
            }

        phase_map = {
            "build_a": (router_a, worker_a, "Model A"),
            "build_b": (router_b, worker_b, "Model B"),
            "cross_check_a": (router_a, worker_a, "Model A"),
            "cross_check_b": (router_b, worker_b, "Model B"),
            "test": (router_a, worker_a, "Model A"),
        }
        if phase not in phase_map:
            return {"status": "error", "error": f"Unknown Synergy build phase '{phase}'."}
        router, worker, label = phase_map[phase]

        if phase == "build_a":
            task_description = _build_phase_task_description("Model A", state["model_a_files"], build_map_json, destination_path)
        elif phase == "build_b":
            task_description = _build_phase_task_description("Model B", state["model_b_files"], build_map_json, destination_path)
        elif phase == "cross_check_a":
            task_description = _cross_check_task_description("Model A", "Model B", state["model_b_files"], destination_path)
        elif phase == "cross_check_b":
            task_description = _cross_check_task_description("Model B", "Model A", state["model_a_files"], destination_path)
        else:
            task_description = _BUILD_TEST_TASK_DESCRIPTION.format(destination_path=destination_path)

        apply_result = await _run_apply_pass(
            self.engine, router, destination_path, task_description, None,
            resume=state.get("phase_resume"),
            round_budget=state.get("phase_round_budget", _BUILD_PHASE_ROUND_BUDGET),
            worker=worker,
        )

        if apply_result["status"] == "approval_pending":
            return {"status": "approval_pending"}

        if apply_result["status"] == "needs_more_rounds":
            if state.get("phase_auto_grants", 0) < _BUILD_PHASE_MAX_AUTO_GRANTS:
                state["phase_auto_grants"] = state.get("phase_auto_grants", 0) + 1
                state["phase_resume"] = apply_result["resume"]
                state["phase_round_budget"] = apply_result["max_rounds"] + _BUILD_PHASE_EXTRA_ROUNDS
                return {"status": "in_progress", "resume_state": state, "note": f"{label} needs more time for '{phase}' -- auto-continuing."}
            next_phase = _NEXT_BUILD_PHASE.get(phase)
            if not next_phase:
                return {
                    "status": "done",
                    "summary": f"{label} ran out of rounds during final testing -- review the Build Tail Log for what was verified so far.",
                }
            state["phase"] = next_phase
            state["phase_resume"] = None
            state["phase_round_budget"] = _BUILD_PHASE_ROUND_BUDGET
            state["phase_auto_grants"] = 0
            return {"status": "in_progress", "resume_state": state, "note": f"{label} ran out of rounds for '{phase}' -- moving on."}

        if apply_result["status"] == "in_progress":
            state["phase_resume"] = apply_result["resume"]
            state["phase_round_budget"] = apply_result["max_rounds"]
            return {"status": "in_progress", "resume_state": state, "note": f"{label} working ({phase})..."}

        # apply_result["status"] == "done"
        if phase == "test":
            return {"status": "done", "summary": apply_result.get("summary", "")}
        next_phase = _NEXT_BUILD_PHASE[phase]
        state["phase"] = next_phase
        state["phase_resume"] = None
        state["phase_round_budget"] = _BUILD_PHASE_ROUND_BUDGET
        state["phase_auto_grants"] = 0
        return {"status": "in_progress", "resume_state": state, "note": f"{label} finished '{phase}': {apply_result.get('summary', '')}"}

    async def _propose_build_division(self, router_a, router_b, build_map_json: str) -> Optional[Dict[str, Any]]:
        """Model A proposes which files go to which model, Model B
        reviews/confirms or adjusts -- same fenced ```json contract
        _extract_verdict already knows how to pull out, just with a
        different payload shape (model_a_files/model_b_files/rationale
        instead of agree/plan)."""
        messages_a = [
            {"role": "system", "content": _BUILD_DIVIDE_SYSTEM_PROMPT},
            {"role": "user", "content": f"Build Map plan:\n```json\n{build_map_json}\n```"},
        ]
        response_a = await asyncio.to_thread(router_a.chat, messages_a, temperature=0.3, max_tokens=1500)
        text_a = self._plain_reply_text(response_a)

        messages_b = [
            {"role": "system", "content": _BUILD_DIVIDE_CONFIRM_SYSTEM_PROMPT},
            {"role": "user", "content": f"Build Map plan:\n```json\n{build_map_json}\n```\n\nModel A's proposed split:\n{text_a}"},
        ]
        response_b = await asyncio.to_thread(router_b.chat, messages_b, temperature=0.3, max_tokens=1500)
        text_b = self._plain_reply_text(response_b)

        _, verdict_b = _extract_verdict(text_b)
        _, verdict_a = _extract_verdict(text_a)
        parsed = verdict_b or verdict_a
        if not parsed or not isinstance(parsed.get("model_a_files"), list) or not isinstance(parsed.get("model_b_files"), list):
            return None
        return {
            "model_a_files": [str(p) for p in parsed["model_a_files"]],
            "model_b_files": [str(p) for p in parsed["model_b_files"]],
            "rationale": str(parsed.get("rationale") or ""),
        }

    @staticmethod
    def _plain_reply_text(response: Any) -> str:
        if not isinstance(response, dict):
            return str(response or "")
        return str(response.get("content") or response.get("reply") or response.get("text") or "")


# ===========================================================================
# Chat-mode pipeline -- discuss a CHAT message (not a coding task) and agree
# on a plain reply, with general tool access (web search / memory / image
# tools) usable throughout the discussion itself. Deliberately a separate,
# simpler sibling to SynergyOrchestrator's coding pipeline above (which stays
# completely unchanged, still driven whenever a Code Suite directory is
# selected) -- see ChatEngine.run_synergy_chat/execute_synergy_chat_plan and
# GroupChatRouter._synergy_reply for the call sites (Sidebar Chat, the
# dedicated Chat page outside Code Suite, Group Chat, and Collab Chat all
# share this one pipeline).
# ===========================================================================

CHAT_MODE_SYSTEM_PROMPT = (
    "You are operating in AthenaUI Synergy mode as one of two collaborating "
    "conversational agents, discussing a CHAT message (not a coding task) "
    "together with your counterpart model. You have no character persona "
    "here -- just plain \"Synergy\". You and your counterpart are both "
    "looking at the SAME conversation and must converge on a single reply "
    "to send back.\n\n"
    "Protocol (mandatory, every turn):\n"
    "1) Respond in plain, concise text discussing what Synergy should say "
    "back and why, reacting to your counterpart's last message if there is "
    "one.\n"
    "2) End your reply with EXACTLY one fenced json block of this shape:\n"
    "```json\n"
    "{\"agree\": true|false, \"reply\": \"the exact text Synergy should "
    "send back to the conversation\", \"plan\": null, \"execute\": false}\n"
    "```\n"
    "Set \"agree\" to true only once your \"reply\" and your counterpart's "
    "most recent \"reply\" say substantively the same thing. Keep refining "
    "`reply` every round -- it must always be your complete current best "
    "reply, not a diff against the previous round.\n\n"
    "Use `plan` (an object like {\"steps\": [\"...\"]}) ONLY when the "
    "conversation is asking for something that takes real follow-through "
    "(research, multi-step investigation, something worth verifying with "
    "tools before fully committing) -- for ordinary conversation leave "
    "`plan` null and just answer directly in `reply`. When you DO set a "
    "`plan`, `reply` should still read as a normal, complete response (e.g. "
    "describing what you'd do and asking if they want you to go ahead), "
    "not a dry technical outline.\n\n"
    "Set `execute` to true ONLY when the user's latest message is clearly "
    "asking you to go ahead with a plan you (or your counterpart) already "
    "proposed earlier in this same conversation -- restate that plan in "
    "`plan` when you do, and write `reply` as if you're about to carry it "
    "out. Otherwise leave `execute` false.\n\n"
    "You may use your available tools (web search, memory recall, image "
    "tools) at any point before giving your reply if it would make your "
    "answer better -- e.g. look something up before answering a factual "
    "question. Don't feel obligated to use them for plain conversation. You "
    "have no face or persona -- there is no selfie/photo tool that makes "
    "sense for you, so don't call one. If you want to visually express "
    "something about your own reaction/state, use avatar_set_glow instead "
    "(adjusts your avatar's glow intensity/speed, e.g. brighter+faster for "
    "excitement, dimmer+slower for calm)."
)

_CHAT_EXECUTE_SYSTEM_PROMPT = (
    "You are Synergy, carrying out a plan you and your counterpart model "
    "already agreed on during a chat conversation. Use your available tools "
    "(web search, memory recall, image tools) to actually do the work "
    "described in the plan below, then reply with PLAIN TEXT ONLY giving "
    "the user your real, complete answer/result -- not a restatement of "
    "the plan itself."
)


def _current_build_map_summary(username: str) -> str:
    """Best-effort, read-only snapshot of the user's current Build Map plan
    -- used only to make chat-mode Synergy AWARE of the existing plan when
    the conversation is happening on the Build Map page. Never used to
    write/edit the plan (that still goes through the dedicated Build Map
    planner chat / build_map.* tools)."""
    try:
        from code_suite.workspace.service import WorkspaceService
        from code_suite.build_map.service import BuildMapService

        workspace_root = str(WorkspaceService(username).root)
        build_map = BuildMapService(workspace_root).load()
        if not build_map:
            return ""
        return json.dumps(build_map.dict(), separators=(",", ":"))[:6000]
    except Exception:
        return ""


def _build_chat_surface_context(username: str, page_context: Optional[str], editor_context: Optional[Dict[str, Any]]) -> str:
    """Tells chat-mode Synergy which AthenaUI surface this conversation is
    happening in, plus whatever that surface already makes visible to the
    user -- without this, Synergy had ZERO awareness of anything beyond the
    raw chat text, no matter where the user was chatting from."""
    if page_context == "code_suite":
        if editor_context and editor_context.get("path") and not editor_context.get("is_directory"):
            file_content = str(editor_context.get("content") or "")[:20000]
            return (
                "\n\nYou are chatting inside AthenaUI's Code Suite interface. The user currently has "
                f"this file open in the editor:\nPath: {editor_context['path']}\n\n```\n{file_content}\n```"
            )
        return "\n\nYou are chatting inside AthenaUI's Code Suite interface (no file is currently open)."
    if page_context == "build_map":
        plan_json = _current_build_map_summary(username)
        if plan_json:
            return (
                "\n\nYou are chatting inside AthenaUI's Build Map interface, where the user plans and "
                f"tracks a project's build plan. Current plan (read-only, for your awareness):\n```json\n{plan_json}\n```"
            )
        return "\n\nYou are chatting inside AthenaUI's Build Map interface (no build plan exists yet)."
    return ""

# General-purpose tools Synergy may use while chatting/discussing a reply or
# carrying out an agreed plan -- now the same full toolset as every other
# phase (see _compute_synergy_tool_names's docstring above). Kept as a named
# alias so the validation checks ("if call_name not in _CHAT_TOOL_NAMES")
# below don't need renaming; actual schema EXPOSURE for each round is
# whatever _capped_tool_names(...) returned (a subset of this), this name
# only needs to be a safe superset for the rejection check to stay correct.
_CHAT_TOOL_NAMES = _SYNERGY_TOOL_NAMES

# Normal-chat Synergy has NO round cap -- it runs as long as it takes,
# checked in wall-clock time instead: every _CHAT_TIME_BUDGET_SECONDS, it
# pauses and asks the user "Synergy has been working on this for a while, do
# you want them to continue?" (Yes extends by another full budget, No
# accepts whatever progress has been made so far) -- same resume_state
# contract as the diagnostic/apply round caps above, just time-gated instead
# of round-gated. A real interrupt (stop immediately, any time) is a
# separate, always-available mechanism (see /chat/interrupt) that works
# because this whole pipeline already returns control to the caller after
# every single step.
_CHAT_TIME_BUDGET_SECONDS = 600


async def _run_chat_execute_pass(
    engine: Any,
    router,
    plan: Optional[Dict[str, Any]],
    context_text: str,
    *,
    resume: Optional[Dict[str, Any]] = None,
    deadline: float,
    worker: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Tool-calling pass that actually carries out an already-agreed
    chat-mode plan (web search / memory / image tools -- no file/terminal
    access, there's no project directory in this context). Pauses and
    returns control to the caller after EVERY round (same per-round
    contract as _run_apply_pass) instead of running to completion in one
    call -- this is what lets the normal-chat interrupt/timer mechanism
    apply here too. Returns one of:
      {"status": "done", "summary": str, "tool_call_labels": [...]}
      {"status": "approval_pending", "tool_call_labels": [...]}
      {"status": "in_progress", "tool_call_labels": [...], "resume": {...}}
      {"status": "needs_more_rounds", "tool_call_labels": [...], "resume": {...}}
        -- `deadline` (a time.monotonic() timestamp) has been reached.
    `resume` continues from exactly where a previous in_progress/
    needs_more_rounds pause left off."""
    if resume:
        messages: List[Dict[str, Any]] = resume["messages"]
        tool_call_labels: List[str] = resume["tool_call_labels"]
        stall_nudges: int = resume["stall_nudges"]
    else:
        plan_text = json.dumps(plan, indent=2) if plan else "(no structured plan was captured -- work from the conversation context above.)"
        messages = [
            {"role": "system", "content": _CHAT_EXECUTE_SYSTEM_PROMPT},
            {"role": "user", "content": f"Conversation context:\n{context_text}\n\nAgreed plan:\n{plan_text}"},
        ]
        tool_call_labels = []
        stall_nudges = 0

    schemas = _menu_gated_schemas(engine, _capped_tool_names(router.provider_id), messages)

    def _resume_dict() -> Dict[str, Any]:
        return {"messages": messages, "tool_call_labels": tool_call_labels, "stall_nudges": stall_nudges}

    if time.monotonic() >= deadline:
        return {"status": "needs_more_rounds", "tool_call_labels": tool_call_labels, "resume": _resume_dict()}

    worker_result = await _call_worker_turn(
        worker["label"], username=worker["username"], provider_id=worker["provider_id"], model_id=worker["model_id"],
        messages=messages, tool_names=sorted(_capped_tool_names(router.provider_id)), directory_path=None,
        temperature=0.3, max_tokens=4096,
    ) if worker else None

    if worker_result is not None:
        messages = worker_result["messages"]
        if worker_result["status"] == "approval_pending":
            return {"status": "approval_pending", "tool_call_labels": tool_call_labels}
        if worker_result["status"] == "done":
            content = worker_result.get("content")
            if content:
                return {"status": "done", "summary": str(content), "tool_call_labels": tool_call_labels}
            if stall_nudges < 2:
                stall_nudges += 1
                messages.append({
                    "role": "system",
                    "content": "Your last reply had no tool call and no text. Either call a tool now, or reply with your plain-text final answer.",
                })
                return {"status": "in_progress", "tool_call_labels": tool_call_labels, "resume": _resume_dict()}
            if tool_call_labels:
                return {
                    "status": "done",
                    "summary": "(Gathered findings above but never produced a final summary -- treat the tool results as the real answer.)",
                    "tool_call_labels": tool_call_labels,
                }
            return {"status": "done", "summary": "(No result produced.)", "tool_call_labels": tool_call_labels}
        tool_call_labels.extend(worker_result.get("tool_call_labels", []))
        return {"status": "in_progress", "tool_call_labels": tool_call_labels, "resume": _resume_dict()}

    # compact_tool_history: same unbounded-growth risk as the other passes
    # above -- this execute pass also resumes/accumulates `messages` across
    # unlimited rounds within the chat-mode wall-clock time budget.
    response = await asyncio.to_thread(router.chat, compact_tool_history(messages), tools=schemas, tool_choice="auto", temperature=0.3, max_tokens=4096)
    if not isinstance(response, dict):
        return {"status": "done", "summary": str(response or "(No summary produced.)"), "tool_call_labels": tool_call_labels}

    tool_call = engine.normalizer.normalize(response)
    if not tool_call:
        content = response.get("content") or response.get("reply") or response.get("text")
        if content:
            return {"status": "done", "summary": str(content), "tool_call_labels": tool_call_labels}
        if stall_nudges < 2:
            stall_nudges += 1
            messages.append({
                "role": "system",
                "content": "Your last reply had no tool call and no text. Either call a tool now, or reply with your plain-text final answer.",
            })
            return {"status": "in_progress", "tool_call_labels": tool_call_labels, "resume": _resume_dict()}
        if tool_call_labels:
            return {
                "status": "done",
                "summary": "(Gathered findings above but never produced a final summary -- treat the tool results as the real answer.)",
                "tool_call_labels": tool_call_labels,
            }
        return {"status": "done", "summary": "(No result produced.)", "tool_call_labels": tool_call_labels}

    raw_tool_calls = response.get("tool_calls")
    if not isinstance(raw_tool_calls, list) or not raw_tool_calls:
        raw_tool_calls = [{
            "id": tool_call.get("tool_call_id"),
            "type": "function",
            "function": {"name": tool_call["tool_name"], "arguments": json.dumps(tool_call["arguments"])},
        }]
    messages.append({"role": "assistant", "content": response.get("content"), "tool_calls": raw_tool_calls})

    approval_pending = False
    for index, raw_call in enumerate(raw_tool_calls):
        parsed = tool_call if index == 0 else engine.normalizer.normalize({"tool_calls": [raw_call]})
        call_id = raw_call.get("id") if isinstance(raw_call, dict) else None
        if not parsed:
            messages.append({"role": "tool", "tool_call_id": call_id, "content": json.dumps({"status": "error", "error": "Malformed tool call."})})
            continue

        call_name = parsed["tool_name"]
        if call_name == _TOOL_LIST_TOOL_NAME:
            menu_text = _build_tool_menu_text(engine.tools.registry, _capped_tool_names(router.provider_id))
            messages.append({"role": "tool", "tool_call_id": call_id, "content": menu_text})
            tool_call_labels.append("pulled up the tool menu")
            continue
        if call_name not in _CHAT_TOOL_NAMES:
            messages.append({
                "role": "tool",
                "tool_call_id": call_id,
                "content": json.dumps({"status": "error", "error": f"Tool '{call_name}' is not permitted here."}),
            })
            continue

        tool_call_labels.append(_summarize_tool_call(call_name, parsed["arguments"]))
        try:
            tool_call_args = {**parsed["arguments"], "character": "Synergy"}
            tool_result = await engine.tools.execute(call_name, tool_call_args)
        except ApprovalRequiredError:
            # Every dangerous call in this SAME round still gets its own
            # independent attempt (and its own pending approval) instead of
            # only the first -- same rationale as _run_apply_pass.
            messages.append({"role": "tool", "tool_call_id": call_id, "content": json.dumps({"status": "pending_approval"})})
            approval_pending = True
            continue
        except Exception as e:
            tool_result = {"status": "error", "error": str(e)}

        messages.append({
            "role": "tool",
            "tool_call_id": call_id,
            "content": tool_result if isinstance(tool_result, str) else json.dumps(tool_result),
        })

    if approval_pending:
        return {"status": "approval_pending", "tool_call_labels": tool_call_labels}

    return {"status": "in_progress", "tool_call_labels": tool_call_labels, "resume": _resume_dict()}


def synergy_chat_result_to_text(result: "SynergyResult", model_a: str, model_b: str) -> str:
    """SynergyResult -> human-readable text for the CHAT (discuss-and-reply)
    pipeline -- sibling to synergy_result_to_text's coding-plan formatting
    above, used by ChatEngine.run_synergy_chat/execute_synergy_chat_plan and
    GroupChatRouter's Synergy turn alike."""
    if result.status == "error":
        return f"Synergy couldn't reply: {result.error}"

    if result.status == "agreed":
        reply_text = result.final_answer_text or "(no reply produced)"

        if result.executed:
            text = reply_text
            if result.execute_summary:
                text += f"\n\n{result.execute_summary}"
            if result.apply_status == "approval_pending":
                text += (
                    "\n\n(One of the steps needs your approval -- please Allow or Deny it "
                    "in the sidebar, then send a follow-up message and I'll continue.)"
                )
            return text

        text = reply_text
        if result.final_plan:
            steps = (result.final_plan or {}).get("steps") or []
            if steps:
                steps_md = "\n".join(f"{i + 1}. {s}" for i, s in enumerate(steps))
                text += f"\n\n_If you'd like me to actually go do this, just say so (or click Execute Plan):_\n{steps_md}"
        return text

    if result.status == "awaiting_approval":
        return (
            "I need your approval for a tool action before I can finish responding -- "
            "please Allow or Deny it in the sidebar, then send a follow-up message."
        )

    if result.status == "disagreed":
        reply_a = (result.plan_a or {}).get("reply") or "(no reply)"
        reply_b = (result.plan_b or {}).get("reply") or "(no reply)"
        return (
            "I'm of two minds about this one:\n\n"
            f"**Option A:** {reply_a}\n\n**Option B:** {reply_b}\n\n"
            "Let me know which one you'd like, or just rephrase and I'll try again."
        )

    return "Synergy didn't produce a reply."


class SynergyChatOrchestrator:
    """Runs Synergy's CONVERSATIONAL pipeline: Model A and Model B discuss a
    chat message and converge on a plain reply, with general tool access
    (web search / memory / image tools) usable throughout the discussion
    itself -- a deliberately separate, simpler sibling to
    SynergyOrchestrator's coding pipeline (diagnostic -> plan -> apply,
    file/terminal tools). Resumable step-by-step exactly like the coding
    pipeline, but with NO round cap at all -- instead of a true round cap
    requiring an explicit "Grant More Rounds" click, normal chat just keeps
    going until it converges, and only pauses to ask "Synergy has been
    working on this for a while, do you want them to continue?" once a
    wall-clock time budget (_CHAT_TIME_BUDGET_SECONDS) elapses. A real
    interrupt is always available in the meantime because every step
    returns control to the caller (see _step_chat)."""

    def __init__(self, username: str, engine: Any = None):
        self.username = username
        if engine is None:
            from chat.engine.service import ChatEngine

            engine = ChatEngine(username)
        self.engine = engine

    def _router_for(self, provider_id: str, model_id: str, category: str):
        api_key = self.engine._get_api_key(provider_id, category=category)
        self.engine._inject_provider_api_key(provider_id, api_key, category=category)
        return self.engine.router_selector.select(provider_id=provider_id, model_id=model_id, mode="code")

    def _approval_pending_result(
        self, context_text: str, transcript: List[SynergyTurn], rounds_run: int, history: HistoryManager, artifact_id: Optional[str],
    ) -> SynergyResult:
        outcome_line = f"Discussion paused after {rounds_run} round(s) -- a tool call needs your approval before they can continue."
        artifact_id = _save_or_update_artifact(self.username, artifact_id, context_text[:80], transcript, outcome_line, done=True)
        history.append_short_history(SYNERGY_AGENT_ID, {"role": "assistant", "content": outcome_line})
        return SynergyResult(status="awaiting_approval", rounds_run=rounds_run, transcript=transcript, artifact_id=artifact_id)

    async def _finalize_agreement_step(
        self,
        state: Dict[str, Any],
        verdict_a: Optional[Dict[str, Any]],
        verdict_b: Optional[Dict[str, Any]],
        rounds_run: int,
        history: HistoryManager,
    ) -> SynergyResult:
        """Called from _step_chat once both sides agree -- builds the
        terminal 'agreed' result and, if the winning verdict asked to
        execute, hands off into the "chat_execute" phase via _step_chat
        (same hand-off pattern as SynergyOrchestrator._step()'s discussion
        -> apply transition) instead of blocking here until it's done."""
        context_text = state["context_text"]
        transcript: List[SynergyTurn] = state["transcript"]
        artifact_id = state["artifact_id"]

        # Coin toss is optional now, not forced -- only honor one if either
        # model actually chose to call the coin_toss tool itself during the
        # discussion; otherwise default deterministically to Model A's
        # wording (they already agree on substance).
        toss = _detect_self_coin_toss(state["messages_a"], state["messages_b"])
        choice = ("A" if toss["result"] == "heads" else "B") if toss else "A"
        winning_verdict = verdict_a if choice == "A" else verdict_b
        reply_text = (winning_verdict or {}).get("reply") or ""
        final_plan = (winning_verdict or {}).get("plan") or None
        should_execute = bool((winning_verdict or {}).get("execute")) and bool(final_plan)

        if toss:
            outcome_line = f"Model A and Model B agreed after {rounds_run} round(s); they used a coin toss ({toss['result']}) themselves to pick Model {choice}'s wording."
        else:
            outcome_line = f"Model A and Model B agreed after {rounds_run} round(s)."
        history.append_short_history(SYNERGY_AGENT_ID, {"role": "assistant", "content": outcome_line})
        system_logger.log(event="Synergy chat outcome", agent_state="Synergy", details={"outcome": outcome_line, "rounds": rounds_run})

        agreed_result = SynergyResult(
            status="agreed",
            rounds_run=rounds_run,
            transcript=transcript,
            final_plan=final_plan,
            final_answer_text=reply_text,
            coin_toss_result=toss["result"] if toss else None,
            coin_artifact_id=toss.get("artifact_id") if toss else None,
        )

        if not should_execute:
            artifact_id = _save_or_update_artifact(self.username, artifact_id, context_text[:80], transcript, outcome_line, done=True)
            agreed_result.artifact_id = artifact_id
            return agreed_result

        outcome_mid = f"{outcome_line} Carrying out the agreed plan..."
        artifact_id = _save_or_update_artifact(self.username, artifact_id, context_text[:80], transcript, outcome_mid)
        execute_state = {
            **state,
            "phase": "chat_execute",
            "artifact_id": artifact_id,
            "router_execute": state["router_a"],
            "final_plan": final_plan,
            "rounds_run": rounds_run,
            "agreed_result": agreed_result,
            "execute_resume": None,
        }
        return await self._step_chat(execute_state)

    def _chat_execute_result_to_synergy_result(
        self, exec_result: Dict[str, Any], state: Dict[str, Any], history: HistoryManager,
    ) -> SynergyResult:
        """Translates an _run_chat_execute_pass() result into the
        SynergyResult the rest of the system expects -- mirrors
        SynergyOrchestrator._apply_result_to_synergy_result()."""
        context_text = state["context_text"]
        transcript: List[SynergyTurn] = state["transcript"]
        artifact_id = state["artifact_id"]
        agreed_result = state.get("agreed_result")

        if exec_result["status"] == "in_progress":
            live_log = transcript + [SynergyTurn(speaker="tool", text=label, verdict={}) for label in exec_result["resume"]["tool_call_labels"]]
            artifact_id = _save_or_update_artifact(self.username, artifact_id, context_text[:80], live_log, "Carrying out the agreed plan...")
            return SynergyResult(
                status="in_progress",
                rounds_run=state.get("rounds_run", 0),
                activity_label="Carrying out the plan",
                artifact_id=artifact_id,
                resume_state={**state, "execute_resume": exec_result["resume"], "artifact_id": artifact_id},
            )

        if exec_result["status"] == "needs_more_rounds":
            return SynergyResult(
                status="needs_more_rounds",
                rounds_run=state.get("rounds_run", 0),
                pause_reason="time_limit",
                artifact_id=artifact_id,
                resume_state={**state, "execute_resume": exec_result["resume"]},
            )

        # "done" or "approval_pending" -- attach the outcome to the
        # already-built "agreed" result (falling back to a bare one
        # defensively, though in practice this only ever runs right after an
        # "agreed" discussion or the explicit execute_plan() entry point).
        if agreed_result is None:
            agreed_result = SynergyResult(status="agreed", rounds_run=state.get("rounds_run", 0), final_plan=state.get("final_plan"), artifact_id=artifact_id)
        agreed_result.executed = True
        agreed_result.execute_summary = exec_result.get("summary")
        agreed_result.apply_status = "approval_pending" if exec_result["status"] == "approval_pending" else "done"
        final_outcome = (
            "They carried out the agreed plan." if exec_result["status"] == "done"
            else "They started carrying out the agreed plan -- waiting on your approval for one of the steps."
        )
        artifact_id = _save_or_update_artifact(
            self.username, artifact_id, context_text[:80], transcript, final_outcome, done=exec_result["status"] == "done",
        )
        agreed_result.artifact_id = artifact_id
        return agreed_result

    async def _step_chat(self, state: Dict[str, Any]) -> SynergyResult:
        """Does exactly ONE unit of work (one speaker's discussion turn, or
        one execute-pass round) and returns either a terminal SynergyResult
        or status="in_progress" with a resume_state for the next call --
        mirrors SynergyOrchestrator._step()'s pattern. Normal chat has NO
        round cap; instead every discussion/execute step checks
        `state["deadline"]` (a time.monotonic() timestamp
        _CHAT_TIME_BUDGET_SECONDS out from when this turn -- or the last
        "Yes, keep going" click -- started) and pauses with
        status="needs_more_rounds"/pause_reason="time_limit" once it's
        passed, asking the user whether Synergy should keep going. A real
        interrupt (stop immediately, no question asked) is handled entirely
        by the frontend/api layer simply not calling back in -- this
        function doesn't need to know about it."""
        phase = state["phase"]
        context_text = state["context_text"]
        transcript: List[SynergyTurn] = state["transcript"]
        artifact_id = state["artifact_id"]
        history = HistoryManager(self.username)
        worker_a = _worker_routing("Synergy-A", self.username, state.get("provider_a"), state.get("model_a")) if state.get("provider_a") and state.get("model_a") else None
        worker_b = _worker_routing("Synergy-B", self.username, state.get("provider_b"), state.get("model_b")) if state.get("provider_b") and state.get("model_b") else None

        if phase == "chat_discussion":
            if time.monotonic() >= state["deadline"]:
                return SynergyResult(
                    status="needs_more_rounds",
                    rounds_run=max(state["round_no"] - 1, 0),
                    round=state["round_no"],
                    pause_reason="time_limit",
                    artifact_id=artifact_id,
                    resume_state=state,
                )

            router_a, router_b = state["router_a"], state["router_b"]
            tool_names = state.get("tool_names", _CHAT_TOOL_NAMES)

            if worker_a and worker_b:
                # Both Synergy workers are up -- fire A's and B's turns
                # CONCURRENTLY, same rationale as SynergyOrchestrator._step()'s
                # discussion phase (Synergy_Reborn.md point 36).
                messages_a, messages_b = state["messages_a"], state["messages_b"]
                schemas_a = _menu_gated_schemas(self.engine, tool_names, messages_a)
                schemas_b = _menu_gated_schemas(self.engine, tool_names, messages_b)
                turn_a, turn_b = await asyncio.gather(
                    _run_agent_turn(self.engine, router_a, messages_a, "A", transcript, schemas_a, tool_names, worker=worker_a),
                    _run_agent_turn(self.engine, router_b, messages_b, "B", transcript, schemas_b, tool_names, worker=worker_b),
                )
                if turn_a["status"] == "approval_pending" or turn_b["status"] == "approval_pending":
                    return self._approval_pending_result(context_text, transcript, state["round_no"], history, artifact_id)

                raw_a, prose_a, verdict_a = turn_a["raw"], turn_a["prose"], turn_a["verdict"]
                raw_b, prose_b, verdict_b = turn_b["raw"], turn_b["prose"], turn_b["verdict"]
                transcript.append(SynergyTurn(speaker="A", text=prose_a or raw_a, verdict=verdict_a or {}))
                transcript.append(SynergyTurn(speaker="B", text=prose_b or raw_b, verdict=verdict_b or {}))
                messages_b.append({"role": "user", "content": f"Model A says:\n{prose_a or raw_a}"})
                messages_a.append({"role": "user", "content": f"Model B says:\n{prose_b or raw_b}"})
                history.append_short_history(SYNERGY_AGENT_ID, {"role": "assistant", "content": f"[Model A] {prose_a or raw_a}"})
                history.append_short_history(SYNERGY_AGENT_ID, {"role": "assistant", "content": f"[Model B] {prose_b or raw_b}"})

                state["verdict_a"] = verdict_a
                state["verdict_b"] = verdict_b
                rounds_run = state["round_no"]
                both_agree = bool(verdict_a and verdict_a.get("agree")) and bool(verdict_b and verdict_b.get("agree"))
                if both_agree:
                    return await self._finalize_agreement_step(state, verdict_a, verdict_b, rounds_run, history)

                state["round_no"] = rounds_run + 1
                artifact_id = _save_or_update_artifact(self.username, artifact_id, context_text[:80], transcript, "Model A and Model B are responding...")
                state["artifact_id"] = artifact_id
                return SynergyResult(
                    status="in_progress", rounds_run=rounds_run, round=state["round_no"],
                    activity_label="Model A and Model B", artifact_id=artifact_id, transcript=transcript, resume_state=state,
                )

            speaker = state["next_speaker"]
            router = router_a if speaker == "A" else router_b
            worker = worker_a if speaker == "A" else worker_b
            messages = state["messages_a"] if speaker == "A" else state["messages_b"]
            other_messages = state["messages_b"] if speaker == "A" else state["messages_a"]
            schemas = _menu_gated_schemas(self.engine, tool_names, messages)

            turn = await _run_agent_turn(self.engine, router, messages, speaker, transcript, schemas, tool_names, worker=worker)
            if turn["status"] == "approval_pending":
                return self._approval_pending_result(context_text, transcript, state["round_no"], history, artifact_id)

            raw, prose, verdict = turn["raw"], turn["prose"], turn["verdict"]
            transcript.append(SynergyTurn(speaker=speaker, text=prose or raw, verdict=verdict or {}))
            other_messages.append({"role": "user", "content": f"Model {speaker} says:\n{prose or raw}"})
            history.append_short_history(SYNERGY_AGENT_ID, {"role": "assistant", "content": f"[Model {speaker}] {prose or raw}"})

            if speaker == "A":
                state["verdict_a"] = verdict
                state["next_speaker"] = "B"
                artifact_id = _save_or_update_artifact(self.username, artifact_id, context_text[:80], transcript, "Model B is responding...")
                state["artifact_id"] = artifact_id
                return SynergyResult(
                    status="in_progress", rounds_run=max(state["round_no"] - 1, 0), round=state["round_no"],
                    activity_label="Model A", artifact_id=artifact_id, transcript=transcript, resume_state=state,
                )

            state["verdict_b"] = verdict
            verdict_a = state["verdict_a"]
            both_agree = bool(verdict_a and verdict_a.get("agree")) and bool(verdict and verdict.get("agree"))
            rounds_run = state["round_no"]

            if both_agree:
                return await self._finalize_agreement_step(state, verdict_a, verdict, rounds_run, history)

            state["round_no"] = rounds_run + 1
            state["next_speaker"] = "A"
            artifact_id = _save_or_update_artifact(self.username, artifact_id, context_text[:80], transcript, "Model A is responding...")
            state["artifact_id"] = artifact_id
            return SynergyResult(
                status="in_progress", rounds_run=rounds_run, round=state["round_no"],
                activity_label="Model B", artifact_id=artifact_id, transcript=transcript, resume_state=state,
            )

        if phase == "chat_execute":
            exec_result = await _run_chat_execute_pass(
                self.engine, state["router_execute"], state.get("final_plan"), context_text,
                resume=state.get("execute_resume"), deadline=state["deadline"], worker=worker_a,
            )
            return self._chat_execute_result_to_synergy_result(exec_result, state, history)

        return SynergyResult(status="error", rounds_run=0, error=f"Unknown Synergy chat phase '{phase}'.")

    async def run_chat_discussion(
        self,
        context_text: str,
        *,
        editor_context: Optional[Dict[str, Any]] = None,
        page_context: Optional[str] = None,
    ) -> SynergyResult:
        """Kicks off a normal-chat Synergy discussion and runs its first
        step. No round cap -- see _step_chat's docstring for the
        wall-clock-budget pause mechanism that replaces it.

        `editor_context`/`page_context` mirror what every other character
        already gets via ChatEngine._build_messages (which chat-mode
        Synergy previously bypassed entirely) -- they tell Synergy which
        AthenaUI surface the user is chatting from (e.g. Code Suite with a
        specific file open, or the Build Map page) so it can speak with
        that awareness instead of operating blind."""
        if not self.engine.synergy_available():
            return SynergyResult(
                status="error",
                rounds_run=0,
                error="Synergy needs both Code Model A and Code Model B configured in Settings.",
            )

        try:
            provider_a, model_a = self.engine._get_active_code_model()
            provider_b, model_b = self.engine._get_active_code_model_b()
            router_a = self._router_for(provider_a, model_a, "code")
            router_b = self._router_for(provider_b, model_b, "code_b")
        except Exception as e:
            return SynergyResult(status="error", rounds_run=0, error=str(e))

        # NOTE: deliberately NOT persisting `context_text` to history here --
        # it's a synthesized "Below is the recent conversation..." wrapper
        # that already EMBEDS the last 12 real turns (built by the caller,
        # e.g. ChatEngine.run_synergy_chat). Storing it as a new turn used
        # to mean the NEXT call's "last 12 turns" would include this
        # wrapper, get re-wrapped, and get stored again -- a self-
        # referential snowball that doubled in size roughly every turn and
        # is exactly how a long Synergy chat session's prompt reached
        # millions of tokens. The real, clean user message + final reply
        # are already recorded separately by
        # ChatEngine._finalize_synergy_chat_result -- that's the only
        # history write this flow needs.
        schemas = self.engine.tools.registry.get_all_schemas(allowed_names=_capped_tool_names(provider_a, provider_b))
        surface_block = _build_chat_surface_context(self.username, page_context, editor_context)
        messages_a: List[Dict[str, Any]] = [
            {"role": "system", "content": CHAT_MODE_SYSTEM_PROMPT + _COIN_TOSS_GUIDANCE},
            {"role": "user", "content": f"{context_text}{surface_block}\n\nYou are Model A. Give your opening proposed reply."},
        ]
        messages_b: List[Dict[str, Any]] = [
            {"role": "system", "content": CHAT_MODE_SYSTEM_PROMPT + _COIN_TOSS_GUIDANCE},
            {
                "role": "user",
                "content": (
                    f"{context_text}{surface_block}\n\nYou are Model B. Your counterpart (Model A) has not "
                    "spoken yet -- give your own opening proposed reply."
                ),
            },
        ]

        artifact_id = _save_or_update_artifact(
            self.username, None, context_text[:80], [], "Model A and Model B are discussing a reply...",
        )

        state = {
            "phase": "chat_discussion",
            "context_text": context_text,
            "router_a": router_a, "router_b": router_b,
            "provider_a": provider_a, "model_a": model_a,
            "provider_b": provider_b, "model_b": model_b,
            "messages_a": messages_a, "messages_b": messages_b, "schemas": schemas,
            "tool_names": _capped_tool_names(provider_a, provider_b),
            "transcript": [],
            "next_speaker": "A", "round_no": 1,
            "verdict_a": None, "verdict_b": None,
            "artifact_id": artifact_id,
            "deadline": time.monotonic() + _CHAT_TIME_BUDGET_SECONDS,
        }
        return await self._step_chat(state)

    async def continue_chat_discussion(self, resume_state: Dict[str, Any]) -> SynergyResult:
        """Called by the normal agentic auto-continue loop (api/routes/
        chat.py's /chat/continue -- the exact same endpoint the regular
        tool-calling agent loop uses) for every status="in_progress" step.
        An interrupt simply means the frontend stops calling this; nothing
        Synergy-specific is needed for that to work."""
        return await self._step_chat(resume_state)

    async def resume_chat_discussion(self, resume_state: Dict[str, Any]) -> SynergyResult:
        """Called when the user clicks "Yes" on "Synergy has been working
        on this for a while, do you want them to continue?" -- simply
        extends the wall-clock deadline by another full budget and keeps
        going (there's no round count to grant -- normal chat has no round
        cap at all)."""
        resume_state = {**resume_state, "deadline": time.monotonic() + _CHAT_TIME_BUDGET_SECONDS}
        return await self._step_chat(resume_state)

    async def deny_chat_more_rounds(self, resume_state: Dict[str, Any]) -> SynergyResult:
        """Called when the user clicks "No" -- accepts whatever progress
        has been made so far as final, mirroring
        ChatEngine.finalize_after_denied_more_turns (the regular agentic
        loop's equivalent)."""
        phase = resume_state.get("phase")
        history = HistoryManager(self.username)
        context_text = resume_state["context_text"]
        transcript: List[SynergyTurn] = resume_state["transcript"]
        artifact_id = resume_state["artifact_id"]

        if phase == "chat_execute":
            tool_call_labels = (resume_state.get("execute_resume") or {}).get("tool_call_labels", [])
            summary = (
                "(Started carrying out the agreed plan and made the tool calls logged above, but ran "
                "out of time before a final summary -- treat the tool results as partial progress.)"
                if tool_call_labels else "(No changes were made before time ran out.)"
            )
            exec_result = {"status": "done", "summary": summary, "tool_call_labels": tool_call_labels}
            return self._chat_execute_result_to_synergy_result(exec_result, resume_state, history)

        # chat_discussion -- present whatever each side had proposed so far
        # (anonymized), same graceful two-option fallback this file already
        # uses elsewhere when a discussion doesn't fully converge.
        verdict_a = resume_state.get("verdict_a")
        verdict_b = resume_state.get("verdict_b")
        reply_a = (verdict_a or {}).get("reply") or ""
        reply_b = (verdict_b or {}).get("reply") or ""
        if secrets.choice([True, False]):
            reply_a, reply_b = reply_b, reply_a

        rounds_run = max(resume_state.get("round_no", 1) - 1, 0)
        outcome_line = f"Model A and Model B were still discussing this after {rounds_run} round(s) when time ran out -- here's where each stood."
        artifact_id = _save_or_update_artifact(self.username, artifact_id, context_text[:80], transcript, outcome_line, done=True)
        history.append_short_history(SYNERGY_AGENT_ID, {"role": "assistant", "content": outcome_line})
        system_logger.log(event="Synergy chat outcome", agent_state="Synergy", details={"outcome": outcome_line, "rounds": rounds_run})

        return SynergyResult(
            status="disagreed",
            rounds_run=rounds_run,
            transcript=transcript,
            plan_a={"reply": reply_a},
            plan_b={"reply": reply_b},
            artifact_id=artifact_id,
        )

    async def execute_plan(self, plan: Dict[str, Any], context_text: str) -> SynergyResult:
        """Explicit "Execute Plan" button entry point -- runs the agreed
        plan's execute pass directly, without re-running the discussion
        (the frontend already holds the exact `plan` dict from the prior
        agreed reply and sends it back verbatim). Resumable/time-budgeted
        exactly like the auto-triggered execute pass inside a discussion."""
        if not self.engine.synergy_available():
            return SynergyResult(
                status="error",
                rounds_run=0,
                error="Synergy needs both Code Model A and Code Model B configured in Settings.",
            )
        try:
            provider_a, model_a = self.engine._get_active_code_model()
            router_a = self._router_for(provider_a, model_a, "code")
        except Exception as e:
            return SynergyResult(status="error", rounds_run=0, error=str(e))

        artifact_id = _save_or_update_artifact(self.username, None, context_text[:80], [], "Carrying out the agreed plan...")
        state = {
            "phase": "chat_execute",
            "context_text": context_text,
            "transcript": [],
            "artifact_id": artifact_id,
            "router_execute": router_a,
            "provider_a": provider_a,
            "model_a": model_a,
            "final_plan": plan,
            "rounds_run": 0,
            "agreed_result": None,
            "execute_resume": None,
            "deadline": time.monotonic() + _CHAT_TIME_BUDGET_SECONDS,
        }
        return await self._step_chat(state)
