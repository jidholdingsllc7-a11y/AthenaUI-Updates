﻿# AthenaUI v3.5 — Runtime Initialization
# File: backend/core/runtime/runtime.py
# Created: 2026-03-28 18:10 CDT
# Updated: 2026-07-27 19:49 CDT

from dataclasses import dataclass
from typing import Optional

from core.env.env_loader import Env

class RuntimeNotInitialized(Exception):
    """Raised when get_runtime() is called before runtime initialization."""
    pass


@dataclass
class RuntimeContext:
    """
    Holds global runtime state for AthenaUI v3.1.
    This object is created once at startup and shared across the backend.
    """
    env: Env
    version: str = "3.7.0"
    debug: bool = True


_runtime: Optional[RuntimeContext] = None


def init_runtime(debug: bool = True) -> RuntimeContext:
    """
    Initialize the global runtime context.
    This should be called once during backend startup (e.g., in api/main.py).
    """

    global _runtime

    # Load environment variables and validate directories
    Env.load()

    # Create runtime context
    _runtime = RuntimeContext(
        env=Env,
        version="3.7.0",
        debug=debug,
    )

    print(f"AthenaUI v{_runtime.version} runtime initialized.")
    print(f"Root directory: {Env.ROOT_DIR}")
    print(f"Vault directory: {Env.VAULT_DIR}")
    print(f"Data directory: {Env.DATA_DIR}")

    return _runtime


def get_runtime() -> RuntimeContext:
    """
    Retrieve the global runtime context.
    Raises an error if the runtime has not been initialized.
    """

    if _runtime is None:
        raise RuntimeNotInitialized(
            "Runtime has not been initialized. "
            "Call init_runtime() before accessing runtime context."
        )

    return _runtime
