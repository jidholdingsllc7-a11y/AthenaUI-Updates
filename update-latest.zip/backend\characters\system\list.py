﻿# AthenaUI v3.5 — Character List
# File: backend/characters/system/list.py
# Created: 2026-04-10 22:34 CDT
# Updated: 2026-07-27 19:49 CDT

from __future__ import annotations

import json
from pathlib import Path

from vault.controller import VaultController, SYSTEM_CHARACTERS

# Reserved, characterless dual-model discussion mode (see
# chat/synergy/service.py's SYNERGY_CHARACTER_NAME) -- never a real persona,
# but still gets a minimal vault character record (seeded below) purely so
# the existing avatar-upload/voice-assignment machinery, which all key off
# load_character/save_character by name, can give it a custom avatar + voice
# like any other character. api/routes/characters.py's /list route filters
# this name back OUT of its response so it never shows up in the normal
# character grid/dropdowns.
SYNERGY_CHARACTER_NAME = "Synergy"

# Locked-in defaults for every install/update (chosen during dev testing and
# bundled permanently so a fresh account never shows a voiceless/avatarless
# Synergy). The avatar image itself ships at
# system_agents/Synergy/gallery/modern/ and is picked up automatically by
# api/routes/characters.py::_avatar_candidates()'s seeded-system-agent-gallery
# fallback -- no explicit `avatar.path` is set here so it keeps working no
# matter where the app is installed.
SYNERGY_VOICE_ID = "5OhY6eII5od0GRAOSINf"
SYNERGY_AVATAR_GLOW = {"enabled": True, "intensity": 0.5, "speed": 0.5}


def _ensure_synergy_character(username: str) -> None:
    vault = VaultController.get_vault(username)
    existing = vault.characters.get(SYNERGY_CHARACTER_NAME)

    from .save import save_character

    if existing is not None:
        # Backfill already-created records (e.g. from an install that
        # predates locking these defaults in) instead of leaving them stuck
        # without a voice/avatar forever.
        profile = existing.profile if isinstance(existing.profile, dict) else {}
        avatar = profile.get("avatar") or {}
        changed = False

        if not profile.get("voice_id"):
            profile["voice_id"] = SYNERGY_VOICE_ID
            changed = True
        if not avatar.get("locked"):
            avatar["locked"] = True
            changed = True
        if not avatar.get("glow"):
            avatar["glow"] = dict(SYNERGY_AVATAR_GLOW)
            changed = True

        if changed:
            profile["avatar"] = avatar
            save_character(username, profile, key=SYNERGY_CHARACTER_NAME)
        return

    from .schema import new_character_base

    char = new_character_base()
    char["name"] = SYNERGY_CHARACTER_NAME
    char["meta"]["source"] = "reserved"
    char["voice_id"] = SYNERGY_VOICE_ID
    char["avatar"] = {"locked": True, "glow": dict(SYNERGY_AVATAR_GLOW)}
    save_character(username, char, key=SYNERGY_CHARACTER_NAME)


# ---------------------------------------------------------
#  SYSTEM CHARACTER DIRECTORIES
# ---------------------------------------------------------

# Resolve from this file location so listing works regardless server cwd.
SYSTEM_DIR = Path(__file__).resolve().parent
SYSTEM_AGENTS_DIR = SYSTEM_DIR / "system_agents"


# ---------------------------------------------------------
#  LOAD SYSTEM CHARACTER BASE JSON
# ---------------------------------------------------------

def _load_system_character_base(name: str) -> dict:
    """
    Loads the .base.json file for a system character.
    """

    base_path = SYSTEM_AGENTS_DIR / f"{name}.base.json"
    if base_path.exists():
        return json.loads(base_path.read_text())

    return {}


# ---------------------------------------------------------
#  LIST ALL CHARACTERS (SYSTEM + USER)
# ---------------------------------------------------------

def list_all_characters(username: str) -> dict:
    """
    Returns a merged list of:
      - system characters (Sol, Maximos, Orion)
      - user-created characters
    v3.1 stores characters inside vault.characters (Pydantic models).
    """

    _ensure_synergy_character(username)
    vault = VaultController.get_vault(username)

    # -----------------------------
    # 1. Load user characters
    # -----------------------------
    user_characters = {}

    for name, char in vault.characters.items():
        profile = char.profile if isinstance(char.profile, dict) else {}

        if isinstance(profile, dict) and "meta" in profile and "name" in profile:
            # Full rich character record (v3.0 schema), as produced by the
            # temp-character creation flow (characters/system/save.py).
            user_characters[name] = profile
        elif name in SYSTEM_CHARACTERS:
            # System agents seeded via VaultService.seed_system_agents() only
            # store the narrow `profile` sub-section in the vault, not the
            # full rich record -- prefer the .base.json version below instead
            # of clobbering it with that narrower shape.
            continue
        else:
            # Best-effort pass-through for any other/legacy shape.
            user_characters[name] = profile

    # -----------------------------
    # 2. Load system characters
    # -----------------------------
    system_characters = {}

    # System agent .base.json files
    for base_file in SYSTEM_AGENTS_DIR.glob("*.base.json"):
        name = base_file.name.replace(".base.json", "")
        system_characters[name] = json.loads(base_file.read_text())

        # A system agent added to the roster AFTER this user already
        # completed onboarding never got its one-time vault seed
        # (VaultService.seed_system_agents() only ever runs once, at
        # finalize_onboarding()). Backfill it on-demand here so every OTHER
        # vault-keyed lookup for this character (raw VaultService/
        # VaultController.get_character() call sites, the Maximos per-agent
        # key storage, etc.) behaves the same as any other system character
        # from now on, instead of each one needing its own fallback fix.
        if name not in vault.characters:
            from vault.service import VaultService
            VaultService.seed_single_system_agent(username, name)

    # -----------------------------
    # 3. Merge system + user
    # -----------------------------
    merged = {}

    # System characters first
    for name, data in system_characters.items():
        merged[name] = data

    # User characters override system if present
    for name, data in user_characters.items():
        merged[name] = data

    # A system character's voice_id and safety_role are permanently
    # hardcoded on its .base.json and must never be shadowed by a stale rich
    # vault override saved before that field existed/was assigned (e.g. an
    # override saved before safety_role was added to the schema carries
    # safety_role=None forever, which breaks group-chat turn ordering).
    # Force both back to the current .base.json value for any system
    # character, even when a rich vault override exists.
    for name, base_data in system_characters.items():
        if name in merged:
            merged[name]["voice_id"] = base_data.get("voice_id")
            merged[name]["safety_role"] = base_data.get("safety_role")

    return merged

