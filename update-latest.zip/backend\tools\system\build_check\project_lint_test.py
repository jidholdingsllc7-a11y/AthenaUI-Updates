# AthenaUI v3.7 — Project Lint/Test Tool
# File: backend/tools/system/build_check/project_lint_test.py
# Created: 2026-10-25

from __future__ import annotations

from typing import Any, Dict

from ._common import BuildCheckError, detect_lint_command, detect_test_command, resolve_target_dir, run_command

capabilities = {
    "needs_filesystem": True,
    "needs_bridge": False,
    "needs_network": False,
    "needs_user": True,
    "is_dangerous": True,
}


async def run(args: Dict[str, Any]) -> Dict[str, Any]:
    """
    Runs a project's lint check and/or test suite -- auto-detects the right
    command per mode from project marker files (npm run lint/test, cargo
    clippy/test, go test, ruff, pytest), or runs a single explicit `command`
    override instead (which skips auto-detection and `mode` entirely).
    `mode` is "lint", "test", or "both" (default).
    """
    username = args.get("username")
    if not username:
        return {"status": "error", "error": "Missing required argument: username."}

    try:
        target = resolve_target_dir(username, args.get("path"), args.get("_scope_dir"))
    except BuildCheckError as e:
        return {"status": "error", "error": str(e)}

    override = args.get("command")
    if override:
        return await run_command(target, override)

    mode = str(args.get("mode") or "both").strip().lower()
    if mode not in ("lint", "test", "both"):
        return {"status": "error", "error": "'mode' must be 'lint', 'test', or 'both'."}

    results: Dict[str, Any] = {}

    if mode in ("lint", "both"):
        lint_cmd = detect_lint_command(target)
        results["lint"] = (
            await run_command(target, lint_cmd)
            if lint_cmd
            else {"status": "skipped", "reason": "No lint command auto-detected for this project type."}
        )

    if mode in ("test", "both"):
        test_cmd = detect_test_command(target)
        results["test"] = (
            await run_command(target, test_cmd)
            if test_cmd
            else {"status": "skipped", "reason": "No test command auto-detected for this project type."}
        )

    overall = "failed" if any(r.get("status") == "failed" for r in results.values()) else "ok"
    return {"status": overall, "results": results}
