# AthenaUI v3.5 — Selfie Generate Tool
# File: backend/tools/system/images/image_generate_selfie.py
# Purpose: Lets an agent generate a new selfie of themselves, using their
# own existing avatar/gallery photo as the reference image, when the user
# asks for one during chat (e.g. "send me a selfie").
# Created: 2026-08-01

from typing import Any, Dict
from llm.image_generation.service import ImageGenerationService

capabilities = {
    "needs_bridge": False,
    "needs_filesystem": False,
    "needs_network": True,
    "needs_user": True,
}

async def run(args: Dict[str, Any]):
    username = args.get("username", "system")
    character = args.get("character") or args.get("character_id")
    prompt = args.get("prompt")
    emotion = args.get("emotion")
    reference_image = args.get("reference_image")

    if not character:
        return {"error": "Missing character for selfie generation"}

    try:
        service = ImageGenerationService()
        return await service.generate_selfie(
            username=username,
            character=character,
            prompt=prompt,
            emotion=emotion,
            reference_image=reference_image,
        )
    except Exception as e:
        return {"error": str(e)}
