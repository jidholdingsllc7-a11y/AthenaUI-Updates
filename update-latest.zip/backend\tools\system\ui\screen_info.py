# AthenaUI v3.5 — Screen Info Tool (Bridge Wrapper)
# File: backend/tools/system/ui/screen_info.py
# Created: 2026-10-01
# Purpose: Reports the real screen resolution so an agent can ground mouse
# coordinates against actual screen bounds instead of guessing blind.

import httpx
from typing import Dict, Any

BRIDGE_URL = "http://localhost:9000"

capabilities = {
    "needs_bridge": True,
    "needs_filesystem": False,
    "needs_network": False,
    "needs_user": False,
}

async def run(args: Dict[str, Any]) -> Dict[str, Any]:
    async with httpx.AsyncClient() as client:
        resp = await client.get(f"{BRIDGE_URL}/ui/screen_info")
        return resp.json()
