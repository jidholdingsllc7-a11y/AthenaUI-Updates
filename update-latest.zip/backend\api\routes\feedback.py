# AthenaUI v3.5 — Feedback API Routes
# File: backend/api/routes/feedback.py

from __future__ import annotations

from typing import Any, Dict

from fastapi import APIRouter, Body, Depends, HTTPException

from api.deps.auth_middleware import get_current_user
from feedback.service import submit_feedback

router = APIRouter(prefix="/feedback", tags=["feedback"])


def _username_from_user(user: Any) -> str:
    username = user.get("username") if isinstance(user, dict) else getattr(user, "username", None)
    if not username:
        raise HTTPException(status_code=401, detail="Authentication required.")
    return str(username)


@router.post("")
async def send_feedback(
    payload: Dict[str, Any] = Body(...),
    user: Dict[str, Any] = Depends(get_current_user),
):
    username = _username_from_user(user)
    message = str(payload.get("message", ""))
    if not message.strip():
        raise HTTPException(status_code=400, detail="'message' is required.")

    try:
        result = submit_feedback(username, message=message, contact_email=payload.get("contact_email"))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    return {"ok": True, **result}
