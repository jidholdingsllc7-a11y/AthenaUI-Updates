# AthenaUI — Stable machine fingerprint for license binding
# File: backend/licensing/fingerprint.py
#
# Generates a stable per-machine identifier used to bind a license to one
# machine (see licensing/service.py + the Worker's /activate machine-lock).
# Primary source is Windows' own per-install MachineGuid
# (HKLM\SOFTWARE\Microsoft\Cryptography) -- it's generated once at OS
# install time and doesn't change across reboots, user profiles, or
# hardware-detection quirks (unlike WMI CPU/disk queries, which can reorder
# or vary based on driver/enumeration state). Hashed (never sent/stored
# raw) and cached in the SystemVault so it's computed once per install and
# stays stable even if this detection logic is later tweaked.

import hashlib
import platform

try:
    import winreg
except ImportError:  # pragma: no cover - this app only ships on Windows
    winreg = None

from system_vault.system_vault import SystemVault

_MACHINE_ID_KEY = "license_machine_id"


def _read_machine_guid() -> str:
    if winreg is None:
        return ""
    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography") as key:
            value, _ = winreg.QueryValueEx(key, "MachineGuid")
            return str(value)
    except OSError:
        return ""


def _compute_machine_id() -> str:
    raw = "|".join([
        _read_machine_guid(),
        platform.node() or "",
        platform.system() or "",
    ])
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def get_machine_id() -> str:
    """Returns this machine's stable fingerprint, computing and caching it
    in the SystemVault on first call."""
    cached = SystemVault.get(_MACHINE_ID_KEY)
    if cached:
        return str(cached)

    machine_id = _compute_machine_id()
    SystemVault.set(_MACHINE_ID_KEY, machine_id)
    return machine_id
