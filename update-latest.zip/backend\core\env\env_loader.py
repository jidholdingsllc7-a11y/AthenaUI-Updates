﻿# AthenaUI v3.5 — Environment Loader
# File: backend/core/env/env_loader.py
# Updated: 2026-07-27 19:49 CDT

import os
import shutil
from pathlib import Path
from typing import Optional


class EnvError(Exception):
    """Raised when required environment variables are missing or invalid."""
    pass


class Env:
    """
    Centralized environment configuration for AthenaUI v3.1.
    Loads environment variables, resolves paths, and validates required settings.
    """

    # ---------------------------------------------------------
    # Root paths
    # ---------------------------------------------------------
    ROOT_DIR: Path = Path(__file__).resolve().parents[3]
    BACKEND_DIR: Path = ROOT_DIR / "backend"

    # Writable per-user data root. A packaged/installed build normally lives
    # under "Program Files", which a standard (non-admin) user cannot write
    # to -- so Electron's main.js sets ATHENAUI_USER_DATA_DIR (app.getPath
    # ("userData"), e.g. %APPDATA%\AthenaUI) before spawning this process.
    # Falls back to BACKEND_DIR for local dev, where the source tree itself
    # is already writable.
    _USER_DATA_OVERRIDE: Optional[str] = os.environ.get("ATHENAUI_USER_DATA_DIR")
    WRITABLE_ROOT: Path = Path(_USER_DATA_OVERRIDE) if _USER_DATA_OVERRIDE else BACKEND_DIR

    DATA_DIR: Path = WRITABLE_ROOT / "data"
    VAULT_DIR: Path = WRITABLE_ROOT / "vault"

    # ---------------------------------------------------------
    # LLM Provider Keys (ALL providers supported by AthenaUI v3.1)
    # ---------------------------------------------------------

    # OpenAI + Azure OpenAI
    OPENAI_API_KEY: Optional[str] = None
    AZURE_OPENAI_API_KEY: Optional[str] = None
    AZURE_OPENAI_ENDPOINT: Optional[str] = None

    # Anthropic
    ANTHROPIC_API_KEY: Optional[str] = None

    # Google Gemini
    GEMINI_API_KEY: Optional[str] = None

    # Mistral
    MISTRAL_API_KEY: Optional[str] = None

    # Groq
    GROQ_API_KEY: Optional[str] = None

    # Fireworks
    FIREWORKS_API_KEY: Optional[str] = None

    # Together AI
    TOGETHER_API_KEY: Optional[str] = None

    # Cohere
    COHERE_API_KEY: Optional[str] = None

    # AI21
    AI21_API_KEY: Optional[str] = None

    # Perplexity
    PERPLEXITY_API_KEY: Optional[str] = None

    # xAI (Grok)
    XAI_API_KEY: Optional[str] = None

    # HuggingFace Inference API
    HUGGINGFACE_API_KEY: Optional[str] = None

    # HuggingFace TGI (local or remote)
    HF_TGI_ENDPOINT: Optional[str] = None

    # LM Studio (OpenAI-compatible local endpoint)
    LMSTUDIO_API_BASE: Optional[str] = None

    # Ollama (local)
    OLLAMA_API_BASE: Optional[str] = None

    # Atlas Server (local -- orchestrates multiple fine-tuned models
    # behind one OpenAI-compatible endpoint, see atlas-server/)
    ATLAS_SERVER_API_BASE: Optional[str] = None
    ATLAS_SERVER_API_KEY: Optional[str] = None

    # AWS Bedrock
    AWS_ACCESS_KEY_ID: Optional[str] = None
    AWS_SECRET_ACCESS_KEY: Optional[str] = None
    AWS_SESSION_TOKEN: Optional[str] = None
    AWS_REGION: Optional[str] = None
    # Bedrock API key (bearer token) auth -- alternative to the SigV4
    # access key/secret pair above, used via `Authorization: Bearer <token>`.
    AWS_BEARER_TOKEN_BEDROCK: Optional[str] = None

    # OpenRouter
    OPENROUTER_API_KEY: Optional[str] = None
    OPENROUTER_SITE_URL: Optional[str] = None
    OPENROUTER_APP_NAME: Optional[str] = None

    # Custom HTTP provider
    CUSTOM_HTTP_API_BASE: Optional[str] = None
    CUSTOM_HTTP_API_KEY: Optional[str] = None

    # ---------------------------------------------------------
    # Redis (chat history buffer)
    # ---------------------------------------------------------
    REDIS_URL: Optional[str] = None

    # ---------------------------------------------------------
    # Maximos Memory Server (long-term, per-character agent memory)
    # ---------------------------------------------------------
    MAXIMOS_URL: Optional[str] = None
    MAXIMOS_GLOBAL_KEY: Optional[str] = None

    # ---------------------------------------------------------
    # Email (optional)
    # ---------------------------------------------------------
    SMTP_HOST: Optional[str] = None
    SMTP_PORT: Optional[int] = None
    SMTP_USER: Optional[str] = None
    SMTP_PASSWORD: Optional[str] = None

    # ---------------------------------------------------------
    # UI Bridge (desktop/DOM automation)
    # ---------------------------------------------------------
    UI_BRIDGE_URL: Optional[str] = None

    # ---------------------------------------------------------
    # Load environment variables
    # ---------------------------------------------------------
    @classmethod
    def load(cls):
        """
        Load environment variables into the Env class.
        This should be called once during backend startup.
        """

        # OpenAI + Azure
        cls.OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
        cls.AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
        cls.AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")

        # Anthropic
        cls.ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")

        # Gemini
        cls.GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

        # Mistral
        cls.MISTRAL_API_KEY = os.getenv("MISTRAL_API_KEY")

        # Groq
        cls.GROQ_API_KEY = os.getenv("GROQ_API_KEY")

        # Fireworks
        cls.FIREWORKS_API_KEY = os.getenv("FIREWORKS_API_KEY")

        # Together
        cls.TOGETHER_API_KEY = os.getenv("TOGETHER_API_KEY")

        # Cohere
        cls.COHERE_API_KEY = os.getenv("COHERE_API_KEY")

        # AI21
        cls.AI21_API_KEY = os.getenv("AI21_API_KEY")

        # Perplexity
        cls.PERPLEXITY_API_KEY = os.getenv("PERPLEXITY_API_KEY")

        # xAI
        cls.XAI_API_KEY = os.getenv("XAI_API_KEY")

        # HuggingFace
        cls.HUGGINGFACE_API_KEY = os.getenv("HUGGINGFACE_API_KEY")

        # HF TGI
        cls.HF_TGI_ENDPOINT = os.getenv("HF_TGI_ENDPOINT")

        # LM Studio
        cls.LMSTUDIO_API_BASE = os.getenv("LMSTUDIO_API_BASE")

        # Ollama
        cls.OLLAMA_API_BASE = os.getenv("OLLAMA_API_BASE")

        # Atlas Server -- plug-and-play default so no setup is required
        # when it's running locally on its default port.
        cls.ATLAS_SERVER_API_BASE = os.getenv("ATLAS_SERVER_API_BASE", "http://127.0.0.1:8090")
        cls.ATLAS_SERVER_API_KEY = os.getenv("ATLAS_SERVER_API_KEY")

        # AWS Bedrock
        cls.AWS_ACCESS_KEY_ID = os.getenv("AWS_ACCESS_KEY_ID")
        cls.AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY")
        cls.AWS_SESSION_TOKEN = os.getenv("AWS_SESSION_TOKEN")
        cls.AWS_REGION = os.getenv("AWS_REGION")
        cls.AWS_BEARER_TOKEN_BEDROCK = os.getenv("AWS_BEARER_TOKEN_BEDROCK")

        # OpenRouter
        cls.OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")
        cls.OPENROUTER_SITE_URL = os.getenv("OPENROUTER_SITE_URL")
        cls.OPENROUTER_APP_NAME = os.getenv("OPENROUTER_APP_NAME", "AthenaUI")

        # Custom HTTP
        cls.CUSTOM_HTTP_API_BASE = os.getenv("CUSTOM_HTTP_API_BASE")
        cls.CUSTOM_HTTP_API_KEY = os.getenv("CUSTOM_HTTP_API_KEY")

        # Redis
        cls.REDIS_URL = os.getenv("REDIS_URL", "redis://127.0.0.1:6379/0")

        # Maximos Memory Server (MAXIMOS_GLOBAL_KEY, if unset, is
        # auto-discovered from the server's own key file on this machine --
        # see chat/memory/maximos_client.py)
        cls.MAXIMOS_URL = os.getenv("MAXIMOS_URL", "http://127.0.0.1:7842")
        cls.MAXIMOS_GLOBAL_KEY = os.getenv("MAXIMOS_GLOBAL_KEY")

        # Email
        cls.SMTP_HOST = os.getenv("SMTP_HOST")
        cls.SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
        cls.SMTP_USER = os.getenv("SMTP_USER")
        cls.SMTP_PASSWORD = os.getenv("SMTP_PASSWORD")

        # UI Bridge (desktop/DOM automation)
        cls.UI_BRIDGE_URL = os.getenv("UI_BRIDGE_URL", "http://127.0.0.1:8123")

        cls._seed_writable_root()

        # Ensure required directories exist
        cls.DATA_DIR.mkdir(parents=True, exist_ok=True)
        (cls.DATA_DIR / "users").mkdir(parents=True, exist_ok=True)
        (cls.VAULT_DIR / "users").mkdir(parents=True, exist_ok=True)

        cls._validate()

    @classmethod
    def _seed_writable_root(cls) -> None:
        """
        First run only, and only when WRITABLE_ROOT is an override (i.e. a
        packaged install writing outside BACKEND_DIR): copy the shipped
        default data/vault trees from BACKEND_DIR into WRITABLE_ROOT so the
        stub users.json/sessions.json and any bundled default assets are
        present the first time the app runs as this Windows user. No-op on
        every subsequent run once WRITABLE_ROOT/data and /vault exist.
        """
        if not cls._USER_DATA_OVERRIDE:
            return

        for name in ("data", "vault"):
            dest = cls.WRITABLE_ROOT / name
            src = cls.BACKEND_DIR / name
            if dest.exists() or not src.exists():
                continue
            try:
                shutil.copytree(src, dest)
            except OSError:
                dest.mkdir(parents=True, exist_ok=True)

    # ---------------------------------------------------------
    # Validation
    # ---------------------------------------------------------
    @classmethod
    def _validate(cls):
        """
        Validate required environment variables.
        We do NOT require all provider keys — only the ones the user wants to use.
        """

        # Redis is required for chat history buffer
        if not cls.REDIS_URL:
            raise EnvError("REDIS_URL is required but missing.")

        # Vault directory must exist
        if not cls.VAULT_DIR.exists():
            raise EnvError(f"Vault directory missing: {cls.VAULT_DIR}")

    # ---------------------------------------------------------
    # Summary
    # ---------------------------------------------------------
    @classmethod
    def summary(cls) -> dict:
        """
        Return a safe summary of loaded environment settings.
        (Does NOT include secrets.)
        """
        return {
            "root_dir": str(cls.ROOT_DIR),
            "backend_dir": str(cls.BACKEND_DIR),
            "data_dir": str(cls.DATA_DIR),
            "vault_dir": str(cls.VAULT_DIR),
            "redis_url": cls.REDIS_URL,
            "email_enabled": bool(cls.SMTP_USER and cls.SMTP_PASSWORD),
            "ui_bridge_url": cls.UI_BRIDGE_URL,
        }
