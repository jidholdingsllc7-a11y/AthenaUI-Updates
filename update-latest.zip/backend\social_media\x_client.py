# AthenaUI -- X (Twitter) API v2 Client
# File: backend/social_media/x_client.py
#
# Minimal OAuth1.0a "user context" signed client for posting a Tweet via
# X API v2 (POST /2/tweets). Uses `requests_oauthlib.OAuth1` for the actual
# HMAC-SHA1 signing (rather than hand-rolling percent-encoding/signature
# logic) since a well-tested library is safer than a bespoke implementation
# of a security-sensitive signing scheme. The (synchronous) `requests` call
# is offloaded to a worker thread via `asyncio.to_thread` so this client
# still presents an async interface consistent with the other social_media
# clients (facebook_client.py, moltbook_client.py) and the rest of the
# backend's async route/tool handlers.

from __future__ import annotations

import asyncio
from typing import Any, Dict

import requests
from requests_oauthlib import OAuth1

BASE_URL = "https://api.twitter.com/2"

# Standard (non-upgraded / non-Premium) X post character limit.
STANDARD_CHAR_LIMIT = 280
# "Upgraded"/Premium (X Premium+/verified organizations) character limit.
UPGRADED_CHAR_LIMIT = 25000


class XError(Exception):
    pass


class XClient:
    def __init__(
        self,
        api_key: str,
        api_secret: str,
        access_token: str,
        access_token_secret: str,
        bearer_token: str = "",
    ):
        self._auth = OAuth1(
            client_key=api_key,
            client_secret=api_secret,
            resource_owner_key=access_token,
            resource_owner_secret=access_token_secret,
        )
        # Not used for posting/verify_credentials (both require the OAuth1
        # user-context signing above) -- stored for app-only v2 endpoints
        # (e.g. rate-limit/read lookups) that accept a plain bearer token.
        self.bearer_token = bearer_token

    def _post_tweet_sync(self, text: str) -> Dict[str, Any]:
        resp = requests.post(
            f"{BASE_URL}/tweets",
            json={"text": text},
            auth=self._auth,
            timeout=20,
        )
        if resp.status_code >= 400:
            raise XError(f"X API error {resp.status_code}: {resp.text[:500]}")
        return resp.json()

    async def post_tweet(self, text: str) -> Dict[str, Any]:
        result = await asyncio.to_thread(self._post_tweet_sync, text)
        # POST /2/tweets' own response only ever echoes a short/legacy-length
        # `text` for long-form (>280 char, X Premium "Note Tweet") posts -- the
        # authoritative full text lives in `note_tweet.text` and is only
        # obtainable via a follow-up GET with tweet.fields=note_tweet, never on
        # the create response itself. Read it back here so callers (and the
        # user) get a verified full-text confirmation instead of having to
        # check X manually.
        tweet_id = (result.get("data") or {}).get("id")
        if tweet_id:
            try:
                verify = await asyncio.to_thread(self._get_tweet_sync, tweet_id)
                verified_data = verify.get("data") or {}
                full_text = (verified_data.get("note_tweet") or {}).get("text") or verified_data.get("text")
                if full_text:
                    result["data"]["verified_text"] = full_text
                    result["data"]["verified_length"] = len(full_text)
            except XError:
                pass  # best-effort: the post itself already succeeded, a failed read-back shouldn't fail the whole call
        return result

    def _verify_credentials_sync(self) -> Dict[str, Any]:
        resp = requests.get(
            "https://api.twitter.com/1.1/account/verify_credentials.json",
            auth=self._auth,
            timeout=20,
        )
        if resp.status_code >= 400:
            raise XError(f"X rejected these credentials (HTTP {resp.status_code}): {resp.text[:500]}")
        return resp.json()

    async def verify_credentials(self) -> Dict[str, Any]:
        return await asyncio.to_thread(self._verify_credentials_sync)

    def _get_me_sync(self) -> Dict[str, Any]:
        resp = requests.get(f"{BASE_URL}/users/me", auth=self._auth, timeout=20)
        if resp.status_code >= 400:
            raise XError(f"X API error {resp.status_code}: {resp.text[:500]}")
        return resp.json()

    async def get_me(self) -> Dict[str, Any]:
        """The authenticated account's own user id/username -- needed by the like/retweet endpoints."""
        return await asyncio.to_thread(self._get_me_sync)

    def _get_mentions_sync(self, user_id: str, since_id: str = "", max_results: int = 10) -> Dict[str, Any]:
        params: Dict[str, Any] = {
            "max_results": max(5, min(int(max_results or 10), 100)),
            "tweet.fields": "created_at,author_id,conversation_id",
            "expansions": "author_id",
            "user.fields": "username,name",
        }
        if since_id:
            params["since_id"] = since_id
        resp = requests.get(
            f"{BASE_URL}/users/{user_id}/mentions",
            params=params,
            auth=self._auth,
            timeout=20,
        )
        if resp.status_code >= 400:
            raise XError(f"X API error {resp.status_code}: {resp.text[:500]}")
        return resp.json()

    async def get_mentions(self, user_id: str, since_id: str = "", max_results: int = 10) -> Dict[str, Any]:
        return await asyncio.to_thread(self._get_mentions_sync, user_id, since_id, max_results)

    def _reply_tweet_sync(self, text: str, in_reply_to_tweet_id: str) -> Dict[str, Any]:
        resp = requests.post(
            f"{BASE_URL}/tweets",
            json={"text": text, "reply": {"in_reply_to_tweet_id": in_reply_to_tweet_id}},
            auth=self._auth,
            timeout=20,
        )
        if resp.status_code >= 400:
            raise XError(f"X API error {resp.status_code}: {resp.text[:500]}")
        return resp.json()

    async def reply_tweet(self, text: str, in_reply_to_tweet_id: str) -> Dict[str, Any]:
        return await asyncio.to_thread(self._reply_tweet_sync, text, in_reply_to_tweet_id)

    def _like_tweet_sync(self, user_id: str, tweet_id: str) -> Dict[str, Any]:
        resp = requests.post(
            f"{BASE_URL}/users/{user_id}/likes",
            json={"tweet_id": tweet_id},
            auth=self._auth,
            timeout=20,
        )
        if resp.status_code >= 400:
            raise XError(f"X API error {resp.status_code}: {resp.text[:500]}")
        return resp.json()

    async def like_tweet(self, user_id: str, tweet_id: str) -> Dict[str, Any]:
        return await asyncio.to_thread(self._like_tweet_sync, user_id, tweet_id)

    def _retweet_sync(self, user_id: str, tweet_id: str) -> Dict[str, Any]:
        resp = requests.post(
            f"{BASE_URL}/users/{user_id}/retweets",
            json={"tweet_id": tweet_id},
            auth=self._auth,
            timeout=20,
        )
        if resp.status_code >= 400:
            raise XError(f"X API error {resp.status_code}: {resp.text[:500]}")
        return resp.json()

    async def retweet(self, user_id: str, tweet_id: str) -> Dict[str, Any]:
        return await asyncio.to_thread(self._retweet_sync, user_id, tweet_id)

    def _get_tweet_sync(self, tweet_id: str) -> Dict[str, Any]:
        resp = requests.get(
            f"{BASE_URL}/tweets/{tweet_id}",
            params={
                # note_tweet carries the full text for long-form (>280 char)
                # posts -- the default `text` field alone is not reliable for
                # those (see X's data dictionary: "note_tweet ... Get the
                # complete text of a post").
                "tweet.fields": "created_at,author_id,conversation_id,public_metrics,note_tweet",
                "expansions": "author_id",
                "user.fields": "username,name",
            },
            auth=self._auth,
            timeout=20,
        )
        if resp.status_code >= 400:
            raise XError(f"X API error {resp.status_code}: {resp.text[:500]}")
        return resp.json()

    async def get_tweet(self, tweet_id: str) -> Dict[str, Any]:
        """Look up any single public post by id/URL -- read-only, no automation-rules restriction."""
        return await asyncio.to_thread(self._get_tweet_sync, tweet_id)

    def _get_dm_events_sync(self, since_id: str = "", max_results: int = 10) -> Dict[str, Any]:
        params: Dict[str, Any] = {
            "max_results": max(1, min(int(max_results or 10), 100)),
            "dm_event.fields": "created_at,sender_id,dm_conversation_id,text",
            "expansions": "sender_id",
            "user.fields": "username,name",
        }
        if since_id:
            params["since_id"] = since_id
        resp = requests.get(
            f"{BASE_URL}/dm_events",
            params=params,
            auth=self._auth,
            timeout=20,
        )
        if resp.status_code >= 400:
            raise XError(f"X API error {resp.status_code}: {resp.text[:500]}")
        return resp.json()

    async def get_dm_events(self, since_id: str = "", max_results: int = 10) -> Dict[str, Any]:
        return await asyncio.to_thread(self._get_dm_events_sync, since_id, max_results)

    def _send_dm_sync(self, participant_id: str, text: str) -> Dict[str, Any]:
        resp = requests.post(
            f"{BASE_URL}/dm_conversations/with/{participant_id}/messages",
            json={"text": text},
            auth=self._auth,
            timeout=20,
        )
        if resp.status_code >= 400:
            raise XError(f"X API error {resp.status_code}: {resp.text[:500]}")
        return resp.json()

    async def send_dm(self, participant_id: str, text: str) -> Dict[str, Any]:
        return await asyncio.to_thread(self._send_dm_sync, participant_id, text)
