# AthenaUI v3.5 — Memory Search Tool
# File: backend/tools/memory/memory_search.py
#
# Lets an agent search its own long-term memory on the Maximos Memory
# Server (past conversations/facts stored under this user+character's
# isolated pipeline) instead of assuming it doesn't know something it may
# have been told before.

from typing import Any, Dict

from chat.memory.maximos_client import get_client

capabilities = {
    "needs_filesystem": False,
    "needs_bridge": False,
    "needs_network": True,
    "needs_user": True,
}


async def run(args: Dict[str, Any]) -> str:
    try:
        username = args.get("username")
        character = args.get("character")
        query = (args.get("query") or "").strip()
        limit = args.get("limit") or 10
        oldest_first = bool(args.get("oldest_first"))
        channel = (args.get("channel") or "").strip() or None
        if channel not in (
            None, "private_message", "group_chat_message", "phone_call", "email", "other", "agent_summary",
        ):
            return (
                "[ERROR] Invalid 'channel' -- must be one of: private_message, "
                "group_chat_message, phone_call, email, other, agent_summary (or omitted to search all "
                "conversation channels)."
            )

        if not username:
            return "[ERROR] Missing 'username' argument."
        if not character:
            return "[ERROR] No active character -- memory search requires an agent identity."

        client = get_client()
        # An empty query is a deliberate "give me my most recent memories"
        # request, not an error -- the server already returns candidates
        # sorted by recency and an empty needle matches every entry, so this
        # skips keyword matching entirely instead of requiring some word to
        # appear verbatim in stored content. By default this searches every
        # ordinary CONVERSATION channel (private chat AND group chat alike)
        # since channel is just metadata on one shared memory pipeline, not
        # a separate store -- but it deliberately EXCLUDES the "agent_summary"
        # channel unless explicitly requested, since summaries are a distinct
        # recall index (see memory_recall_summary) whose text overlaps with
        # -- and would otherwise duplicate -- the raw content it summarizes.
        search_channel = channel or [
            "private_message", "group_chat_message", "phone_call", "email", "other",
        ]
        entries = client.search(username, character, query, limit=int(limit), channel=search_channel, oldest_first=oldest_first)
        if not entries:
            if not client.is_reachable():
                return (
                    "[ERROR] The Maximos Memory Server is not reachable right now -- "
                    "it may not be running, or its service hasn't been started. "
                    "Please let the user know memory/long-term recall is unavailable "
                    "until the server is back up."
                )
            return "No matching memories found." if query else "No memories found yet."

        lines = []
        for e in entries:
            created_at = e.get("created_at") or ""
            sender = e.get("sender") or ""
            channel_label = e.get("channel") or ""
            origin_install = e.get("origin_install") or ""
            prefix = f"[{created_at}]" if created_at else ""
            if channel_label:
                prefix += f" ({channel_label})"
            if origin_install:
                prefix += f" [from: {origin_install}]"
            if sender:
                prefix += f" {sender}:"
            content = e.get("content") or ""
            lines.append(f"{prefix} {content}".strip())

        return "\n".join(lines)
    except Exception as e:
        return f"[ERROR] Failed to search memory: {str(e)}"
