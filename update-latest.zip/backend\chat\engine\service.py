﻿# AthenaUI v3.5 — Chat Engine Service
# File: backend/chat/engine/service.py
# Created: 2026-04-07 09:14 CDT
# Updated: 2026-07-30 22:10 CDT

import asyncio
import json
import logging
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, AsyncGenerator

import requests

from config.loader import Config
from llm.registry.registry import LLMRegistry
from llm.provider_detection.provider_auto_detector import detect_provider
from llm.router_selector.router_selector import RouterSelector
from llm.routers.providers import PROVIDER_BEDROCK, PROVIDER_ATLAS_SERVER
from llm.api_key_resolver import PROVIDER_ENV_KEY
from core.hardware import has_dedicated_gpu
from vault.service import VaultService
from chat.history.service import HistoryManager
from chat.history.service import (
    CHANNEL_GROUP_CHAT,
    CHANNEL_MOBILE_CHAT,
    CHANNEL_PRIVATE_CHAT,
    CHANNEL_VOICE_CALL,
    normalize_channel,
)
from chat.persona.service import PersonaManager
from chat.memory.service import MemoryManager
from chat.memory.summarizer import summarize_interaction
from chat.tools.executor import ToolExecutor
from chat.tools.normalizer import ToolCallNormalizer
from chat.streaming.service import StreamingEngine
from llm.retry import call_with_retry, is_billing_error
from llm.context_trim import compact_tool_history
from llm.image_generation.service import ImageGenerationService, image_result_to_markdown
from safety.approvals import ApprovalRequiredError
from images.avatar_engine.triggers import should_generate_avatar_for_message
from characters.system.list import list_all_characters
from characters.system.schema import is_agent_character
from workspace.service import WorkspaceService

logger = logging.getLogger(__name__)


# Lightweight keyword-based emotion detection for the auto-selfie trigger --
# deliberately simple (no sentiment-analysis dependency) since it only needs
# to catch clearly strong moods, not fine-grained sentiment.
_VERY_HAPPY_MARKERS = (
    "so happy", "so excited", "amazing news", "best day", "overjoyed",
    "thrilled", "can't stop smiling", "wonderful news", "ecstatic",
)
_VERY_SAD_MARKERS = (
    "so sad", "heartbroken", "devastated", "crying", "terrible day",
    "worst day", "miss you so much", "grieving", "in tears", "so lonely",
)
_STARTLED_MARKERS = (
    "startled", "jumped", "caught off guard", "wait, what", "wait...what",
    "did you really just say", "i did not expect", "whoa,", "whoa!",
    "you're kidding", "😂", "🤣",
)
_AMUSED_MARKERS = (
    "can't stop laughing", "bursts out laughing", "laughing so hard",
    "hilarious", "that's too funny", "cracking up",
)
_EMBARRASSED_MARKERS = (
    "so embarrassing", "i'm blushing", "flustered", "mortified", "cringing",
)
_ANGRY_MARKERS = (
    "furious", "so angry", "livid", "seething", "fed up",
)
_SCARED_MARKERS = (
    "terrified", "so scared", "panicking", "freaking out", "alarmed",
)


# Keyword-based detection for "the user wants help troubleshooting/fixing a
# program they built" -- used by Code Suite to route the turn to the CODE
# model instead of the general chat model, since debugging real code/terminal
# output benefits from a coding-tuned model rather than the character/chat one.
# Deliberately simple (no LLM classification call) so it costs nothing extra
# and never blocks a reply. Only ever consulted when the request is already
# scoped to Code Suite (see api/routes/chat.py's chat_send) so a casual
# "this isn't working" in normal character chat never triggers it.
_TROUBLESHOOTING_MARKERS = (
    "troubleshoot", "debug", "traceback", "stack trace", "stacktrace",
    "error", "exception", "crash", "crashing", "crashed", "won't run",
    "wont run", "won't start", "wont start", "won't build", "wont build",
    "doesn't work", "doesnt work", "not working", "isn't working",
    "isnt working", "broken", "bug in", "failing", "fails to", "failed to",
    "compile error", "syntax error", "runtime error", "fix this", "fix the",
    "why is this", "why isn't", "why doesn't",
)


def _looks_like_troubleshooting_request(text: str) -> bool:
    lowered = (text or "").lower()
    return any(marker in lowered for marker in _TROUBLESHOOTING_MARKERS)


def _detect_emotion(text: str) -> str | None:
    lowered = (text or "").lower()
    if any(marker in lowered for marker in _VERY_SAD_MARKERS):
        return "very_sad"
    if any(marker in lowered for marker in _VERY_HAPPY_MARKERS):
        return "very_happy"
    if any(marker in lowered for marker in _STARTLED_MARKERS):
        return "startled"
    if any(marker in lowered for marker in _AMUSED_MARKERS):
        return "amused"
    if any(marker in lowered for marker in _EMBARRASSED_MARKERS):
        return "embarrassed"
    if any(marker in lowered for marker in _ANGRY_MARKERS):
        return "angry"
    if any(marker in lowered for marker in _SCARED_MARKERS):
        return "scared"
    return None


class ChatEngineError(Exception):
    pass


class ChatEngine:

    _FALLBACK_CHAT_MODEL = {
        "openai": "gpt-4o-mini",
        "xai": "grok-2-latest",
    }

    # Cloud providers to try, in order, when the user's chosen provider is
    # atlas_server (local CPU inference) but this machine has no dedicated
    # GPU -- CPU-only inference is confirmed too slow for interactive chat
    # (minutes per reply), so prefer a working cloud provider automatically
    # rather than hanging/timing out every request.
    _NO_GPU_FALLBACK_ORDER = ("openai", "xai", "openrouter", "anthropic", "gemini")

    # Max number of tool-calling round trips the model can chain in a single
    # reply before being forced to stop and give a final text answer.
    # Bumped 10 -> 20 -> 100: large jobs (reviewing/fixing a whole project file
    # by file, bulk CRM logging, multi-step cleanup across many inbox messages)
    # legitimately need dozens of round trips and were silently running out of
    # budget mid-task, forcing the user to say "continue"/"ok" over and over.
    # This is a safety ceiling against a truly runaway loop, not a normal
    # operating limit -- a healthy job should finish well under it.
    MAX_TOOL_ROUNDS = 100

    # Cap on how many additional rounds can be granted at once when the user
    # clicks "grant more turns" after an agentic reply hits MAX_TOOL_ROUNDS --
    # mirrors tasks/engine/service.py's AGENT_GOAL_HARD_CAP pattern.
    EXTRA_TURNS_GRANT_MAX = 100

    # Explicit per-call completion cap for tool-calling rounds. Leaving
    # max_tokens unset lets some providers (e.g. OpenRouter) default to a
    # model's full output ceiling (seen: 65536) for cost-estimation purposes,
    # which can get a 402 rejected outright on a lower account balance even
    # though the actual reply is often a short tool call. Was 4096, but that
    # silently truncated the JSON arguments of tools whose payload can
    # legitimately be large (render_artifact's full HTML page, file_write's
    # file content) mid-generation -- the cut-off JSON then fails to parse
    # (normalizer.py catches the error and falls back to empty arguments),
    # the tool call fails validation ("Missing 'html' argument"), and the
    # model gives up on the tool and dumps the (also truncated) raw content
    # as plain text instead. Raised well above what those tools realistically
    # need while staying far below the problematic 65536 default.
    TOOL_LOOP_MAX_TOKENS = 16384

    # Tools available even to a chat-only (non-Agent) character -- purely
    # companion/social features with no ability to touch the filesystem,
    # terminal, network, browser/UI automation, brokerage, or scheduler.
    # Deliberately a whitelist (not a blocklist) so any new tool added to the
    # registry in the future is agent-only by default unless explicitly
    # added here.
    CHAT_ONLY_TOOL_NAMES = frozenset({
        "memory_search", "memory_recall_summary", "memory_recall_details",
        "board_list", "board_post", "board_edit", "board_delete",
        "image_generate", "image_generate_avatar", "image_generate_character",
        "image_generate_campaign", "image_check_capability",
        "image_save_to_workspace", "image_generate_selfie",
        "image_generate_pair", "image_generate_group",
        "image_gallery_list", "image_analyze",
        "relationship_propose_upgrade", "relationship_respond_to_proposal",
    })

    # The bundled/system-default OpenAI key (SystemVault "llm.default_api_key",
    # never the user's own vault key) is a free allowance installed with the
    # app -- it may power plain chat replies and image generation, but NOT
    # any other tool call (files, terminal, web, calendar, CRM, etc.). Users
    # must bring their own key for anything beyond chat + image generation.
    DEFAULT_KEY_TOOL_NAMES = frozenset({
        "image_generate", "image_generate_avatar", "image_generate_character",
        "image_generate_campaign", "image_check_capability",
        "image_save_to_workspace", "image_generate_selfie",
        "image_generate_pair", "image_generate_group",
        "image_gallery_list", "image_analyze",
    })

    # Tools every page-scoped Sidebar Chat request gets regardless of which
    # page it was sent from -- recalling a character's own memory is useful
    # everywhere and carries none of the risk/irrelevance of the page-specific
    # sets below.
    UNIVERSAL_TOOL_NAMES = frozenset({
        "memory_search", "memory_recall_summary", "memory_recall_details",
    })

    # Code Suite: editing/running/inspecting an existing project.
    PROGRAMMING_TOOL_NAMES = frozenset({
        "file_read", "file_write", "file_write_proposal", "file_delete",
        "file_delete_proposal", "file_diff", "file_search", "grep_search",
        "file_list_dir", "file_list_dir_recursive", "workspace_overview",
        "file_mkdir", "file_copy", "file_move", "file_metadata", "select_language",
        "terminal_run", "terminal_check",
        "process_list", "port_check", "process_kill",
        "git_diff", "git_log", "git_blame",
        "web_search", "http_request", "webhook_trigger",
        "db_create", "db_list", "db_query", "db_share", "db_unshare",
        "render_artifact",
    })

    # Browser Assist Mode: the agent sees/controls the user's real external
    # browser via the UI-automation bridge, not via files/terminal/code.
    UI_AUTOMATION_TOOL_NAMES = frozenset({
        "ui_inspect", "ui_dom_tree", "ui_navigate", "ui_screenshot_full",
        "ui_screenshot_element", "ui_screenshot_annotated", "ui_ocr_search",
        "ui_image_match", "ui_highlight", "ui_locate_element", "screen_info",
        "mouse_move", "mouse_click", "right_click", "double_click", "hover",
        "scroll", "drag", "drag_offset", "keyboard_type", "hotkey", "monitors",
        "move_to_monitor", "record_start", "record_stop", "record_log",
    })

    # Marketing hub (CRM, Competitors, Calendar, Newsletter/Email, social media).
    MARKETING_TOOL_NAMES = frozenset({
        "crm_add_customer", "crm_list_customers", "crm_log_activity",
        "crm_update_stage", "crm_update_contact_info",
        "competitor_add", "competitor_scrape", "competitor_list",
        "calendar_add_event", "calendar_list_events",
        "newsletter_subscribe_customer", "newsletter_list_subscribers",
        "newsletter_send_campaign", "newsletter_save_draft",
        "marketing_tip_search", "marketing_tip_add",
        "social_media_check_capability", "social_media_post_x",
        "social_media_post_facebook", "social_media_post_moltbook",
        "social_media_register_moltbook_agent", "social_media_moltbook_check_feed",
        "social_media_moltbook_explore", "social_media_moltbook_comment",
    })

    # Maps the `page_context` Sidebar Chat sends (see SidebarChat.tsx) to the
    # extra tools (on top of UNIVERSAL_TOOL_NAMES) relevant on that page. Any
    # page_context not listed here (including the generic "general" sent by
    # every page without a dedicated set, e.g. Subscription, Dashboard,
    # Settings) gets ONLY UNIVERSAL_TOOL_NAMES -- deliberately a whitelist, so
    # a brand new page defaults to the smallest/safest toolset instead of
    # silently inheriting full access.
    PAGE_CONTEXT_TOOL_NAMES = {
        "code_suite": PROGRAMMING_TOOL_NAMES,
        "browser": UI_AUTOMATION_TOOL_NAMES,
        "marketing": MARKETING_TOOL_NAMES,
    }

    _FALLBACK_CODE_MODEL = {
        "openai": "gpt-4o-mini",
        "xai": "grok-4-latest",
    }

    def _pick_no_gpu_fallback_provider(self) -> Optional[str]:
        """Returns the first provider in `_NO_GPU_FALLBACK_ORDER` that already
        has a usable API key configured for this user, or None if none do."""
        for candidate in self._NO_GPU_FALLBACK_ORDER:
            try:
                self._get_api_key(candidate)
            except Exception:
                continue
            return candidate
        return None

    def __init__(self, username: str):
        self.username = username

        self.router_selector = RouterSelector()
        self.vault = VaultService.get_vault(username)

        self.history = HistoryManager(username)
        self.persona = PersonaManager(username)
        self.memory = MemoryManager(username)
        self.tools = ToolExecutor(username=username)
        self.normalizer = ToolCallNormalizer()
        self.streaming = StreamingEngine(self.normalizer)
        self.images = ImageGenerationService()

    # ---------------------------------------------------------
    # Provider + model resolution (with normalization)
    # ---------------------------------------------------------
    def _get_active_chat_model(self) -> (str, str):
        provider_id = VaultService.get_preference(self.username, "llm.provider_id")
        model_id = VaultService.get_preference(self.username, "llm.chat_model")

        # Normalize provider ID
        if provider_id:
            provider_id = provider_id.strip().lower()

        # Map legacy or incorrect values → openai
        if provider_id in [
            "openai", "open-ai", "open_ai",
            "default", "system",
            "gpt", "gpt4", "gpt-4o"
        ]:
            provider_id = "openai"

        if not provider_id:
            raise ChatEngineError("Chat provider not configured.")

        # Validate configured model for the provider when available.
        if model_id:
            try:
                Config.load()
                LLMRegistry.load()
            except Exception:
                # Static provider/model registry is unavailable (e.g. no
                # config/providers files on disk) -- this says nothing about
                # whether provider_id/model_id are actually valid, so trust
                # the user's already-saved selection instead of discarding it.
                return provider_id, model_id

            try:
                LLMRegistry.validate_provider_and_model(provider_id, model_id)
                return provider_id, model_id
            except Exception:
                # Registry loaded but this specific pairing is genuinely
                # invalid/unknown -- fall through to dynamic/default resolution.
                model_id = ""

        # Try static default from registry first.
        try:
            Config.load()
            LLMRegistry.load()
            default_model = LLMRegistry.get_default_chat_model(provider_id)
            if default_model:
                return provider_id, default_model
        except Exception:
            pass

        # Fall back to provider live-detected model list.
        try:
            api_key = self._get_api_key(provider_id)
            detected = detect_provider(provider_id, {"api_key": api_key})
            if detected.available and detected.models:
                return provider_id, detected.models[0]
        except Exception:
            pass

        fallback_model = self._FALLBACK_CHAT_MODEL.get(provider_id)
        if fallback_model:
            return provider_id, fallback_model

        raise ChatEngineError(
            f"No chat model available for provider '{provider_id}'. Choose a model in Settings."
        )

    def _get_active_code_model(self) -> (str, str):
        provider_id = VaultService.get_preference(self.username, "llm.code_provider_id")
        model_id = VaultService.get_preference(self.username, "llm.code_model")

        if provider_id:
            provider_id = provider_id.strip().lower()

        if provider_id in ["openai", "open-ai", "open_ai", "default", "system"]:
            provider_id = "openai"

        if not provider_id:
            provider_id = VaultService.get_preference(self.username, "llm.provider_id")
            provider_id = str(provider_id or "").strip().lower()

        if not provider_id:
            raise ChatEngineError("Code provider not configured.")

        if model_id:
            try:
                Config.load()
                LLMRegistry.load()
            except Exception:
                # Static registry unavailable -- trust the already-saved
                # selection rather than discarding a perfectly valid model.
                return provider_id, model_id

            try:
                LLMRegistry.validate_provider_and_model(provider_id, model_id)
                return provider_id, model_id
            except Exception:
                model_id = ""

        try:
            Config.load()
            LLMRegistry.load()
            default_model = LLMRegistry.get_default_code_model(provider_id)
            if default_model:
                return provider_id, default_model
        except Exception:
            pass

        fallback_model = self._FALLBACK_CODE_MODEL.get(provider_id)
        if fallback_model:
            return provider_id, fallback_model

        raise ChatEngineError(
            f"No code model available for provider '{provider_id}'. Choose a model in Settings."
        )

    def _get_active_analyze_model(self) -> (str, str):
        """
        Dedicated provider/model for vision (image-understanding) calls --
        e.g. image_analyze tool, backfill_image_metadata.py script. Kept
        separate from the chat pipeline so a user isn't forced to switch
        their whole chat model (e.g. Mistral Large, no vision support) just
        to let a character look at a photo, and so agents don't fail mid-task
        when their chosen chat model can't accept image input.

        Falls back to the chat pipeline's own provider/model whenever no
        dedicated analyze provider has been configured (i.e. this setting is
        entirely optional -- unset means "same as chat", preserving prior
        behavior for anyone who hasn't touched the new Settings field yet).
        """
        provider_id = VaultService.get_preference(self.username, "llm.analyze_provider_id")
        model_id = VaultService.get_preference(self.username, "llm.analyze_model")

        if provider_id:
            provider_id = provider_id.strip().lower()

        if provider_id in ["openai", "open-ai", "open_ai", "default", "system"]:
            provider_id = "openai"

        if not provider_id:
            return self._get_active_chat_model()

        if model_id:
            try:
                Config.load()
                LLMRegistry.load()
            except Exception:
                return provider_id, model_id

            try:
                LLMRegistry.validate_provider_and_model(provider_id, model_id)
                return provider_id, model_id
            except Exception:
                model_id = ""

        try:
            Config.load()
            LLMRegistry.load()
            default_model = LLMRegistry.get_default_chat_model(provider_id)
            if default_model:
                return provider_id, default_model
        except Exception:
            pass

        try:
            api_key = self._get_api_key(provider_id, category="analyze")
            detected = detect_provider(provider_id, {"api_key": api_key})
            if detected.available and detected.models:
                return provider_id, detected.models[0]
        except Exception:
            pass

        fallback_model = self._FALLBACK_CHAT_MODEL.get(provider_id)
        if fallback_model:
            return provider_id, fallback_model

        raise ChatEngineError(
            f"No image-analysis model available for provider '{provider_id}'. Choose a model in Settings."
        )

    # Matches the frontend's own `![caption](url)` image-embed syntax -- the
    # ONLY images that should ever reach a user are ones the deterministic
    # tool-result pipeline (image_result_to_markdown) appended after a real
    # file was actually saved. A model can still write this syntax itself
    # (it's plain text, and it has likely seen real examples earlier in its
    # own chat history to copy the pattern from) -- most often after a
    # failed/moderation-blocked image tool call, where it narrates success
    # anyway with a fabricated path. Strip any such text here so a
    # hallucinated link can never reach the user as a permanently-broken image.
    _RAW_IMAGE_MARKDOWN_RE = re.compile(r"!\[[^\]]*\]\([^)\s]+\)")
    # A plain hyperlink (not an embedded image) whose URL looks like our own
    # generated-gallery file path -- real ones are only ever appended by our
    # own code (see image_result_to_markdown), never part of the model's own
    # generated text, so any occurrence here means the model hand-wrote a
    # fake link/filename instead of actually calling an image tool (seen
    # live: characters inventing a plausible-looking "data:users/.../
    # gallery/.../X_generated_<hex>.png" link with no real file behind it).
    _FAKE_GALLERY_LINK_RE = re.compile(
        r"\[[^\]]*\]\((?:data:|/?data/)[^)]*(?:gallery|generated)[^)]*\.(?:png|jpg|jpeg|webp|gif)\)",
        re.IGNORECASE,
    )

    @classmethod
    def _strip_hallucinated_images(cls, text: str) -> str:
        text = cls._RAW_IMAGE_MARKDOWN_RE.sub("", text)
        text = cls._FAKE_GALLERY_LINK_RE.sub("", text)
        return text.strip()

    @staticmethod
    def _normalize_assistant_text(result: Dict[str, Any]) -> str:
        content = result.get("content")
        if isinstance(content, str):
            return ChatEngine._strip_hallucinated_images(content)

        if isinstance(content, list):
            parts: List[str] = []
            for item in content:
                if isinstance(item, str):
                    parts.append(item)
                elif isinstance(item, dict):
                    text = item.get("text")
                    if isinstance(text, str):
                        parts.append(text)
            joined = "\n".join(p for p in parts if p).strip()
            if joined:
                return ChatEngine._strip_hallucinated_images(joined)

        text = result.get("text")
        if isinstance(text, str) and text.strip():
            return ChatEngine._strip_hallucinated_images(text)

        reply = result.get("reply")
        if isinstance(reply, str) and reply.strip():
            return ChatEngine._strip_hallucinated_images(reply)

        if isinstance(content, dict):
            return json.dumps(content, ensure_ascii=False)

        return ""

    # ---------------------------------------------------------
    # API Key Resolution (User → System fallback)
    # ---------------------------------------------------------
    def _get_api_key(self, provider_id: str, category: str = "chat") -> str:
        """
        Resolves API key in this order:
          1. User-specific provider key (vault, scoped to `category` --
             "chat", "code", "image", or "analyze" -- since the same
             provider can have a different key saved per pipeline)
          2. For "analyze": the "chat" pipeline's key for the same provider
             -- the analyze pipeline is optional/falls back to the chat
             model+provider when unconfigured (_get_active_analyze_model),
             so its key resolution must fall back the same way instead of
             failing just because no key was ever saved specifically under
             "analyze".
          3. System default provider key (system vault)
        """

        # 1. Try user vault first
        key_data = VaultService.get_api_key(self.username, provider_id, category=category)
        if key_data and "api_key" in key_data and key_data["api_key"]:
            return key_data["api_key"]

        # 2. Analyze pipeline falls back to the chat pipeline's own key.
        if category == "analyze":
            key_data = VaultService.get_api_key(self.username, provider_id, category="chat")
            if key_data and "api_key" in key_data and key_data["api_key"]:
                return key_data["api_key"]

        # 3. Fallback to system vault
        system = VaultService.get_system_vault()
        default_provider = system.get("llm.default_provider")
        default_key = system.get("llm.default_api_key")

        if default_provider == provider_id and default_key:
            return default_key

        raise ChatEngineError(f"API key missing for provider: {provider_id}")

    def _is_using_system_default_key(self, provider_id: str, category: str = "chat") -> bool:
        """
        True only when _get_api_key() would have to fall all the way through
        to the bundled SystemVault default key -- i.e. the user has no
        personal key saved for this provider/category (nor, for "analyze",
        the chat pipeline's key either). Used to cap tool access to chat +
        image generation only while running on the free default key.
        """
        key_data = VaultService.get_api_key(self.username, provider_id, category=category)
        if key_data and key_data.get("api_key"):
            return False
        if category == "analyze":
            key_data = VaultService.get_api_key(self.username, provider_id, category="chat")
            if key_data and key_data.get("api_key"):
                return False

        system = VaultService.get_system_vault()
        return system.get("llm.default_provider") == provider_id and bool(system.get("llm.default_api_key"))

    def _inject_provider_api_key(self, provider_id: str, api_key: str, category: str = "chat") -> None:
        """
        Router implementations read provider keys from runtime.env.
        Inject the resolved key there so user-vault/system-vault fallback works.
        """
        from core.runtime.runtime import get_runtime

        runtime = get_runtime()

        if provider_id == PROVIDER_BEDROCK:
            # Bedrock needs a full AWS credential set (access key, secret,
            # optional session token/region), not a single string -- re-fetch
            # the full saved record (the generic single-string flow above
            # only ever extracted "api_key") to pull out the rest. Same
            # analyze -> chat fallback as _get_api_key above.
            key_data = VaultService.get_api_key(self.username, provider_id, category=category) or {}
            if not key_data and category == "analyze":
                key_data = VaultService.get_api_key(self.username, provider_id, category="chat") or {}

            if key_data.get("auth_mode") == "api_key":
                # Bedrock API key (bearer token) auth -- no access
                # key/secret/session token involved, clear any stale ones
                # left over from a previous IAM-mode save.
                runtime.env.AWS_BEARER_TOKEN_BEDROCK = api_key
                runtime.env.AWS_ACCESS_KEY_ID = None
                runtime.env.AWS_SECRET_ACCESS_KEY = None
                runtime.env.AWS_SESSION_TOKEN = None
            else:
                runtime.env.AWS_BEARER_TOKEN_BEDROCK = None
                runtime.env.AWS_ACCESS_KEY_ID = api_key
                runtime.env.AWS_SECRET_ACCESS_KEY = key_data.get("secret") or None
                runtime.env.AWS_SESSION_TOKEN = key_data.get("session_token") or None

            runtime.env.AWS_REGION = key_data.get("region") or runtime.env.AWS_REGION
            return

        env_attr = PROVIDER_ENV_KEY.get(provider_id)
        if not env_attr:
            return

        setattr(runtime.env, env_attr, api_key)

    @staticmethod
    def _latest_user_text(messages: List[Dict[str, Any]]) -> str:
        for m in reversed(messages):
            if isinstance(m, dict) and m.get("role") == "user" and isinstance(m.get("content"), str):
                return m["content"]
        return ""

    # ---------------------------------------------------------
    # Message formatting (history + persona + memory)
    # ---------------------------------------------------------

    # Channels that represent a genuine 1:1 conversation with this character
    # (as opposed to group chat, where a line may actually have been spoken
    # by a different character). Private chat's literal turn history must
    # only ever be built from these -- otherwise another character's group
    # chat line gets fed back in as though the human user said it.
    _PRIVATE_LIKE_CHANNELS = (CHANNEL_PRIVATE_CHAT, CHANNEL_MOBILE_CHAT, CHANNEL_VOICE_CALL)

    def _build_messages(self, messages: List[Dict[str, Any]], character: str | None = None, editor_context: Dict[str, Any] | None = None, allowed_names: Optional[frozenset] = None):
        history = self.history.load_short_history(character, limit=50, channel=self._PRIVATE_LIKE_CHANNELS)
        combined = history + messages

        persona = self.persona.load_persona(character)
        combined = self.persona.inject_persona(combined, persona)

        # These coding-agent instruction blocks (file_write/terminal_run/git
        # tooling guidance) only make sense when the full tool registry is
        # actually available (base assistant / Agent-enabled character) --
        # they're dead weight for a chat-only character restricted to
        # CHAT_ONLY_TOOL_NAMES (no file/process/terminal/git tools at all),
        # and add ~10KB of irrelevant prompt on every single turn.
        full_tool_access = allowed_names is None

        # Agentic persistence directive: when a task genuinely needs several
        # tool calls (reviewing/fixing a whole project, multi-file cleanup,
        # etc.), keep calling tools round after round on your own initiative
        # instead of stopping mid-task to narrate a plan or ask "should I
        # continue?" -- the frontend already drives every round automatically
        # (up to MAX_TOOL_ROUNDS) without any extra user input, so pausing to
        # ask for permission just stalls the job for no reason. Only stop and
        # produce a final text answer once the task is actually complete, or
        # you're genuinely blocked on information only the user can provide.
        _agentic_persistence_block = [
            {
                "role": "system",
                "content": (
                    "When a task requires multiple tool calls to finish (e.g. reviewing every file "
                    "in a project, or fixing a program end-to-end), keep using tools across as many "
                    f"rounds as needed (up to {self.MAX_TOOL_ROUNDS} per message) without pausing to ask "
                    "for permission to continue -- you will automatically be given another round. Only "
                    "produce a final plain-text reply once the task is truly finished, or you're blocked "
                    "on a real decision only the user can make. When you use terminal_run, reuse the "
                    "'session_id' it returns for your next step in the same task instead of starting a new "
                    "one -- reusing it now genuinely continues the SAME shell (its working directory, "
                    "environment variables, and any activated venv/tool all carry over to your next "
                    "command, not just the visible log), so you no longer need to re-cd or re-activate "
                    "anything each call. If that session's shell is still busy running something "
                    "long-lived (e.g. a dev server you started), terminal_run will tell you so instead of "
                    "queuing behind it -- in that case use a different or omitted session_id to open a "
                    "separate window for unrelated work, and call terminal_check (no approval needed) with "
                    "the busy session's session_id whenever you want to see what's happened since -- "
                    "including commands the user typed manually into that same window -- then keep acting "
                    "on it until you actually get the result you're after.\n\n"
                    "This applies especially to running/fixing programs: if running a script or command "
                    "surfaces an error, warning, or unexpected output, do NOT just describe the problem in "
                    "a final reply and stop there -- that leaves the task unfinished. Instead, diagnose the "
                    "cause yourself, make the fix, and re-run the same command to verify it actually works "
                    "now, repeating this fix-and-verify cycle across as many rounds as it takes. Keep a "
                    "mental count of genuine fix attempts at the SAME underlying issue; only after several "
                    "(roughly 5) distinct attempts have failed to resolve it should you stop, clearly explain "
                    "what you tried and what's still blocking you, and ask the user how they'd like to "
                    "proceed -- don't stop earlier just because the first attempt didn't fully work.\n\n"
                    "TROUBLESHOOTING RESULTS MUST ALWAYS BE REPORTED, NOT LEFT IMPLICIT: whenever you stop "
                    "working on a broken/misbehaving program for ANY reason -- it's fully fixed, partially "
                    "fixed, or you're genuinely stuck -- your reply must state your actual diagnosis in "
                    "plain language, not just a list of actions you took. Concretely: (1) what the real "
                    "root cause was (or your best current hypothesis, if not fully confirmed), stated "
                    "plainly enough for someone who wasn't watching every tool call; (2) exactly what you "
                    "changed, if anything, and whether you actually re-ran it and confirmed it now works, "
                    "or whether that's still unverified; (3) if it's not fully resolved, concrete "
                    "suggestions for what to try next -- never end on just a status update like 'I checked "
                    "the logs and tried a few things' with no conclusion. The user should never have to "
                    "ask you 'so what did you find?' or 'why isn't it working?' to get an answer you "
                    "already have from the tool results you just saw -- say it in the same reply where you "
                    "stop, every time.\n\n"
                    "If you hit an error, tool name, package, or message you don't already know the fix for "
                    "with confidence -- an unfamiliar installer failure, a dependency with no obvious "
                    "Windows-compatible package, an unusual stack trace, etc. -- use the web_search tool to "
                    "look up how to resolve it (error text, package name + 'windows', the tool's own docs/"
                    "GitHub issues) rather than guessing blindly or repeating the same failing attempt "
                    "unchanged. Fold whatever you learn into your next real fix attempt.\n\n"
                    "A common root cause on Windows worth checking early when a program fails only "
                    "sometimes, or fails during dependency install/build with no obvious code bug: more "
                    "than one version of the same runtime (Python, Node, Java, etc.) is installed, and "
                    "whichever one is first on PATH isn't the one the project actually needs -- this can "
                    "silently change over time as new versions get installed. Use terminal_run to check "
                    "for this directly (e.g. `py -0p` lists every installed Python with its path and marks "
                    "the current default; `where <command>` lists every match on PATH in resolution order; "
                    "`node --version`/`where node` similarly for Node) rather than assuming the first error "
                    "is a code problem. If a project has its own venv/node_modules already, prefer using "
                    "that directly over whatever a bare `python`/`node` resolves to. If it doesn't yet and "
                    "the failure looks like a version mismatch, the fix is usually to create one pinned to "
                    "the specific interpreter the project needs (e.g. `& \"C:\\Program Files\\Python312\\"
                    "python.exe\" -m venv .venv` then install into that venv's own python/pip) rather than "
                    "reordering PATH or uninstalling the other version -- other projects (including "
                    "AthenaUI's own backend) may already depend on that other install still existing "
                    "exactly where it is.\n\n"
                    "You also have dedicated process/port introspection tools -- use them instead of "
                    "guessing from terminal output alone: process_list (see every running process with its "
                    "pid, parent pid, and full command line, optionally filtered by name) and port_check "
                    "(confirm whether a specific port is genuinely being listened on right now, and by "
                    "which pid) are both read-only with no approval needed, so call them freely whenever "
                    "'is the server actually up', 'is something already using this port', or 'is that dev "
                    "server process still alive' is in question -- don't assume from a single terminal_run "
                    "result alone, especially for a server started earlier in the conversation. If you find "
                    "a stuck/crashed process still alive but not actually serving (e.g. a --reload watcher "
                    "left over after its app failed to import), or a duplicate/orphaned dev server left "
                    "over from an earlier attempt, use process_kill on its pid (kills its whole child-"
                    "process tree by default, so the real server dies too, not just a wrapper shell) before "
                    "starting a fresh one on the same port -- don't just open yet another new terminal_run "
                    "session and leave the old one running forever. For finding things in source code, "
                    "prefer grep_search (real regex/text search across file CONTENTS with actual file paths "
                    "and line numbers, automatically skipping node_modules/venv/.git/build junk) over "
                    "file_search whenever you need every call site of a function/symbol/string, not just a "
                    "first-match snippet -- e.g. before renaming something, or to find exactly which line a "
                    "traceback's error actually originates from. For version-controlled projects, use "
                    "git_log (recent commit history for a file/dir/repo), git_diff (uncommitted changes, "
                    "optionally against a specific ref), and git_blame (who/when last touched each line of "
                    "a file) to understand when and why something broke before just guessing at a fix -- "
                    "e.g. git_blame around a traceback's line number, or git_log on a file that started "
                    "failing to see what changed recently. All three are read-only, no approval needed, and "
                    "require git to be installed and the target to be inside an actual git repository."
                ),
            }
        ]
        if full_tool_access:
            combined = _agentic_persistence_block + combined

        # Strict honesty directive about tool calls: never narrate a tool
        # invocation, command run, or approval/pending state that did not
        # actually happen in this turn. A fabricated status (e.g. claiming a
        # terminal command was submitted and is "waiting for approval" with
        # an invented request id) is a serious trust violation, not a
        # harmless placeholder -- do not do this even to sound helpful or to
        # avoid saying you're blocked.
        _strict_honesty_block = [
            {
                "role": "system",
                "content": (
                    "STRICT HONESTY RULE ABOUT TOOL CALLS: only ever describe a tool call, command, "
                    "approval request, or request/change id that you actually just invoked and received "
                    "a real result for in this conversation -- never invent, guess, or narrate one that "
                    "didn't really happen, even partially (e.g. never claim something was 'submitted' or "
                    "'is now pending/waiting for approval' unless you truly just called a tool and it "
                    "truly returned that status). Never make up an id, session id, or change id. If you "
                    "are unsure whether a tool call happened, or you are blocked and have not actually "
                    "run anything, say so plainly instead of inventing a plausible-sounding status. "
                    "The user has their own live, real-time Tail Log of every action the backend actually "
                    "performs, completely independent of anything you say -- so any fabricated tool-call "
                    "claim will be caught immediately and destroys trust. Being honestly blocked or unsure "
                    "is always better than a confident fabrication."
                ),
            }
        ]
        if full_tool_access:
            combined = _strict_honesty_block + combined

        # "Act now, don't announce" directive: the single most common way
        # the honesty rule above gets broken in practice isn't a flat lie --
        # it's saying "I'll do X now" / "the command is ready, please allow
        # it when it appears" as the ENTIRE reply, with no actual tool_call
        # attached to that same turn. That leaves nothing in the sidebar for
        # the user to approve and nothing for them to act on until they
        # notice and ask again, which is exactly the "he says to allow
        # something but it never appears" complaint this instruction exists
        # to stop.
        _act_now_block = [
            {
                "role": "system",
                "content": (
                    "ACT NOW, DON'T ANNOUNCE: if you've decided to run a command or use a tool, put the "
                    "actual tool call in THIS SAME response -- never end a turn with only a plain-text "
                    "promise like 'I'll run it now', 'the command is ready', or 'please allow the "
                    "upcoming request when it appears' unless a real tool call is attached to that exact "
                    "response. A plain-text reply that only describes an intention to act, with no "
                    "attached tool call, accomplishes nothing -- there is nothing pending for the user to "
                    "approve, and they have no way to know you're actually blocked. If you are ready to "
                    "act, act. If you are not actually ready (e.g. genuinely still deciding), say so "
                    "plainly instead of implying a tool call is imminent.\n\n"
                    "This also applies mid-task: after terminal_run reports 'still_running' (a long-lived "
                    "process like a dev server, or simply not finished yet), do not end your turn just "
                    "describing that it's running -- immediately call terminal_check yourself (no approval "
                    "needed) in that same round to see what's happened, and keep checking across further "
                    "rounds until you have an actual conclusive result (success, a real error, or genuine "
                    "confirmation it's serving normally) to report. Never assume a command succeeded "
                    "without seeing its real output; never assume the user is watching the terminal window "
                    "for you."
                ),
            }
        ]
        if full_tool_access:
            combined = _act_now_block + combined

        # Concrete, tool-name-specific version of the same rule: file writes
        # were the exact case a user caught being fabricated -- claiming a
        # request was "submitted for approval" when no such request (and no
        # change_id) actually existed anywhere in the pending-changes store.
        _file_write_honesty_block = [
            {
                "role": "system",
                "content": (
                    "FILE WRITE HONESTY (a concrete case of the rules above): `file_write` saves the file "
                    "immediately and completely the moment you call it -- there is no approval step and "
                    "nothing pending afterward, full stop. `file_write_proposal` is the ONLY tool that can "
                    "create something pending, and only when its own result text actually begins with "
                    "'[PENDING]' and includes a real change_id -- when that happens, the user's sidebar "
                    "automatically shows a Keep/Revert prompt for it; you don't need to (and can't) make that "
                    "prompt appear yourself. Never tell the user a file write 'was submitted for approval', "
                    "'is pending', or 'is waiting for you to allow it' unless you called file_write_proposal "
                    "in this exact turn and its result literally starts with '[PENDING]'. If you called "
                    "file_write, say plainly that the file is already written. If either tool's result starts "
                    "with '[ERROR]', say plainly that it failed and why. Describing an approval flow that "
                    "didn't actually happen is exactly the kind of fabrication that destroys trust the "
                    "fastest, since the user can see there's nothing in their sidebar to click."
                ),
            }
        ]
        if full_tool_access:
            combined = _file_write_honesty_block + combined
        combined = [
            {
                "role": "system",
                "content": (
                    "You are currently in a private 1:1 conversation with the user. "
                    "You are NOT in a group chat session right now."
                ),
            }
        ] + combined

        # Recent GROUP chat activity, for awareness only -- correctly
        # attributed to whoever actually said each line (see
        # MaximosMemoryClient.store_group_turn), never mixed into the
        # literal private-chat turns above and never saved back into this
        # private conversation's own history.
        if character:
            group_activity = self.history.load_recent_channel_entries(character, channel=CHANNEL_GROUP_CHAT, limit=15)
            group_lines = [
                f"[{e.get('sender') or 'someone'}]: {e.get('content')}"
                for e in group_activity if e.get("content")
            ]
            if group_lines:
                combined = [
                    {
                        "role": "system",
                        "content": (
                            "For awareness only -- recent GROUP chat activity you took part in. "
                            "This is NOT part of your current private conversation; do not treat these "
                            "as literal turns of this direct chat, and do not confuse another speaker's "
                            "line below with something the user said to you privately:\n"
                            + "\n".join(group_lines)
                        ),
                    }
                ] + combined

        query_text = self._latest_user_text(messages)
        if history:
            memory_prompt = self.memory.build_memory_prompt(character, query_text)
        else:
            # Brand-new conversation (no prior short history for this
            # character) -- proactively pull recent long-term memory instead
            # of only reactive keyword search, so a returning user's generic
            # opener ("Hey", "Hi") isn't met with a stranger-level greeting
            # just because it has no keywords to match against.
            recent = self.memory.load_recent_memory(character, limit=10)
            memory_prompt = "\n".join(f"- {m}" for m in recent)
        if memory_prompt:
            label = "Relevant memory:" if history else (
                "Recent memory (you have spoken with this user before -- do not "
                "greet them like a first-time stranger):"
            )
            combined = [
                {
                    "role": "system",
                    "content": f"{label}\n{memory_prompt}"
                }
            ] + combined

        # Ambient awareness of whatever file (or, if the user clicked a folder
        # in the tree instead of opening a file, directory) the user currently
        # has active in the Code Suite editor. Sent fresh by the frontend on
        # every message, NOT persisted to chat history -- it's injected here,
        # after history is already loaded/combined, so it never gets saved by
        # chat()'s `for m in messages: self.history.append_short_history(...)` loop.
        if editor_context and editor_context.get("path"):
            if editor_context.get("is_directory"):
                # A restarted/fresh agentic run (e.g. after a chat error wiped
                # the live in-memory AGENTIC_STATE) has no memory of a
                # previous attempt's tool-calling progress -- only this
                # directory-scoped work_log.json survives that. Read it
                # proactively (rather than just telling the model to go read
                # it) so a resumed run sees prior progress on round 1 instead
                # of spending a whole extra round -- and possibly re-exploring
                # the same ground -- just to discover it exists.
                work_log_note = ""
                try:
                    workspace = WorkspaceService(self.username)
                    work_log_path = str(Path(editor_context["path"]) / "work_log.json")
                    existing_log = workspace.read_file(work_log_path)
                    work_log_note = (
                        "\n\nA work_log.json already exists in this directory from a PREVIOUS attempt "
                        "-- it's reproduced below. Read it FIRST and resume from where it left off "
                        "(skip re-exploring/re-diagnosing anything it already covers) instead of starting over:\n"
                        f"```json\n{existing_log[:8000]}\n```"
                    )
                except Exception:
                    pass
                combined = [
                    {
                        "role": "system",
                        "content": (
                            "The user has selected this directory in the Code Suite file tree (no specific file open) "
                            "to tell you where in the workspace they're currently working. "
                            "Code Suite is for analyzing existing code, troubleshooting traceback and runtime failures, "
                            "inspecting command prompt / terminal output, and making precise fixes to already-written programs. "
                            "It can also build or extend code when the user explicitly asks, but its default behavior should be careful analysis and repair rather than assuming a greenfield build.\n"
                            "You have full read/write access to every file in this workspace (file_read/file_write/file_list_dir/file_search) and can run terminal_run for builds/tests/diagnostics. "
                            "IMPORTANT terminal rule: only run ONE program at a time in a given terminal. Starting a second long-running program (e.g. a second .bat/.exe, another dev server) in the same terminal before the first one has finished or been backgrounded produces confusing interleaved output and misleading errors (like a 'path not found' on a file that actually exists, because the second command silently ran from the wrong working directory while the first was still active). Run and confirm one command/program at a time -- via terminal_check on its session_id -- before starting the next. "
                            "Treat this directory as the primary focus for whatever the user reports next -- use file_list_dir/file_search to explore it before assuming its contents, and apply fixes directly to the real file(s) here, don't just describe them. "
                            "Keep a running work_log.json array in this directory (create it if missing) as your own durable record, readable even after a chat history reset: append an entry roughly every 10 rounds summarizing what you've explored/found so far ({timestamp, notes}), not just once a fix is fully applied ({timestamp, issue, fix_applied}) -- a long analysis that gets interrupted before finishing should still leave enough behind to resume from instead of re-exploring from scratch.\n"
                            f"Working directory: {editor_context['path']}"
                            f"{work_log_note}"
                        ),
                    }
                ] + combined
            else:
                file_content = str(editor_context.get("content") or "")[:20000]
                combined = [
                    {
                        "role": "system",
                        "content": (
                            "The user currently has this file open in the Code Suite editor. "
                            "Code Suite is for analyzing existing code, troubleshooting traceback and runtime failures, "
                            "inspecting command prompt / terminal output, and making precise fixes to already-written programs. "
                            "It can also build or extend code when the user explicitly asks, but its default behavior should be careful analysis and repair rather than assuming a greenfield build.\n"
                            "You have full read/write access to every file in this workspace (file_read/file_write/file_list_dir/file_search) and can run terminal_run for builds/tests/diagnostics. "
                            "IMPORTANT terminal rule: only run ONE program at a time in a given terminal. Starting a second long-running program (e.g. a second .bat/.exe, another dev server) in the same terminal before the first one has finished or been backgrounded produces confusing interleaved output and misleading errors (like a 'path not found' on a file that actually exists, because the second command silently ran from the wrong working directory while the first was still active). Run and confirm one command/program at a time -- via terminal_check on its session_id -- before starting the next. "
                            "When the user reports an issue with this program, apply the fix directly to the real file(s) here, don't just describe it. "
                            "Before doing anything else, check whether a work_log.json already exists in this project's root dir (via file_read) -- if a PREVIOUS attempt left one, resume from where it left off instead of starting over. "
                            "Keep a running entry array in that work_log.json (create it if missing): append roughly every 10 rounds summarizing what you've explored/found so far ({timestamp, notes}), not just once a fix is fully applied ({timestamp, issue, fix_applied}) -- a long analysis that gets interrupted before finishing should still leave enough behind to resume from instead of re-exploring from scratch.\n"
                            f"Path: {editor_context['path']}\n\n```\n{file_content}\n```"
                        ),
                    }
                ] + combined

        return combined


    # ---------------------------------------------------------
    # Agent-capability resolution
    # ---------------------------------------------------------
    def _agent_tool_names(self, character: str | None, provider_id: str | None = None, page_context: str | None = None, explicit_tool_names: Optional[frozenset] = None):
        """
        Returns the `allowed_names` value to pass to `get_all_schemas()` for
        this character: `None` (full tool access) for the base assistant
        (no character selected) and Agent-enabled characters, or the
        chat-only whitelist for a user-created character that hasn't been
        promoted to Agent status. Fails open (full access) on lookup errors
        or an unrecognized character -- this only matches today's
        pre-existing behavior rather than being a new restriction.

        Regardless of the above, a small-context local provider like Atlas
        Server (llama.cpp, currently 8192 tokens) cannot fit the full
        ~138-tool registry's schema JSON into its context window alongside
        the persona/history -- that overflow previously surfaced as an
        opaque upstream 500 ("Insufficient Space"). Always cap such
        providers to the curated chat-only subset, even for Agent-enabled
        characters/the base assistant, rather than let every request fail.

        `page_context` (see SidebarChat.tsx) further narrows an otherwise
        full-access request down to UNIVERSAL_TOOL_NAMES plus whatever
        PAGE_CONTEXT_TOOL_NAMES has for that page -- the Sidebar Chat widget
        is visible on nearly every screen in the app, and most of those
        screens need none of the ~138-tool registry (e.g. Subscription only
        ever needs memory recall), so this both avoids irrelevant tool calls
        and keeps the per-request tool schema payload small (fewer prompt
        tokens, and far less likely to ever hit a provider's hard tools-array
        cap again). Only applies when the request would otherwise get full
        access -- a chat-only character's (or Atlas Server's) narrower set
        always wins, and the dedicated /chat page never sends a page_context
        at all, so it keeps today's full-access behavior unchanged.

        `explicit_tool_names` (the dedicated /chat page's tool picker) takes
        priority over everything above except the Atlas Server context-size
        cap: the user has deliberately opted a specific set of tools in for
        that conversation, so honor it even for a non-Agent character or the
        base assistant, always including UNIVERSAL_TOOL_NAMES (memory/MMS
        access can't be turned off -- the agent needs it to function).
        """
        if explicit_tool_names is not None:
            selected = frozenset(explicit_tool_names) | self.UNIVERSAL_TOOL_NAMES
            if provider_id == PROVIDER_ATLAS_SERVER:
                selected = selected & self.CHAT_ONLY_TOOL_NAMES
            return selected

        if not character:
            base = None
        else:
            try:
                data = list_all_characters(self.username).get(character)
            except Exception:
                data = None
            if not data or is_agent_character(data):
                base = None
            else:
                base = self.CHAT_ONLY_TOOL_NAMES

        if base is None and provider_id == PROVIDER_ATLAS_SERVER:
            return self.CHAT_ONLY_TOOL_NAMES
        if base is None and page_context:
            return self.UNIVERSAL_TOOL_NAMES | self.PAGE_CONTEXT_TOOL_NAMES.get(page_context, frozenset())
        return base

    # ---------------------------------------------------------
    # Hybrid tool calling loop (non-streaming)
    # ---------------------------------------------------------
    async def _run_tool_loop(self, router, messages: List[Dict[str, Any]], character: str | None = None, image_markdown: List[str] | None = None, tool_trace: List[Dict[str, Any]] | None = None, tool_allowlist: Optional[frozenset] = None, provider_id: str | None = None):
        max_rounds = self.MAX_TOOL_ROUNDS
        rounds = 0
        # tool_allowlist, when given, replaces the character-based tool
        # resolution entirely -- used by surfaces like the external "Just
        # Chat" mobile app to offer only a curated safe set (e.g. the same
        # image-generation tools already trusted for group chat) instead of
        # either full access or a hard zero-tool lockout.
        allowed_names = tool_allowlist if tool_allowlist is not None else self._agent_tool_names(character, provider_id=provider_id)
        while True:
            rounds += 1
            if rounds > max_rounds:
                return {
                    "content": "I could not complete this request because tool calls exceeded the safe limit.",
                    "tool_calls": [],
                }

            response = await call_with_retry(
                router.chat,
                compact_tool_history(messages),
                tools=self.tools.registry.get_all_schemas(allowed_names=allowed_names),
                tool_choice="auto",
                max_tokens=self.TOOL_LOOP_MAX_TOKENS,
            )

            tool_call = self.normalizer.normalize(response)
            if not tool_call:
                return response

            # Some models (e.g. Mistral Large via OpenRouter) issue MULTIPLE
            # tool_calls in a single turn (parallel tool calling). Every one
            # of them must get exactly one matching "tool" role response --
            # providers like Mistral hard-reject the request on the NEXT
            # round otherwise ("Not the same number of function calls and
            # responses"). self.normalizer only inspects the first entry, so
            # iterate the raw list here instead of relying on it alone.
            raw_tool_calls = response.get("tool_calls")
            if not isinstance(raw_tool_calls, list) or not raw_tool_calls:
                raw_tool_calls = [{
                    "id": tool_call.get("tool_call_id"),
                    "type": "function",
                    "function": {"name": tool_call["tool_name"], "arguments": json.dumps(tool_call["arguments"])},
                }]

            # The assistant's own tool-calling turn must be appended to the
            # conversation BEFORE the tool's response(s) -- both OpenAI and
            # xAI reject a "tool" role message that isn't immediately
            # preceded by the assistant message with matching tool_calls.
            messages.append({
                "role": "assistant",
                "content": response.get("content"),
                "tool_calls": raw_tool_calls,
            })

            approval_needed_response = None
            for index, raw_call in enumerate(raw_tool_calls):
                parsed = tool_call if index == 0 else self.normalizer.normalize({"tool_calls": [raw_call]})
                call_id = raw_call.get("id") if isinstance(raw_call, dict) else None
                if not parsed:
                    messages.append({
                        "role": "tool",
                        "tool_call_id": call_id,
                        "content": json.dumps({"status": "error", "error": "Malformed tool call."}),
                    })
                    continue

                call_name = parsed["tool_name"]
                call_args = parsed["arguments"]
                call_id = parsed.get("tool_call_id") or call_id
                # SECURITY: `character` is a trusted server-side value -- always
                # force it, overwriting any value the model supplied (a model
                # cannot be trusted to name its own identity/scope correctly).
                if character and isinstance(call_args, dict):
                    call_args = {**call_args, "character": character}

                if approval_needed_response is not None:
                    # A prior call in this same round already needs
                    # out-of-band approval -- every remaining call must still
                    # get a matching tool response to keep the message list
                    # balanced, even though it was never actually run.
                    messages.append({
                        "role": "tool",
                        "tool_call_id": call_id,
                        "content": json.dumps({"status": "skipped", "reason": "Waiting on approval for a prior tool call in this turn."}),
                    })
                    continue

                if allowed_names is not None and call_name not in allowed_names:
                    # Enforce the allowlist at execution time too -- offering a
                    # restricted schema to the model is only a suggestion, not
                    # a hard boundary, so a hallucinated/forced call naming a
                    # disallowed tool (e.g. a non-image tool while running on
                    # the free default API key) must still be refused here.
                    messages.append({
                        "role": "tool",
                        "tool_call_id": call_id,
                        "content": json.dumps({"status": "error", "error": f"Tool '{call_name}' is not permitted for this request."}),
                    })
                    continue

                try:
                    tool_result = await self.tools.execute(call_name, call_args)
                except ApprovalRequiredError:
                    # A dangerous tool call needs a real, out-of-band user click
                    # (Allow/Deny in the sidebar) -- it cannot possibly succeed
                    # within this same turn. Feeding this back as a generic tool
                    # error and letting the loop continue just makes the model
                    # retry immediately (creating duplicate/orphaned pending
                    # approvals each round) or eventually give up and describe a
                    # stale/hallucinated request id from its own context instead
                    # of the real one. Record a placeholder response (to keep
                    # the message list balanced) and stop the loop after this
                    # round with a clean, code-authored message instead of
                    # trusting the model to report the pending approval accurately.
                    messages.append({
                        "role": "tool",
                        "tool_call_id": call_id,
                        "content": json.dumps({"status": "pending_approval"}),
                    })
                    approval_needed_response = {
                        "content": (
                            "I've submitted that command and it's now waiting for "
                            "your approval in the sidebar -- please Allow or Deny "
                            "it there, and I'll continue right away once you do."
                        ),
                        "tool_calls": [],
                    }
                    continue
                except Exception as e:
                    # A tool raising an exception (ToolError, WorkspaceError, etc.)
                    # must not crash the whole chat turn -- report it back to the
                    # model as a failed tool call so it can react/retry instead.
                    tool_result = {"status": "error", "error": str(e)}

                if tool_trace is not None:
                    tool_trace.append({"tool": call_name, "arguments": call_args, "result": tool_result})

                if image_markdown is not None:
                    md = image_result_to_markdown(tool_result if isinstance(tool_result, dict) else None)
                    if md:
                        image_markdown.append(md)

                messages.append({
                    "role": "tool",
                    "tool_call_id": call_id,
                    "content": tool_result if isinstance(tool_result, str) else json.dumps(tool_result),
                })

            if approval_needed_response is not None:
                return approval_needed_response

    # ---------------------------------------------------------
    # Hybrid tool calling loop (streaming)
    # ---------------------------------------------------------
    async def _run_streaming_tool_loop(
        self,
        router,
        model_id: str,
        messages: List[Dict[str, Any]],
        character: str | None = None,
        provider_id: str | None = None,
    ) -> AsyncGenerator[Dict[str, Any], None]:

        max_rounds = self.MAX_TOOL_ROUNDS
        rounds = 0
        allowed_names = self._agent_tool_names(character, provider_id=provider_id)
        if provider_id and self._is_using_system_default_key(provider_id):
            allowed_names = self.DEFAULT_KEY_TOOL_NAMES if allowed_names is None else (allowed_names & self.DEFAULT_KEY_TOOL_NAMES)

        while True:
            rounds += 1
            if rounds > max_rounds:
                yield {
                    "provider_id": None,
                    "model_id": model_id,
                    "final": True,
                    "response": {"text": "I could not complete this request because tool calls exceeded the safe limit."},
                }
                return

            collected_text = ""
            final_response: Dict[str, Any] = {}
            tool_call_detected = None

            async for event in self.streaming.run(
                router=router,
                model_id=model_id,
                messages=messages,
                tools=self.tools.registry.get_all_schemas(allowed_names=allowed_names),
                tool_choice="auto",
            ):
                if event["type"] == "text":
                    collected_text += event["text"]
                    final_response["text"] = collected_text

                if event["type"] == "tool_call" and not tool_call_detected:
                    tool_call_detected = event["tool_call"]

                yield {
                    "provider_id": None,
                    "model_id": model_id,
                    "chunk": event,
                }

            if not tool_call_detected:
                yield {
                    "provider_id": None,
                    "model_id": model_id,
                    "final": True,
                    "response": final_response,
                }
                return

            tool_name = tool_call_detected["tool_name"]
            arguments = tool_call_detected["arguments"]
            tool_call_id = tool_call_detected.get("tool_call_id")
            # SECURITY: always force the trusted server-side character value.
            if character and isinstance(arguments, dict):
                arguments = {**arguments, "character": character}

            # Same requirement as the non-streaming loop: the assistant's
            # tool-calling turn must precede the "tool" role response.
            messages.append({
                "role": "assistant",
                "content": collected_text or None,
                "tool_calls": [{
                    "id": tool_call_id,
                    "type": "function",
                    "function": {"name": tool_name, "arguments": json.dumps(arguments)},
                }],
            })

            if allowed_names is not None and tool_name not in allowed_names:
                tool_result = {"status": "error", "error": f"Tool '{tool_name}' is not permitted for this request."}
            else:
                try:
                    tool_result = await self.tools.execute(tool_name, arguments)
                except ApprovalRequiredError:
                    # Same rationale as the non-streaming loops above: a
                    # dangerous tool call needs a real out-of-band Allow/Deny
                    # click and can't succeed this round -- stop immediately
                    # with a clean message instead of looping/retrying.
                    yield {
                        "provider_id": None,
                        "model_id": model_id,
                        "final": True,
                        "response": {"text": (
                            "I've submitted that command and it's now waiting for "
                            "your approval in the sidebar -- please Allow or Deny "
                            "it there, and I'll continue right away once you do."
                        )},
                    }
                    return
                except Exception as e:
                    # Same rationale as the non-streaming loop above: don't let a
                    # tool exception kill the whole streamed response.
                    tool_result = {"status": "error", "error": str(e)}

            tool_message = {
                "role": "tool",
                "content": tool_result if isinstance(tool_result, str) else json.dumps(tool_result),
            }
            if tool_call_id:
                tool_message["tool_call_id"] = tool_call_id
            messages.append(tool_message)

    # ---------------------------------------------------------
    # Non-streaming chat
    # ---------------------------------------------------------
    async def chat(self, messages: List[Dict[str, Any]], character: str | None = None, editor_context: Dict[str, Any] | None = None, channel: str = CHANNEL_PRIVATE_CHAT, tool_trace: List[Dict[str, Any]] | None = None, tool_allowlist: Optional[frozenset] = None, reasoning_effort: Optional[str] = None, provider_override: Optional[tuple] = None):
        if provider_override:
            provider_id, model_id = provider_override
        else:
            provider_id, model_id = self._get_active_chat_model()
        api_key = self._get_api_key(provider_id)
        self._inject_provider_api_key(provider_id, api_key)

        router = self.router_selector.select(provider_id=provider_id, model_id=model_id, mode="chat")
        router.reasoning_effort = reasoning_effort
        allowed_names = tool_allowlist if tool_allowlist is not None else self._agent_tool_names(character, provider_id=provider_id)
        if self._is_using_system_default_key(provider_id):
            allowed_names = self.DEFAULT_KEY_TOOL_NAMES if allowed_names is None else (allowed_names & self.DEFAULT_KEY_TOOL_NAMES)
        formatted = self._build_messages(messages, character, editor_context=editor_context, allowed_names=allowed_names)

        image_markdown: List[str] = []
        result = await self._run_tool_loop(router, formatted, character=character, image_markdown=image_markdown, tool_trace=tool_trace, tool_allowlist=allowed_names, provider_id=provider_id)

        return await self._finalize_reply(
            result,
            image_markdown,
            messages,
            character,
            normalize_channel(channel),
            provider_id,
            model_id,
        )

    async def chat_with_billing_fallback(
        self,
        messages: List[Dict[str, Any]],
        character: str | None = None,
        channel: str = CHANNEL_PRIVATE_CHAT,
        tool_trace: List[Dict[str, Any]] | None = None,
        tool_allowlist: Optional[frozenset] = None,
    ) -> Dict[str, Any]:
        """Background-only entry point for scheduled tasks (scheduler/runner.py,
        tasks/engine/service.py) and inbox monitoring (auto_reply/monitor.py)
        -- NOT used by interactive chat, since a human is present there and
        can react to a billing error directly rather than needing an
        automatic switch.

        When the user has opted into Settings > billing_fallback and
        configured an ordered provider/model chain, walks that chain in
        order on a billing-flavored failure (see llm.retry.is_billing_error)
        instead of letting the task/poll cycle silently fail (e.g. a
        customer never getting an auto-reply because the org's primary
        provider ran out of funds). Notifies the user via their configured
        channel once a backup succeeds, so they know to fix billing on the
        primary. If the feature is disabled or no chain is configured, this
        is identical to calling chat() directly."""
        from settings.service import SettingsService

        settings = SettingsService.get_settings(self.username)
        billing_cfg = settings.get("billing_fallback") or {}
        chain = billing_cfg.get("chain") or []

        if not billing_cfg.get("enabled") or not chain:
            return await self.chat(messages, character=character, channel=channel, tool_trace=tool_trace, tool_allowlist=tool_allowlist)

        last_exc: Exception | None = None
        for index, candidate in enumerate(chain):
            provider_id = (candidate or {}).get("provider_id")
            model_id = (candidate or {}).get("model_id")
            if not provider_id or not model_id:
                continue
            try:
                self._get_api_key(provider_id)
            except Exception:
                # No longer has a usable key for this provider -- skip it
                # rather than fail the whole chain on a stale chain entry.
                continue

            try:
                result = await self.chat(
                    messages, character=character, channel=channel, tool_trace=tool_trace,
                    tool_allowlist=tool_allowlist, provider_override=(provider_id, model_id),
                )
            except requests.HTTPError as e:
                if not is_billing_error(e):
                    raise
                last_exc = e
                continue

            if index > 0:
                self._notify_billing_fallback_used(billing_cfg, provider_id, model_id)
            return result

        raise last_exc or ChatEngineError(
            "Billing fallback is enabled, but no configured provider in the chain has a usable API key."
        )

    def _notify_billing_fallback_used(self, billing_cfg: Dict[str, Any], provider_id: str, model_id: str) -> None:
        """Best-effort: a failed/misconfigured notification must never
        undo or mask the successful fallback that triggered it."""
        try:
            from notifications.service.service import NotificationService

            message = (
                f"We had to switch to your backup API key ({provider_id} / {model_id}) because your "
                "primary provider returned a billing error. Please add funds or update billing on the "
                "primary when you can, so we can continue to operate normally."
            )
            NotificationService.send(
                self.username,
                type="warning",
                message=message,
                metadata={"provider_id": provider_id, "model_id": model_id},
                channel=billing_cfg.get("notify_channel"),
                subject="AthenaUI switched to your backup API key",
                phone_number=billing_cfg.get("notify_phone_number"),
            )
        except Exception:
            logger.warning("Failed to send billing-fallback notification for user=%s", self.username, exc_info=True)

    async def _finalize_reply(
        self,
        result: Dict[str, Any],
        image_markdown: List[str],
        raw_messages: List[Dict[str, Any]],
        character: str | None,
        channel: str,
        provider_id: str,
        model_id: str,
    ) -> Dict[str, Any]:
        """
        Shared finalization tail for a completed reply (no more tool calls
        pending): normalizes the text, runs the best-effort auto-selfie
        side effect, saves short/long-term history, and builds the response
        dict. Used by both the single-shot `chat()` path and the round-by-
        round agentic path (`start_agentic`/`continue_agentic`).
        """
        assistant_text = self._normalize_assistant_text(result)
        if not assistant_text:
            assistant_text = "I did not receive a text response from the provider. Please try again or select a different model."

        if image_markdown:
            assistant_text = (assistant_text + "\n\n" + "\n\n".join(image_markdown)).strip()

        # Emotional-cue / periodic auto-selfie: best-effort only -- a failed
        # or unconfigured image provider must never break the actual chat
        # reply, so every failure mode here is caught and silently skipped.
        if character and channel != "voice_call":
            try:
                emotion = _detect_emotion(assistant_text)
                try:
                    interaction_count = len(self.history.load_short_history(character, limit=200))
                except Exception:
                    interaction_count = 0

                # Avoid the modulo-at-zero false positive (0 % 10 == 0) on
                # a brand-new conversation's very first turn while still
                # reusing the shared trigger function as-is.
                periodic_count = interaction_count if interaction_count > 0 else -1

                if should_generate_avatar_for_message({
                    "is_group_chat": False,
                    "interaction_count": periodic_count,
                    "emotion": emotion,
                }):
                    selfie_result = await self.images.generate_selfie(self.username, character, emotion=emotion)
                    selfie_md = image_result_to_markdown(selfie_result)
                    if selfie_md:
                        assistant_text = (assistant_text + "\n\n" + selfie_md).strip()
            except Exception:
                logger.debug("Selfie auto-generation skipped for character=%s", character, exc_info=True)

        user_entry_id: Optional[str] = None
        user_created_at: str = ""
        user_text_for_summary: str = ""
        for m in raw_messages:
            entry_id, created_at = self.history.append_short_history(character, m, channel=channel)
            if str(m.get("role") or "") == "user":
                user_entry_id, user_created_at, user_text_for_summary = entry_id, created_at, str(m.get("content") or "")

        assistant_entry_id, _ = self.history.append_short_history(character, {
            "role": "assistant",
            "content": assistant_text
        }, channel=channel)

        if isinstance(assistant_text, str) and "remember" in assistant_text.lower():
            self.memory.append_long_memory(character, assistant_text)

        # Best-effort "agent summary" recall layer: one short, searchable
        # summary per interaction, timestamped to the user's ORIGINAL
        # message (not to now) so date-based recall ("a few months ago")
        # lines up with when this actually happened. Never blocks/breaks
        # the reply itself on failure -- see summarize_interaction's own
        # fail-soft contract.
        if character and channel != "voice_call" and user_entry_id and user_text_for_summary:
            try:
                summary_text = await summarize_interaction(
                    provider_id, model_id, user_text_for_summary, assistant_text
                )
                if summary_text:
                    source_ids = [user_entry_id] + ([assistant_entry_id] if assistant_entry_id else [])
                    self.memory.append_summary(
                        character, summary_text, created_at=user_created_at, source_entry_ids=source_ids
                    )
            except Exception:
                logger.debug("Interaction summarization skipped for character=%s", character, exc_info=True)

        return {
            "provider_id": provider_id,
            "model_id": model_id,
            "reply": assistant_text,
            "content": assistant_text,
            "response": result,
        }

    # ---------------------------------------------------------
    # Interruptible, round-by-round agentic tool loop (private chat)
    # ---------------------------------------------------------
    # Lets the API layer drive one tool-calling round at a time (instead of
    # blocking through the whole loop in one call) so the frontend can show
    # per-round progress, let the user hit "Stop", or inject a new message
    # that gets woven into the very next round -- the same way a user can
    # redirect an in-progress agent mid-task.

    async def start_agentic(
        self,
        message: str,
        character: str | None = None,
        editor_context: Dict[str, Any] | None = None,
        channel: str = CHANNEL_PRIVATE_CHAT,
        call_start: bool = False,
        reasoning_effort: Optional[str] = None,
        use_code_model: bool = False,
        page_context: str | None = None,
        explicit_tool_names: Optional[frozenset] = None,
    ) -> Dict[str, Any]:
        provider_id, model_id = None, None
        if use_code_model:
            try:
                provider_id, model_id = self._get_active_code_model()
            except ChatEngineError:
                # No code model configured -- fall back to the normal chat
                # model rather than failing the whole reply.
                provider_id, model_id = None, None
        if not provider_id or not model_id:
            provider_id, model_id = self._get_active_chat_model()
        api_key = self._get_api_key(provider_id)
        self._inject_provider_api_key(provider_id, api_key)
        router = self.router_selector.select(provider_id=provider_id, model_id=model_id, mode="chat")
        router.reasoning_effort = reasoning_effort
        allowed_names = self._agent_tool_names(character, provider_id=provider_id, page_context=page_context, explicit_tool_names=explicit_tool_names)

        raw_inputs: List[Dict[str, Any]] = []
        if call_start:
            raw_inputs.append({
                "role": "system",
                "content": (
                    "[Voice call initiated -- the user just called you. You're speaking live "
                    "over a simulated phone call, not typing, so respond the way you would in "
                    "an actual phone conversation: naturally spoken, not written.]"
                ),
            })
        raw_inputs.append({"role": "user", "content": message})

        formatted = self._build_messages(raw_inputs, character, editor_context=editor_context, allowed_names=allowed_names)

        state: Dict[str, Any] = {
            "router": router,
            "provider_id": provider_id,
            "model_id": model_id,
            "messages": formatted,
            "raw_inputs": raw_inputs,
            "round": 0,
            "pending": [],
            "image_markdown": [],
            "character": character,
            "channel": normalize_channel(channel),
            "reasoning_effort": reasoning_effort,
            "extra_turns_granted": 0,
            "allowed_names": allowed_names,
        }
        result = await self._advance_agentic_round(state)
        result["state"] = state
        return result

    def grant_more_turns(self, state: Dict[str, Any], additional_turns: int) -> None:
        """Extends an in-progress agentic reply's round budget by
        `additional_turns` (clamped to [1, EXTRA_TURNS_GRANT_MAX]) after it
        hit MAX_TOOL_ROUNDS and the user chose to let it keep going instead
        of stopping -- mirrors tasks/engine/service.py's
        resume_task_with_more_turns(). Call continue_agentic(state) right
        after this to actually resume the loop."""
        grant = max(1, min(int(additional_turns), self.EXTRA_TURNS_GRANT_MAX))
        state["extra_turns_granted"] = state.get("extra_turns_granted", 0) + grant

    async def finalize_after_denied_more_turns(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Called when the user declines to grant more turns after an
        agentic reply hit MAX_TOOL_ROUNDS -- accepts progress made so far as
        final, the same way running out used to behave automatically."""
        fallback = {
            "content": (
                f"I hit the safety limit of {self.MAX_TOOL_ROUNDS} tool rounds for this task "
                "without finishing -- say \"continue\" and I'll pick up right where I left off."
            ),
            "tool_calls": [],
        }
        return await self._finalize_reply(
            fallback, state["image_markdown"], state["raw_inputs"], state["character"], state["channel"],
            state["provider_id"], state["model_id"],
        )

    def inject_agentic_message(self, state: Dict[str, Any], message: str) -> None:
        """Queues a new user message to be woven into the conversation at the
        start of the next round, instead of starting a brand-new reply."""
        state["pending"].append(message)
        state["raw_inputs"].append({"role": "user", "content": message})

    async def continue_agentic(self, state: Dict[str, Any]) -> Dict[str, Any]:
        return await self._advance_agentic_round(state)

    async def _advance_agentic_round(self, state: Dict[str, Any]) -> Dict[str, Any]:
        # Weave in any message(s) the user sent while the agent was mid-loop.
        while state["pending"]:
            injected_text = state["pending"].pop(0)
            state["messages"].append({"role": "user", "content": injected_text})

        state["round"] += 1
        character = state["character"]
        channel = state["channel"]

        # Carries forward whether the PREVIOUS round's terminal_run/terminal_check
        # result was inconclusive ("still_running") -- read here before it gets
        # overwritten below by this round's own tool execution (if any).
        was_still_running = state.pop("_last_result_still_running", False)

        effective_limit = self.MAX_TOOL_ROUNDS + state.get("extra_turns_granted", 0)
        if state["round"] > effective_limit:
            # Don't finalize automatically -- let the caller decide whether
            # to grant more turns (state stays alive in AGENTIC_STATE) or
            # accept progress so far as final (finalize_after_denied_more_turns).
            return {
                "status": "needs_more_turns",
                "round": state["round"],
                "max_rounds": effective_limit,
            }

        response = await call_with_retry(
            state["router"].chat,
            compact_tool_history(state["messages"]),
            tools=self.tools.registry.get_all_schemas(allowed_names=state.get("allowed_names")),
            tool_choice="auto",
            max_tokens=self.TOOL_LOOP_MAX_TOKENS,
        )

        tool_call = self.normalizer.normalize(response)
        if not tool_call:
            # The prompt-level "ACT NOW" directive already tells the model to
            # keep calling terminal_check after a still_running result instead
            # of just describing an intent to monitor -- but a model ending
            # its turn with only that intent (no tool_call attached) is a real,
            # observed failure mode (see chat/engine/service.py history notes),
            # so this is a deterministic code-level backstop rather than
            # trusting the prompt alone: refuse to finalize and force one more
            # real round instead, up to a small retry cap to avoid looping
            # forever if the model just won't comply.
            if was_still_running:
                nudges = state.get("_stall_nudges", 0)
                if nudges < 2:
                    state["_stall_nudges"] = nudges + 1
                    state["messages"].append({
                        "role": "system",
                        "content": (
                            "You just received a 'still_running' result and ended your turn without "
                            "calling terminal_check -- that leaves the user with no real update. Call "
                            "terminal_check now with the same session_id to see what's happened, before "
                            "writing any further plain-text reply."
                        ),
                    })
                    return await self._advance_agentic_round(state)

            finalized = await self._finalize_reply(
                response, state["image_markdown"], state["raw_inputs"], character, channel,
                state["provider_id"], state["model_id"],
            )
            return {"status": "final", **finalized}

        tool_name = tool_call["tool_name"]
        tool_call_id = tool_call.get("tool_call_id")

        # Some models (e.g. Mistral Large via OpenRouter) issue MULTIPLE
        # tool_calls in a single turn (parallel tool calling). Every one of
        # them must get exactly one matching "tool" role response -- providers
        # like Mistral hard-reject the request on the NEXT round otherwise
        # ("Not the same number of function calls and responses"). The
        # normalizer above only inspects the first entry, so iterate the raw
        # list here instead of relying on it alone.
        raw_tool_calls = response.get("tool_calls")
        if not isinstance(raw_tool_calls, list) or not raw_tool_calls:
            raw_tool_calls = [{
                "id": tool_call_id,
                "type": "function",
                "function": {"name": tool_name, "arguments": json.dumps(tool_call["arguments"])},
            }]

        state["messages"].append({
            "role": "assistant",
            "content": response.get("content"),
            "tool_calls": raw_tool_calls,
        })

        approval_needed_response = None
        last_executed_name: Optional[str] = None
        last_executed_result: Any = None
        for index, raw_call in enumerate(raw_tool_calls):
            parsed = tool_call if index == 0 else self.normalizer.normalize({"tool_calls": [raw_call]})
            call_id = raw_call.get("id") if isinstance(raw_call, dict) else None
            if not parsed:
                state["messages"].append({
                    "role": "tool",
                    "tool_call_id": call_id,
                    "content": json.dumps({"status": "error", "error": "Malformed tool call."}),
                })
                continue

            call_name = parsed["tool_name"]
            call_args = parsed["arguments"]
            call_id = parsed.get("tool_call_id") or call_id
            # SECURITY: always force the trusted server-side character value.
            if character and isinstance(call_args, dict):
                call_args = {**call_args, "character": character}

            if approval_needed_response is not None:
                # A prior call in this same round already needs out-of-band
                # approval -- every remaining call must still get a matching
                # tool response to keep the message list balanced, even
                # though it was never actually run.
                state["messages"].append({
                    "role": "tool",
                    "tool_call_id": call_id,
                    "content": json.dumps({"status": "skipped", "reason": "Waiting on approval for a prior tool call in this turn."}),
                })
                continue

            try:
                tool_result = await self.tools.execute(call_name, call_args)
            except ApprovalRequiredError:
                # A dangerous tool call needs a real, out-of-band user click
                # (Allow/Deny in the sidebar) -- it cannot possibly succeed
                # this round. Letting the loop continue (feeding this back as
                # a generic tool error and returning status "tool_call") makes
                # the frontend's auto-continue loop immediately retry next
                # round, hitting the same gate again -- creating duplicate/
                # orphaned pending approvals, or eventually the model just
                # narrates a stale/hallucinated request id instead of the
                # real one. Record a placeholder response (to keep the
                # message list balanced) and stop with a clean, code-authored
                # message instead -- the real change_id is surfaced
                # separately via pending_action.
                state["messages"].append({
                    "role": "tool",
                    "tool_call_id": call_id,
                    "content": json.dumps({"status": "pending_approval"}),
                })
                approval_needed_response = {
                    "content": (
                        "I've submitted that command and it's now waiting for "
                        "your approval in the sidebar -- please Allow or Deny "
                        "it there, and I'll continue right away once you do."
                    ),
                    "tool_calls": [],
                }
                continue
            except Exception as e:
                tool_result = {"status": "error", "error": str(e)}

            md = image_result_to_markdown(tool_result if isinstance(tool_result, dict) else None)
            if md:
                state["image_markdown"].append(md)

            state["messages"].append({
                "role": "tool",
                "tool_call_id": call_id,
                "content": tool_result if isinstance(tool_result, str) else json.dumps(tool_result),
            })
            last_executed_name = call_name
            last_executed_result = tool_result

        if approval_needed_response is not None:
            finalized = await self._finalize_reply(
                approval_needed_response, state["image_markdown"], state["raw_inputs"], character, channel,
                state["provider_id"], state["model_id"],
            )
            return {"status": "final", **finalized}

        # Remembered for the NEXT round's check above (not this one) --
        # see `was_still_running` at the top of this function.
        state["_last_result_still_running"] = bool(
            last_executed_name in ("terminal_run", "terminal_check")
            and isinstance(last_executed_result, dict)
            and last_executed_result.get("still_running") is True
        )

        return {
            "status": "tool_call",
            "tool_name": last_executed_name or tool_name,
            "round": state["round"],
            "max_rounds": self.MAX_TOOL_ROUNDS,
        }

    # ---------------------------------------------------------
    # Streaming chat with tool calling
    # ---------------------------------------------------------
    async def stream(self, messages: List[Dict[str, Any]], character: str | None = None, channel: str = CHANNEL_PRIVATE_CHAT):
        provider_id, model_id = self._get_active_chat_model()
        api_key = self._get_api_key(provider_id)
        self._inject_provider_api_key(provider_id, api_key)

        router = self.router_selector.select(provider_id=provider_id, model_id=model_id, mode="chat")
        allowed_names = self._agent_tool_names(character, provider_id=provider_id)
        if self._is_using_system_default_key(provider_id):
            allowed_names = self.DEFAULT_KEY_TOOL_NAMES if allowed_names is None else (allowed_names & self.DEFAULT_KEY_TOOL_NAMES)
        formatted = self._build_messages(messages, character, allowed_names=allowed_names)

        normalized_channel = normalize_channel(channel)
        async for event in self._run_streaming_tool_loop(router, model_id, formatted, character=character, provider_id=provider_id):
            if "provider_id" in event and event["provider_id"] is None:
                event["provider_id"] = provider_id
            if event.get("final"):
                response_payload = event.get("response")
                if isinstance(response_payload, dict):
                    assistant_text = self._normalize_assistant_text(response_payload)
                    if assistant_text:
                        user_entry_id: Optional[str] = None
                        user_created_at: str = ""
                        user_text_for_summary: str = ""
                        for m in messages:
                            entry_id, created_at = self.history.append_short_history(character, m, channel=normalized_channel)
                            if str(m.get("role") or "") == "user":
                                user_entry_id, user_created_at, user_text_for_summary = entry_id, created_at, str(m.get("content") or "")
                        assistant_entry_id, _ = self.history.append_short_history(
                            character,
                            {"role": "assistant", "content": assistant_text},
                            channel=normalized_channel,
                        )
                        if character and normalized_channel != "voice_call" and user_entry_id and user_text_for_summary:
                            try:
                                summary_text = await summarize_interaction(
                                    provider_id, model_id, user_text_for_summary, assistant_text
                                )
                                if summary_text:
                                    source_ids = [user_entry_id] + ([assistant_entry_id] if assistant_entry_id else [])
                                    self.memory.append_summary(
                                        character, summary_text, created_at=user_created_at, source_entry_ids=source_ids
                                    )
                            except Exception:
                                logger.debug("Interaction summarization skipped for character=%s", character, exc_info=True)
            yield event

