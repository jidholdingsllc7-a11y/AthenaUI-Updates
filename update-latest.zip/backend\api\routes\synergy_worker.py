# AthenaUI -- Synergy Worker orchestration routes (main backend side)
# File: backend/api/routes/synergy_worker.py
#
# Synergy_Reborn.md Section 1 & 3: Synergy A/B run as separate Uvicorn/
# FastAPI processes ("synergy_worker/app.py") with no stored provider
# credentials of their own. This router gives those processes exactly two
# things they need from the main backend:
#   1. A place to register themselves at startup (so the main backend knows
#      which host:port currently serves "Synergy-A" / "Synergy-B").
#   2. A credential-proxy endpoint for outbound LLM calls -- the worker sends
#      the chat/tool payload here; this process resolves the user's real
#      vault-stored API key, calls the provider, and returns the raw
#      response. The real key never leaves the main backend process.
#
# Auth model: these calls come from local worker *processes*, not a logged-in
# browser session, so they can't present a user JWT. Instead both sides read
# the same shared secret from a local-only token file (see
# get_or_create_worker_token) and the worker sends it as a bearer token.

from __future__ import annotations

import asyncio
import json
import os
import secrets
import subprocess
import sys
import time
from typing import Any, Dict, Optional

import psutil
from fastapi import APIRouter, Header, HTTPException

from core.env.env_loader import Env
from logs_system.system.service import system_logger

router = APIRouter(prefix="/synergy", tags=["synergy_worker"])

_TOKEN_FILE = Env.DATA_DIR / "synergy_worker.token"

_VALID_LABELS = ("Synergy-A", "Synergy-B")

# In-memory registry of currently-running worker processes, keyed by label.
# Intentionally not persisted -- lost on backend restart, workers re-register
# on their own next startup.
_REGISTERED_WORKERS: Dict[str, Dict[str, Any]] = {}

# ---------------------------------------------------------------------------
# Process lifecycle (Start/Stop/Restart Synergy, Settings page) -- lets a
# user who isn't using Synergy skip running two extra always-on processes,
# and recovers from the common "backend restarted, workers are orphaned and
# unregistered" situation without a manual terminal/script. PIDs are
# persisted to disk (unlike _REGISTERED_WORKERS above) specifically so Stop
# still works after a backend restart -- the whole point is these processes
# outlive the backend that spawned them.
# ---------------------------------------------------------------------------
_PID_FILE = Env.DATA_DIR / "synergy_worker_pids.json"
_LOG_DIR = Env.DATA_DIR / "logs"
_WORKER_PORTS: Dict[str, int] = {"Synergy-A": 8101, "Synergy-B": 8102}
_DEFAULT_BACKEND_URL = "http://127.0.0.1:8000"


def _load_tracked_pids() -> Dict[str, int]:
    if _PID_FILE.exists():
        try:
            return {k: int(v) for k, v in json.loads(_PID_FILE.read_text(encoding="utf-8")).items()}
        except Exception:
            return {}
    return {}


def _save_tracked_pids(pids: Dict[str, int]) -> None:
    Env.DATA_DIR.mkdir(parents=True, exist_ok=True)
    _PID_FILE.write_text(json.dumps(pids), encoding="utf-8")


def _is_alive(pid: Optional[int]) -> bool:
    if not pid:
        return False
    try:
        return psutil.pid_exists(pid) and psutil.Process(pid).is_running()
    except (psutil.NoSuchProcess, psutil.AccessDenied, ValueError):
        return False


def _python_executable() -> str:
    venv_python = Env.BACKEND_DIR / "venv" / "Scripts" / "python.exe"
    return str(venv_python) if venv_python.exists() else sys.executable


def _spawn_worker(label: str, port: int, backend_url: str) -> int:
    """Launches one Synergy worker as a detached child process, mirroring
    scripts/start_synergy_workers.ps1 exactly (same module, same env vars)
    so it registers with this backend and behaves identically either way."""
    _LOG_DIR.mkdir(parents=True, exist_ok=True)
    log_file = open(_LOG_DIR / f"{label.lower()}.log", "a", encoding="utf-8")
    env = {
        **os.environ,
        "SYNERGY_LABEL": label,
        "SYNERGY_PORT": str(port),
        "SYNERGY_HOST": "127.0.0.1",
        "ATHENA_BACKEND_URL": backend_url,
    }
    creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    try:
        proc = subprocess.Popen(
            [_python_executable(), "-m", "uvicorn", "synergy_worker.app:app", "--host", "127.0.0.1", "--port", str(port)],
            cwd=str(Env.BACKEND_DIR),
            env=env,
            stdout=log_file,
            stderr=subprocess.STDOUT,
            creationflags=creationflags,
        )
    finally:
        log_file.close()  # child already holds its own duplicated handle
    return proc.pid


def _stop_worker(label: str, pid: int) -> None:
    try:
        proc = psutil.Process(pid)
    except psutil.NoSuchProcess:
        return
    children = []
    try:
        children = proc.children(recursive=True)
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        pass
    for p in [proc, *children]:
        try:
            p.terminate()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    _, alive = psutil.wait_procs([proc, *children], timeout=5)
    for p in alive:
        try:
            p.kill()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

# Per-label active session config, set via /synergy/<label>/session at
# Synergy-session start and read back by the worker itself (point 7: "the
# worker does not persist it beyond the session" -- so the main backend is
# the source of truth here, not a file the worker writes).
_ACTIVE_SESSIONS: Dict[str, Dict[str, Any]] = {}


def get_or_create_worker_token() -> str:
    """Shared localhost-only secret both the main backend and every Synergy
    worker process read from the same file on disk."""
    Env.DATA_DIR.mkdir(parents=True, exist_ok=True)
    if _TOKEN_FILE.exists():
        token = _TOKEN_FILE.read_text(encoding="utf-8").strip()
        if token:
            return token
    token = secrets.token_hex(32)
    _TOKEN_FILE.write_text(token, encoding="utf-8")
    return token


def get_worker(label: str) -> Optional[Dict[str, Any]]:
    """In-process accessor for chat/synergy/service.py (Phase 1b) -- looks
    up a currently-registered worker's {label,host,port,registered_at}, or
    None if that worker hasn't (yet) registered with this backend."""
    return _REGISTERED_WORKERS.get(label)


def workers_available() -> bool:
    """True only when BOTH Synergy-A and Synergy-B are currently registered
    -- Phase 1b's distributed execution path is only ever used when both
    are up; otherwise Synergy falls back to in-process execution."""
    return bool(_REGISTERED_WORKERS.get("Synergy-A")) and bool(_REGISTERED_WORKERS.get("Synergy-B"))


def _require_worker_token(authorization: Optional[str]) -> None:
    expected = get_or_create_worker_token()
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Missing worker token.")
    supplied = authorization.split(" ", 1)[1].strip()
    if not secrets.compare_digest(supplied, expected):
        raise HTTPException(status_code=401, detail="Invalid worker token.")


@router.post("/register")
async def register_worker(payload: Dict[str, Any], authorization: Optional[str] = Header(None)) -> Dict[str, Any]:
    """Called by a Synergy Worker process at its own startup.
    Body: {"label": "Synergy-A", "host": "127.0.0.1", "port": 8101}"""
    _require_worker_token(authorization)

    label = str(payload.get("label") or "").strip()
    host = str(payload.get("host") or "").strip()
    port = payload.get("port")
    if label not in _VALID_LABELS or not host or not isinstance(port, int):
        raise HTTPException(
            status_code=400,
            detail=f"label must be one of {_VALID_LABELS}; host/port required.",
        )

    _REGISTERED_WORKERS[label] = {
        "label": label,
        "host": host,
        "port": port,
        "registered_at": time.time(),
    }
    system_logger.log(event=f"Synergy worker registered: {label} at {host}:{port}")
    return {"ok": True, "label": label}


@router.get("/workers")
async def list_workers() -> Dict[str, Any]:
    """Status of currently-registered Synergy worker processes."""
    return {"workers": list(_REGISTERED_WORKERS.values())}


@router.get("/status")
async def worker_process_status() -> Dict[str, Any]:
    """Settings page status card: per-label {running, registered, pid} --
    `running` is a real OS-level process check (survives a backend restart
    that just wiped `_REGISTERED_WORKERS`), `registered` reflects whether
    this backend has actually heard from it since ITS OWN last restart.
    Deliberately separate flags: a worker can be running-but-unregistered
    (common right after a backend restart, until the worker's own
    background re-register loop or a manual restart catches it up)."""
    pids = _load_tracked_pids()
    statuses = {}
    for label in _VALID_LABELS:
        pid = pids.get(label)
        statuses[label] = {
            "label": label,
            "running": _is_alive(pid),
            "registered": bool(_REGISTERED_WORKERS.get(label)),
            "pid": pid if _is_alive(pid) else None,
            "port": _WORKER_PORTS[label],
        }
    return {"workers": statuses}


@router.post("/start")
async def start_workers() -> Dict[str, Any]:
    """Launches whichever of Synergy-A/Synergy-B aren't already running
    (tracked by PID, not by registration -- see worker_process_status)."""
    pids = _load_tracked_pids()
    started, already_running = [], []
    for label, port in _WORKER_PORTS.items():
        if _is_alive(pids.get(label)):
            already_running.append(label)
            continue
        pids[label] = _spawn_worker(label, port, _DEFAULT_BACKEND_URL)
        started.append(label)
    _save_tracked_pids(pids)
    system_logger.log(event="Synergy workers start requested", details={"started": started, "already_running": already_running})
    return {"started": started, "already_running": already_running}


@router.post("/stop")
async def stop_workers() -> Dict[str, Any]:
    """Stops both tracked worker processes (if running) and clears their
    registration, so Synergy cleanly falls back to in-process execution
    instead of looking for workers that are gone."""
    pids = _load_tracked_pids()
    stopped = []
    for label in _VALID_LABELS:
        pid = pids.get(label)
        if _is_alive(pid):
            _stop_worker(label, pid)
            stopped.append(label)
        pids.pop(label, None)
        _REGISTERED_WORKERS.pop(label, None)
    _save_tracked_pids(pids)
    system_logger.log(event="Synergy workers stopped", details={"stopped": stopped})
    return {"stopped": stopped}


@router.post("/restart")
async def restart_workers() -> Dict[str, Any]:
    """Stop then start both workers -- the practical fix for "worker is
    running but unregistered" (e.g. after a main-backend restart whose
    in-memory registry doesn't survive it)."""
    await stop_workers()
    await asyncio.sleep(1)
    return await start_workers()


@router.post("/{label}/session")
async def configure_session(label: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    """Called by the main backend's own Synergy-session-start flow (not by
    the worker) to record which user/provider/model a worker should use for
    the session about to start. The worker fetches this via GET below --
    this process is the source of truth, the worker never persists it."""
    if label not in _VALID_LABELS:
        raise HTTPException(status_code=400, detail=f"label must be one of {_VALID_LABELS}")

    username = str(payload.get("username") or "").strip()
    provider_id = str(payload.get("provider_id") or "").strip()
    model_id = str(payload.get("model_id") or "").strip()
    if not username or not provider_id or not model_id:
        raise HTTPException(status_code=400, detail="username, provider_id, model_id are required.")

    _ACTIVE_SESSIONS[label] = {
        "username": username,
        "provider_id": provider_id,
        "model_id": model_id,
        "set_at": time.time(),
    }
    return {"ok": True}


@router.get("/{label}/session")
async def get_session(label: str, authorization: Optional[str] = Header(None)) -> Dict[str, Any]:
    """Polled by the worker itself to learn its current session config."""
    _require_worker_token(authorization)
    if label not in _VALID_LABELS:
        raise HTTPException(status_code=400, detail=f"label must be one of {_VALID_LABELS}")
    session = _ACTIVE_SESSIONS.get(label)
    if not session:
        raise HTTPException(status_code=404, detail="No active session configured for this worker yet.")
    return session


# ---------------------------------------------------------------------------
# Inter-agent messaging (Synergy_Reborn.md Section 8, points 34-37).
# Deliberately minimal: each label's inbox is just an in-memory list, drained
# whenever that worker's next round starts (synergy_worker/app.py's
# _run_one_round) -- no delivery guarantees/acks/persistence beyond this
# backend process's lifetime, matching the "as little structure as possible"
# build directive for this layer.
# ---------------------------------------------------------------------------
_INBOXES: Dict[str, list] = {"Synergy-A": [], "Synergy-B": []}


@router.post("/message")
async def send_message(payload: Dict[str, Any], authorization: Optional[str] = Header(None)) -> Dict[str, Any]:
    """Body: {"from": "Synergy-A", "to": "Synergy-B", "text": "..."}"""
    _require_worker_token(authorization)
    sender = str(payload.get("from") or "").strip()
    recipient = str(payload.get("to") or "").strip()
    text = str(payload.get("text") or "").strip()
    if sender not in _VALID_LABELS or recipient not in _VALID_LABELS or not text:
        raise HTTPException(status_code=400, detail="from/to must be valid labels; text is required.")
    _INBOXES[recipient].append({"from": sender, "text": text, "ts": time.time()})
    return {"status": "sent"}


@router.get("/{label}/inbox")
async def drain_inbox(label: str, authorization: Optional[str] = Header(None)) -> Dict[str, Any]:
    """Returns and CLEARS all currently queued messages for `label` --
    "check and drain" semantics (point 37: workers check their inbox between
    tool calls / before starting a new task step)."""
    _require_worker_token(authorization)
    if label not in _VALID_LABELS:
        raise HTTPException(status_code=400, detail=f"label must be one of {_VALID_LABELS}")
    messages = _INBOXES.get(label, [])
    _INBOXES[label] = []
    return {"label": label, "messages": messages}


@router.post("/proxy/chat")
async def proxy_chat(payload: Dict[str, Any], authorization: Optional[str] = Header(None)) -> Dict[str, Any]:
    """The ONLY path a Synergy Worker has to actually call an LLM provider --
    the worker never holds or sees the real provider API key (Section 3).
    Body: {"username", "provider_id", "model_id", "messages", "tools",
    "tool_choice", "temperature", "max_tokens"}. Returns the raw
    router.chat() response dict, unmodified."""
    _require_worker_token(authorization)

    username = str(payload.get("username") or "").strip()
    provider_id = str(payload.get("provider_id") or "").strip()
    model_id = str(payload.get("model_id") or "").strip()
    messages = payload.get("messages")
    if not username or not provider_id or not model_id or not isinstance(messages, list):
        raise HTTPException(status_code=400, detail="username, provider_id, model_id, messages are required.")

    from chat.engine.service import ChatEngine, ChatEngineError

    engine = ChatEngine(username=username)
    try:
        api_key = engine._get_api_key(provider_id)
    except ChatEngineError as e:
        raise HTTPException(status_code=400, detail=str(e))

    engine._inject_provider_api_key(provider_id, api_key)
    router_impl = engine.router_selector.select(provider_id=provider_id, model_id=model_id, mode="chat")

    try:
        response = await asyncio.to_thread(
            router_impl.chat,
            messages,
            tools=payload.get("tools"),
            tool_choice=payload.get("tool_choice") or "auto",
            temperature=payload.get("temperature") if payload.get("temperature") is not None else 0.2,
            max_tokens=payload.get("max_tokens") if payload.get("max_tokens") is not None else 8192,
        )
    except Exception as e:
        system_logger.log(event=f"Synergy proxy chat error ({provider_id}/{model_id}): {e}", level="error")
        raise HTTPException(status_code=502, detail=f"Provider call failed: {e}")

    if not isinstance(response, dict):
        response = {"content": str(response)}
    return response
