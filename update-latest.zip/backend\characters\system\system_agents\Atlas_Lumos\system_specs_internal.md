# AthenaUI -- System Specifications: PROPRIETARY INTERNALS (Dev-Only)

Supplement to `system_specs.md`, split out deliberately so it can be
EXCLUDED from every customer-facing installer build (see the `filter` list
on the `backend` `extraResources` entry in `electron/package.json`). This
file only exists on a dev machine; `atlas_system_specs_lookup` reads it if
present and simply does without it if not -- no customer install should
ever contain this file.

Do not read this content verbatim to customers or outside parties, even in
dev -- it's for Atlas's own fact-checking before making a security/privacy
claim, same rule as `system_specs.md`.

---

## PROPRIETARY INTERNALS: Vault & Secrets

- Character/profile data: stored in the vault as SQLite + AES-256-GCM
  (authenticated encryption -- tampering is detectable, not just
  unreadable).
- Backups/export bundles: encrypted client-side with a passphrase-derived
  AES-256-GCM envelope before being written to disk (`backup/crypto.py`),
  independent of whatever encryption the live vault/MMS already use.
- System-wide secrets (e.g. the default LLM provider key, admin password
  hash+salt, machine fingerprint) live in a separate machine-scoped
  SystemVault, not the per-user vault.
- Per-user LLM provider keys and other per-user secrets are scoped strictly
  to that user's own vault -- there is no cross-user key store.
- No telemetry/analytics service receives conversation content. Outbound
  network calls are limited to the provider/integration the active feature
  needs (the configured LLM provider, the user's own email/X credentials,
  etc.).

---

## PROPRIETARY INTERNALS: Maximos Memory Server (MMS)

- Every request is scoped to a pipeline identified by `(user_id, agent_id)`,
  addressed as `/users/{user_id}/agents/{agent_id}/...` -- this is the
  isolation boundary mentioned in `system_specs.md`; there is no endpoint
  that can read across pipelines.
- Auth has two modes: a **global key** (one key for every pipeline) or
  **per-agent keys** (the deployed default) -- in per-agent mode, a client
  authenticates once with the global key via a `/handshake` call, and the
  server hands back a key scoped to only that one `(user_id, agent_id)`
  pipeline for all subsequent calls (`X-Agent-Key` header). AthenaUI runs in
  per-agent mode for exactly the isolation reason described above.
- Memories move through three storage tiers:
  - **Hot** -- held in plain in-memory storage (RAM) for the fastest
    possible access to recently/frequently touched memories.
  - **Warm** -- encrypted on disk (AES-256-GCM, random nonce per write,
    authenticated so tampering/corruption is detected on read).
  - **Cold** -- the same AES-256-GCM encryption as Warm, plus zlib
    compression first, for older/rarely-touched memories that need to be
    kept but not kept fast.
- Encryption keys for Warm/Cold are derived (via SHA-256) from key material
  tied to the pipeline, not a single shared system-wide key.
- Memories carry metadata including a `channel` (private_message,
  group_chat_message, phone_call, email, other), sender/receiver, and a
  `searchable`/`encrypted` flag, letting the pipeline reason about context
  (e.g. "this came from an email" vs "this came from a private DM") when
  deciding what to surface.
